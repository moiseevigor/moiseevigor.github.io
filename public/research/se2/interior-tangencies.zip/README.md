# Interior tangencies in the rotating SE(2) cells

TangencyCount extends the Riccati equality test through the center and proves its strict monotonicity on either side. The concrete cell_tangencies theorem counts the unit-slope parameters of each open bracket for every modulus. The counted_contact theorem gives the phase branch and a nonzero cubic coefficient for every period representative.

Use the toolchain and dependency revisions supplied in this archive. From its root run

    lake exe cache get
    lake build
    lake env lean Audit.lean

Compare the final output with axioms.txt. SHA256SUMS identifies every input. The 97 declarations include the witnesses for the whole-paper claim ledger.
