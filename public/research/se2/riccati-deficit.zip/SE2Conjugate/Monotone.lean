import SE2Conjugate.Identities

/-!
# Lemma 3.1(iv), part 1: monotonicity consequences of the identities

With the initial values `sn 0 = 0`, `cn 0 = 1`, `ℰ 0 = 0` and `dn > 0`:
* `Γ` is strictly increasing, `Γ 0 = 0`, so `Γ > 0` on `(0, ∞)`;
* `ℰ` is strictly increasing with `ℰ 0 = 0`, so `ℰ > 0` on `(0, ∞)`;
* `q = p - ℰ(p) > 0` on `(0, ∞)` (Moiseev–Sachkov, Lemma 5.1), proved from `q' = k² sn² ≥ 0`
  and the fact that `sn` cannot vanish on an interval;
* `β₁` is strictly decreasing where `sn > 0` and strictly increasing where `sn < 0` (for `p > 0`);
* `f₁/cn` is strictly decreasing on every interval where `cn ≠ 0`;
* `α₁/dn` is strictly decreasing where `f₁ > 0` and strictly increasing where `f₁ < 0` (for `p > 0`).
-/

noncomputable section

/-- Jacobi data with the initial values at `0` and `dn > 0`. -/
structure JacobiInit extends JacobiData where
  d_pos : ∀ p, 0 < d p
  s0 : s 0 = 0
  c0 : c 0 = 1
  eps0 : eps 0 = 0

namespace JacobiInit

variable (J : JacobiInit)

theorem d_ne (p : ℝ) : J.d p ≠ 0 := (J.d_pos p).ne'

theorem d0 : J.d 0 = 1 := by
  have h := J.sd 0
  rw [J.s0] at h
  have hd := J.d_pos 0
  nlinarith

/-! ### `Γ` -/

theorem Γ_zero : J.toJacobiData.Γ 0 = 0 := by
  unfold JacobiData.Γ
  rw [J.s0, J.c0, J.eps0, J.d0]
  ring

theorem Γ_strictMono : StrictMono J.toJacobiData.Γ := by
  apply strictMono_of_deriv_pos
  intro x
  rw [(J.toJacobiData.hasDerivAt_Γ x (J.d_ne x)).deriv]
  have hk : 0 < 1 - J.k ^ 2 := by nlinarith [J.k_pos, J.k_lt_one]
  exact div_pos hk (pow_pos (J.d_pos x) 2)

theorem Γ_pos {p : ℝ} (hp : 0 < p) : 0 < J.toJacobiData.Γ p := by
  have := J.Γ_strictMono hp
  rwa [J.Γ_zero] at this

/-! ### `ℰ` and `q` -/

theorem eps_strictMono : StrictMono J.eps := by
  apply strictMono_of_deriv_pos
  intro x
  rw [(J.heps x).deriv]
  exact pow_pos (J.d_pos x) 2

theorem eps_pos {p : ℝ} (hp : 0 < p) : 0 < J.eps p := by
  have := J.eps_strictMono hp
  rwa [J.eps0] at this

theorem q_zero : J.toJacobiData.q 0 = 0 := by
  unfold JacobiData.q
  rw [J.eps0]
  ring

theorem q_monotone : Monotone J.toJacobiData.q := by
  apply monotone_of_deriv_nonneg
  · exact fun x => (J.toJacobiData.hasDerivAt_q x).differentiableAt
  · intro x
    rw [(J.toJacobiData.hasDerivAt_q x).deriv]
    positivity

/-- `sn` does not vanish identically on an interval: `sn = 0` on `[a, b]` with `a < b` would force
`cn = 0` there (`sn' = cn dn`), contradicting `cn² + sn² = 1`. -/
theorem s_not_zero_on_interval {a b : ℝ} (hab : a < b) : ¬ ∀ t ∈ Set.Icc a b, J.s t = 0 := by
  intro h
  set t := (a + b) / 2 with ht
  have htI : t ∈ Set.Ioo a b := ⟨by rw [ht]; linarith, by rw [ht]; linarith⟩
  have hev : J.s =ᶠ[nhds t] fun _ => (0 : ℝ) :=
    Filter.eventuallyEq_of_mem (Ioo_mem_nhds htI.1 htI.2)
      (fun x hx => h x (Set.Ioo_subset_Icc_self hx))
  have h1 := (J.hs t).congr_of_eventuallyEq hev.symm
  have h2 := (hasDerivAt_const t (0 : ℝ)).unique h1
  -- h2 : 0 = cn t * dn t, so cn t = 0
  have hc : J.c t = 0 := by
    rcases mul_eq_zero.mp h2.symm with hc | hd
    · exact hc
    · exact absurd hd (J.d_ne t)
  have hs : J.s t = 0 := h t (Set.Ioo_subset_Icc_self htI)
  have := J.sc t
  rw [hc, hs] at this
  norm_num at this

theorem q_pos {p : ℝ} (hp : 0 < p) : 0 < J.toJacobiData.q p := by
  rcases lt_or_eq_of_le (J.q_monotone hp.le) with h | h
  · rwa [J.q_zero] at h
  · exfalso
    -- q is constant on [0, p], so q' = k² sn² = 0 there, so sn = 0 on (0, p)
    have hconst : ∀ t ∈ Set.Icc 0 p, J.toJacobiData.q t = 0 := by
      intro t ht
      have h1 := J.q_monotone ht.1
      have h2 := J.q_monotone ht.2
      rw [J.q_zero] at h1
      rw [← h, J.q_zero] at h2
      linarith
    apply J.s_not_zero_on_interval (show p / 4 < 3 * p / 4 by linarith)
    intro t ht
    have h0 : 0 < t := by linarith [ht.1]
    have h1 : t < p := by linarith [ht.2]
    have hev2 : J.toJacobiData.q =ᶠ[nhds t] fun _ => (0 : ℝ) :=
      Filter.eventuallyEq_of_mem (Ioo_mem_nhds h0 h1)
        (fun y hy => hconst y (Set.Ioo_subset_Icc_self hy))
    have hd1 := (J.toJacobiData.hasDerivAt_q t).congr_of_eventuallyEq hev2.symm
    have hd2 := (hasDerivAt_const t (0 : ℝ)).unique hd1
    have hk2 : J.k ^ 2 * J.s t ^ 2 = 0 := hd2.symm
    rcases mul_eq_zero.mp hk2 with hk | hs2
    · exact absurd hk (pow_ne_zero 2 J.k_pos.ne')
    · exact (pow_eq_zero_iff two_ne_zero).mp hs2

/-! ### Strict monotonicity of `β₁`, `f₁/cn`, `α₁/dn` on intervals of constant sign -/

theorem β1_strictAntiOn {D : Set ℝ} (hD : Convex ℝ D) (hpos : ∀ p ∈ interior D, 0 < p)
    (hs : ∀ p ∈ interior D, 0 < J.s p) : StrictAntiOn J.toJacobiData.β1 D := by
  apply strictAntiOn_of_deriv_neg hD
  · exact fun p _ => (J.toJacobiData.hasDerivAt_β1 p).continuousAt.continuousWithinAt
  · intro x hx
    rw [(J.toJacobiData.hasDerivAt_β1 x).deriv, J.toJacobiData.β1_deriv_eq_Γ x (J.d_ne x)]
    have hΓ := J.Γ_pos (hpos x hx)
    have hsx := hs x hx
    have hdx := J.d_pos x
    linarith [mul_pos (mul_pos hsx hdx) hΓ]

theorem β1_strictMonoOn {D : Set ℝ} (hD : Convex ℝ D) (hpos : ∀ p ∈ interior D, 0 < p)
    (hs : ∀ p ∈ interior D, J.s p < 0) : StrictMonoOn J.toJacobiData.β1 D := by
  apply strictMonoOn_of_deriv_pos hD
  · exact fun p _ => (J.toJacobiData.hasDerivAt_β1 p).continuousAt.continuousWithinAt
  · intro x hx
    rw [(J.toJacobiData.hasDerivAt_β1 x).deriv, J.toJacobiData.β1_deriv_eq_Γ x (J.d_ne x)]
    have hΓ := J.Γ_pos (hpos x hx)
    have hsx := hs x hx
    have hdx := J.d_pos x
    nlinarith [mul_pos (mul_pos (neg_pos.mpr hsx) hdx) hΓ]

theorem f1_div_c_strictAntiOn {D : Set ℝ} (hD : Convex ℝ D) (hc : ∀ p ∈ D, J.c p ≠ 0) :
    StrictAntiOn (fun p => J.toJacobiData.f1 p / J.c p) D := by
  apply strictAntiOn_of_deriv_neg hD
  · exact fun p hp => (J.toJacobiData.hasDerivAt_f1_div_c p (hc p hp)).continuousAt.continuousWithinAt
  · intro x hx
    have hxD : x ∈ D := interior_subset hx
    rw [(J.toJacobiData.hasDerivAt_f1_div_c x (hc x hxD)).deriv]
    have hdx := J.d_pos x
    have hcx := hc x hxD
    have hc2 : 0 < J.c x ^ 2 := by positivity
    have hd2 : 0 < J.d x ^ 2 := by positivity
    exact div_neg_of_neg_of_pos (by linarith) hc2

theorem α1_div_d_strictAntiOn {D : Set ℝ} (hD : Convex ℝ D) (hpos : ∀ p ∈ interior D, 0 < p)
    (hf : ∀ p ∈ interior D, 0 < J.toJacobiData.f1 p) :
    StrictAntiOn (fun p => J.toJacobiData.α1 p / J.d p) D := by
  apply strictAntiOn_of_deriv_neg hD
  · exact fun p _ => (J.toJacobiData.hasDerivAt_α1_div_d p (J.d_ne p)).continuousAt.continuousWithinAt
  · intro x hx
    rw [(J.toJacobiData.hasDerivAt_α1_div_d x (J.d_ne x)).deriv]
    have := J.eps_pos (hpos x hx)
    have := hf x hx
    have := J.d_pos x
    exact div_neg_of_neg_of_pos (by nlinarith) (by positivity)

theorem α1_div_d_strictMonoOn {D : Set ℝ} (hD : Convex ℝ D) (hpos : ∀ p ∈ interior D, 0 < p)
    (hf : ∀ p ∈ interior D, J.toJacobiData.f1 p < 0) :
    StrictMonoOn (fun p => J.toJacobiData.α1 p / J.d p) D := by
  apply strictMonoOn_of_deriv_pos hD
  · exact fun p _ => (J.toJacobiData.hasDerivAt_α1_div_d p (J.d_ne p)).continuousAt.continuousWithinAt
  · intro x hx
    rw [(J.toJacobiData.hasDerivAt_α1_div_d x (J.d_ne x)).deriv]
    have := J.eps_pos (hpos x hx)
    have := hf x hx
    have := J.d_pos x
    exact div_pos (by nlinarith) (by positivity)

end JacobiInit

end
