import SE2Conjugate.HamiltonianFlow

/-! Positive radial-time normalization and Hamiltonian scaling.
The endpoint is still represented in a real heading lift. -/
noncomputable section
namespace JacobiConcrete.AmplitudeChart
set_option maxHeartbeats 1200000

/-- Time is absorbed into the full initial covector, in the published h1,h2,h3 convention. -/
def radialTime (q : V3) : V3 :=
  ![q 0 * Real.sin (q 1/2), -q 0 * Real.cos (q 1/2), q 0*q 2/2]

def dRadialTime (q : V3) : V3 →L[ℝ] V3 := ContinuousLinearMap.pi
  ![Real.sin (q 1/2) • coord 0 + (q 0*Real.cos (q 1/2)/2) • coord 1,
    (-Real.cos (q 1/2)) • coord 0 + (q 0*Real.sin (q 1/2)/2) • coord 1,
    (q 2/2) • coord 0 + (q 0/2) • coord 2]

theorem radialTime_strict (q : V3) : HasStrictFDerivAt radialTime (dRadialTime q) q := by
  apply hasStrictFDerivAt_pi.mpr
  intro i
  fin_cases i
  · have h := (hasStrictFDerivAt_apply (𝕜 := ℝ) 0 q).mul
      (((hasStrictFDerivAt_apply (𝕜 := ℝ) 1 q).mul_const ((2:ℝ)⁻¹)).sin)
    simp only [div_eq_mul_inv] at ⊢
    refine h.congr_fderiv ?_
    ext v
    simp [coord]
    ring
  · have h := (hasStrictFDerivAt_apply (𝕜 := ℝ) 0 q).neg.mul
      (((hasStrictFDerivAt_apply (𝕜 := ℝ) 1 q).mul_const ((2:ℝ)⁻¹)).cos)
    simp only [div_eq_mul_inv] at ⊢
    refine h.congr_fderiv ?_
    ext v
    simp [coord]
    ring
  · have h := ((hasStrictFDerivAt_apply (𝕜 := ℝ) 0 q).mul
      (hasStrictFDerivAt_apply (𝕜 := ℝ) 2 q)).mul_const ((2:ℝ)⁻¹)
    simp only [div_eq_mul_inv] at ⊢
    refine h.congr_fderiv ?_
    ext v
    simp [coord]
    ring

theorem radialTime_det (q : V3) : (jacobian radialTime q).det = (q 0)^2/4 := by
  unfold jacobian
  rw [(radialTime_strict q).hasFDerivAt.fderiv]
  erw [Matrix.det_fin_three]
  simp [dRadialTime, coord]
  nlinarith [Real.sin_sq_add_cos_sq (q 1/2)]

theorem radialTime_kernel (q v : V3) (ht : q 0 ≠ 0) :
    fderiv ℝ radialTime q v = 0 ↔ v = 0 := by
  constructor
  · intro hz
    by_contra hv
    have h := (nontrivial_kernel_iff radialTime q).mp ⟨v,hv,hz⟩
    rw [radialTime_det] at h
    exact (div_ne_zero (pow_ne_zero 2 ht) (by norm_num)) h
  · rintro rfl
    exact map_zero _

def radialLinearEquiv (q : V3) (ht : q 0 ≠ 0) : V3 ≃L[ℝ] V3 :=
  (LinearMap.equivOfIsUnitDet (f := (fderiv ℝ radialTime q).toLinearMap) (by
    apply isUnit_iff_ne_zero.mpr
    rw [← LinearMap.det_toMatrix']
    change (jacobian radialTime q).det ≠ 0
    rw [radialTime_det]
    exact div_ne_zero (pow_ne_zero 2 ht) (by norm_num))).toContinuousLinearEquiv

theorem radialLinearEquiv_coe (q : V3) (ht : q 0 ≠ 0) :
    (radialLinearEquiv q ht : V3 →L[ℝ] V3) = fderiv ℝ radialTime q := by
  ext v
  simp [radialLinearEquiv, LinearMap.equivOfIsUnitDet_apply]

theorem radialEquiv_strict (q : V3) (ht : q 0 ≠ 0) :
    HasStrictFDerivAt radialTime (radialLinearEquiv q ht : V3 →L[ℝ] V3) q := by
  rw [radialLinearEquiv_coe, (radialTime_strict q).hasFDerivAt.fderiv]
  exact radialTime_strict q

def radialLocalChart (q : V3) (ht : q 0 ≠ 0) : OpenPartialHomeomorph V3 V3 :=
  (radialEquiv_strict q ht).toOpenPartialHomeomorph radialTime

theorem radialLocalChart_mem (q : V3) (ht : q 0 ≠ 0) :
    q ∈ (radialLocalChart q ht).source :=
  (radialEquiv_strict q ht).mem_toOpenPartialHomeomorph_source

theorem radialTime_energy (q : V3) :
    ((radialTime q 0)^2+(radialTime q 1)^2)/2 = (q 0)^2/2 := by
  simp [radialTime]
  nlinarith [Real.sin_sq_add_cos_sq (q 1/2)]

/-- Elliptic source coordinates to full covector at time one. -/
def fullCovector (sigma : ℝ) (y : V3) : V3 := radialTime (covectorCoords sigma y)

theorem fullCovector_deriv (sigma : ℝ) (y : V3) (h0 : 0 < y 2) (h1 : y 2 < 1) :
    HasFDerivAt (fullCovector sigma)
      ((fderiv ℝ radialTime (covectorCoords sigma y)).comp (fderiv ℝ (covectorCoords sigma) y)) y :=
  (radialTime_strict _).hasFDerivAt.differentiableAt.hasFDerivAt.comp y
    (covectorCoords_strict sigma y h0 h1).hasFDerivAt.differentiableAt.hasFDerivAt

theorem fullCovector_det (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    (jacobian (fullCovector sigma) y).det = -(y 0)^2/(y 2)^3 := by
  rw [jacobian_eq_linearMatrix, (fullCovector_deriv sigma y h0 h1).fderiv,
    linearMatrix_comp, Matrix.det_mul, ← jacobian_eq_linearMatrix,
    ← jacobian_eq_linearMatrix, radialTime_det, covectorCoords_det sigma hs y h0 h1,
    covectorCoords_eq sigma y h0 h1]
  simp
  ring

theorem fullCovector_kernel (sigma : ℝ) (hs : sigma^2=1) (y v : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (ht : y 0 ≠ 0) :
    fderiv ℝ (fullCovector sigma) y v = 0 ↔ v=0 := by
  rw [(fullCovector_deriv sigma y h0 h1).fderiv]
  change fderiv ℝ radialTime _ (fderiv ℝ (covectorCoords sigma) y v)=0 ↔ v=0
  rw [radialTime_kernel _ _ (by rw [covectorCoords_eq sigma y h0 h1]; exact ht),
    covectorCoords_kernel sigma hs y h0 h1]

/-- Rank loss expressed using the full-covector source, without any scalar definition. -/
theorem fullCovector_variation_iff (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (ht : y 0 ≠ 0) :
    (∃ v : V3, fderiv ℝ (fullCovector sigma) y v ≠ 0 ∧
      fderiv ℝ (physicalEndpoint sigma) y v = 0) ↔ StationaryVariation sigma y := by
  simp only [StationaryVariation, ne_eq, fullCovector_kernel sigma hs y _ h0 h1 ht,
    physicalSource_kernel sigma hs y h0 h1]

/-- The scaled trajectory starts at the identity with the full initial covector. -/
theorem fullCovector_initial (sigma : ℝ) (hs : sigma = 1 ∨ sigma = -1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    scaleState (y 0) (rotatingState (y 2) h0 h1 sigma (y 1/y 2) 0) =
      ![0,0,0,fullCovector sigma y 0,fullCovector sigma y 1,fullCovector sigma y 2] := by
  have hi := (full (y 2) h0 h1).endpoint_at_zero sigma (y 1/y 2)
  have hsou := physicalSource_eq sigma hs y h0 h1
  have hh (i : Fin 4) := congrFun hsou i
  dsimp [physicalSource, normalizedEmbedding] at hh
  rw [covectorCoords_eq sigma y h0 h1] at hh
  ext i
  fin_cases i
  · exact hi.1
  · exact hi.2.1
  · exact hi.2.2
  all_goals simp [scaleState, rotatingState, fullCovector, radialTime,
    covectorCoords_eq sigma y h0 h1]
  · left
    have h := hh 1
    dsimp at h
    exact h.symm
  · left
    have h := hh 2
    dsimp at h
    linarith
  · ring

/-- Any Hamiltonian solution on [0,1] with fullCovector initial data has this endpoint.
The six ODE components and uniqueness are checked; the geometric derivation of the ODE is classical. -/
theorem unitTime_endpoint (sigma : ℝ) (hs : sigma = 1 ∨ sigma = -1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (f : ℝ → State)
    (hfc : ContinuousOn f (Set.Icc 0 1))
    (hf : ∀ s ∈ Set.Ico 0 1, HasDerivAt f (hamiltonianField (f s)) s)
    (hinit : f 0 = ![0,0,0,fullCovector sigma y 0,fullCovector sigma y 1,fullCovector sigma y 2]) :
    ![f 1 0,f 1 1,f 1 2] = rectifiedEndpoint sigma y := by
  have hs2 : sigma^2=1 := by rcases hs with rfl|rfl <;> norm_num
  have h := scaleState_unique_on (y 0) (rotatingState (y 2) h0 h1 sigma (y 1/y 2)) f
    (fun s => rotatingState_solves (y 2) h0 h1 sigma (y 1/y 2) s hs2) hfc hf
    (by rw [fullCovector_initial sigma hs y h0 h1]; exact hinit)
  rw [h, rectified_eq_concrete sigma y h0 h1]
  rfl

/-- The full initial covector is a local source chart away from time zero. -/
def fullCovectorLinearEquiv (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (ht : y 0 ≠ 0) : V3 ≃L[ℝ] V3 :=
  (LinearMap.equivOfIsUnitDet (f := (fderiv ℝ (fullCovector sigma) y).toLinearMap) (by
    apply isUnit_iff_ne_zero.mpr
    rw [← LinearMap.det_toMatrix']
    change (jacobian (fullCovector sigma) y).det ≠ 0
    rw [fullCovector_det sigma hs y h0 h1]
    exact div_ne_zero (neg_ne_zero.mpr (pow_ne_zero 2 ht)) (pow_ne_zero 3 h0.ne'))).toContinuousLinearEquiv

theorem fullCovectorLinearEquiv_coe (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (ht : y 0 ≠ 0) :
    (fullCovectorLinearEquiv sigma hs y h0 h1 ht : V3 →L[ℝ] V3) =
      fderiv ℝ (fullCovector sigma) y := by
  ext v
  simp [fullCovectorLinearEquiv, LinearMap.equivOfIsUnitDet_apply]

theorem fullCovectorEquiv_strict (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (ht : y 0 ≠ 0) :
    HasStrictFDerivAt (fullCovector sigma)
      (fullCovectorLinearEquiv sigma hs y h0 h1 ht : V3 →L[ℝ] V3) y := by
  rw [fullCovectorLinearEquiv_coe]
  have h := (radialTime_strict (covectorCoords sigma y)).comp y
    (covectorCoords_strict sigma y h0 h1)
  change HasStrictFDerivAt (fullCovector sigma) _ y at h
  rwa [h.hasFDerivAt.fderiv]

def fullCovectorLocalChart (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (ht : y 0 ≠ 0) : OpenPartialHomeomorph V3 V3 :=
  (fullCovectorEquiv_strict sigma hs y h0 h1 ht).toOpenPartialHomeomorph (fullCovector sigma)

theorem fullCovectorLocalChart_mem (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (ht : y 0 ≠ 0) :
    y ∈ (fullCovectorLocalChart sigma hs y h0 h1 ht).source :=
  (fullCovectorEquiv_strict sigma hs y h0 h1 ht).mem_toOpenPartialHomeomorph_source

end JacobiConcrete.AmplitudeChart
