import SE2Conjugate.HamiltonianFlow

noncomputable section
open Set Filter MeasureTheory
open scoped Topology

namespace SE2Control

/-- Dual quadratic form of the ordinary linearized endpoint Gramian.
The two spatial costates are constant, and z is the angular costate. -/
def response (θ : ℝ → ℝ) (a b : ℝ) (z : ℝ → ℝ) (t : ℝ) :=
  (a*Real.cos (θ t)+b*Real.sin (θ t))^2 + (z t)^2

theorem zero_energy {T a b : ℝ} {θ z v ω : ℝ → ℝ} (hT : 0<T)
    (hθ : ContinuousOn θ (Icc 0 T)) (hz : ContinuousOn z (Icc 0 T))
    (ht : ∀ t ∈ Ioo 0 T, HasDerivAt θ (ω t) t)
    (hadj : ∀ t ∈ Ioo 0 T, HasDerivAt z (v t*(a*Real.sin (θ t)-b*Real.cos (θ t))) t)
    (hspeed : ∀ t ∈ Ioo 0 T, v t ^ 2 + ω t ^ 2 = 1)
    (he : (∫ t in (0:ℝ)..T, response θ a b z t) = 0) :
    a=0 ∧ b=0 ∧ z T=0 := by
  have hcont : ContinuousOn (response θ a b z) (Icc 0 T) := by
    unfold response
    fun_prop
  have vanish (t : ℝ) (h : t ∈ Icc 0 T) : a*Real.cos (θ t)+b*Real.sin (θ t)=0 ∧ z t=0 := by
    have nonneg (s : ℝ) : 0 ≤ response θ a b z s := by unfold response; positivity
    have hzero : response θ a b z t = 0 := by
      by_contra hn
      have pos := intervalIntegral.integral_lt_integral_of_continuousOn_of_le_of_exists_lt hT
        (f := fun _ : ℝ => (0:ℝ)) continuousOn_const hcont
        (fun s _ => nonneg s) ⟨t,h,lt_of_le_of_ne (nonneg t) (Ne.symm hn)⟩
      simp [he] at pos
    unfold response at hzero
    exact ⟨by nlinarith [sq_nonneg (z t)],by nlinarith [sq_nonneg (a*Real.cos (θ t)+b*Real.sin (θ t))]⟩
  obtain ⟨t,hlo,hhi⟩ := exists_between hT
  have hi : t ∈ Ioo 0 T := ⟨hlo,hhi⟩
  have near : Icc (0:ℝ) T ∈ 𝓝 t := Icc_mem_nhds hlo hhi
  have fzero : (fun s => a*Real.cos (θ s)+b*Real.sin (θ s)) =ᶠ[𝓝 t] fun _ => 0 :=
    by filter_upwards [near] with s h using (vanish s h).1
  have zzero : z =ᶠ[𝓝 t] fun _ => 0 := by filter_upwards [near] with s h using (vanish s h).2
  have d1 := ((((ht t hi).cos.const_mul a).add ((ht t hi).sin.const_mul b)).congr_of_eventuallyEq
    fzero.symm).unique (hasDerivAt_const t 0)
  have d2 := ((hadj t hi).congr_of_eventuallyEq zzero.symm).unique (hasDerivAt_const t 0)
  have d3 : a*Real.sin (θ t)-b*Real.cos (θ t)=0 := by
    by_contra hn
    have hv := (mul_eq_zero.mp d2).resolve_right hn
    have hd : ω t * (a*Real.sin (θ t)-b*Real.cos (θ t))=0 := by linarith
    have hw := (mul_eq_zero.mp hd).resolve_right hn
    simpa [hv,hw] using hspeed t hi
  have d0 := (vanish t (Ioo_subset_Icc_self hi)).1
  have unit := Real.sin_sq_add_cos_sq (θ t)
  refine ⟨?_,?_,(vanish T ⟨hT.le,le_rfl⟩).2⟩
  · linear_combination Real.cos (θ t)*d0 + Real.sin (θ t)*d3 - a*unit
  · linear_combination Real.sin (θ t)*d0 - Real.cos (θ t)*d3 - b*unit

theorem rotating_zero_energy (J : JacobiFull) (σ ψ T a b : ℝ) (hs : σ^2=1) (hT : 0<T)
    (z : ℝ → ℝ) (hz : ContinuousOn z (Icc 0 T))
    (hadj : ∀ t ∈ Ioo 0 T, HasDerivAt z (σ*J.s (J.terminalPhase ψ t)*
      (a*Real.sin (J.endpointTheta ψ t)-b*Real.cos (J.endpointTheta ψ t))) t)
    (he : (∫ t in (0:ℝ)..T, response (J.endpointTheta ψ) a b z t) = 0) :
    a=0 ∧ b=0 ∧ z T=0 :=
  zero_energy hT (fun t _ => (J.hasDerivAt_endpointTheta ψ t).continuousAt.continuousWithinAt)
    hz (fun t _ => J.hasDerivAt_endpointTheta ψ t) hadj
    (fun t _ => J.controls_unit σ (J.terminalPhase ψ t) hs) he

/-- The normal cost multiplier describes every annihilator of the augmented
endpoint. Here A is the ordinary endpoint differential and L its multiplier. -/
theorem augmented_annihilator {U V : Type*} [AddCommGroup U] [Module ℝ U]
    [AddCommGroup V] [Module ℝ V] (A : U →ₗ[ℝ] V) (hA : Function.Surjective A)
    (L η : V →ₗ[ℝ] ℝ) (c : ℝ) :
    (∀ u, η (A u)+c*L (A u)=0) ↔ η = (-c) • L := by
  constructor
  · intro h
    ext v
    obtain ⟨u,rfl⟩ := hA v
    simp only [LinearMap.smul_apply,smul_eq_mul]
    linarith [h u]
  · rintro rfl u
    simp

end SE2Control
