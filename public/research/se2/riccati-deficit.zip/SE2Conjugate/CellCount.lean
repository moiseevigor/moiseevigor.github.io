import SE2Conjugate.RightBracket

/-!
# Theorem 4.1, the count in a cell

On the cell `[p_n^1, p_{n+1}^1)`, `n = m + 1`:
* `(-1)^m f₁ > 0` on the whole open cell, so `(-1)^m α₁/dn` is strictly decreasing there and `α₁`
  has at most one zero in the cell;
* on `(bₙ, p_{n+1}^1)` both `α` and `β` are positive, so `J₂ > 0`: no conjugate time;
* on `(eL, eR)`, between the brackets, `X < 0`, so `α, β < 0` and `J₂ < 0`: no conjugate time;
* hence the roots in the half-open cell are one per closed bracket: exactly two for `eL < eR`.
-/

noncomputable section

namespace JacobiPeriodic

/-- `α₁(2nK) = (-1)^n dn(2nK) · 2n(K - 2E)`. -/
theorem α1_even (J : JacobiPeriodic) (n : ℕ) : J.toJacobiData.α1 (2 * n * J.K)
    = (-1) ^ n * J.d (2 * n * J.K) * (2 * n * J.K - 2 * (2 * n * J.E)) := by
  show J.c (2 * n * J.K) * J.d (2 * n * J.K) * (2 * n * J.K - 2 * J.eps (2 * n * J.K))
    + J.s (2 * n * J.K) * (J.d (2 * n * J.K) ^ 2
      + J.eps (2 * n * J.K) * (2 * n * J.K - J.eps (2 * n * J.K))) = _
  rw [J.s_even, J.c_even, J.eps_even]
  ring

end JacobiPeriodic

namespace JacobiFull

variable (J : JacobiFull) (m : ℕ)

/-- The reduced Jacobian `J₂(τ, p) = α(p) sn²τ + β(p) cn²τ`. -/
def J2 (τ p : ℝ) : ℝ := J.toJacobiData.α p * J.s τ ^ 2 + J.toJacobiData.β p * J.c τ ^ 2

theorem leftBracket_J2 (τ p : ℝ) : (J.leftBracket m).J2 τ p = J.J2 τ p := rfl
theorem rightBracket_J2 (τ p : ℝ) : (J.rightBracket m).J2 τ p = J.J2 τ p := rfl

theorem pL_succ_mem : J.pL (m + 1) ∈ Set.Ioo ((2 * m + 3) * J.K) ((2 * m + 4) * J.K) := by
  have h := J.pL_mem (m + 1)
  have e1 : (2 * ((m + 1 : ℕ) : ℝ) + 1) * J.K = (2 * m + 3) * J.K := by push_cast; ring
  have e2 : (2 * ((m + 1 : ℕ) : ℝ) + 2) * J.K = (2 * m + 4) * J.K := by push_cast; ring
  rw [e1, e2] at h
  exact h

/-- `(-1)^m f₁ > 0` on the whole open cell `(p_n^1, p_{n+1}^1)`. -/
theorem signed_f1_pos_cell {p : ℝ} (hp : p ∈ Set.Ioo (J.pL m) (J.pL (m + 1))) :
    0 < (-1) ^ m * J.toJacobiData.f1 p := by
  have hK := J.K_pos
  rcases lt_trichotomy p ((2 * m + 3) * J.K) with h | h | h
  · exact J.toJacobiPeriodic.f1_sign_after m ⟨hp.1, h⟩
  · rw [h, ← J.cast3 m, J.toJacobiPeriodic.f1_odd (m + 1)]
    have := J.toJacobiPeriodic.k'_pos
    rw [neg_one_pow_succ_mul, neg_neg, ← mul_assoc, ← sq, neg_one_pow_sq, one_mul]
    exact this
  · have h' := J.toJacobiPeriodic.f1_sign_before (m + 1) (p := p)
      ⟨by rw [J.cast3 m]; exact h, hp.2⟩
    rw [neg_one_pow_succ_mul, neg_one_pow_succ_mul, neg_neg] at h'
    exact h'

/-- The signed quotient `(-1)^m α₁/dn` is strictly decreasing on the closed cell. -/
theorem signed_α1_div_d_strictAntiOn :
    StrictAntiOn (fun p => (-1) ^ m * (J.toJacobiData.α1 p / J.d p))
      (Set.Icc (J.pL m) (J.pL (m + 1))) := by
  have hpos : ∀ p ∈ interior (Set.Icc (J.pL m) (J.pL (m + 1))), 0 < p := by
    rw [interior_Icc]; intro p hp; linarith [hp.1, J.pL_pos m]
  rcases neg_one_pow_eq_or ℝ m with h | h
  · have hf : ∀ p ∈ interior (Set.Icc (J.pL m) (J.pL (m + 1))), 0 < J.toJacobiData.f1 p := by
      rw [interior_Icc]; intro p hp
      have := J.signed_f1_pos_cell m hp; rw [h, one_mul] at this; exact this
    have hanti := J.toJacobiInit.α1_div_d_strictAntiOn (convex_Icc _ _) hpos hf
    rw [h]
    simpa using hanti
  · have hf : ∀ p ∈ interior (Set.Icc (J.pL m) (J.pL (m + 1))), J.toJacobiData.f1 p < 0 := by
      rw [interior_Icc]; intro p hp
      have := J.signed_f1_pos_cell m hp; rw [h] at this; linarith
    have hmono := J.toJacobiInit.α1_div_d_strictMonoOn (convex_Icc _ _) hpos hf
    rw [h]
    intro x hx y hy hxy
    have := hmono hx hy hxy
    simp only at this ⊢
    linarith

/-- `α₁` has at most one zero in the closed cell. -/
theorem α1_zero_unique {p q : ℝ} (hp : p ∈ Set.Icc (J.pL m) (J.pL (m + 1)))
    (hq : q ∈ Set.Icc (J.pL m) (J.pL (m + 1))) (h0 : J.toJacobiData.α1 p = 0)
    (h1 : J.toJacobiData.α1 q = 0) : p = q := by
  apply (J.signed_α1_div_d_strictAntiOn m).injOn hp hq
  show (-1 : ℝ) ^ m * (J.toJacobiData.α1 p / J.d p) = (-1) ^ m * (J.toJacobiData.α1 q / J.d q)
  rw [h0, h1, zero_div, zero_div]

/-- `(-1)^m β₁ > 0` on `(bₙ, (2m+4)K]`. -/
theorem signed_β1_pos_after_bR {p : ℝ} (hp : p ∈ Set.Ioc (J.bR m) ((2 * m + 4) * J.K)) :
    0 < (-1) ^ m * J.toJacobiData.β1 p := by
  have hanti := J.toJacobiPeriodic.signed_β1_strictAntiOn (m + 1) (by omega)
  rw [J.cast2 m, J.cast4 m] at hanti
  have hK := J.K_pos
  have hb := J.bR_mem m
  have hpI : p ∈ Set.Icc ((2 * m + 2) * J.K) ((2 * m + 4) * J.K) :=
    ⟨by linarith [hp.1, hb.1], hp.2⟩
  have hbI : J.bR m ∈ Set.Icc ((2 * m + 2) * J.K) ((2 * m + 4) * J.K) := ⟨hb.1.le, by linarith [hb.2]⟩
  have := hanti hbI hpI hp.1
  simp only at this
  rw [J.β1_bR, mul_zero] at this
  rw [neg_one_pow_succ_mul] at this
  linarith

/-- On `(bₙ, p_{n+1}^1)`, `β > 0` and `α > 0`. -/
theorem β_pos_after_bR {p : ℝ} (hp : p ∈ Set.Ioo (J.bR m) (J.pL (m + 1))) :
    0 < J.toJacobiData.β p := by
  have hK := J.K_pos
  have h1 := J.signed_f1_pos_cell m ⟨by linarith [hp.1, (J.bR_mem m).1, (J.pL_mem m).2], hp.2⟩
  have h2 := J.signed_β1_pos_after_bR m ⟨hp.1, by linarith [hp.2, (J.pL_succ_mem m).2]⟩
  have := mul_pos h1 h2
  rw [mul_mul_mul_comm, ← sq, neg_one_pow_sq, one_mul] at this
  exact this

/-- `β > 0` at a positive time forces `α = (1-k²)(β + ℓ) > 0` and `J₂ > 0` for every phase. -/
theorem J2_pos_of_β_pos {p : ℝ} (hp : 0 < p) (hβ : 0 < J.toJacobiData.β p) (τ : ℝ) :
    0 < J.J2 τ p := by
  have hℓ : 0 < J.toJacobiData.ell p :=
    mul_pos (J.toJacobiInit.eps_pos hp) (J.toJacobiInit.q_pos hp)
  have hk : 0 < 1 - J.k ^ 2 := by nlinarith [J.k_pos, J.k_lt_one]
  have hα : 0 < J.toJacobiData.α p := by
    rw [J.toJacobiData.collapse_alpha p]
    have := J.toJacobiData.collapse_beta p
    exact mul_pos hk (by linarith)
  have hsc := J.sc τ
  unfold J2
  nlinarith [mul_nonneg hα.le (sq_nonneg (J.s τ)), mul_nonneg hβ.le (sq_nonneg (J.c τ)),
    mul_pos hα hβ]

/-- `X < 0` at a positive time forces `β = X - ℓ < 0`, `α = (1-k²)X < 0` and `J₂ < 0`. -/
theorem J2_neg_of_X_neg {p : ℝ} (hp : 0 < p) (hX : J.toJacobiData.X p < 0) (τ : ℝ) :
    J.J2 τ p < 0 := by
  have hℓ : 0 < J.toJacobiData.ell p :=
    mul_pos (J.toJacobiInit.eps_pos hp) (J.toJacobiInit.q_pos hp)
  have hk : 0 < 1 - J.k ^ 2 := by nlinarith [J.k_pos, J.k_lt_one]
  have hβ : 0 < -J.toJacobiData.β p := by rw [J.toJacobiData.collapse_beta p]; linarith
  have hα : 0 < -J.toJacobiData.α p := by
    rw [J.toJacobiData.collapse_alpha p]; nlinarith
  have hsc := J.sc τ
  unfold J2
  nlinarith [mul_nonneg hα.le (sq_nonneg (J.s τ)), mul_nonneg hβ.le (sq_nonneg (J.c τ)),
    mul_pos hα hβ]

/-- No conjugate time on `(bₙ, p_{n+1}^1)`. -/
theorem J2_pos_after_bR {p : ℝ} (hp : p ∈ Set.Ioo (J.bR m) (J.pL (m + 1))) (τ : ℝ) :
    0 < J.J2 τ p :=
  J.J2_pos_of_β_pos (by linarith [hp.1, (J.bR_mem m).1, J.two_m_two_pos m])
    (J.β_pos_after_bR m hp) τ

/-! ### Part 2: nothing between the brackets, and the count -/

/-- `X = sn α₁ < 0` strictly between the brackets, on `(eL, eR)`. -/
theorem X_neg_gap {p : ℝ} (hp : p ∈ Set.Ioo (J.eL m) (J.eR m)) : J.toJacobiData.X p < 0 := by
  have hK := J.K_pos
  have hXdef : J.toJacobiData.X p = J.s p * J.toJacobiData.α1 p := rfl
  have hbR := J.bR_mem m
  have hpL1 := J.pL_succ_mem m
  have hanti := J.signed_α1_div_d_strictAntiOn m
  have hmemL : J.eL m ∈ Set.Icc (J.pL m) (J.pL (m + 1)) :=
    ⟨J.pL_le_eL m, by linarith [J.eL_le m, hpL1.1]⟩
  have hmemR : J.eR m ∈ Set.Icc (J.pL m) (J.pL (m + 1)) :=
    ⟨by linarith [J.eR_ge m, (J.pL_mem m).2], by linarith [J.eR_le_bR m, hbR.2, hpL1.1]⟩
  have hmemp : p ∈ Set.Icc (J.pL m) (J.pL (m + 1)) :=
    ⟨by linarith [hp.1, J.pL_le_eL m], by linarith [hp.2, hmemR.2]⟩
  have hd := J.d_pos p
  rcases lt_trichotomy p ((2 * m + 2) * J.K) with h | h | h
  · -- left of `2nK`: `(-1)^m α₁ < 0` past its zero `eL`, `(-1)^m sn > 0`
    have h0 := J.α1_eL_of_lt m (by linarith [hp.1])
    have := hanti hmemL hmemp hp.1
    simp only at this
    rw [h0, zero_div, mul_zero, ← mul_div_assoc, div_lt_iff₀ hd, zero_mul] at this
    have hs := J.signed_s_pos m ⟨by linarith [hp.1, J.pL_le_eL m, (J.pL_mem m).1], h⟩
    have hprod := mul_pos hs (neg_pos.mpr this)
    rw [mul_neg, mul_mul_mul_comm, ← sq, neg_one_pow_sq, one_mul] at hprod
    rw [hXdef]; linarith
  · -- `p = 2nK` would make both `eL` and `eR` zeros of `α₁` in the cell
    exfalso
    have h0L := J.α1_eL_of_lt m (by rw [← h]; exact hp.1)
    have h0R := J.α1_eR_of_gt m (by rw [← h]; exact hp.2)
    have := J.α1_zero_unique m hmemL hmemR h0L h0R
    linarith [hp.1, hp.2]
  · -- right of `2nK`: `(-1)^m α₁ > 0` before its zero `eR`, `(-1)^(m+1) sn > 0`
    have h0 := J.α1_eR_of_gt m (by linarith [hp.2])
    have := hanti hmemp hmemR hp.2
    simp only at this
    rw [h0, zero_div, mul_zero, ← mul_div_assoc, lt_div_iff₀ hd, zero_mul] at this
    have hs := J.signed_s_pos_R m ⟨h, by linarith [hp.2, J.eR_le_bR m, hbR.2]⟩
    have hprod := mul_pos hs this
    rw [neg_one_pow_succ_mul, neg_mul, mul_mul_mul_comm, ← sq, neg_one_pow_sq, one_mul] at hprod
    rw [hXdef]; linarith

/-- No conjugate time strictly between the brackets: `J₂ < 0` on `(eL, eR)` for every phase. -/
theorem J2_neg_gap {p : ℝ} (hp : p ∈ Set.Ioo (J.eL m) (J.eR m)) (τ : ℝ) : J.J2 τ p < 0 :=
  J.J2_neg_of_X_neg (by linarith [hp.1, J.pL_le_eL m, J.pL_pos m]) (J.X_neg_gap m hp) τ

/-- **Theorem 4.1, the roots in a cell**: for every phase `ψ` the zeros of `J₂(ψ+p, p)` in the
half-open cell `[p_n^1, p_{n+1}^1)` are one point of the left bracket and one of the right
bracket, and they coincide only at `2nK` (which forces `eL = eR = 2nK`, i.e. `k = k₀`). -/
theorem cell_roots (ψ : ℝ) :
    ∃ p ∈ Set.Icc (J.pL m) (J.eL m), ∃ q ∈ Set.Icc (J.eR m) (J.bR m),
      {x | x ∈ Set.Ico (J.pL m) (J.pL (m + 1)) ∧ J.J2 (ψ + x) x = 0} = {p, q} ∧
      (p = q → p = (2 * m + 2) * J.K) := by
  obtain ⟨p, ⟨hpI, hp0⟩, hpu⟩ := J.left_exact_time m ψ
  obtain ⟨q, ⟨hqI, hq0⟩, hqu⟩ := J.right_exact_time m ψ
  have hK := J.K_pos
  have hbR := J.bR_mem m
  have hpL1 := J.pL_succ_mem m
  refine ⟨p, hpI, q, hqI, ?_, fun h => by linarith [hpI.2, J.eL_le m, J.eR_ge m, hqI.1]⟩
  ext x
  simp only [Set.mem_ofPred_eq, Set.mem_insert_iff, Set.mem_singleton_iff]
  constructor
  · rintro ⟨hx, hx0⟩
    rcases le_or_gt x (J.eL m) with h1 | h1
    · exact Or.inl (hpu x ⟨⟨hx.1, h1⟩, hx0⟩)
    rcases lt_or_ge x (J.eR m) with h2 | h2
    · exact absurd hx0 (J.J2_neg_gap m ⟨h1, h2⟩ _).ne
    rcases le_or_gt x (J.bR m) with h3 | h3
    · exact Or.inr (hqu x ⟨⟨h2, h3⟩, hx0⟩)
    · exact absurd hx0 (J.J2_pos_after_bR m ⟨h3, hx.2⟩ _).ne'
  · rintro (rfl | rfl)
    · exact ⟨⟨hpI.1, by linarith [hpI.2, J.eL_le m, hpL1.1]⟩, hp0⟩
    · exact ⟨⟨by linarith [hqI.1, J.eR_ge m, (J.pL_mem m).2],
        by linarith [hqI.2, hbR.2, hpL1.1]⟩, hq0⟩

/-- **Theorem 4.1, the count**: when the brackets are disjoint (`eL < eR`, i.e. `k ≠ k₀`),
every phase has exactly two conjugate times in `[p_n^1, p_{n+1}^1)`. -/
theorem two_per_cell (hne : J.eL m < J.eR m) (ψ : ℝ) :
    {x | x ∈ Set.Ico (J.pL m) (J.pL (m + 1)) ∧ J.J2 (ψ + x) x = 0}.ncard = 2 := by
  obtain ⟨p, hp, q, hq, h, -⟩ := J.cell_roots m ψ
  rw [h]
  exact Set.ncard_pair (ne_of_lt (by linarith [hp.2, hq.1]))


/-! ### Part 3: the brackets touch exactly when `K = 2E` -/

theorem signed_α1_2nK : (-1) ^ m * J.toJacobiData.α1 ((2 * m + 2) * J.K)
    = (2 * m + 2) * J.d ((2 * m + 2) * J.K) * (2 * J.E - J.K) := by
  have h := J.toJacobiPeriodic.α1_even (m + 1)
  rw [J.cast2 m] at h
  rw [h, pow_succ]
  push_cast
  rcases neg_one_pow_eq_or ℝ m with h1 | h1 <;> rw [h1] <;> ring

theorem two_m_two_mem : (2 * m + 2) * J.K ∈ Set.Icc (J.pL m) (J.pL (m + 1)) :=
  ⟨(J.pL_mem m).2.le, by linarith [(J.pL_succ_mem m).1, J.K_pos]⟩

/-- The left bracket stops before `2nK` exactly when `2E < K` (`k > k₀`). -/
theorem eL_lt_iff : J.eL m < (2 * m + 2) * J.K ↔ 2 * J.E < J.K := by
  have hK := J.K_pos
  have hd := J.d_pos ((2 * m + 2) * J.K)
  have hval := J.signed_α1_2nK m
  have hanti := J.signed_α1_div_d_strictAntiOn m
  have hmem2 := J.two_m_two_mem m
  have hpos : (0 : ℝ) < (2 * m + 2) * J.d ((2 * m + 2) * J.K) := by positivity
  constructor
  · intro h
    have h0 := J.α1_eL_of_lt m h
    have hmemL : J.eL m ∈ Set.Icc (J.pL m) (J.pL (m + 1)) :=
      ⟨J.pL_le_eL m, by linarith [J.eL_le m, hmem2.2]⟩
    have := hanti hmemL hmem2 h
    simp only at this
    rw [h0, zero_div, mul_zero, ← mul_div_assoc, hval, div_lt_iff₀ hd, zero_mul] at this
    nlinarith
  · intro h
    have hneg : (-1) ^ m * J.toJacobiData.α1 ((2 * m + 2) * J.K) < 0 := by
      rw [hval]; exact mul_neg_of_pos_of_neg hpos (by linarith)
    obtain ⟨z, hz, hα⟩ := J.exists_α1_zero m (J.pL_mem m).2.le
      (mul_nonpos_of_nonneg_of_nonpos (J.signed_α1_pL_pos m).le hneg.le)
    have hzne : z ≠ (2 * m + 2) * J.K := fun e => by rw [← e, hα, mul_zero] at hneg; exact lt_irrefl _ hneg
    have hzZ : z ∈ J.ZL m := Or.inl ⟨hz, hα⟩
    exact lt_of_le_of_lt (csInf_le (J.ZL_bddBelow m) hzZ) (lt_of_le_of_ne hz.2 hzne)

/-- The right bracket starts after `2nK` exactly when `K < 2E` (`k < k₀`). -/
theorem eR_gt_iff : (2 * m + 2) * J.K < J.eR m ↔ J.K < 2 * J.E := by
  have hK := J.K_pos
  have hd := J.d_pos ((2 * m + 2) * J.K)
  have hval := J.signed_α1_2nK m
  have hanti := J.signed_α1_div_d_strictAntiOn m
  have hmem2 := J.two_m_two_mem m
  have hbR := J.bR_mem m
  have hpos : (0 : ℝ) < (2 * m + 2) * J.d ((2 * m + 2) * J.K) := by positivity
  constructor
  · intro h
    have h0 := J.α1_eR_of_gt m h
    have hmemR : J.eR m ∈ Set.Icc (J.pL m) (J.pL (m + 1)) :=
      ⟨by linarith [J.eR_ge m, hmem2.1], by linarith [J.eR_le_bR m, hbR.2, (J.pL_succ_mem m).1]⟩
    have := hanti hmem2 hmemR h
    simp only at this
    rw [h0, zero_div, mul_zero, ← mul_div_assoc, hval, lt_div_iff₀ hd, zero_mul] at this
    nlinarith
  · intro h
    have hpos2 : 0 < (-1) ^ m * J.toJacobiData.α1 ((2 * m + 2) * J.K) := by
      rw [hval]; exact mul_pos hpos (by linarith)
    have hneg : (-1) ^ m * J.toJacobiData.α1 (J.bR m) < 0 := by
      have := J.signed_α1_bR_pos m
      rw [neg_one_pow_succ_mul] at this; linarith
    obtain ⟨z, hz, hα⟩ := J.exists_α1_zero m hbR.1.le
      (mul_nonpos_of_nonneg_of_nonpos hpos2.le hneg.le)
    have hzne : (2 * m + 2) * J.K ≠ z := fun e => by
      rw [e, hα, mul_zero] at hpos2; exact lt_irrefl _ hpos2
    have hzZ : z ∈ J.ZR m := Or.inl ⟨hz, hα⟩
    exact lt_of_lt_of_le (lt_of_le_of_ne hz.1 hzne) (le_csSup (J.ZR_bddAbove m) hzZ)

theorem eL_le_eR : J.eL m ≤ J.eR m := le_trans (J.eL_le m) (J.eR_ge m)

/-- The brackets touch (at `2nK`) exactly when `K = 2E`, i.e. `k = k₀`. -/
theorem eL_eq_eR_iff : J.eL m = J.eR m ↔ J.K = 2 * J.E := by
  have h1 := J.eL_lt_iff m
  have h2 := J.eR_gt_iff m
  have h3 := J.eL_le m
  have h4 := J.eR_ge m
  constructor
  · intro h
    have hL : ¬ J.eL m < (2 * m + 2) * J.K := fun hlt => by linarith
    have hR : ¬ (2 * m + 2) * J.K < J.eR m := fun hlt => by linarith
    rw [h1] at hL; rw [h2] at hR
    linarith [not_lt.mp hL, not_lt.mp hR]
  · intro h
    have hL : ¬ J.eL m < (2 * m + 2) * J.K := by rw [h1]; linarith
    have hR : ¬ (2 * m + 2) * J.K < J.eR m := by rw [h2]; linarith
    linarith [not_lt.mp hL, not_lt.mp hR]

theorem eL_lt_eR_iff : J.eL m < J.eR m ↔ J.K ≠ 2 * J.E := by
  have h := J.eL_eq_eR_iff m
  exact ⟨fun hlt hk => (ne_of_lt hlt) (h.mpr hk),
    fun hk => lt_of_le_of_ne (J.eL_le_eR m) (fun e => hk (h.mp e))⟩

/-- **Theorem 4.1, the count in terms of the modulus**: for `K ≠ 2E` (`k ≠ k₀`) every phase has
exactly two conjugate times in `[p_n^1, p_{n+1}^1)`. -/
theorem two_per_cell_of_ne (hk : J.K ≠ 2 * J.E) (ψ : ℝ) :
    {x | x ∈ Set.Ico (J.pL m) (J.pL (m + 1)) ∧ J.J2 (ψ + x) x = 0}.ncard = 2 :=
  J.two_per_cell m ((J.eL_lt_eR_iff m).mpr hk) ψ

/-- The two conjugate times of a cell coincide only for `K = 2E`, and then at `2nK`. -/
theorem coincide_imp (ψ : ℝ) :
    ∃ p ∈ Set.Icc (J.pL m) (J.eL m), ∃ q ∈ Set.Icc (J.eR m) (J.bR m),
      {x | x ∈ Set.Ico (J.pL m) (J.pL (m + 1)) ∧ J.J2 (ψ + x) x = 0} = {p, q} ∧
      (p = q → p = (2 * m + 2) * J.K ∧ J.K = 2 * J.E) := by
  obtain ⟨p, hp, q, hq, h, hc⟩ := J.cell_roots m ψ
  refine ⟨p, hp, q, hq, h, fun e => ⟨hc e, (J.eL_eq_eR_iff m).mp ?_⟩⟩
  linarith [hp.2, hq.1, J.eL_le m, J.eR_ge m]

end JacobiFull

end
