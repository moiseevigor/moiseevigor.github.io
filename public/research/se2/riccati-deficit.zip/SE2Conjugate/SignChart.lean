import SE2Conjugate.EndpointExpansion
import SE2Conjugate.CriticalModulus

/-! Lemma 3.1(iv). The half-period index in the article is n=m+1. -/
noncomputable section
open Set JacobiCore.EndpointExpansion
namespace JacobiCore.SignChart
variable (J : JacobiCore)

theorem alpha_interior (m : ℕ) :
    endpoint .alpha J m ∈ Ioo (J.toJacobiFull.pL m) (J.toJacobiFull.bR m) := by
  let F := J.toJacobiFull
  obtain ⟨hm,hz,_⟩ := alpha_endpoint_spec J m
  change F.toJacobiData.α1 (endpoint .alpha J m)=0 at hz
  refine ⟨hm.1.lt_of_ne ?_,hm.2.lt_of_ne ?_⟩
  · intro e
    have h := F.signed_α1_pL_pos m
    rw [e,hz,mul_zero] at h
    exact (lt_irrefl _ h)
  · intro e
    have h := F.signed_α1_bR_pos m
    rw [← e,hz,mul_zero] at h
    exact (lt_irrefl _ h)

/-- Value, exact derivative and its nonvanishing, for every indexed alpha zero. -/
theorem alpha_simple (m : ℕ) :
    let a := endpoint .alpha J m
    J.toJacobiData.α1 a=0 ∧
    HasDerivAt J.toJacobiData.α1 (-(J.eps a*J.toJacobiData.f1 a)/J.d a) a ∧
    deriv J.toJacobiData.α1 a ≠ 0 := by
  let a := endpoint .alpha J m
  let F := J.toJacobiFull
  have hz : J.toJacobiData.α1 a=0 := (alpha_endpoint_spec J m).2.1
  have h := alpha_interior J m
  have endlt := (F.bR_mem m).2.trans (F.pL_succ_mem m).1
  have hf := F.signed_f1_pos_cell m ⟨h.1,h.2.trans endlt⟩
  have hfn : J.toJacobiData.f1 a ≠ 0 := by
    intro he
    rw [show F.toJacobiData.f1 (endpoint .alpha J m)=0 from he,mul_zero] at hf
    exact lt_irrefl _ hf
  have he := F.toJacobiInit.eps_pos ((F.pL_pos m).trans h.1)
  have hd := J.d_pos a
  have q := J.toJacobiData.hasDerivAt_α1_div_d a hd.ne'
  have prod := q.mul (J.hd a)
  have eqfun : (fun x => J.toJacobiData.α1 x / J.d x) * J.d = J.toJacobiData.α1 := by
    funext x; exact div_mul_cancel₀ _ (J.d_pos x).ne'
  change HasDerivAt ((fun x => J.toJacobiData.α1 x / J.d x) * J.d) _ a at prod
  rw [eqfun] at prod
  have der : HasDerivAt J.toJacobiData.α1 (-(J.eps a*J.toJacobiData.f1 a)/J.d a) a := by
    apply prod.congr_deriv
    change -(J.eps a*J.toJacobiData.f1 a)/J.d a^2*J.d a+
      (J.toJacobiData.α1 a/J.d a)*_ = _
    rw [hz,zero_div,zero_mul,add_zero]; field_simp
  exact ⟨hz,der,der.deriv.symm ▸ div_ne_zero (neg_ne_zero.mpr (mul_ne_zero he.ne' hfn)) hd.ne'⟩

theorem alpha_signs (m : ℕ) {p : ℝ}
    (hp : p ∈ Icc (J.toJacobiFull.pL m) (J.toJacobiFull.pL (m+1))) :
    let a := endpoint .alpha J m
    (p<a ↔ 0<(-1:ℝ)^m*J.toJacobiData.α1 p) ∧
    (a<p ↔ (-1:ℝ)^m*J.toJacobiData.α1 p<0) := by
  let F := J.toJacobiFull
  let a := endpoint .alpha J m
  obtain ⟨ha,hz,_⟩ := alpha_endpoint_spec J m
  have mem : a ∈ Icc (F.pL m) (F.pL (m+1)) :=
    ⟨ha.1,ha.2.trans ((F.bR_mem m).2.trans (F.pL_succ_mem m).1).le⟩
  have anti := F.signed_α1_div_d_strictAntiOn m
  have h₁ := anti.lt_iff_gt mem hp
  have h₂ := anti.lt_iff_gt hp mem
  change F.toJacobiData.α1 a=0 at hz
  change (-1:ℝ)^m*(F.toJacobiData.α1 a / F.d a)<(-1:ℝ)^m*(F.toJacobiData.α1 p / F.d p) ↔ p<a at h₁
  change (-1:ℝ)^m*(F.toJacobiData.α1 p / F.d p)<(-1:ℝ)^m*(F.toJacobiData.α1 a / F.d a) ↔ a<p at h₂
  rw [hz,zero_div,mul_zero,← mul_div_assoc] at h₁ h₂
  change (p<a ↔ 0<(-1:ℝ)^m*F.toJacobiData.α1 p) ∧ (a<p ↔ (-1:ℝ)^m*F.toJacobiData.α1 p<0)
  exact ⟨h₁.symm.trans (div_pos_iff_of_pos_right (J.d_pos p)),h₂.symm.trans (by simpa only [zero_mul] using (div_lt_iff₀ (F.d_pos p) (a := (0:ℝ)) (b := (-1:ℝ)^m*F.toJacobiData.α1 p)))⟩

/-- Consecutive beta zeros, including the initial interval with b₀=0. -/
theorem beta_signs (m : ℕ) {p : ℝ}
    (hp : p ∈ Ioo (match m with | 0 => 0 | i+1 => J.toJacobiFull.bR i) (J.toJacobiFull.bR m)) :
    0<(-1:ℝ)^(m+1)*J.toJacobiData.β1 p := by
  let F := J.toJacobiFull
  by_cases h : (2*(m:ℝ)+2)*J.K ≤ p
  · exact F.signed_β1_pos_before_bR m ⟨h,hp.2⟩
  · cases m with
    | zero =>
      have lt : p≤2*J.K := by push_cast at h; linarith
      have s := F.β1_neg_Ioc ⟨hp.1,lt⟩
      change 0<(-1:ℝ)^(0+1)*F.toJacobiData.β1 p
      simpa using s
    | succ i =>
      have ub : p≤(2*(i:ℝ)+4)*J.K := by push_cast at h; linarith
      have s := F.signed_β1_pos_after_bR i ⟨hp.1,ub⟩
      change 0<(-1:ℝ)^(i+1+1)*F.toJacobiData.β1 p
      simpa [pow_succ] using s

theorem alpha_center_value (n : ℕ) :
    J.toJacobiData.α1 (2*n*J.K)=(-1:ℝ)^n*(2*n)*(J.K-2*J.E) := by
  have h := J.toJacobiFull.toJacobiPeriodic.α1_even n
  change J.toJacobiData.α1 (2*n*J.K)=(-1:ℝ)^n*J.d (2*n*J.K)*(2*n*J.K-2*(2*n*J.E)) at h
  have d := J.d_shift_n n 0
  rw [zero_add,J.d0] at d
  rw [h,d]; ring

open JacobiConcrete
/-- Placement relative to the unique critical modulus and the first upper bracket. -/
theorem modulus_placement {k κ : ℝ} (hk : k ∈ Ioo (0:ℝ) 1) (hc : κ ∈ Ioo (0:ℝ) 1)
    (hz : JacobiConcrete.K κ=2*secondIntegral κ (Real.pi/2)) (m : ℕ) :
    let J := core k hk.1 hk.2
    let P := (2*(m:ℝ)+2)*J.K
    let a := endpoint .alpha J m
    (k<κ → P<a) ∧ (k=κ → a=P) ∧ (κ<k → a<P) ∧
      J.toJacobiFull.p1 = if k≤κ then 2*J.K else endpoint .alpha J 0 := by
  let J := core k hk.1 hk.2
  let F := J.toJacobiFull
  have hc0 : normalizedGap κ=0 := by simp [normalizedGap,← hz]
  have e : J.E=secondIntegral k (Real.pi/2) := full_E k hk.1 hk.2
  have below (h : k<κ) : J.K<2*J.E := by
    have s := gap_strictAnti hk hc h
    rw [hc0] at s
    change 0<(2*secondIntegral k (Real.pi/2)-JacobiConcrete.K k)/k at s
    rw [e]; exact sub_pos.mp ((div_pos_iff_of_pos_right hk.1).mp s)
  have above (h : κ<k) : 2*J.E<J.K := by
    have s := gap_strictAnti hc hk h
    rw [hc0] at s
    change (2*secondIntegral k (Real.pi/2)-JacobiConcrete.K k)/k<0 at s
    rw [e]; change 2*secondIntegral k (Real.pi/2)<JacobiConcrete.K k
    exact sub_neg.mp (by simpa only [zero_mul] using (div_lt_iff₀ hk.1).mp s)
  have equal (h : k=κ) : J.K=2*J.E := by rw [e]; change JacobiConcrete.K k=_; simpa [h] using hz
  change (k<κ → (2*(m:ℝ)+2)*J.K<endpoint .alpha J m) ∧ (k=κ → endpoint .alpha J m=(2*(m:ℝ)+2)*J.K) ∧ (κ<k → endpoint .alpha J m<(2*(m:ℝ)+2)*J.K) ∧ _
  refine ⟨fun h => ?_,fun h => ?_,fun h => ?_,?_⟩
  · have s := below h
    simp only [endpoint,if_neg s.asymm,if_pos s]; exact (F.eR_gt_iff m).mpr s
  · have s := equal h
    simp [endpoint,← s]
  · have s := above h
    simp only [endpoint,if_pos s]; exact (F.eL_lt_iff m).mpr s
  · change F.eL 0=if k≤κ then 2*J.K else endpoint .alpha J 0
    split_ifs with h
    · have le : J.K≤2*J.E := h.lt_or_eq.elim (fun l => (below l).le) (fun l => (equal l).le)
      have a := F.eL_le 0
      have b := mt (F.eL_lt_iff 0).mp (not_lt.mpr le)
      change F.eL 0=2*F.K
      simpa using le_antisymm a (not_lt.mp b)
    · simp only [endpoint,if_pos (above (lt_of_not_ge h))]; rfl
end JacobiCore.SignChart
