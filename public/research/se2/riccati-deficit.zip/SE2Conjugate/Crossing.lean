import Mathlib

/-!
# Lemma 3.3 (Crossing principle): the counting part

Let `u : [lo, hi] → [0, K]` be continuous with `u lo = 0`, `u hi = K`, such that the two phase
branches `ψ₊ = u - id` and `ψ₋ = -u - id` are strictly monotone (in the paper this follows from
`|u'| ≥ 1`, analyticity and the unboundedness of `u'`).  Then for every phase `ψ` the line
`τ = ψ + p` meets the closed curve `{τ ≡ ±u(p) (mod 2K), lo ≤ p ≤ hi}` in exactly one point:
there is exactly one `p ∈ [lo, hi]` with `σ u(p) - p ≡ ψ (mod 2K)` for some sign `σ`.

The proof is the tiling argument of the paper: `ψ₊` sweeps `[-lo, K - hi]`, `ψ₋` sweeps
`[-K - hi, -lo]`, the two arcs cover a full period and overlap only at `-lo`, which both
branches reach at `p = lo`; the endpoints `±K - hi` are reached only at `p = hi`.
-/

structure CrossingData where
  K : ℝ
  K_pos : 0 < K
  lo : ℝ
  hi : ℝ
  lo_lt_hi : lo < hi
  u : ℝ → ℝ
  u_cont : ContinuousOn u (Set.Icc lo hi)
  u_lo : u lo = 0
  u_hi : u hi = K
  plus_mono : StrictMonoOn (fun p => u p - p) (Set.Icc lo hi)
  minus_anti : StrictAntiOn (fun p => -u p - p) (Set.Icc lo hi)

namespace CrossingData

variable (C : CrossingData)

/-- The branch `ψ₊ = u - id`. -/
def psiP (p : ℝ) : ℝ := C.u p - p

/-- The branch `ψ₋ = -u - id`. -/
def psiM (p : ℝ) : ℝ := -C.u p - p

theorem lo_mem : C.lo ∈ Set.Icc C.lo C.hi := Set.left_mem_Icc.mpr C.lo_lt_hi.le
theorem hi_mem : C.hi ∈ Set.Icc C.lo C.hi := Set.right_mem_Icc.mpr C.lo_lt_hi.le

theorem psiP_lo : C.psiP C.lo = -C.lo := by simp [psiP, C.u_lo]
theorem psiP_hi : C.psiP C.hi = C.K - C.hi := by simp [psiP, C.u_hi]
theorem psiM_lo : C.psiM C.lo = -C.lo := by simp [psiM, C.u_lo]
theorem psiM_hi : C.psiM C.hi = -C.K - C.hi := by simp [psiM, C.u_hi]

theorem psiP_strictMono : StrictMonoOn C.psiP (Set.Icc C.lo C.hi) := C.plus_mono
theorem psiM_strictAnti : StrictAntiOn C.psiM (Set.Icc C.lo C.hi) := C.minus_anti

/-- The bracket is shorter than a quarter period: `hi - lo < K`. -/
theorem hi_sub_lo_lt : C.hi - C.lo < C.K := by
  have h := C.psiP_strictMono C.lo_mem C.hi_mem C.lo_lt_hi
  rw [C.psiP_lo, C.psiP_hi] at h
  linarith

theorem psiP_range {p : ℝ} (hp : p ∈ Set.Icc C.lo C.hi) :
    -C.lo ≤ C.psiP p ∧ C.psiP p ≤ C.K - C.hi := by
  have hm := C.psiP_strictMono.monotoneOn
  have h1 := hm C.lo_mem hp hp.1
  have h2 := hm hp C.hi_mem hp.2
  rw [C.psiP_lo] at h1
  rw [C.psiP_hi] at h2
  exact ⟨h1, h2⟩

theorem psiM_range {p : ℝ} (hp : p ∈ Set.Icc C.lo C.hi) :
    -C.K - C.hi ≤ C.psiM p ∧ C.psiM p ≤ -C.lo := by
  have hm := C.psiM_strictAnti.antitoneOn
  have h1 := hm hp C.hi_mem hp.2
  have h2 := hm C.lo_mem hp hp.1
  rw [C.psiM_hi] at h1
  rw [C.psiM_lo] at h2
  exact ⟨h1, h2⟩

theorem psiP_eq_lo {p : ℝ} (hp : p ∈ Set.Icc C.lo C.hi) (h : C.psiP p = -C.lo) : p = C.lo :=
  C.psiP_strictMono.injOn hp C.lo_mem (by rw [h, C.psiP_lo])

theorem psiP_eq_hi {p : ℝ} (hp : p ∈ Set.Icc C.lo C.hi) (h : C.psiP p = C.K - C.hi) : p = C.hi :=
  C.psiP_strictMono.injOn hp C.hi_mem (by rw [h, C.psiP_hi])

theorem psiM_eq_lo {p : ℝ} (hp : p ∈ Set.Icc C.lo C.hi) (h : C.psiM p = -C.lo) : p = C.lo :=
  C.psiM_strictAnti.injOn hp C.lo_mem (by rw [h, C.psiM_lo])

theorem psiM_eq_hi {p : ℝ} (hp : p ∈ Set.Icc C.lo C.hi) (h : C.psiM p = -C.K - C.hi) :
    p = C.hi :=
  C.psiM_strictAnti.injOn hp C.hi_mem (by rw [h, C.psiM_hi])

/-- The value of a branch at `p`: `σ u p - p` for `σ = ±1`. -/
def branch (σ : ℝ) (p : ℝ) : ℝ := σ * C.u p - p

theorem branch_one (p : ℝ) : C.branch 1 p = C.psiP p := by simp [branch, psiP]
theorem branch_neg_one (p : ℝ) : C.branch (-1) p = C.psiM p := by simp [branch, psiM]

theorem branch_range {σ p : ℝ} (hσ : σ = 1 ∨ σ = -1) (hp : p ∈ Set.Icc C.lo C.hi) :
    -C.K - C.hi ≤ C.branch σ p ∧ C.branch σ p ≤ C.K - C.hi := by
  have hK := C.K_pos
  have hll := C.hi_sub_lo_lt
  rcases hσ with rfl | rfl
  · rw [C.branch_one]
    obtain ⟨h1, h2⟩ := C.psiP_range hp
    have := C.lo_lt_hi
    constructor <;> linarith
  · rw [C.branch_neg_one]
    obtain ⟨h1, h2⟩ := C.psiM_range hp
    have := C.lo_lt_hi
    constructor <;> linarith

/-- Existence: every phase is attained on one of the two branches, modulo `2K`. -/
theorem exists_branch (ψ : ℝ) :
    ∃ p ∈ Set.Icc C.lo C.hi, ∃ σ : ℝ, (σ = 1 ∨ σ = -1) ∧
      ∃ n : ℤ, C.branch σ p = ψ + 2 * C.K * n := by
  have h2K : 0 < 2 * C.K := by linarith [C.K_pos]
  set n : ℤ := ⌊(ψ + C.K + C.hi) / (2 * C.K)⌋ with hn
  set ψ' : ℝ := ψ - 2 * C.K * n with hψ'
  have hlo' : -C.K - C.hi ≤ ψ' := by
    have h := Int.floor_le ((ψ + C.K + C.hi) / (2 * C.K))
    rw [le_div_iff₀ h2K] at h
    rw [hψ']
    linarith
  have hhi' : ψ' < C.K - C.hi := by
    have h := Int.lt_floor_add_one ((ψ + C.K + C.hi) / (2 * C.K))
    rw [div_lt_iff₀ h2K] at h
    rw [hψ']
    linarith
  by_cases hcase : -C.lo ≤ ψ'
  · have hcont : ContinuousOn C.psiP (Set.Icc C.lo C.hi) := C.u_cont.sub continuousOn_id
    have hmem : ψ' ∈ Set.Icc (C.psiP C.lo) (C.psiP C.hi) := by
      rw [C.psiP_lo, C.psiP_hi]
      exact ⟨hcase, hhi'.le⟩
    obtain ⟨p, hp, hpψ⟩ := intermediate_value_Icc C.lo_lt_hi.le hcont hmem
    refine ⟨p, hp, 1, Or.inl rfl, -n, ?_⟩
    rw [C.branch_one, hpψ, hψ']
    push_cast
    ring
  · simp only [not_le] at hcase
    have hcont : ContinuousOn C.psiM (Set.Icc C.lo C.hi) := C.u_cont.neg.sub continuousOn_id
    have hmem : ψ' ∈ Set.Icc (C.psiM C.hi) (C.psiM C.lo) := by
      rw [C.psiM_lo, C.psiM_hi]
      exact ⟨hlo', hcase.le⟩
    obtain ⟨p, hp, hpψ⟩ := intermediate_value_Icc' C.lo_lt_hi.le hcont hmem
    refine ⟨p, hp, -1, Or.inr rfl, -n, ?_⟩
    rw [C.branch_neg_one, hpψ, hψ']
    push_cast
    ring

/-- Two branch values that agree are attained at the same `p`. -/
theorem eq_of_branch_eq {σ₁ σ₂ p₁ p₂ : ℝ} (hσ₁ : σ₁ = 1 ∨ σ₁ = -1) (hσ₂ : σ₂ = 1 ∨ σ₂ = -1)
    (hp₁ : p₁ ∈ Set.Icc C.lo C.hi) (hp₂ : p₂ ∈ Set.Icc C.lo C.hi)
    (h : C.branch σ₁ p₁ = C.branch σ₂ p₂) : p₁ = p₂ := by
  rcases hσ₁ with rfl | rfl <;> rcases hσ₂ with rfl | rfl
  · rw [C.branch_one, C.branch_one] at h
    exact C.psiP_strictMono.injOn hp₁ hp₂ h
  · rw [C.branch_one, C.branch_neg_one] at h
    have h1 := C.psiP_range hp₁
    have h2 := C.psiM_range hp₂
    have e1 : C.psiP p₁ = -C.lo := by linarith
    have e2 : C.psiM p₂ = -C.lo := by linarith
    rw [C.psiP_eq_lo hp₁ e1, C.psiM_eq_lo hp₂ e2]
  · rw [C.branch_neg_one, C.branch_one] at h
    have h1 := C.psiM_range hp₁
    have h2 := C.psiP_range hp₂
    have e1 : C.psiM p₁ = -C.lo := by linarith
    have e2 : C.psiP p₂ = -C.lo := by linarith
    rw [C.psiM_eq_lo hp₁ e1, C.psiP_eq_lo hp₂ e2]
  · rw [C.branch_neg_one, C.branch_neg_one] at h
    exact C.psiM_strictAnti.injOn hp₁ hp₂ h

/-- Uniqueness: two meetings of the line with the curve are the same point. -/
theorem unique_branch {ψ σ₁ σ₂ p₁ p₂ : ℝ} {n₁ n₂ : ℤ} (hσ₁ : σ₁ = 1 ∨ σ₁ = -1)
    (hσ₂ : σ₂ = 1 ∨ σ₂ = -1) (hp₁ : p₁ ∈ Set.Icc C.lo C.hi) (hp₂ : p₂ ∈ Set.Icc C.lo C.hi)
    (h₁ : C.branch σ₁ p₁ = ψ + 2 * C.K * n₁) (h₂ : C.branch σ₂ p₂ = ψ + 2 * C.K * n₂) :
    p₁ = p₂ := by
  have hK := C.K_pos
  have hll := C.hi_sub_lo_lt
  have r₁ := C.branch_range hσ₁ hp₁
  have r₂ := C.branch_range hσ₂ hp₂
  -- the two representatives differ by a multiple of 2K inside an interval of length 2K
  have hdiff : (n₁ : ℝ) - n₂ ≤ 1 ∧ (n₂ : ℝ) - n₁ ≤ 1 := by
    constructor <;> nlinarith
  have hint : n₁ = n₂ ∨ n₁ = n₂ + 1 ∨ n₂ = n₁ + 1 := by
    have a1 : n₁ - n₂ ≤ 1 := by exact_mod_cast hdiff.1
    have a2 : n₂ - n₁ ≤ 1 := by exact_mod_cast hdiff.2
    omega
  rcases hint with hn | hn | hn
  · subst hn
    exact C.eq_of_branch_eq hσ₁ hσ₂ hp₁ hp₂ (by rw [h₁, h₂])
  · -- branch σ₁ p₁ = branch σ₂ p₂ + 2K: both at the ends, both at p = hi
    have hv : C.branch σ₁ p₁ = C.branch σ₂ p₂ + 2 * C.K := by
      rw [h₁, h₂, hn]; push_cast; ring
    have e₁ : C.branch σ₁ p₁ = C.K - C.hi := by linarith
    have e₂ : C.branch σ₂ p₂ = -C.K - C.hi := by linarith
    have q₁ : p₁ = C.hi := by
      rcases hσ₁ with rfl | rfl
      · rw [C.branch_one] at e₁
        exact C.psiP_eq_hi hp₁ e₁
      · rw [C.branch_neg_one] at e₁
        obtain ⟨h1, h2⟩ := C.psiM_range hp₁
        have := C.lo_lt_hi
        linarith
    have q₂ : p₂ = C.hi := by
      rcases hσ₂ with rfl | rfl
      · rw [C.branch_one] at e₂
        obtain ⟨h1, h2⟩ := C.psiP_range hp₂
        have := C.lo_lt_hi
        linarith
      · rw [C.branch_neg_one] at e₂
        exact C.psiM_eq_hi hp₂ e₂
    rw [q₁, q₂]
  · have hv : C.branch σ₂ p₂ = C.branch σ₁ p₁ + 2 * C.K := by
      rw [h₁, h₂, hn]; push_cast; ring
    have e₂ : C.branch σ₂ p₂ = C.K - C.hi := by linarith
    have e₁ : C.branch σ₁ p₁ = -C.K - C.hi := by linarith
    have q₂ : p₂ = C.hi := by
      rcases hσ₂ with rfl | rfl
      · rw [C.branch_one] at e₂
        exact C.psiP_eq_hi hp₂ e₂
      · rw [C.branch_neg_one] at e₂
        obtain ⟨h1, h2⟩ := C.psiM_range hp₂
        have := C.lo_lt_hi
        linarith
    have q₁ : p₁ = C.hi := by
      rcases hσ₁ with rfl | rfl
      · rw [C.branch_one] at e₁
        obtain ⟨h1, h2⟩ := C.psiP_range hp₁
        have := C.lo_lt_hi
        linarith
      · rw [C.branch_neg_one] at e₁
        exact C.psiM_eq_hi hp₁ e₁
    rw [q₁, q₂]

/-- **Lemma 3.3, counting part.** For every phase there is exactly one `p ∈ [lo, hi]` at which the
line `τ = ψ + p` meets the curve `τ ≡ ±u(p) (mod 2K)`. -/
theorem crossing (ψ : ℝ) :
    ∃! p, p ∈ Set.Icc C.lo C.hi ∧
      ∃ σ : ℝ, (σ = 1 ∨ σ = -1) ∧ ∃ n : ℤ, C.branch σ p = ψ + 2 * C.K * n := by
  obtain ⟨p, hp, σ, hσ, n, hn⟩ := C.exists_branch ψ
  refine ⟨p, ⟨hp, σ, hσ, n, hn⟩, ?_⟩
  rintro p' ⟨hp', σ', hσ', n', hn'⟩
  exact C.unique_branch hσ' hσ hp' hp hn' hn

end CrossingData
