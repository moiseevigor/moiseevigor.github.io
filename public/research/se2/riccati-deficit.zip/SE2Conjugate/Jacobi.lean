import Mathlib

/-!
# Abstract Jacobi data

The paper "All conjugate times of the rotating geodesics in the sub-Riemannian problem on SE(2)"
(version 2) works with Jacobi's functions `sn`, `cn`, `dn` and Jacobi's epsilon `ℰ` of a fixed
modulus `0 < k < 1`.  Mathlib does not define them.  Everything in the paper's Lemmas 3.1 and 3.2
uses only the derivative rules `sn' = cn dn`, `cn' = -sn dn`, `dn' = -k² sn cn`, `ℰ' = dn²`
(DLMF 22.13(i), 22.16(ii)) and the two algebraic relations `cn² + sn² = 1`, `dn² = 1 - k² sn²`
(DLMF 22.6.1).  We package these as a structure and prove the paper's identities for any
functions satisfying them.
-/

noncomputable section

set_option linter.unnecessarySeqFocus false

theorem neg_one_pow_sq (m : ℕ) : ((-1 : ℝ) ^ m) ^ 2 = 1 := by
  rw [← pow_mul, mul_comm, pow_mul]; simp

theorem neg_one_pow_succ_mul (m : ℕ) (x : ℝ) : (-1 : ℝ) ^ (m + 1) * x = -((-1) ^ m * x) := by
  rw [pow_succ]; ring

/-- Jacobi data of modulus `k`: four functions `s, c, d, eps : ℝ → ℝ` with the derivative rules
and algebraic relations of `sn`, `cn`, `dn` and Jacobi's epsilon. -/
structure JacobiData where
  k : ℝ
  k_pos : 0 < k
  k_lt_one : k < 1
  s : ℝ → ℝ
  c : ℝ → ℝ
  d : ℝ → ℝ
  eps : ℝ → ℝ
  hs : ∀ p, HasDerivAt s (c p * d p) p
  hc : ∀ p, HasDerivAt c (-(s p * d p)) p
  hd : ∀ p, HasDerivAt d (-(k ^ 2 * s p * c p)) p
  heps : ∀ p, HasDerivAt eps (d p ^ 2) p
  sc : ∀ p, c p ^ 2 + s p ^ 2 = 1
  sd : ∀ p, d p ^ 2 = 1 - k ^ 2 * s p ^ 2

namespace JacobiData

variable (J : JacobiData)

/-- `q = p - ℰ(p)`. -/
def q (p : ℝ) : ℝ := p - J.eps p

/-- `f₁ = cn (ℰ - p) - dn sn`, the Maxwell function. -/
def f1 (p : ℝ) : ℝ := J.c p * (J.eps p - p) - J.d p * J.s p

/-- `β₁ = cn ℰ - dn sn`. -/
def β1 (p : ℝ) : ℝ := J.c p * J.eps p - J.d p * J.s p

/-- `α₁ = cn dn (p - 2ℰ) + sn (dn² + ℰ (p - ℰ))`. -/
def α1 (p : ℝ) : ℝ :=
  J.c p * J.d p * (p - 2 * J.eps p) + J.s p * (J.d p ^ 2 + J.eps p * (p - J.eps p))

/-- `X = sn α₁`. -/
def X (p : ℝ) : ℝ := J.s p * J.α1 p

/-- `ℓ = ℰ q`. -/
def ell (p : ℝ) : ℝ := J.eps p * J.q p

/-- `α = (1 - k²) sn α₁`, the coefficient of `sn² τ` in `J₂`. -/
def α (p : ℝ) : ℝ := (1 - J.k ^ 2) * J.s p * J.α1 p

/-- `β = f₁ β₁`, the coefficient of `cn² τ` in `J₂`. -/
def β (p : ℝ) : ℝ := J.f1 p * J.β1 p

/-- `Γ = ℰ - k² sn cn / dn`. -/
def Γ (p : ℝ) : ℝ := J.eps p - J.k ^ 2 * (J.s p * J.c p) / J.d p

/-! ### Derivatives of the named functions -/

theorem hasDerivAt_q (p : ℝ) : HasDerivAt J.q (J.k ^ 2 * J.s p ^ 2) p := by
  have h := (hasDerivAt_id' p).sub (J.heps p)
  unfold q
  exact h.congr_deriv (by linear_combination (-1) * J.sd p)

theorem hasDerivAt_f1 (p : ℝ) :
    HasDerivAt J.f1 (J.s p * J.d p * J.q p - J.c p * J.d p ^ 2) p := by
  have h := ((J.hc p).mul ((J.heps p).sub (hasDerivAt_id' p))).sub ((J.hd p).mul (J.hs p))
  unfold f1
  exact h.congr_deriv (by simp only [Pi.sub_apply]; unfold q; linear_combination (J.c p) * J.sd p)

theorem hasDerivAt_β1 (p : ℝ) :
    HasDerivAt J.β1 (-(J.s p * J.d p * J.eps p) + J.k ^ 2 * J.s p ^ 2 * J.c p) p := by
  have h := ((J.hc p).mul (J.heps p)).sub ((J.hd p).mul (J.hs p))
  unfold β1
  exact h.congr_deriv (by ring)

theorem hasDerivAt_α1 (p : ℝ) :
    HasDerivAt J.α1
      (2 * J.c p ^ 2 * J.eps p * J.s p * J.k ^ 2 - J.c p ^ 2 * J.s p * J.k ^ 2 * p
        - J.c p * J.d p ^ 3 - J.c p * J.d p * J.eps p ^ 2 + J.c p * J.d p * J.eps p * p
        - 2 * J.c p * J.d p * J.s p ^ 2 * J.k ^ 2 + J.c p * J.d p + J.eps p * J.s p) p := by
  have h := (((J.hc p).mul (J.hd p)).mul ((hasDerivAt_id' p).sub ((J.heps p).const_mul 2))).add
    ((J.hs p).mul (((J.hd p).pow 2).add ((J.heps p).mul ((hasDerivAt_id' p).sub (J.heps p)))))
  unfold α1
  exact h.congr_deriv (by simp only [Pi.sub_apply] <;> norm_num <;> ring)

end JacobiData

end
