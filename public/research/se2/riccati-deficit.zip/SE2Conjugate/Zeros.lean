import SE2Conjugate.Monotone

/-!
# Lemma 3.1(iv), part 2: the zeros of `β₁`

`JacobiPeriodic` adds the values of `sn, cn, ℰ` at the multiples of `K` and the sign of `sn`
and `cn` between them (DLMF 22.4, 22.16(ii)).  With Lemma 3.1(iii) (`β₁' = -sn dn Γ`, `Γ > 0`)
this gives: for `n ≥ 1`, `β₁` has exactly one zero in `(2nK, (2n+1)K)` and none in
`[(2n-1)K, 2nK]`.
-/

noncomputable section

structure JacobiPeriodic extends JacobiInit where
  K : ℝ
  E : ℝ
  K_pos : 0 < K
  E_pos : 0 < E
  E_lt_K : E < K
  s_even : ∀ n : ℕ, s (2 * n * K) = 0
  s_odd : ∀ n : ℕ, s ((2 * n + 1) * K) = (-1) ^ n
  c_even : ∀ n : ℕ, c (2 * n * K) = (-1) ^ n
  c_odd : ∀ n : ℕ, c ((2 * n + 1) * K) = 0
  d_odd : ∀ n : ℕ, d ((2 * n + 1) * K) = Real.sqrt (1 - k ^ 2)
  eps_even : ∀ n : ℕ, eps (2 * n * K) = 2 * n * E
  eps_odd : ∀ n : ℕ, eps ((2 * n + 1) * K) = (2 * n + 1) * E
  /-- `sn` has the sign `(-1)^n` on `(2nK, (2n+2)K)`. -/
  s_sign : ∀ n : ℕ, ∀ p ∈ Set.Ioo (2 * n * K) ((2 * n + 2) * K), 0 < (-1) ^ n * s p
  /-- `cn` has the sign `(-1)^(n+1)` on `((2n+1)K, (2n+3)K)`. -/
  c_sign : ∀ n : ℕ, ∀ p ∈ Set.Ioo ((2 * n + 1) * K) ((2 * n + 3) * K), 0 < (-1) ^ (n + 1) * c p

namespace JacobiPeriodic

variable (J : JacobiPeriodic)

theorem k'_pos : 0 < Real.sqrt (1 - J.k ^ 2) := by
  apply Real.sqrt_pos.mpr
  nlinarith [J.k_pos, J.k_lt_one]

theorem β1_even (n : ℕ) : J.toJacobiData.β1 (2 * n * J.K) = (-1) ^ n * (2 * n * J.E) := by
  show J.c (2 * n * J.K) * J.eps (2 * n * J.K) - J.d (2 * n * J.K) * J.s (2 * n * J.K) = _
  rw [J.s_even, J.c_even, J.eps_even]
  ring

theorem β1_odd (n : ℕ) :
    J.toJacobiData.β1 ((2 * n + 1) * J.K) = -((-1) ^ n * Real.sqrt (1 - J.k ^ 2)) := by
  show J.c ((2 * n + 1) * J.K) * J.eps ((2 * n + 1) * J.K)
      - J.d ((2 * n + 1) * J.K) * J.s ((2 * n + 1) * J.K) = _
  rw [J.s_odd, J.c_odd, J.d_odd]
  ring

/-- The signed function `(-1)^n β₁` is strictly decreasing on `[2nK, (2n+2)K]` for `n ≥ 1`
(and on `[2nK, (2n+2)K] ∩ (0, ∞)` in general). -/
theorem signed_β1_strictAntiOn (n : ℕ) (hn : 1 ≤ n) :
    StrictAntiOn (fun p => (-1) ^ n * J.toJacobiData.β1 p)
      (Set.Icc (2 * n * J.K) ((2 * n + 2) * J.K)) := by
  apply strictAntiOn_of_deriv_neg (convex_Icc _ _)
  · exact (continuousOn_const.mul
      (fun p _ => (J.toJacobiData.hasDerivAt_β1 p).continuousAt.continuousWithinAt))
  · rw [interior_Icc]
    intro x hx
    have hd : HasDerivAt (fun p => (-1) ^ n * J.toJacobiData.β1 p)
        ((-1) ^ n * (-(J.s x * J.d x * J.toJacobiData.Γ x))) x := by
      have := (J.toJacobiData.hasDerivAt_β1 x).const_mul ((-1 : ℝ) ^ n)
      rw [J.toJacobiData.β1_deriv_eq_Γ x (J.d_ne x)] at this
      exact this
    rw [hd.deriv]
    have hxpos : 0 < x := by
      have hK := J.K_pos
      have : (0 : ℝ) < 2 * n * J.K := by
        have : (1 : ℝ) ≤ n := by exact_mod_cast hn
        nlinarith
      linarith [hx.1]
    have hΓ := J.toJacobiInit.Γ_pos hxpos
    have hs := J.s_sign n x hx
    have hdx := J.d_pos x
    have : 0 < ((-1) ^ n * J.s x) * J.d x * J.toJacobiData.Γ x := by positivity
    nlinarith

/-- Existence and uniqueness of the zero `bₙ` of `β₁` in `(2nK, (2n+1)K)`, `n ≥ 1`. -/
theorem exists_unique_β1_zero (n : ℕ) (hn : 1 ≤ n) :
    ∃! b, b ∈ Set.Ioo (2 * n * J.K) ((2 * n + 1) * J.K) ∧ J.toJacobiData.β1 b = 0 := by
  have hK := J.K_pos
  have hanti := J.signed_β1_strictAntiOn n hn
  have hsub : Set.Icc (2 * n * J.K) ((2 * n + 1) * J.K) ⊆ Set.Icc (2 * n * J.K) ((2 * n + 2) * J.K) :=
    Set.Icc_subset_Icc le_rfl (by linarith)
  have hanti' := hanti.mono hsub
  have hlt : 2 * n * J.K < (2 * n + 1) * J.K := by nlinarith
  set g := fun p => (-1) ^ n * J.toJacobiData.β1 p with hg
  have hcont : ContinuousOn g (Set.Icc (2 * n * J.K) ((2 * n + 1) * J.K)) :=
    continuousOn_const.mul
      (fun p _ => (J.toJacobiData.hasDerivAt_β1 p).continuousAt.continuousWithinAt)
  have hga : g (2 * n * J.K) = 2 * n * J.E := by
    rw [hg]; simp only; rw [J.β1_even]; ring_nf; simp
  have hgb : g ((2 * n + 1) * J.K) = -Real.sqrt (1 - J.k ^ 2) := by
    rw [hg]; simp only; rw [J.β1_odd]; ring_nf; simp
  have hpos : 0 < g (2 * n * J.K) := by
    rw [hga]
    have : (1 : ℝ) ≤ n := by exact_mod_cast hn
    nlinarith [J.E_pos]
  have hneg : g ((2 * n + 1) * J.K) < 0 := by rw [hgb]; linarith [J.k'_pos]
  -- existence by the intermediate value theorem on the decreasing function g
  have hmem : (0 : ℝ) ∈ Set.Icc (g ((2 * n + 1) * J.K)) (g (2 * n * J.K)) := ⟨hneg.le, hpos.le⟩
  obtain ⟨b, hb, hgb0⟩ := intermediate_value_Icc' hlt.le hcont hmem
  have hb_open : b ∈ Set.Ioo (2 * n * J.K) ((2 * n + 1) * J.K) := by
    rcases eq_or_lt_of_le hb.1 with h | h
    · exfalso; rw [← h] at hgb0; linarith
    rcases eq_or_lt_of_le hb.2 with h' | h'
    · exfalso; rw [h'] at hgb0; linarith
    exact ⟨h, h'⟩
  have hβ0 : J.toJacobiData.β1 b = 0 := by
    have : (-1 : ℝ) ^ n * J.toJacobiData.β1 b = 0 := hgb0
    rcases mul_eq_zero.mp this with h | h
    · exfalso; exact pow_ne_zero n (by norm_num) h
    · exact h
  refine ⟨b, ⟨hb_open, hβ0⟩, ?_⟩
  rintro b' ⟨hb', hβ'⟩
  apply hanti'.injOn (Set.Ioo_subset_Icc_self hb') (Set.Ioo_subset_Icc_self hb_open)
  show (-1 : ℝ) ^ n * J.toJacobiData.β1 b' = (-1) ^ n * J.toJacobiData.β1 b
  rw [hβ', hβ0]

/-- No zero of `β₁` in `[(2m+1)K, (2m+2)K]`: the signed function is negative at both ends and
strictly decreasing. -/
theorem β1_ne_zero_on_odd_interval (m : ℕ) {p : ℝ}
    (hp : p ∈ Set.Icc ((2 * m + 1) * J.K) ((2 * m + 2) * J.K)) : J.toJacobiData.β1 p ≠ 0 := by
  have hK := J.K_pos
  -- signed function with sign (-1)^m, strictly decreasing on [2mK, (2m+2)K] ∩ (0, ∞)
  have hanti : StrictAntiOn (fun p => (-1) ^ m * J.toJacobiData.β1 p)
      (Set.Icc ((2 * m + 1) * J.K) ((2 * m + 2) * J.K)) := by
    apply strictAntiOn_of_deriv_neg (convex_Icc _ _)
    · exact (continuousOn_const.mul
        (fun p _ => (J.toJacobiData.hasDerivAt_β1 p).continuousAt.continuousWithinAt))
    · rw [interior_Icc]
      intro x hx
      have hd : HasDerivAt (fun p => (-1) ^ m * J.toJacobiData.β1 p)
          ((-1) ^ m * (-(J.s x * J.d x * J.toJacobiData.Γ x))) x := by
        have := (J.toJacobiData.hasDerivAt_β1 x).const_mul ((-1 : ℝ) ^ m)
        rw [J.toJacobiData.β1_deriv_eq_Γ x (J.d_ne x)] at this
        exact this
      rw [hd.deriv]
      have hxpos : 0 < x := by nlinarith [hx.1]
      have hΓ := J.toJacobiInit.Γ_pos hxpos
      have hs := J.s_sign m x ⟨by nlinarith [hx.1], hx.2⟩
      have hdx := J.d_pos x
      have : 0 < ((-1) ^ m * J.s x) * J.d x * J.toJacobiData.Γ x := by positivity
      nlinarith
  have hga : (-1 : ℝ) ^ m * J.toJacobiData.β1 ((2 * m + 1) * J.K) = -Real.sqrt (1 - J.k ^ 2) := by
    rw [J.β1_odd]; ring_nf; simp
  have hgb : (-1 : ℝ) ^ m * J.toJacobiData.β1 ((2 * m + 2) * J.K) = -(2 * (m + 1) * J.E) := by
    have : (2 * m + 2 : ℝ) * J.K = 2 * ((m + 1 : ℕ) : ℝ) * J.K := by push_cast; ring
    rw [this, J.β1_even]; push_cast; ring_nf; simp
  intro h0
  have hmono := hanti.antitoneOn
  have h1 := hmono (Set.left_mem_Icc.mpr (by nlinarith)) hp hp.1
  have h2 := hmono hp (Set.right_mem_Icc.mpr (by nlinarith)) hp.2
  simp only at h1 h2
  rw [h0, mul_zero] at h1 h2
  rw [hga] at h1
  linarith [J.k'_pos]

end JacobiPeriodic

end
