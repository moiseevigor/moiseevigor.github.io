import SE2Conjugate.LargeIndex

/-! The three endpoints of a rotating SE(2) cell. After removing the
half-period shift, each root obeys n D g = f + r/n. A chord estimate for
g first gives distance O(1/n) to its simple zero. Taylor expansion in
that distance then gives the signed correction and an O(1/n²) error.
The bounds below apply simultaneously on compact interior modulus sets. -/

noncomputable section
open Set
namespace JacobiCore.EndpointExpansion

/-- Uniform value and derivative bounds on a quarter-period window. -/
private def Regular (f : JacobiCore → ℝ → ℝ) : Prop :=
  ∀ M : ℝ, 1 ≤ M → ∃ C : ℝ, 1 ≤ C ∧ ∀ J : JacobiCore, J.K ≤ M →
    ∀ x : ℝ, |x| ≤ J.K → ∃ v, HasDerivAt (f J) v x ∧ |f J x| ≤ C ∧ |v| ≤ C

private theorem reg_add {f g} (hf : Regular f) (hg : Regular g) :
    Regular (fun J x => f J x + g J x) := by
  intro M hm
  obtain ⟨A,ha,hf⟩ := hf M hm
  obtain ⟨B,hb,hg⟩ := hg M hm
  refine ⟨A+B,by linarith,?_⟩
  intro J h x hx
  obtain ⟨v,d,a,b⟩ := hf J h x hx
  obtain ⟨w,e,c,t⟩ := hg J h x hx
  exact ⟨_,d.add e,(abs_add_le ..).trans (add_le_add a c),(abs_add_le ..).trans (add_le_add b t)⟩

private theorem reg_sub {f g} (hf : Regular f) (hg : Regular g) :
    Regular (fun J x => f J x - g J x) := by
  intro M hm
  obtain ⟨A,ha,hf⟩ := hf M hm
  obtain ⟨B,hb,hg⟩ := hg M hm
  refine ⟨A+B,by linarith,?_⟩
  intro J h x hx
  obtain ⟨v,d,a,b⟩ := hf J h x hx
  obtain ⟨w,e,c,t⟩ := hg J h x hx
  exact ⟨_,d.sub e,(abs_sub _ _).trans (add_le_add a c),(abs_sub _ _).trans (add_le_add b t)⟩

private theorem reg_mul {f g} (hf : Regular f) (hg : Regular g) :
    Regular (fun J x => f J x * g J x) := by
  intro M hm
  obtain ⟨A,ha,hf⟩ := hf M hm
  obtain ⟨B,hb,hg⟩ := hg M hm
  refine ⟨2*(A*B),by nlinarith [mul_le_mul ha hb zero_le_one (by linarith)],?_⟩
  intro J h x hx
  obtain ⟨v,d,a,b⟩ := hf J h x hx
  obtain ⟨w,e,c,t⟩ := hg J h x hx
  refine ⟨_,d.mul e,?_,?_⟩
  · rw [abs_mul]; nlinarith [mul_le_mul a c (abs_nonneg _) (by linarith)]
  · refine (abs_add_le ..).trans ?_
    rw [abs_mul,abs_mul]
    linarith [mul_le_mul b c (abs_nonneg _) (by linarith),
      mul_le_mul a t (abs_nonneg _) (by linarith)]

private theorem reg_const (c : ℝ) : Regular (fun _ _ => c) :=
  fun _ _ => ⟨1+|c|,by linarith [abs_nonneg c],fun _ _ x _ =>
    ⟨0,hasDerivAt_const x c,by linarith,by simp; positivity⟩⟩

private theorem reg_K : Regular (fun J _ => J.K) := by
  intro M hm; refine ⟨M,hm,?_⟩; intro J h x _
  exact ⟨0,hasDerivAt_const x _,by simpa [abs_of_pos J.K_pos] using h,by simpa using (zero_le_one.trans hm)⟩

private theorem reg_E : Regular (fun J _ => J.E) := by
  intro M hm; refine ⟨M,hm,?_⟩; intro J h x _
  exact ⟨0,hasDerivAt_const x _,by simpa [abs_of_pos J.E_pos] using J.E_lt_K.le.trans h,by simpa using (zero_le_one.trans hm)⟩

private theorem reg_x : Regular (fun _ x => x) := by
  intro M hm; exact ⟨M,hm,fun J h x hx => ⟨1,hasDerivAt_id x,hx.trans h,by simpa using hm⟩⟩

private theorem reg_s : Regular (fun J => J.s) := by
  intro _ _; refine ⟨1,le_rfl,?_⟩; intro J _ x _
  exact ⟨_,J.hs x,J.abs_s_le_one x,by rw [abs_mul]; exact mul_le_one₀ (J.abs_c_le_one _) (abs_nonneg _) (J.abs_d_le_one _)⟩

private theorem reg_c : Regular (fun J => J.c) := by
  intro _ _; refine ⟨1,le_rfl,?_⟩; intro J _ x _
  exact ⟨_,J.hc x,J.abs_c_le_one x,by rw [abs_neg,abs_mul]; exact mul_le_one₀ (J.abs_s_le_one _) (abs_nonneg _) (J.abs_d_le_one _)⟩

private theorem reg_d : Regular (fun J => J.d) := by
  intro _ _; refine ⟨1,le_rfl,?_⟩; intro J _ x _
  refine ⟨_,J.hd x,J.abs_d_le_one x,?_⟩
  rw [abs_neg,abs_mul,abs_mul,abs_of_nonneg (sq_nonneg _)]
  apply mul_le_one₀ _ (abs_nonneg _) (J.abs_c_le_one _)
  apply mul_le_one₀ _ (abs_nonneg _) (J.abs_s_le_one _)
  nlinarith [J.k_pos,J.k_lt_one,sq_nonneg (1-J.k),mul_pos J.k_pos (sub_pos.mpr J.k_lt_one)]

private theorem reg_e : Regular (fun J => J.eps) := by
  intro M hm; refine ⟨M,hm,?_⟩; intro J h x hx
  obtain ⟨l,r⟩ := abs_le.mp hx
  have a := J.eps_strictMono.monotone l
  have b := J.eps_strictMono.monotone r
  rw [JacobiCore.Addition.epsilon_neg] at a
  change -J.E ≤ _ at a
  change _ ≤ J.E at b
  refine ⟨_,J.heps x,abs_le.mpr ⟨by linarith [J.E_lt_K],by linarith [J.E_lt_K]⟩,?_⟩
  rw [abs_pow]; exact (pow_le_one₀ (abs_nonneg _) (J.abs_d_le_one _)).trans hm

private theorem window_lip {f : ℝ → ℝ} {K C : ℝ}
    (h : ∀ x, |x| ≤ K → ∃ v, HasDerivAt f v x ∧ |v| ≤ C)
    {x y : ℝ} (hx : |x| ≤ K) (hy : |y| ≤ K) :
    |f x-f y| ≤ C*|x-y| := by
  let d := deriv f
  have hd (z : ℝ) (hz : z ∈ Icc (-K) K) : HasDerivAt f (d z) z ∧ |d z| ≤ C := by
    obtain ⟨v,hv,hb⟩ := h z (abs_le.mpr hz)
    simpa [d,hv.deriv] using And.intro hv hb
  simpa [Real.norm_eq_abs] using
    (convex_Icc (-K) K).norm_image_sub_le_of_norm_hasDerivWithin_le
      (fun z hz => (hd z hz).1.hasDerivWithinAt)
      (fun z hz => by simpa [Real.norm_eq_abs] using (hd z hz).2)
      (abs_le.mp hy) (abs_le.mp hx)

private theorem controls {f} (h : Regular f) {M : ℝ} (hm : 1≤M) :
    ∃ C : ℝ, 1≤C ∧ ∀ J : JacobiCore, J.K≤M → ∀ x, |x|≤J.K →
      |f J x|≤C ∧ ∀ y, |y|≤J.K → |f J x-f J y|≤C*|x-y| := by
  obtain ⟨C,hC,d⟩ := h M hm
  refine ⟨C,hC,?_⟩
  intro J hJ x hx
  obtain ⟨_,_,v,_⟩ := d J hJ x hx
  refine ⟨v,fun y hy => window_lip (fun t ht => ?_) hx hy⟩
  obtain ⟨v,hv,_,hb⟩ := d J hJ t ht
  exact ⟨v,hv,hb⟩

inductive Edge | maxwell | beta | alpha

private def base (e : Edge) (J : JacobiCore) : ℝ :=
  match e with | .maxwell => -J.K | .beta => J.K | .alpha => 0
private def g (e : Edge) (J : JacobiCore) := match e with
  | .alpha => J.s | _ => J.c
private def dg (e : Edge) (J : JacobiCore) (x : ℝ) := match e with
  | .alpha => J.c x * J.d x | _ => 0-J.s x * J.d x
private def weight (e : Edge) (J : JacobiCore) := match e with
  | .maxwell => 2*(J.K-J.E) | .beta => 2*J.E | .alpha => 4*J.E*(J.K-J.E)
private def first (e : Edge) (J : JacobiCore) (x : ℝ) := match e with
  | .maxwell => J.c x*(J.eps x-x)-J.d x*J.s x
  | .beta => J.d x*J.s x-J.c x*J.eps x
  | .alpha => 2*(2*J.E-J.K)*(J.c x*J.d x) -
      2*J.s x*(J.E*(x-J.eps x)+(J.K-J.E)*J.eps x)
private def last (e : Edge) (J : JacobiCore) (x : ℝ) := match e with
  | .alpha => 0-(J.c x*J.d x*(x-2*J.eps x)+
      J.s x*(J.d x*J.d x+J.eps x*(x-J.eps x)))
  | _ => 0

local macro "endpoint_reg" : tactic => `(tactic|
  repeat' first | exact reg_s | exact reg_c | exact reg_d | exact reg_e | exact reg_x
                | exact reg_K | exact reg_E | apply reg_const
                | apply reg_sub | apply reg_add | apply reg_mul)

private theorem reg_first (e : Edge) : Regular (first e) := by cases e <;> unfold first <;> endpoint_reg
private theorem reg_last (e : Edge) : Regular (last e) := by cases e <;> unfold last <;> endpoint_reg
private theorem reg_dg (e : Edge) : Regular (dg e) := by cases e <;> unfold dg <;> endpoint_reg

private theorem deriv_g (e : Edge) (J : JacobiCore) (x : ℝ) :
    HasDerivAt (g e J) (dg e J x) x := by
  cases e <;> simp only [g,dg,zero_sub] <;> first | exact J.hs x | exact J.hc x

private theorem base_mem (e : Edge) (J : JacobiCore) : |base e J|≤J.K := by
  cases e <;> simp [base,abs_of_pos J.K_pos,J.K_pos.le]

private theorem g_base (e : Edge) (J : JacobiCore) : g e J (base e J)=0 := by
  cases e <;> simp [g,base,(Addition.even_cd J J.K).1,J.cK,J.s0]

private theorem g_taylor (e : Edge) {M : ℝ} (hm : 1≤M) :
    ∃ T : ℝ, 1≤T ∧ ∀ J : JacobiCore, J.K≤M → ∀ x, |x|≤J.K →
    |g e J x-dg e J (base e J)*(x-base e J)| ≤ T*|x-base e J|^2 := by
  obtain ⟨T,hT,b⟩ := controls (reg_dg e) hm
  refine ⟨T,hT,?_⟩; intro J h x hx
  let a := base e J
  have ha := base_mem e J
  let f := fun z => g e J z-dg e J a*(z-a)
  have hd (z : ℝ) : HasDerivAt f (dg e J z-dg e J a) z := by
    convert (deriv_g e J z).sub (((hasDerivAt_id z).sub_const a).const_mul (dg e J a)) using 1 <;> first | rfl | simp
  have bound (z : ℝ) (hz : z ∈ uIcc a x) : |dg e J z - dg e J a| ≤ T*|x-a| := by
    have sub := uIcc_subset_Icc (abs_le.mp ha) (abs_le.mp hx) hz
    exact ((b J h z (abs_le.mpr sub)).2 a ha).trans
      (mul_le_mul_of_nonneg_left (by rw [abs_sub_comm z a,abs_sub_comm x a]; simpa [Real.dist_eq] using Real.dist_left_le_of_mem_uIcc hz) (by linarith))
  have line := (convex_uIcc a x).norm_image_sub_le_of_norm_hasDerivWithin_le
    (fun z _ => (hd z).hasDerivWithinAt) (fun z hz => by simpa [Real.norm_eq_abs] using bound z hz)
    (left_mem_uIcc : a ∈ uIcc a x) (right_mem_uIcc : x ∈ uIcc a x)
  simpa [f,a,g_base,Real.norm_eq_abs,pow_two,mul_assoc] using line

private theorem sn_inverse (J : JacobiCore) {x : ℝ} (hx : |x|≤J.K) :
    |x|≤J.K*|J.s x| := by
  have h := LargeIndex.sn_chord J ⟨abs_nonneg x,hx⟩
  refine h.trans (mul_le_mul_of_nonneg_left ?_ J.K_pos.le)
  rcases le_or_gt 0 x with hp|hn
  · rw [abs_of_nonneg hp]; exact le_abs_self _
  · rw [abs_of_neg hn,J.s_neg]; exact neg_le_abs _

private theorem cn_inverse (J : JacobiCore) {x : ℝ} (hx : x ∈ Icc 0 J.K) :
    |x-J.K|≤J.K/J.d J.K*|J.c x| := by
  have h := sn_inverse J (x := x-J.K) (abs_le.mpr ⟨by linarith [hx.1],by linarith [hx.2,J.K_pos]⟩)
  have v := (J.quarter_values (x-J.K)).2
  rw [sub_add_cancel] at v
  have ha := congrArg abs v
  simp only [abs_div,abs_neg,abs_mul,abs_of_pos (J.d_pos _)] at ha
  have hv := (eq_div_iff (J.d_pos _).ne').mp ha
  rw [div_mul_eq_mul_div,le_div_iff₀ (J.d_pos J.K)]
  calc
    _ ≤ (J.K*|J.s (x-J.K)|)*J.d J.K := mul_le_mul_of_nonneg_right h (J.d_pos _).le
    _ = J.K*(|J.c x| *J.d (x-J.K)) := by rw [hv]; ring
    _ ≤ J.K*(|J.c x| *1) := by
      exact mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left ((le_abs_self _).trans (J.abs_d_le_one _)) (abs_nonneg _)) J.K_pos.le
    _ = _ := by ring

/-- A first-order zero of a leading coefficient localizes a perturbed root
to second order. All bounds here are finite-index bounds. -/
private theorem perturb {N D v t G f f₀ r M T H R : ℝ}
    (hn : 1≤N) (hd : 0<D) (hv : v≠0) (hm : 1≤M) (ht : 0≤T) (hh : 0≤H) (hr : 0≤R)
    (hdm : D≤M) (hinv : 1/D≤M) (hinv' : 1/(D*|v|)≤M)
    (chord : |t|≤M*|G|) (tay : |G-v*t|≤T*|t|^2)
    (hval : |f|≤H) (hdiff : |f-f₀|≤H*|t|) (rval : |r|≤R)
    (eqn : N*D*G=f+r/N) :
    let Z := M*(H+R)*M
    |t-f₀/(N*D*v)| ≤ (M*T*Z^2+H*Z+R)*M/N^2 := by
  let Z := M*(H+R)*M
  have hN : 0<N := by linarith
  have hM : 0≤M := by linarith
  have hw : 0<D*|v| := mul_pos hd (abs_pos.mpr hv)
  have absEq := congrArg abs eqn
  rw [abs_mul,abs_mul,abs_of_pos hN,abs_of_pos hd] at absEq
  have b : N*D*|G|≤H+R := by
    rw [absEq]; apply (abs_add_le ..).trans
    rw [abs_div,abs_of_pos hN]
    exact add_le_add hval ((div_le_self (abs_nonneg _) hn).trans rval)
  have z : N*|t|≤Z := calc
    _ ≤ N*(M*|G|) := mul_le_mul_of_nonneg_left chord hN.le
    _ = M*(N*D*|G|)*(1/D) := by field_simp
    _ ≤ M*(H+R)*M := by gcongr
  have iden : N^2*(D*v)*(t-f₀/(N*D*v)) =
      D*(N^2*(v*t-G))+N*(f-f₀)+r := by
    field_simp [hN.ne',hd.ne',hv] at eqn ⊢
    linear_combination (norm := ring) eqn
  let B := M*T*Z^2+H*Z+R
  have bound : |N^2*(D*v)*(t-f₀/(N*D*v))|≤B := by
    rw [iden]
    refine (abs_add_le ..).trans (add_le_add ?_ rval)
    refine (abs_add_le ..).trans (add_le_add ?_ ?_)
    · rw [abs_mul,abs_mul,abs_of_pos hd,abs_of_nonneg (sq_nonneg N),abs_sub_comm]
      calc
        _ ≤ M*(N^2*(T*|t|^2)) := by gcongr
        _ = M*T*(N*|t|)^2 := by ring
        _ ≤ _ := by gcongr
    · rw [abs_mul,abs_of_pos hN]
      calc
        _ ≤ N*(H*|t|) := by gcongr
        _ = H*(N*|t|) := by ring
        _ ≤ _ := by gcongr
  rw [abs_mul,abs_mul,abs_of_nonneg (sq_nonneg N),abs_mul,abs_of_pos hd] at bound
  apply (le_div_iff₀ (sq_pos_of_pos hN)).mpr
  calc
    _ = (N^2*(D*|v|)*|t-f₀/(N*D*v)|)*(1/(D*|v|)) := by field_simp
    _ ≤ B*M := by gcongr

/-- The shifted alpha root can be specified by its coefficient equation
and its enclosing window. Uniqueness identifies it with the indexed root. -/
private def coefficient (e : Edge) (J : JacobiCore) : ℝ → ℝ := match e with
  | .maxwell => J.toJacobiData.f1 | .beta => J.toJacobiData.β1 | .alpha => J.toJacobiData.α1

private theorem shifted (e : Edge) (J : JacobiCore) (n : ℕ) {x : ℝ}
    (hn : 0<(n:ℝ)) (zero : coefficient e J (x+2*n*J.K)=0) :
    (n:ℝ)*weight e J*g e J x = first e J x + last e J x/n := by
  have sign : (-1:ℝ)^n ≠ 0 := pow_ne_zero _ (by norm_num)
  let p := x+2*n*J.K
  cases e with
  | maxwell =>
    change J.c p*(J.eps p-p)-J.d p*J.s p=0 at zero
    dsimp only [p] at zero
    rw [J.c_shift_n,J.d_shift_n,J.s_shift_n,J.epsilon_periods] at zero
    simp only [weight,g,first,last,zero_div,add_zero]
    apply mul_left_cancel₀ sign
    linear_combination -zero
  | beta =>
    change J.c p*J.eps p-J.d p*J.s p=0 at zero
    dsimp only [p] at zero
    rw [J.c_shift_n,J.d_shift_n,J.s_shift_n,J.epsilon_periods] at zero
    simp only [weight,g,first,last,zero_div,add_zero]
    apply mul_left_cancel₀ sign
    linear_combination zero
  | alpha =>
    change J.c p*J.d p*(p-2*J.eps p)+J.s p*(J.d p^2+J.eps p*(p-J.eps p))=0 at zero
    dsimp only [p] at zero
    rw [J.c_shift_n,J.d_shift_n,J.s_shift_n,J.epsilon_periods] at zero
    simp only [weight,g,first,last]
    field_simp [hn.ne']
    apply mul_left_cancel₀ sign
    linear_combination zero

/-- The three indexed zeros in the paper's cell n=m+1. -/
def endpoint (e : Edge) (J : JacobiCore) (m : ℕ) : ℝ :=
  let F := J.toJacobiFull
  match e with
  | .maxwell => F.pL m
  | .beta => F.bR m
  | .alpha => if 2*J.E<J.K then F.eL m else if J.K<2*J.E then F.eR m
      else (2*(m:ℝ)+2)*J.K

private def window (e : Edge) (J : JacobiCore) (x : ℝ) : Prop := match e with
  | .maxwell => x ∈ Icc (-J.K) 0
  | .beta => x ∈ Icc 0 J.K
  | .alpha => |x|≤J.K

private theorem placement (e : Edge) (J : JacobiCore) (m : ℕ) :
    let p := endpoint e J m
    window e J (p-(2*(m:ℝ)+2)*J.K) ∧ coefficient e J p=0 := by
  let F := J.toJacobiFull
  have l := F.pL_mem m
  have r := F.bR_mem m
  change (2*(m:ℝ)+1)*J.K < F.pL m ∧ F.pL m < (2*(m:ℝ)+2)*J.K at l
  change (2*(m:ℝ)+2)*J.K < F.bR m ∧ F.bR m < (2*(m:ℝ)+3)*J.K at r
  cases e with
  | maxwell => exact ⟨⟨by dsimp [endpoint,window,F] at *; linarith [l.1], by dsimp [endpoint,window,F] at *; linarith [l.2]⟩,F.f1_pL m⟩
  | beta => exact ⟨⟨by dsimp [endpoint,window,F] at *; linarith [r.1],by dsimp [endpoint,window,F] at *; linarith [r.2]⟩,F.β1_bR m⟩
  | alpha =>
    change |(if _ then F.eL m else if _ then F.eR m else _) - _|≤J.K ∧ _
    by_cases h : 2*J.E<J.K
    · simp only [endpoint,coefficient,if_pos h]
      have s := (F.eL_lt_iff m).mpr h
      have t := F.pL_le_eL m
      change F.eL m < (2*(m:ℝ)+2)*J.K at s
      exact ⟨abs_le.mpr ⟨by linarith [l.1],by linarith [J.K_pos]⟩,F.α1_eL_of_lt m s⟩
    · by_cases h' : J.K<2*J.E
      · simp only [endpoint,coefficient,if_neg h,if_pos h']
        have s := (F.eR_gt_iff m).mpr h'
        have t := F.eR_le_bR m
        change (2*(m:ℝ)+2)*J.K < F.eR m at s
        exact ⟨abs_le.mpr ⟨by linarith [J.K_pos],by linarith [r.2]⟩,F.α1_eR_of_gt m s⟩
      · have eq : 2*J.E=J.K := by linarith
        simp only [endpoint,coefficient,if_neg h,if_neg h',sub_self,abs_zero]
        have sign := F.signed_α1_2nK m
        change (-1:ℝ)^m*J.toJacobiData.α1 ((2*(m:ℝ)+2)*J.K)=_* (2*J.E-J.K) at sign
        rw [eq,sub_self,mul_zero] at sign
        exact ⟨J.K_pos.le,(mul_eq_zero.mp sign).resolve_left (pow_ne_zero _ (by norm_num))⟩

private def Dval (e : Edge) (K E : ℝ) := match e with
  | .maxwell => 2*(K-E) | .beta => 2*E | .alpha => 4*E*(K-E)
private def speed (e : Edge) (d : ℝ) := match e with | .alpha => 1 | _ => d
private def capacity (e : Edge) (K E d : ℝ) :=
  let D := Dval e K E
  max 1 (max K (max (K/d) (max D (max (1/D) (1/(D*speed e d))))))

private theorem weight_eq (e : Edge) (J : JacobiCore) : Dval e J.K J.E=weight e J := by cases e <;> rfl
private theorem weight_pos (e : Edge) (J : JacobiCore) : 0<weight e J := by
  have := J.E_pos; have := sub_pos.mpr J.E_lt_K; cases e <;> dsimp [weight] <;> positivity

private theorem speed_eq (e : Edge) (J : JacobiCore) :
    |dg e J (base e J)|=speed e (J.d J.K) := by
  cases e <;> simp [speed,dg,base,J.s_neg,J.sK,J.c0,J.d0,(Addition.even_cd J J.K).2,abs_of_pos (J.d_pos _)]

/-- Coefficients of 1/n in the three indexed offsets. -/
def correction (e : Edge) (K E : ℝ) := match e with
  | .maxwell => 1/(2*(K-E))
  | .beta => -(1/(2*E))
  | .alpha => (2*E-K)/(2*E*(K-E))

private theorem coefficient_ratio (e : Edge) (J : JacobiCore) (N : ℝ) (hn : 0<N) :
    first e J (base e J)/(N*weight e J*dg e J (base e J))=correction e J.K J.E/N := by
  have d := (J.d_pos J.K).ne'
  have E := J.E_pos.ne'
  have Q := (sub_pos.mpr J.E_lt_K).ne'
  cases e <;> simp [first,base,weight,dg,correction,J.s_neg,J.sK,J.cK,J.s0,J.c0,J.d0,
      (Addition.even_cd J J.K).1,(Addition.even_cd J J.K).2] <;> field_simp
  ring

private theorem estimate (e : Edge) {M : ℝ} (hm : 1≤M) :
    ∃ C : ℝ, 0<C ∧ ∀ J : JacobiCore, capacity e J.K J.E (J.d J.K)≤M →
    ∀ m : ℕ, let N := (m:ℝ)+1
      |endpoint e J m - 2*N*J.K - base e J - correction e J.K J.E/N|≤C/N^2 := by
  obtain ⟨T,hT,ht⟩ := g_taylor e hm
  obtain ⟨H,hH,hf⟩ := controls (reg_first e) hm
  obtain ⟨R,hR,hr⟩ := controls (reg_last e) hm
  let Z := M*(H+R)*M
  refine ⟨(M*T*Z^2+H*Z+R)*M,by dsimp [Z]; positivity,?_⟩
  intro J cap m
  simp only [capacity,max_le_iff,weight_eq,← speed_eq] at cap
  obtain ⟨_,hK,hKd,hD,hi,hi'⟩ := cap
  let N := (m:ℝ)+1
  let x := endpoint e J m - 2*N*J.K
  let a := base e J
  have hn : 1≤N := by dsimp [N]; linarith [Nat.cast_nonneg (α := ℝ) m]
  have hN : 0<N := by linarith
  have loc := placement e J m
  have win : window e J x := by
    dsimp [x,N]; rw [show 2*((m:ℝ)+1)=2*m+2 by ring]; exact loc.1
  have hx : |x|≤J.K := by
    cases e <;> simp only [window] at win
    · exact abs_le.mpr ⟨win.1,win.2.trans J.K_pos.le⟩
    · exact abs_le.mpr ⟨(neg_nonpos.mpr J.K_pos.le).trans win.1,win.2⟩
    · exact win
  have chord : |x-a|≤M*|g e J x| := by
    cases e with
    | beta => exact (cn_inverse J win).trans (mul_le_mul_of_nonneg_right hKd (abs_nonneg _))
    | alpha => simpa [a,base,g] using (sn_inverse J hx).trans (mul_le_mul_of_nonneg_right hK (abs_nonneg _))
    | maxwell =>
      have v := cn_inverse J (x := -x) ⟨by linarith [win.2],by linarith [win.1]⟩
      rw [(Addition.even_cd J x).1] at v
      change |x- -J.K|≤M*|J.c x|
      rw [show x- -J.K = -(-x-J.K) by ring,abs_neg]
      exact v.trans (mul_le_mul_of_nonneg_right hKd (abs_nonneg _))
  have zn : coefficient e J (x+2*((m+1:ℕ):ℝ)*J.K)=0 := by
    rw [show x+2*((m+1:ℕ):ℝ)*J.K=endpoint e J m by dsimp [x,N]; push_cast; ring]; exact loc.2
  have eqn := shifted e J (m+1) (by positivity) zn
  have hv : dg e J a ≠ 0 := by
    have pos : 0<speed e (J.d J.K) := by cases e <;> simp [speed,J.d_pos]
    exact abs_pos.mp ((speed_eq e J).symm ▸ pos)
  have v := perturb hn (weight_pos e J) hv hm (zero_le_one.trans hT) (zero_le_one.trans hH)
    (zero_le_one.trans hR) hD hi hi' chord (ht J hK x hx)
    (hf J hK x hx).1 ((hf J hK x hx).2 a (base_mem e J)) (hr J hK x hx).1
    (by simpa only [Nat.cast_add,Nat.cast_one] using eqn)
  rw [coefficient_ratio e J N hN] at v
  exact v
end JacobiCore.EndpointExpansion

namespace JacobiCore.EndpointExpansion
/-- The middle endpoint is the unique alpha₁ zero between the
Maxwell and beta₁ endpoints, including at K=2E. -/
theorem alpha_endpoint_spec (J : JacobiCore) (m : ℕ) :
    let F := J.toJacobiFull
    let a := endpoint .alpha J m
    a ∈ Icc (F.pL m) (F.bR m) ∧ J.toJacobiData.α1 a=0 ∧
      ∀ p ∈ Icc (F.pL m) (F.bR m), J.toJacobiData.α1 p=0 → p=a := by
  let F := J.toJacobiFull
  let a := endpoint .alpha J m
  have h0 : J.toJacobiData.α1 a=0 := (placement .alpha J m).2
  have hl := F.pL_mem m
  have hr := F.bR_mem m
  have ha : a ∈ Icc (F.pL m) (F.bR m) := by
    dsimp [a,endpoint]
    split_ifs
    · exact ⟨F.pL_le_eL m,(F.eL_le m).trans hr.1.le⟩
    · exact ⟨hl.2.le.trans (F.eR_ge m),F.eR_le_bR m⟩
    · exact ⟨hl.2.le,hr.1.le⟩
  have end_le := hr.2.le.trans (F.pL_succ_mem m).1.le
  exact ⟨ha,h0,fun p hp hz => F.α1_zero_unique m ⟨hp.1,hp.2.trans end_le⟩
    ⟨ha.1,ha.2.trans end_le⟩ hz h0⟩

open JacobiConcrete
private theorem compact_edge (e : Edge) {S : Set ℝ} (hs : IsCompact S) (sub : S ⊆ Ioo (0:ℝ) 1) :
    ∃ C : ℝ, 0<C ∧ ∀ k (hk : k ∈ S) (m : ℕ),
      let J := core k (sub hk).1 (sub hk).2
      let N := (m:ℝ)+1
      |endpoint e J m-2*N*J.K-base e J-correction e J.K J.E/N|≤C/N^2 := by
  let cap := fun k : ℝ => capacity e (JacobiConcrete.K k) (secondIntegral k (Real.pi/2)) (Real.sqrt (1-k^2))
  have cont : ContinuousOn cap S := by
    intro k hk
    have hi := sub hk
    let J := core k hi.1 hi.2
    have hK := (hasDerivAt_K k hi.1 hi.2).continuousAt
    have hE := (hasDerivAt_completeSecond k hi.1 hi.2).continuousAt
    have d : Real.sqrt (1-k^2) ≠ 0 := by
      exact (Real.sqrt_pos.mpr (by nlinarith [hi.1,hi.2,mul_pos hi.1 (sub_pos.mpr hi.2)])).ne'
    have he : secondIntegral k (Real.pi/2)=J.E := (full_E k hi.1 hi.2).symm
    have den : Dval e (JacobiConcrete.K k) (secondIntegral k (Real.pi/2)) ≠ 0 := by
      rw [he]; change Dval e J.K J.E ≠ 0; rw [weight_eq]; exact (weight_pos e J).ne'
    apply ContinuousAt.continuousWithinAt
    cases e <;> simp only [cap,capacity,Dval,speed,mul_one] at den ⊢ <;>
      fun_prop (disch := first | assumption | exact mul_ne_zero den d)
  obtain ⟨B,hB⟩ := hs.bddAbove_image cont
  obtain ⟨C,hC,hbound⟩ := estimate e (le_max_left 1 B)
  refine ⟨C,hC,?_⟩; intro k hk m
  apply hbound
  let J := core k (sub hk).1 (sub hk).2
  change capacity e J.K J.E (J.d J.K) ≤ _
  rw [J.dK]
  have he : J.E=secondIntegral k (Real.pi/2) := full_E k (sub hk).1 (sub hk).2
  rw [he]
  exact (hB (show cap k ∈ cap '' S from ⟨k,hk,rfl⟩)).trans (le_max_right ..)

/-- The three expansions in Theorem 5.1(ii), with a single error constant
on any compact interior modulus set and for every cell n=m+1 ≥ 1. -/
theorem compact_three_endpoints {S : Set ℝ} (hs : IsCompact S) (sub : S ⊆ Ioo (0:ℝ) 1) :
    ∃ C : ℝ, 0<C ∧ ∀ k (hk : k ∈ S) (m : ℕ),
      let J := core k (sub hk).1 (sub hk).2
      let F := J.toJacobiFull
      let n := (m:ℝ)+1
      |F.pL m-((2*n-1)*J.K+1/(2*n*(J.K-J.E)))|≤C/n^2 ∧
      |F.bR m-((2*n+1)*J.K-1/(2*n*J.E))|≤C/n^2 ∧
      |endpoint .alpha J m-(2*n*J.K+(2*J.E-J.K)/(2*n*J.E*(J.K-J.E)))|≤C/n^2 := by
  obtain ⟨A,hA,a⟩ := compact_edge .maxwell hs sub
  obtain ⟨B,hB,b⟩ := compact_edge .beta hs sub
  obtain ⟨D,hD,d⟩ := compact_edge .alpha hs sub
  refine ⟨A+B+D,by positivity,?_⟩; intro k hk m
  let J := core k (sub hk).1 (sub hk).2
  let n := (m:ℝ)+1
  have hn : n≠0 := by dsimp [n]; positivity
  have E := J.E_pos.ne'
  have Q := (sub_pos.mpr J.E_lt_K).ne'
  have h₁ := a k hk m
  have h₂ := b k hk m
  have h₃ := d k hk m
  change |J.toJacobiFull.pL m-2*n*J.K- -J.K-(1/(2*(J.K-J.E)))/n|≤A/n^2 at h₁
  change |J.toJacobiFull.bR m-2*n*J.K-J.K-(-(1/(2*J.E)))/n|≤B/n^2 at h₂
  change |endpoint .alpha J m-2*n*J.K-0-((2*J.E-J.K)/(2*J.E*(J.K-J.E)))/n|≤D/n^2 at h₃
  rw [show J.toJacobiFull.pL m-2*n*J.K- -J.K-(1/(2*(J.K-J.E)))/n =
      J.toJacobiFull.pL m-((2*n-1)*J.K+1/(2*n*(J.K-J.E))) by field_simp; ring] at h₁
  rw [show J.toJacobiFull.bR m-2*n*J.K-J.K-(-(1/(2*J.E)))/n =
      J.toJacobiFull.bR m-((2*n+1)*J.K-1/(2*n*J.E)) by field_simp; ring] at h₂
  rw [show endpoint .alpha J m-2*n*J.K-0-((2*J.E-J.K)/(2*J.E*(J.K-J.E)))/n =
      endpoint .alpha J m-(2*n*J.K+(2*J.E-J.K)/(2*n*J.E*(J.K-J.E))) by field_simp; ring] at h₃
  exact ⟨h₁.trans (div_le_div_of_nonneg_right (by linarith) (sq_nonneg n)),
    h₂.trans (div_le_div_of_nonneg_right (by linarith) (sq_nonneg n)),
    h₃.trans (div_le_div_of_nonneg_right (by linarith) (sq_nonneg n))⟩
end JacobiCore.EndpointExpansion
