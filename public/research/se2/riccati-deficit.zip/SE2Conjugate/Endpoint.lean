import SE2Conjugate.Construction

/-!
# Rotating endpoint trajectories and determinant factor
The endpoint formulas solve the horizontal control system, with both rotation signs.
The scalar prefactor is nonzero everywhere on the rotating stratum.
This does NOT yet prove the full parameter differential or its determinant.
-/
noncomputable section
namespace JacobiFull
variable (J : JacobiFull)

def rotationAngle (u : ℝ) : ℝ := Real.arcsin (J.k * J.s u)
def terminalPhase (psi t : ℝ) : ℝ := psi + t / J.k
def endpointTheta (psi t : ℝ) : ℝ := J.rotationAngle psi - J.rotationAngle (J.terminalPhase psi t)
def endpointW (psi t : ℝ) : ℝ := t / J.k + J.eps psi - J.eps (J.terminalPhase psi t)
def endpointX (sigma psi t : ℝ) : ℝ :=
  sigma * J.k * (J.d psi * (J.c psi - J.c (J.terminalPhase psi t)) + J.s psi * J.endpointW psi t)
def endpointY (sigma psi t : ℝ) : ℝ :=
  sigma * (J.k ^ 2 * J.s psi * (J.c psi - J.c (J.terminalPhase psi t)) - J.d psi * J.endpointW psi t)

theorem modulus_sine_mem (u : ℝ) : J.k * J.s u ∈ Set.Ioo (-1 : ℝ) 1 := by
  have hk : J.k ^ 2 < 1 := by nlinarith [J.k_pos, J.k_lt_one]
  have hs : J.s u ^ 2 ≤ 1 := by nlinarith [J.sc u, sq_nonneg (J.c u)]
  have hprod : (J.k * J.s u) ^ 2 < 1 := by
    nlinarith [mul_nonneg (sq_nonneg J.k) (sub_nonneg.mpr hs)]
  constructor <;> nlinarith [sq_nonneg (J.k * J.s u + 1), sq_nonneg (J.k * J.s u - 1)]

theorem sqrt_rotation (u : ℝ) : Real.sqrt (1 - (J.k * J.s u) ^ 2) = J.d u := by
  have he : 1 - (J.k * J.s u) ^ 2 = J.d u ^ 2 := by nlinarith [J.sd u]
  rw [he, Real.sqrt_sq (J.d_pos u).le]

theorem sin_rotationAngle (u : ℝ) : Real.sin (J.rotationAngle u) = J.k * J.s u :=
  Real.sin_arcsin (J.modulus_sine_mem u).1.le (J.modulus_sine_mem u).2.le

theorem cos_rotationAngle (u : ℝ) : Real.cos (J.rotationAngle u) = J.d u := by
  rw [rotationAngle, Real.cos_arcsin, J.sqrt_rotation]

theorem hasDerivAt_rotationAngle (u : ℝ) : HasDerivAt J.rotationAngle (J.k * J.c u) u := by
  have h := (Real.hasDerivAt_arcsin (J.modulus_sine_mem u).1.ne' (J.modulus_sine_mem u).2.ne).comp u
    ((J.hs u).const_mul J.k)
  refine h.congr_deriv ?_
  rw [J.sqrt_rotation]
  field_simp [(J.d_pos u).ne']

theorem endpointTheta_sin (psi t : ℝ) :
    Real.sin (J.endpointTheta psi t) = J.k *
      (J.s psi * J.d (J.terminalPhase psi t) - J.d psi * J.s (J.terminalPhase psi t)) := by
  rw [endpointTheta, Real.sin_sub, J.sin_rotationAngle, J.sin_rotationAngle,
    J.cos_rotationAngle, J.cos_rotationAngle]
  ring

theorem endpointTheta_cos (psi t : ℝ) :
    Real.cos (J.endpointTheta psi t) = J.k ^ 2 * J.s psi * J.s (J.terminalPhase psi t) +
      J.d psi * J.d (J.terminalPhase psi t) := by
  rw [endpointTheta, Real.cos_sub, J.sin_rotationAngle, J.sin_rotationAngle,
    J.cos_rotationAngle, J.cos_rotationAngle]
  ring

theorem hasDerivAt_terminalPhase (psi t : ℝ) : HasDerivAt (J.terminalPhase psi) (1 / J.k) t :=
  ((hasDerivAt_id' t).div_const J.k).const_add psi

theorem hasDerivAt_endpointTheta (psi t : ℝ) :
    HasDerivAt (J.endpointTheta psi) (-J.c (J.terminalPhase psi t)) t := by
  have h := ((J.hasDerivAt_rotationAngle _).comp t (J.hasDerivAt_terminalPhase psi t)).const_sub (J.rotationAngle psi)
  exact h.congr_deriv (by field_simp [J.k_pos.ne'])

theorem hasDerivAt_endpointW (psi t : ℝ) :
    HasDerivAt (J.endpointW psi) (J.k * J.s (J.terminalPhase psi t) ^ 2) t := by
  have h := (((hasDerivAt_id' t).div_const J.k).add_const (J.eps psi)).sub
    ((J.heps _).comp t (J.hasDerivAt_terminalPhase psi t))
  refine h.congr_deriv ?_
  field_simp [J.k_pos.ne']
  nlinarith [J.sd (J.terminalPhase psi t)]

theorem hasDerivAt_endpointX (sigma psi t : ℝ) :
    HasDerivAt (J.endpointX sigma psi)
      (sigma * J.s (J.terminalPhase psi t) * Real.cos (J.endpointTheta psi t)) t := by
  have hc := ((J.hc _).comp t (J.hasDerivAt_terminalPhase psi t)).const_sub (J.c psi)
  have h := ((hc.const_mul (J.d psi)).add ((J.hasDerivAt_endpointW psi t).const_mul (J.s psi))).const_mul (sigma * J.k)
  refine h.congr_deriv ?_
  rw [J.endpointTheta_cos]
  field_simp [J.k_pos.ne']
  ring

theorem hasDerivAt_endpointY (sigma psi t : ℝ) :
    HasDerivAt (J.endpointY sigma psi)
      (sigma * J.s (J.terminalPhase psi t) * Real.sin (J.endpointTheta psi t)) t := by
  have hc := ((J.hc _).comp t (J.hasDerivAt_terminalPhase psi t)).const_sub (J.c psi)
  have h := ((hc.const_mul (J.k ^ 2 * J.s psi)).sub ((J.hasDerivAt_endpointW psi t).const_mul (J.d psi))).const_mul sigma
  refine h.congr_deriv ?_
  rw [J.endpointTheta_sin]
  field_simp [J.k_pos.ne']

theorem endpoint_at_zero (sigma psi : ℝ) :
    J.endpointX sigma psi 0 = 0 ∧ J.endpointY sigma psi 0 = 0 ∧ J.endpointTheta psi 0 = 0 := by
  simp [endpointX, endpointY, endpointTheta, endpointW, terminalPhase]

/-- Positive addition denominator, including quarter-period points. -/
def jacobianDelta (tau p : ℝ) : ℝ := 1 - J.k ^ 2 * J.s p ^ 2 * J.s tau ^ 2

theorem jacobianDelta_pos (tau p : ℝ) : 0 < J.jacobianDelta tau p := by
  have hp : J.s p ^ 2 ≤ 1 := by nlinarith [J.sc p, sq_nonneg (J.c p)]
  have ht : J.s tau ^ 2 ≤ 1 := by nlinarith [J.sc tau, sq_nonneg (J.c tau)]
  have hprod : J.s p ^ 2 * J.s tau ^ 2 ≤ 1 := by
    nlinarith [mul_nonneg (sq_nonneg (J.s p)) (sub_nonneg.mpr ht)]
  have hk : J.k ^ 2 < 1 := by nlinarith [J.k_pos, J.k_lt_one]
  unfold jacobianDelta
  nlinarith [mul_nonneg (sq_nonneg J.k) (sub_nonneg.mpr hprod)]

/-- Scalar formula only: equality to the full endpoint determinant is not proved here. -/
def jacobianExpression (tau p : ℝ) : ℝ :=
  (-4 * J.k / ((1 - J.k ^ 2) * J.jacobianDelta tau p)) * J.J2 tau p

theorem jacobian_prefactor_neg (tau p : ℝ) :
    -4 * J.k / ((1 - J.k ^ 2) * J.jacobianDelta tau p) < 0 := by
  apply div_neg_of_neg_of_pos
  · linarith [J.k_pos]
  · apply mul_pos _ (J.jacobianDelta_pos tau p)
    nlinarith [J.k_pos, J.k_lt_one]

theorem jacobianExpression_zero_iff (tau p : ℝ) :
    J.jacobianExpression tau p = 0 ↔ J.J2 tau p = 0 := by
  unfold jacobianExpression
  exact mul_eq_zero_iff_left (J.jacobian_prefactor_neg tau p).ne

/-- The rotating controls lie on the unit-energy circle for either sign. -/
theorem controls_unit (sigma u : ℝ) (hsigma : sigma ^ 2 = 1) :
    (sigma * J.s u) ^ 2 + (-J.c u) ^ 2 = 1 := by
  nlinarith [J.sc u, sq_nonneg (J.s u), sq_nonneg (J.c u)]

end JacobiFull

namespace JacobiConcrete
variable (k : ℝ) (hk0 : 0 < k) (hk1 : k < 1)

def pendulumGamma (sigma psi t : ℝ) : ℝ :=
  2 * sigma * amplitude k hk0 hk1 (psi + t / k)
def pendulumW (sigma psi t : ℝ) : ℝ :=
  2 * sigma * dn k hk0 hk1 (psi + t / k) / k

theorem hasDerivAt_pendulumGamma (sigma psi t : ℝ) :
    HasDerivAt (pendulumGamma k hk0 hk1 sigma psi)
      (pendulumW k hk0 hk1 sigma psi t) t := by
  have h := ((hasDerivAt_amplitude k hk0 hk1 _).comp t
    (((hasDerivAt_id' t).div_const k).const_add psi)).const_mul (2 * sigma)
  exact h.congr_deriv (by unfold pendulumW dn; ring)

theorem hasDerivAt_pendulumW (sigma psi t : ℝ) (hsigma : sigma = 1 ∨ sigma = -1) :
    HasDerivAt (pendulumW k hk0 hk1 sigma psi)
      (-Real.sin (pendulumGamma k hk0 hk1 sigma psi t)) t := by
  have h := (((hasDerivAt_dn k hk0 hk1 _).comp t
    (((hasDerivAt_id' t).div_const k).const_add psi)).const_mul (2 * sigma)).div_const k
  refine h.congr_deriv ?_
  unfold pendulumGamma sn cn
  rcases hsigma with rfl | rfl
  · simp only [mul_one, Real.sin_two_mul]
    field_simp [hk0.ne']
  · simp only [mul_neg_one, neg_mul, Real.sin_neg, Real.sin_two_mul]
    field_simp [hk0.ne']

theorem pendulum_controls (sigma psi t : ℝ) (hsigma : sigma = 1 ∨ sigma = -1) :
    Real.sin (pendulumGamma k hk0 hk1 sigma psi t / 2) = sigma * sn k hk0 hk1 (psi + t / k) ∧
    Real.cos (pendulumGamma k hk0 hk1 sigma psi t / 2) = cn k hk0 hk1 (psi + t / k) := by
  unfold pendulumGamma sn cn
  simp only [show ∀ a b : ℝ, 2 * a * b / 2 = a * b from fun a b => by ring]
  rcases hsigma with rfl | rfl <;> simp

/-- The concrete endpoint satisfies all five stated pendulum/horizontal equations.
This is a trajectory theorem, not a parameter-determinant theorem. -/
theorem endpoint_hamiltonian_system (sigma psi t : ℝ) (hsigma : sigma = 1 ∨ sigma = -1) :
    let J := full k hk0 hk1
    let gamma := pendulumGamma k hk0 hk1 sigma psi t
    HasDerivAt (J.endpointX sigma psi) (Real.sin (gamma / 2) * Real.cos (J.endpointTheta psi t)) t ∧
    HasDerivAt (J.endpointY sigma psi) (Real.sin (gamma / 2) * Real.sin (J.endpointTheta psi t)) t ∧
    HasDerivAt (J.endpointTheta psi) (-Real.cos (gamma / 2)) t ∧
    HasDerivAt (pendulumGamma k hk0 hk1 sigma psi) (pendulumW k hk0 hk1 sigma psi t) t ∧
    HasDerivAt (pendulumW k hk0 hk1 sigma psi) (-Real.sin gamma) t := by
  dsimp only
  obtain ⟨hs, hc⟩ := pendulum_controls k hk0 hk1 sigma psi t hsigma
  refine ⟨?_, ?_, ?_, hasDerivAt_pendulumGamma k hk0 hk1 sigma psi t,
    hasDerivAt_pendulumW k hk0 hk1 sigma psi t hsigma⟩
  · rw [hs]
    exact (full k hk0 hk1).hasDerivAt_endpointX sigma psi t
  · rw [hs]
    exact (full k hk0 hk1).hasDerivAt_endpointY sigma psi t
  · rw [hc]
    exact (full k hk0 hk1).hasDerivAt_endpointTheta psi t

end JacobiConcrete
end
