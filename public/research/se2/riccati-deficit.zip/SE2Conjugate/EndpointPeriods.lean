import SE2Conjugate.ArticleExtension
import SE2Conjugate.Midpoint

noncomputable section
namespace JacobiConcrete.AmplitudeChart

/-- Actual signed endpoint determinant in the paper's rectified chart at period
n. The fixed source has varphi=k*psi, t=2*k*x+n*(4*k*K). -/
theorem endpoint_period_polynomial (k : ℝ) (hk : 0<k) (hk' : k<1)
    (σ ψ x : ℝ) (hs : σ^2=1) (n : ℕ) :
    let J := core k hk hk'
    let p := x+2*n*J.K
    (jacobian (rectifiedEndpoint σ) ![2*k*p,k*ψ,k]).det =
      (-4*k/((1-k^2)*(1-k^2*J.s x^2*J.s (ψ+x)^2)))*J.periodPolynomial n (ψ+x) x := by
  let J := core k hk hk'
  let p := x+2*n*J.K
  let y : V3 := ![2*k*p,k*ψ,k]
  have h := rectified_det_J2 σ hs y hk hk'
  change (jacobian _ y).det = _
  rw [h]
  change -4*k/((1-k^2)*(1-k^2*J.s ((2*k*p)/(2*k))^2*
    J.s (k*ψ/k+(2*k*p)/(2*k))^2))*J.toJacobiFull.J2 (k*ψ/k+(2*k*p)/(2*k)) ((2*k*p)/(2*k)) = _
  rw [show 2*k*p/(2*k)=p by field_simp, show k*ψ/k=ψ by field_simp]
  dsimp only [p]
  rw [← add_assoc ψ x, J.J2_periods, J.s_shift_n n x, J.s_shift_n n (ψ+x)]
  simp only [mul_pow,neg_one_pow_sq,one_mul]
  rfl

end JacobiConcrete.AmplitudeChart
