import SE2Conjugate.Construction

/-! Distribution of the unique bracket root for uniform initial phase. -/
noncomputable section
open Set MeasureTheory

namespace CrossingData

/-- The two branches up to x occupy one contiguous interval of phase lifts. -/
theorem prefixImage (C : CrossingData) {x ψ : ℝ} (hx : x ∈ Icc C.lo C.hi) :
    ψ ∈ Icc (C.psiM x) (C.psiP x) ↔
      ∃ q ∈ Icc C.lo x, C.psiP q = ψ ∨ C.psiM q = ψ := by
  have sub : Icc C.lo x ⊆ Icc C.lo C.hi := Icc_subset_Icc_right hx.2
  constructor
  · intro h
    by_cases hψ : -C.lo ≤ ψ
    · obtain ⟨q,hq,he⟩ := intermediate_value_Icc hx.1
        ((C.u_cont.sub continuousOn_id).mono sub)
        (show ψ ∈ Icc (C.psiP C.lo) (C.psiP x) from ⟨C.psiP_lo ▸ hψ,h.2⟩)
      exact ⟨q,hq,Or.inl he⟩
    · obtain ⟨q,hq,he⟩ := intermediate_value_Icc' hx.1
        ((C.u_cont.neg.sub continuousOn_id).mono sub)
        (show ψ ∈ Icc (C.psiM x) (C.psiM C.lo) from ⟨h.1,C.psiM_lo ▸ (le_of_not_ge hψ)⟩)
      exact ⟨q,hq,Or.inr he⟩
  · rintro ⟨q,hq,h|h⟩
    · rw [← h]
      exact ⟨(C.psiM_range hx).2.trans (C.psiP_range (sub hq)).1,
        C.psiP_strictMono.monotoneOn (sub hq) hx hq.2⟩
    · rw [← h]
      exact ⟨C.psiM_strictAnti.antitoneOn (sub hq) hx hq.2,
        (C.psiM_range (sub hq)).2.trans (C.psiP_range hx).1⟩
end CrossingData

namespace SBracket
variable (B : SBracket)

def phaseCrossing : CrossingData where
  K := B.K
  K_pos := B.K_pos
  lo := B.p0
  hi := B.p1
  lo_lt_hi := B.p0_lt_p1
  u := B.uu
  u_lo := B.uu_p0
  u_hi := B.uu_p1
  u_cont := B.continuousOn_uu
  plus_mono := B.psiP_strictMono
  minus_anti := B.psiM_strictAnti

def phaseOrigin := (1-B.ε)*B.K/2

theorem prefix_branch_root {q ψ : ℝ} (hq : q ∈ Icc B.p0 B.p1)
    (h : B.phaseCrossing.psiP q = ψ ∨ B.phaseCrossing.psiM q = ψ) :
    B.J2 (B.phaseOrigin+ψ+q) q = 0 := by
  rw [B.J2_eq_zero_iff hq, ← B.Finv_spec (B.r q) (B.r_mem_Icc hq), B.sn_sq_eq_iff]
  change B.uu q - q = ψ ∨ -B.uu q - q = ψ at h
  change ∃ n : ℤ, B.phaseOrigin+ψ+q = B.u q + 2*B.K*n ∨
    B.phaseOrigin+ψ+q = -B.u q + 2*B.K*n
  unfold phaseOrigin
  rcases B.hε with he|he <;> rcases h with h|h <;>
    simp [uu, he] at h ⊢
  · exact ⟨0, Or.inl (by push_cast; linarith)⟩
  · exact ⟨0, Or.inr (by push_cast; linarith)⟩
  · exact ⟨1, Or.inr (by push_cast; linarith)⟩
  · exact ⟨0, Or.inl (by push_cast; linarith)⟩

/-- Phase measured relative to phaseOrigin, on a fundamental interval of length 2K. -/
def rootPrefix (x : ℝ) : Set ℝ :=
  {ψ | ψ ∈ Icc (B.phaseCrossing.psiM B.p1) (B.phaseCrossing.psiP B.p1) ∧
    ∃ q ∈ Icc B.p0 x, B.J2 (B.phaseOrigin+ψ+q) q = 0}

theorem rootPrefix_eq {x : ℝ} (hx : x ∈ Icc B.p0 B.p1) :
    B.rootPrefix x = Icc (B.phaseCrossing.psiM x) (B.phaseCrossing.psiP x) := by
  let C := B.phaseCrossing
  have mem : x ∈ Icc C.lo C.hi := hx
  have sub : Icc B.p0 x ⊆ Icc B.p0 B.p1 := Icc_subset_Icc_right hx.2
  ext ψ
  constructor
  · rintro ⟨hf,q,hq,hr⟩
    obtain ⟨v,hv,hb⟩ := (C.prefixImage C.hi_mem).mp hf
    have he := (B.exact_time (B.phaseOrigin+ψ)).unique
      (show q ∈ Icc B.p0 B.p1 ∧ _ from ⟨sub hq,hr⟩)
      (show v ∈ Icc B.p0 B.p1 ∧ _ from ⟨hv,B.prefix_branch_root hv hb⟩)
    subst v
    exact (C.prefixImage mem).mpr ⟨q,hq,hb⟩
  · intro h
    obtain ⟨q,hq,hb⟩ := (C.prefixImage mem).mp h
    exact ⟨(C.prefixImage C.hi_mem).mpr ⟨q,sub hq,hb⟩, q, hq, B.prefix_branch_root (sub hq) hb⟩

theorem rootPrefix_volume {x : ℝ} (hx : x ∈ Icc B.p0 B.p1) :
    volume (B.rootPrefix x) = ENNReal.ofReal (2*B.uu x) := by
  rw [B.rootPrefix_eq hx, Real.volume_Icc]
  congr 1
  change (B.uu x-x)-(-B.uu x-x) = _
  ring

end SBracket
