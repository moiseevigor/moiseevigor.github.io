import SE2Conjugate.Reduction
import SE2Conjugate.BeforeFirst

/-!
# Concrete real Jacobi functions from the elliptic integral

For `0 < k < 1`, the primitive of `(1-k² sin² phi)^(-1/2)` is an increasing
bijection of the real line. Its inverse defines the unwrapped amplitude.
The resulting sine, cosine, positive square root and second-kind integral
construct every field of `JacobiCore`, including its first positive cn zero.
-/
noncomputable section
open Set
namespace JacobiConcrete

variable (k : ℝ)

def speed (phi : ℝ) : ℝ := Real.sqrt (1 - k ^ 2 * Real.sin phi ^ 2)
def weight (phi : ℝ) : ℝ := 1 / speed k phi
def firstIntegral (phi : ℝ) : ℝ := ∫ t in (0 : ℝ)..phi, weight k t
def secondIntegral (phi : ℝ) : ℝ := ∫ t in (0 : ℝ)..phi, speed k t

theorem radicand_pos (hk0 : 0 < k) (hk1 : k < 1) (phi : ℝ) :
    0 < 1 - k ^ 2 * Real.sin phi ^ 2 := by
  have hk : k ^ 2 < 1 := by nlinarith
  have hs := Real.sin_sq_le_one phi
  nlinarith [sq_nonneg (Real.sin phi), sq_nonneg k]

theorem speed_pos (hk0 : 0 < k) (hk1 : k < 1) (phi : ℝ) : 0 < speed k phi :=
  Real.sqrt_pos.mpr (radicand_pos k hk0 hk1 phi)

theorem speed_le_one (phi : ℝ) : speed k phi ≤ 1 := by
  have h : 1 - k ^ 2 * Real.sin phi ^ 2 ≤ 1 := by
    nlinarith [mul_nonneg (sq_nonneg k) (sq_nonneg (Real.sin phi))]
  simpa [speed] using Real.sqrt_le_sqrt h

theorem weight_pos (hk0 : 0 < k) (hk1 : k < 1) (phi : ℝ) : 0 < weight k phi :=
  div_pos zero_lt_one (speed_pos k hk0 hk1 phi)

theorem one_le_weight (hk0 : 0 < k) (hk1 : k < 1) (phi : ℝ) : 1 ≤ weight k phi := by
  apply (le_div_iff₀ (speed_pos k hk0 hk1 phi)).mpr
  simpa using speed_le_one k phi

theorem speed_continuous : Continuous (speed k) := by
  unfold speed
  fun_prop

theorem weight_continuous (hk0 : 0 < k) (hk1 : k < 1) : Continuous (weight k) :=
  continuous_const.div (speed_continuous k) (fun phi => (speed_pos k hk0 hk1 phi).ne')

theorem firstIntegral_zero : firstIntegral k 0 = 0 := by simp [firstIntegral]
theorem secondIntegral_zero : secondIntegral k 0 = 0 := by simp [secondIntegral]

theorem hasDerivAt_firstIntegral (hk0 : 0 < k) (hk1 : k < 1) (phi : ℝ) :
    HasDerivAt (firstIntegral k) (weight k phi) phi := by
  have h := weight_continuous k hk0 hk1
  exact intervalIntegral.integral_hasDerivAt_right (h.intervalIntegrable _ _)
    h.aestronglyMeasurable.stronglyMeasurableAtFilter h.continuousAt

theorem hasDerivAt_secondIntegral (phi : ℝ) :
    HasDerivAt (secondIntegral k) (speed k phi) phi := by
  have h := speed_continuous k
  exact intervalIntegral.integral_hasDerivAt_right (h.intervalIntegrable _ _)
    h.aestronglyMeasurable.stronglyMeasurableAtFilter h.continuousAt

theorem firstIntegral_strictMono (hk0 : 0 < k) (hk1 : k < 1) :
    StrictMono (firstIntegral k) :=
  strictMono_of_hasDerivAt_pos (hasDerivAt_firstIntegral k hk0 hk1) (weight_pos k hk0 hk1)

theorem firstIntegral_sub_id_monotone (hk0 : 0 < k) (hk1 : k < 1) :
    Monotone (fun phi => firstIntegral k phi - phi) := by
  apply monotone_of_hasDerivAt_nonneg
    (fun phi => (hasDerivAt_firstIntegral k hk0 hk1 phi).sub (hasDerivAt_id' phi))
  intro phi
  exact sub_nonneg.mpr (one_le_weight k hk0 hk1 phi)

theorem firstIntegral_surjective (hk0 : 0 < k) (hk1 : k < 1) :
    Function.Surjective (firstIntegral k) := by
  intro p
  have hc : Continuous (firstIntegral k) :=
    continuous_iff_continuousAt.mpr fun phi => (hasDerivAt_firstIntegral k hk0 hk1 phi).continuousAt
  have hm := firstIntegral_sub_id_monotone k hk0 hk1
  by_cases hp : 0 ≤ p
  · have hbound : p ≤ firstIntegral k p := by
      have := hm hp
      simp only [firstIntegral_zero, sub_zero] at this
      linarith
    obtain ⟨phi, _, hphi⟩ := intermediate_value_Icc hp hc.continuousOn
      (show p ∈ Icc (firstIntegral k 0) (firstIntegral k p) by rw [firstIntegral_zero]; exact ⟨hp, hbound⟩)
    exact ⟨phi, hphi⟩
  · have hp0 : p ≤ 0 := le_of_lt (lt_of_not_ge hp)
    have hbound : firstIntegral k p ≤ p := by
      have := hm hp0
      simp only [firstIntegral_zero, sub_zero] at this
      linarith
    obtain ⟨phi, _, hphi⟩ := intermediate_value_Icc hp0 hc.continuousOn
      (show p ∈ Icc (firstIntegral k p) (firstIntegral k 0) by rw [firstIntegral_zero]; exact ⟨hbound, hp0⟩)
    exact ⟨phi, hphi⟩

/-- The globally increasing elliptic integral as an order isomorphism. -/
def integralIso (hk0 : 0 < k) (hk1 : k < 1) : ℝ ≃o ℝ :=
  StrictMono.orderIsoOfSurjective (firstIntegral k)
    (firstIntegral_strictMono k hk0 hk1) (firstIntegral_surjective k hk0 hk1)

def amplitude (hk0 : 0 < k) (hk1 : k < 1) : ℝ → ℝ := (integralIso k hk0 hk1).symm

theorem integral_amplitude (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) :
    firstIntegral k (amplitude k hk0 hk1 p) = p :=
  (integralIso k hk0 hk1).apply_symm_apply p

theorem amplitude_integral (hk0 : 0 < k) (hk1 : k < 1) (phi : ℝ) :
    amplitude k hk0 hk1 (firstIntegral k phi) = phi :=
  (integralIso k hk0 hk1).symm_apply_apply phi

theorem amplitude_zero (hk0 : 0 < k) (hk1 : k < 1) : amplitude k hk0 hk1 0 = 0 := by
  have h := amplitude_integral k hk0 hk1 0
  rwa [firstIntegral_zero] at h

theorem amplitude_strictMono (hk0 : 0 < k) (hk1 : k < 1) :
    StrictMono (amplitude k hk0 hk1) := (integralIso k hk0 hk1).symm.strictMono

theorem hasDerivAt_amplitude (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) :
    HasDerivAt (amplitude k hk0 hk1) (speed k (amplitude k hk0 hk1 p)) p := by
  have hc : Continuous (amplitude k hk0 hk1) := (integralIso k hk0 hk1).symm.continuous
  have h := HasDerivAt.of_local_left_inverse hc.continuousAt
    (hasDerivAt_firstIntegral k hk0 hk1 (amplitude k hk0 hk1 p))
    (weight_pos k hk0 hk1 _).ne' (Filter.Eventually.of_forall (integral_amplitude k hk0 hk1))
  simpa [weight] using h

def sn (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) : ℝ := Real.sin (amplitude k hk0 hk1 p)
def cn (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) : ℝ := Real.cos (amplitude k hk0 hk1 p)
def dn (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) : ℝ := speed k (amplitude k hk0 hk1 p)
def epsilon (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) : ℝ := secondIntegral k (amplitude k hk0 hk1 p)
def K : ℝ := firstIntegral k (Real.pi / 2)

theorem hasDerivAt_sn (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) :
    HasDerivAt (sn k hk0 hk1) (cn k hk0 hk1 p * dn k hk0 hk1 p) p :=
  (hasDerivAt_amplitude k hk0 hk1 p).sin

theorem hasDerivAt_cn (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) :
    HasDerivAt (cn k hk0 hk1) (-(sn k hk0 hk1 p * dn k hk0 hk1 p)) p := by
  exact ((hasDerivAt_amplitude k hk0 hk1 p).cos).congr_deriv (by unfold sn dn; ring)

theorem hasDerivAt_dn (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) :
    HasDerivAt (dn k hk0 hk1) (-(k ^ 2 * sn k hk0 hk1 p * cn k hk0 hk1 p)) p := by
  have hbase := (hasDerivAt_const p (1 : ℝ)).sub (((hasDerivAt_sn k hk0 hk1 p).pow 2).const_mul (k ^ 2))
  have hr : 1 - k ^ 2 * sn k hk0 hk1 p ^ 2 ≠ 0 := (radicand_pos k hk0 hk1 _).ne'
  have h := hbase.sqrt hr
  change HasDerivAt (dn k hk0 hk1) _ p at h
  refine h.congr_deriv ?_
  have hd : dn k hk0 hk1 p ≠ 0 := (speed_pos k hk0 hk1 _).ne'
  change (0 - k ^ 2 * (2 * sn k hk0 hk1 p ^ (2 - 1) *
    (cn k hk0 hk1 p * dn k hk0 hk1 p))) / (2 * dn k hk0 hk1 p) = _
  norm_num
  field_simp [hd]

theorem hasDerivAt_epsilon (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) :
    HasDerivAt (epsilon k hk0 hk1) (dn k hk0 hk1 p ^ 2) p := by
  have h := (hasDerivAt_secondIntegral k (amplitude k hk0 hk1 p)).comp p
    (hasDerivAt_amplitude k hk0 hk1 p)
  exact h.congr_deriv (by unfold dn; ring)

theorem K_pos (hk0 : 0 < k) (hk1 : k < 1) : 0 < K k := by
  have h := firstIntegral_strictMono k hk0 hk1 Real.pi_div_two_pos
  simpa [firstIntegral_zero, K] using h

theorem cn_K (hk0 : 0 < k) (hk1 : k < 1) : cn k hk0 hk1 (K k) = 0 := by
  simp [cn, K, amplitude_integral]

theorem cn_pos_before_K (hk0 : 0 < k) (hk1 : k < 1) (p : ℝ) (hp : p ∈ Ico 0 (K k)) :
    0 < cn k hk0 hk1 p := by
  have hlo : 0 ≤ amplitude k hk0 hk1 p := by
    have h := (amplitude_strictMono k hk0 hk1).monotone hp.1
    simpa [amplitude_zero] using h
  have hhi : amplitude k hk0 hk1 p < Real.pi / 2 := by
    have h := amplitude_strictMono k hk0 hk1 hp.2
    simpa [K, amplitude_integral] using h
  apply Real.cos_pos_of_mem_Ioo
  exact ⟨by linarith [Real.pi_div_two_pos], hhi⟩

/-- A concrete inhabitant of all 13 core hypotheses, for every real modulus `0 < k < 1`. -/
def core (hk0 : 0 < k) (hk1 : k < 1) : JacobiCore where
  k := k
  k_pos := hk0
  k_lt_one := hk1
  s := sn k hk0 hk1
  c := cn k hk0 hk1
  d := dn k hk0 hk1
  eps := epsilon k hk0 hk1
  hs := hasDerivAt_sn k hk0 hk1
  hc := hasDerivAt_cn k hk0 hk1
  hd := hasDerivAt_dn k hk0 hk1
  heps := hasDerivAt_epsilon k hk0 hk1
  s0 := by simp [sn, amplitude_zero]
  c0 := by simp [cn, amplitude_zero]
  d0 := by simp [dn, speed, amplitude_zero]
  eps0 := by simp [epsilon, amplitude_zero, secondIntegral_zero]
  K := K k
  K_pos := K_pos k hk0 hk1
  cK := cn_K k hk0 hk1
  c_pos := cn_pos_before_K k hk0 hk1

/-- The complete Jacobi structure supplied to the counting theorems. -/
def full (hk0 : 0 < k) (hk1 : k < 1) : JacobiFull := (core k hk0 hk1).toJacobiFull


/-- The formal period agrees with the complete elliptic integral of the first kind. -/
theorem full_K (hk0 : 0 < k) (hk1 : k < 1) : (full k hk0 hk1).K = K k := rfl

/-- The formal epsilon value at K is the complete elliptic integral of the second kind. -/
theorem full_E (hk0 : 0 < k) (hk1 : k < 1) :
    (full k hk0 hk1).E = secondIntegral k (Real.pi / 2) := by
  change epsilon k hk0 hk1 (K k) = _
  simp [epsilon, K, amplitude_integral]

/-- The abstract sn field is the sine of the concrete, unwrapped amplitude. -/
theorem full_sn (hk0 : 0 < k) (hk1 : k < 1) : (full k hk0 hk1).s = sn k hk0 hk1 := rfl

/-- Concrete first-root uniqueness: no Jacobi-function or first-zero existence premise. -/
theorem first_time_unique (hk0 : 0 < k) (hk1 : k < 1) (psi : ℝ) :
    ∃! p, p ∈ Ioc (0 : ℝ) (full k hk0 hk1).p1 ∧ (full k hk0 hk1).J2 (psi + p) p = 0 :=
  (full k hk0 hk1).first_time_complete psi

/-- Concrete two-root count on each half-open cell away from K=2E. -/
theorem two_per_cell (hk0 : 0 < k) (hk1 : k < 1)
    (hcrit : K k ≠ 2 * secondIntegral k (Real.pi / 2)) (m : ℕ) (psi : ℝ) :
    {p | p ∈ Ico ((full k hk0 hk1).pL m) ((full k hk0 hk1).pL (m + 1)) ∧
      (full k hk0 hk1).J2 (psi + p) p = 0}.ncard = 2 := by
  apply (full k hk0 hk1).two_per_cell_of_ne m _ psi
  rwa [full_K, full_E]

/-- Concrete cumulative count, with only modulus bounds and the critical-modulus exclusion. -/
theorem roots_ncard (hk0 : 0 < k) (hk1 : k < 1)
    (hcrit : K k ≠ 2 * secondIntegral k (Real.pi / 2)) (psi : ℝ) (N : ℕ) :
    ((full k hk0 hk1).roots psi N).Finite ∧ ((full k hk0 hk1).roots psi N).ncard = 2 * N := by
  apply (full k hk0 hk1).roots_ncard _ psi N
  rwa [full_K, full_E]

end JacobiConcrete
end
