import Mathlib.LinearAlgebra.Matrix.Polynomial

/-! A determinant degree bound for endpoint variations with translation-only
increments. It is independent of the dynamics that produce those increments. -/
open Matrix Polynomial
open scoped BigOperators Polynomial
namespace TranslationDegree

variable {ι R : Type*} [Fintype ι] [DecidableEq ι] [CommRing R]

theorem row_bound (M : Matrix ι ι R[X]) (d : ι → ℕ)
    (h : ∀ i j, (M i j).natDegree ≤ d i) :
    M.det.natDegree ≤ ∑ i, d i := by
  classical
  rw [Matrix.det_apply]
  apply natDegree_sum_le_of_forall_le
  intro g _
  calc
    _ ≤ (∏ i, M (g i) i).natDegree := by
      rcases Int.units_eq_one_or (Equiv.Perm.sign g) with he|he
      · rw [he, one_smul]
      · rw [he, Units.neg_smul,one_smul,natDegree_neg]
    _ ≤ ∑ i, (M (g i) i).natDegree := natDegree_prod_le _ _
    _ ≤ ∑ i, d (g i) := Finset.sum_le_sum fun i _ => h _ _
    _ = ∑ i, d i := Equiv.sum_comp g d

theorem translation_rows (M : Matrix ι ι R[X]) (rows : Finset ι)
    (h : ∀ i j, (M i j).natDegree ≤ if i ∈ rows then 1 else 0) :
    M.det.natDegree ≤ rows.card := by
  simpa using row_bound M (fun i => if i ∈ rows then 1 else 0) h

end TranslationDegree
