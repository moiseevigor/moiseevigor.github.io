import SE2Conjugate.Construction

/-! Real Jacobi addition, derived from the ODE and two-sided uniqueness.
Classical formula: DLMF 22.8.1--3. No new special-function claim. -/
noncomputable section
namespace JacobiCore.Addition
set_option maxHeartbeats 1600000

theorem circle (k s c d h C D : ℝ)
    (hd : d^2 + k^2*s^2 = 1) (hD : D^2 + k^2*h^2 = 1)
    (hc : c^2+s^2=1) (hC : C^2+h^2=1) :
    (C * c - D * d * h * s) ^ 2 + (C * D * s + c * d * h) ^ 2 - (-h ^ 2 * k ^ 2 * s ^ 2 + 1) ^ 2 = 0 := by
  linear_combination (D ^ 2 * h ^ 2 * s ^ 2 + c ^ 2 * h ^ 2) * hd + (C ^ 2 * s ^ 2 - h ^ 2 * k ^ 2 * s ^ 4 + h ^ 2 * s ^ 2) * hD + (C ^ 2 - h ^ 2 * k ^ 2 * s ^ 2 + h ^ 2) * hc + (-h ^ 2 * k ^ 2 * s ^ 2 + 1) * hC

theorem radicand (k s c d h C D : ℝ)
    (hd : d^2 + k^2*s^2 = 1) (hD : D^2 + k^2*h^2 = 1)
    (hc : c^2+s^2=1) (hC : C^2+h^2=1) :
    k ^ 2 * (C * D * s + c * d * h) ^ 2 - (-h ^ 2 * k ^ 2 * s ^ 2 + 1) ^ 2 + (-C * c * h * k ^ 2 * s + D * d) ^ 2 = 0 := by
  linear_combination (D ^ 2 + c ^ 2 * h ^ 2 * k ^ 2) * hd + (C ^ 2 * k ^ 2 * s ^ 2 - k ^ 2 * s ^ 2 + 1) * hD + (C ^ 2 * h ^ 2 * k ^ 4 * s ^ 2 - h ^ 2 * k ^ 4 * s ^ 2 + h ^ 2 * k ^ 2) * hc + (-h ^ 2 * k ^ 4 * s ^ 4 + k ^ 2 * s ^ 2) * hC

theorem slope_s (k s c d h C D : ℝ)
    (hd : d^2 + k^2*s^2 = 1) (hD : D^2 + k^2*h^2 = 1)
    (hc : c^2+s^2=1) (hC : C^2+h^2=1) :
    2 * c * d * h ^ 2 * k ^ 2 * s * (C * D * s + c * d * h) - (C * c - D * d * h * s) * (-C * c * h * k ^ 2 * s + D * d) + (-h ^ 2 * k ^ 2 * s ^ 2 + 1) * (C * D * c * d - c ^ 2 * h * k ^ 2 * s - d ^ 2 * h * s) = 0 := by
  linear_combination (D ^ 2 * h * s + 2 * c ^ 2 * h ^ 3 * k ^ 2 * s + h ^ 3 * k ^ 2 * s ^ 3 - h * s) * hd + (-h * k ^ 2 * s ^ 3 + h * s) * hD + (C ^ 2 * h * k ^ 2 * s - h ^ 3 * k ^ 4 * s ^ 3 + 2 * h ^ 3 * k ^ 2 * s - h * k ^ 2 * s) * hc + (-h * k ^ 2 * s ^ 3 + h * k ^ 2 * s) * hC

theorem slope_c (k s c d h C D : ℝ)
    (hd : d^2 + k^2*s^2 = 1) (hD : D^2 + k^2*h^2 = 1)
    (hc : c^2+s^2=1) (hC : C^2+h^2=1) :
    2 * c * d * h ^ 2 * k ^ 2 * s * (C * c - D * d * h * s) + (C * D * s + c * d * h) * (-C * c * h * k ^ 2 * s + D * d) + (-h ^ 2 * k ^ 2 * s ^ 2 + 1) * (-C * d * s - D * c * d ^ 2 * h + D * c * h * k ^ 2 * s ^ 2) = 0 := by
  linear_combination (-D * c * h ^ 3 * k ^ 2 * s ^ 2) * hd + (C * d * s) * hD + (C * d * h ^ 2 * k ^ 2 * s) * hc + (-D * c * h * k ^ 2 * s ^ 2) * hC

theorem slope_d (k s c d h C D : ℝ)
    (hd : d^2 + k^2*s^2 = 1) (hD : D^2 + k^2*h^2 = 1)
    (hc : c^2+s^2=1) (hC : C^2+h^2=1) :
    2 * c * d * h ^ 2 * k ^ 2 * s * (-C * c * h * k ^ 2 * s + D * d) + k ^ 2 * (C * c - D * d * h * s) * (C * D * s + c * d * h) + (-h ^ 2 * k ^ 2 * s ^ 2 + 1) * (-C * c ^ 2 * d * h * k ^ 2 + C * d * h * k ^ 2 * s ^ 2 - D * c * k ^ 2 * s) = 0 := by
  linear_combination (D * c * h ^ 2 * k ^ 2 * s) * hd + (-C * d * h * k ^ 2 * s ^ 2) * hD + (-C * d * h ^ 3 * k ^ 4 * s ^ 2) * hc + (D * c * k ^ 2 * s) * hC


theorem epsilon_algebra (k s c d h C D : ℝ)
    (hd : d^2 + k^2*s^2 = 1) (hD : D^2 + k^2*h^2 = 1)
    (hc : c^2+s^2=1) (_hC : C^2+h^2=1) :
    -d ^ 2 * (-h ^ 2 * k ^ 2 * s ^ 2 + 1) ^ 2 + h * k ^ 2 * (c * d * (C * D * s + c * d * h) * (-h ^ 2 * k ^ 2 * s ^ 2 + 1) + s * (C * c - D * d * h * s) * (-C * c * h * k ^ 2 * s + D * d)) + (-C * c * h * k ^ 2 * s + D * d) ^ 2 = 0 := by
  linear_combination (-D ^ 2 * h ^ 2 * k ^ 2 * s ^ 2 + D ^ 2 - c ^ 2 * h ^ 4 * k ^ 4 * s ^ 2 + c ^ 2 * h ^ 2 * k ^ 2 - h ^ 4 * k ^ 4 * s ^ 4 + 2 * h ^ 2 * k ^ 2 * s ^ 2 - 1) * hd + (h ^ 2 * k ^ 4 * s ^ 4 - h ^ 2 * k ^ 2 * s ^ 2 - k ^ 2 * s ^ 2 + 1) * hD + (h ^ 4 * k ^ 6 * s ^ 4 - h ^ 4 * k ^ 4 * s ^ 2 - h ^ 2 * k ^ 4 * s ^ 2 + h ^ 2 * k ^ 2) * hc

variable (J : JacobiCore)

def delta (u v : ℝ) := 1 - J.k^2 * J.s u^2 * J.s v^2
def numS (u v : ℝ) := J.s u * J.c v * J.d v + J.s v * J.c u * J.d u
def numC (u v : ℝ) := J.c u * J.c v - J.s u * J.d u * J.s v * J.d v
def numD (u v : ℝ) := J.d u * J.d v - J.k^2 * J.s u * J.c u * J.s v * J.c v
def addS (v u : ℝ) := numS J u v / delta J u v
def addC (v u : ℝ) := numC J u v / delta J u v
def addD (v u : ℝ) := numD J u v / delta J u v

theorem delta_lower (u v : ℝ) : 1 - J.k^2 ≤ delta J u v := by
  have hs : J.s u^2 ≤ 1 := by nlinarith [J.sc u, sq_nonneg (J.c u)]
  have hv : J.s v^2 ≤ 1 := by nlinarith [J.sc v, sq_nonneg (J.c v)]
  have hh : J.s u^2 * J.s v^2 ≤ 1 := mul_le_one₀ hs (sq_nonneg _) hv
  dsimp [delta]
  nlinarith [mul_nonneg (sq_nonneg J.k) (sub_nonneg.mpr hh)]

theorem delta_pos (u v : ℝ) : 0 < delta J u v := by
  have := delta_lower J u v
  nlinarith [J.k_pos, J.k_lt_one]

theorem add_circle (v u : ℝ) : addS J v u ^ 2 + addC J v u ^ 2 = 1 := by
  have h := circle J.k (J.s u) (J.c u) (J.d u) (J.s v) (J.c v) (J.d v)
    (by linarith [J.sd u]) (by linarith [J.sd v]) (J.sc u) (J.sc v)
  dsimp [addS, addC]
  field_simp [(delta_pos J u v).ne']
  dsimp [numS, numC, delta]
  linear_combination h

theorem add_radicand (v u : ℝ) : addD J v u ^ 2 + J.k^2 * addS J v u ^ 2 = 1 := by
  have h := radicand J.k (J.s u) (J.c u) (J.d u) (J.s v) (J.c v) (J.d v)
    (by linarith [J.sd u]) (by linarith [J.sd v]) (J.sc u) (J.sc v)
  dsimp [addS, addD]
  field_simp [(delta_pos J u v).ne']
  dsimp [numS, numD, delta]
  linear_combination h

theorem delta_deriv (v u : ℝ) : HasDerivAt (fun u => delta J u v)
    (-2 * J.k^2 * J.s u * J.c u * J.d u * J.s v^2) u := by
  have h := ((((J.hs u).pow 2).const_mul (J.k^2)).mul_const (J.s v^2)).const_sub 1
  exact h.congr_deriv (by ring)

theorem numS_deriv (v u : ℝ) : HasDerivAt (fun u => numS J u v)
    (J.c u * J.d u * J.c v * J.d v - J.s v * J.s u * J.d u^2
      - J.s v * J.k^2 * J.s u * J.c u^2) u := by
  have h := (((J.hs u).mul_const (J.c v)).mul_const (J.d v)).add
    (((J.hc u).const_mul (J.s v)).mul (J.hd u))
  exact h.congr_deriv (by ring)

theorem numC_deriv (v u : ℝ) : HasDerivAt (fun u => numC J u v)
    (-J.s u * J.d u * J.c v - J.c u * J.d u^2 * J.s v * J.d v
      + J.k^2 * J.s u^2 * J.c u * J.s v * J.d v) u := by
  have h := ((J.hc u).mul_const (J.c v)).sub
    ((((J.hs u).mul (J.hd u)).mul_const (J.s v)).mul_const (J.d v))
  exact h.congr_deriv (by ring)

theorem numD_deriv (v u : ℝ) : HasDerivAt (fun u => numD J u v)
    (-J.k^2 * J.s u * J.c u * J.d v - J.k^2 * J.c u^2 * J.d u * J.s v * J.c v
      + J.k^2 * J.s u^2 * J.d u * J.s v * J.c v) u := by
  have h := ((J.hd u).mul_const (J.d v)).sub
    (((((J.hs u).const_mul (J.k^2)).mul (J.hc u)).mul_const (J.s v)).mul_const (J.c v))
  exact h.congr_deriv (by ring)

theorem addS_deriv (v u : ℝ) : HasDerivAt (addS J v) (addC J v u * addD J v u) u := by
  have h := (numS_deriv J v u).div (delta_deriv J v u) (delta_pos J u v).ne'
  refine h.congr_deriv ?_
  have ha := slope_s J.k (J.s u) (J.c u) (J.d u) (J.s v) (J.c v) (J.d v)
    (by linarith [J.sd u]) (by linarith [J.sd v]) (J.sc u) (J.sc v)
  dsimp [addC, addD]
  field_simp [(delta_pos J u v).ne']
  dsimp [numS, numC, numD, delta]
  linear_combination ha

theorem addC_deriv (v u : ℝ) : HasDerivAt (addC J v) (-(addS J v u * addD J v u)) u := by
  have h := (numC_deriv J v u).div (delta_deriv J v u) (delta_pos J u v).ne'
  refine h.congr_deriv ?_
  have ha := slope_c J.k (J.s u) (J.c u) (J.d u) (J.s v) (J.c v) (J.d v)
    (by linarith [J.sd u]) (by linarith [J.sd v]) (J.sc u) (J.sc v)
  dsimp [addS, addD]
  field_simp [(delta_pos J u v).ne']
  dsimp [numS, numC, numD, delta]
  linear_combination ha

theorem addD_deriv (v u : ℝ) : HasDerivAt (addD J v) (-(J.k^2 * addS J v u * addC J v u)) u := by
  have h := (numD_deriv J v u).div (delta_deriv J v u) (delta_pos J u v).ne'
  refine h.congr_deriv ?_
  have ha := slope_d J.k (J.s u) (J.c u) (J.d u) (J.s v) (J.c v) (J.d v)
    (by linarith [J.sd u]) (by linarith [J.sd v]) (J.sc u) (J.sc v)
  dsimp [addS, addC]
  field_simp [(delta_pos J u v).ne']
  dsimp [numS, numC, numD, delta]
  linear_combination ha

def additionSol (v : ℝ) : Sol J.k where
  S := addS J v
  C := addC J v
  D := addD J v
  hS := addS_deriv J v
  hC := addC_deriv J v
  hD := addD_deriv J v
  bS := fun u => by
    rw [abs_le_one_iff_mul_self_le_one]
    nlinarith [add_circle J v u, sq_nonneg (addC J v u)]
  bC := fun u => by
    rw [abs_le_one_iff_mul_self_le_one]
    nlinarith [add_circle J v u, sq_nonneg (addS J v u)]
  bD := fun u => by
    rw [abs_le_one_iff_mul_self_le_one]
    nlinarith [add_radicand J v u, mul_nonneg (sq_nonneg J.k) (sq_nonneg (addS J v u))]

def shiftedSol (v : ℝ) : Sol J.k where
  S := fun u => J.s (u+v)
  C := fun u => J.c (u+v)
  D := fun u => J.d (u+v)
  hS := fun u => (J.hs (u+v)).comp_add_const u v
  hC := fun u => (J.hc (u+v)).comp_add_const u v
  hD := fun u => (J.hd (u+v)).comp_add_const u v
  bS := fun u => J.abs_s_le_one (u+v)
  bC := fun u => J.abs_c_le_one (u+v)
  bD := fun u => J.abs_d_le_one (u+v)

/-- Addition holds for every real pair of arguments, including quarter periods. -/
theorem addition (u v : ℝ) : J.s (u+v) = addS J v u ∧
    J.c (u+v) = addC J v u ∧ J.d (u+v) = addD J v u := by
  apply Sol.eq_of_eq_at J.k_pos.le J.k_lt_one.le (shiftedSol J v) (additionSol J v) 0
  all_goals simp [shiftedSol, additionSol, addS, addC, addD, numS, numC, numD, delta,
    J.s0, J.c0, J.d0]


/-- Epsilon's addition formula follows by differentiation and the value at zero. -/
theorem epsilon_addition (u v : ℝ) :
    J.eps (u+v) = J.eps u + J.eps v - J.k^2 * J.s u * J.s v * J.s (u+v) := by
  let f := fun u => J.eps (u+v) - J.eps u - J.eps v +
    J.k^2 * J.s u * J.s v * J.s (u+v)
  have hder : ∀ u, HasDerivAt f 0 u := by
    intro u
    have h := (((J.heps (u+v)).comp_add_const u v).sub (J.heps u)).sub_const (J.eps v)
    have hprod := ((((J.hs u).const_mul (J.k^2)).mul_const (J.s v)).mul
      ((J.hs (u+v)).comp_add_const u v))
    refine (h.add hprod).congr_deriv ?_
    rcases addition J u v with ⟨hs, hc, hd⟩
    rw [hs, hc, hd]
    have ha := epsilon_algebra J.k (J.s u) (J.c u) (J.d u) (J.s v) (J.c v) (J.d v)
      (by linarith [J.sd u]) (by linarith [J.sd v]) (J.sc u) (J.sc v)
    dsimp [addS, addC, addD]
    field_simp [(delta_pos J u v).ne']
    dsimp [numS, numC, numD, delta]
    linear_combination ha
  have heq := is_const_of_deriv_eq_zero (fun x => (hder x).differentiableAt)
    (fun x => (hder x).deriv) u 0
  dsimp [f] at heq
  simp only [zero_add, J.eps0, J.s0, mul_zero, sub_zero, sub_self] at heq
  linarith


/-- Evenness of cn and dn is obtained from the same ODE uniqueness theorem. -/
theorem even_cd (u : ℝ) : J.c (-u) = J.c u ∧ J.d (-u) = J.d u := by
  have h := Sol.eq_of_eq_at J.k_pos.le J.k_lt_one.le J.sol.negTime J.sol 0
    (by simp only [Sol.negTime, sol]; rw [neg_zero, J.s0]; ring)
    (by simp only [Sol.negTime, sol]; rw [neg_zero])
    (by simp only [Sol.negTime, sol]; rw [neg_zero]) u
  exact h.2

theorem epsilon_neg (u : ℝ) : J.eps (-u) = -J.eps u := by
  have h := epsilon_addition J u (-u)
  simp only [add_neg_cancel, J.eps0, J.s0, mul_zero, sub_zero] at h
  linarith

/-- The epsilon increment needed in the midpoint determinant reduction. -/
theorem epsilon_midpoint (tau p : ℝ) :
    J.eps (tau+p) - J.eps (tau-p) = 2 * J.eps p -
      2 * J.k^2 * J.s tau^2 * J.s p * J.c p * J.d p / delta J tau p := by
  rw [sub_eq_add_neg tau p, epsilon_addition J tau p, epsilon_addition J tau (-p),
    epsilon_neg J p, J.s_neg p, (addition J tau p).1, (addition J tau (-p)).1]
  dsimp [addS, numS, delta]
  rw [J.s_neg p, (even_cd J p).1, (even_cd J p).2]
  simp only [neg_sq]
  have hq : 1 - J.k^2 * J.s tau^2 * J.s p^2 ≠ 0 := (delta_pos J tau p).ne'
  field_simp [hq]
  ring

end JacobiCore.Addition

namespace JacobiConcrete
variable (k : ℝ) (hk0 : 0 < k) (hk1 : k < 1)

/-- Concrete global addition theorem; no special-function identities are hypotheses. -/
theorem addition (u v : ℝ) :
    let J := core k hk0 hk1
    sn k hk0 hk1 (u+v) = JacobiCore.Addition.addS J v u ∧
    cn k hk0 hk1 (u+v) = JacobiCore.Addition.addC J v u ∧
    dn k hk0 hk1 (u+v) = JacobiCore.Addition.addD J v u :=
  JacobiCore.Addition.addition (core k hk0 hk1) u v

theorem epsilon_addition (u v : ℝ) :
    epsilon k hk0 hk1 (u+v) = epsilon k hk0 hk1 u + epsilon k hk0 hk1 v -
      k^2 * sn k hk0 hk1 u * sn k hk0 hk1 v * sn k hk0 hk1 (u+v) :=
  JacobiCore.Addition.epsilon_addition (core k hk0 hk1) u v

theorem epsilon_midpoint (tau p : ℝ) :
    epsilon k hk0 hk1 (tau+p) - epsilon k hk0 hk1 (tau-p) =
      2 * epsilon k hk0 hk1 p -
      2*k^2 * sn k hk0 hk1 tau^2 * sn k hk0 hk1 p * cn k hk0 hk1 p * dn k hk0 hk1 p /
        (1-k^2 * sn k hk0 hk1 tau^2 * sn k hk0 hk1 p^2) :=
  JacobiCore.Addition.epsilon_midpoint (core k hk0 hk1) tau p

end JacobiConcrete
