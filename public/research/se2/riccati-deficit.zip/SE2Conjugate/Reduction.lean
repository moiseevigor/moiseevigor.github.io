import Mathlib
import SE2Conjugate.Jacobi
import SE2Conjugate.Monotone
import SE2Conjugate.Zeros
import SE2Conjugate.FirstCell

/-!
# Reducing the trust base of `JacobiFull`

The formalization of the counting theorems takes the Jacobi functions as data satisfying 31
hypotheses (`JacobiData`, `JacobiInit`, `JacobiPeriodic`, `JacobiFull`).  Mathlib has no Jacobi
functions, but most of those hypotheses follow from a much smaller core: the defining ODE
`sn' = cn dn`, `cn' = -sn dn`, `dn' = -k² sn cn`, `ℰ' = dn²` with the initial values
`(sn, cn, dn, ℰ)(0) = (0, 1, 1, 0)`, and the first positive zero `K` of `cn`.

This file proves, for any such core:

* the algebraic relations `cn² + sn² = 1` and `dn² = 1 - k² sn²` (first integrals of the ODE),
* `dn > 0` everywhere,
* uniqueness of solutions of the ODE (a Gronwall argument on the squared distance of two
  solution triples), from which the reflection `u ↦ 2K - u` and the shift `u ↦ u + 2K`
  symmetries follow, and with them every value of `sn, cn, dn, ℰ` at the multiples of `K`,
  the sign clauses of `JacobiPeriodic`, and `0 < E < K` with `E := ℰ(K)`.
-/

noncomputable section

open Set

/-- The core: the ODE, the initial values, and `K`, the first positive zero of `cn`. -/
structure JacobiCore where
  k : ℝ
  k_pos : 0 < k
  k_lt_one : k < 1
  s : ℝ → ℝ
  c : ℝ → ℝ
  d : ℝ → ℝ
  eps : ℝ → ℝ
  hs : ∀ p, HasDerivAt s (c p * d p) p
  hc : ∀ p, HasDerivAt c (-(s p * d p)) p
  hd : ∀ p, HasDerivAt d (-(k ^ 2 * s p * c p)) p
  heps : ∀ p, HasDerivAt eps (d p ^ 2) p
  s0 : s 0 = 0
  c0 : c 0 = 1
  d0 : d 0 = 1
  eps0 : eps 0 = 0
  K : ℝ
  K_pos : 0 < K
  cK : c K = 0
  c_pos : ∀ p ∈ Ico 0 K, 0 < c p

namespace JacobiCore

variable (J : JacobiCore)

/-! ### First integrals: the algebraic relations -/

theorem sc (p : ℝ) : J.c p ^ 2 + J.s p ^ 2 = 1 := by
  have hderiv : ∀ x, HasDerivAt (fun x => J.c x ^ 2 + J.s x ^ 2) 0 x := by
    intro x
    have h := ((J.hc x).pow 2).add ((J.hs x).pow 2)
    refine h.congr_deriv ?_
    norm_num <;> ring
  have hconst := is_const_of_deriv_eq_zero (fun x => (hderiv x).differentiableAt)
    (fun x => (hderiv x).deriv)
  have := hconst p 0
  rw [this, J.c0, J.s0]; norm_num

theorem sd (p : ℝ) : J.d p ^ 2 = 1 - J.k ^ 2 * J.s p ^ 2 := by
  have hderiv : ∀ x, HasDerivAt (fun x => J.d x ^ 2 + J.k ^ 2 * J.s x ^ 2) 0 x := by
    intro x
    have h := ((J.hd x).pow 2).add (((J.hs x).pow 2).const_mul (J.k ^ 2))
    refine h.congr_deriv ?_
    norm_num <;> ring
  have hconst := is_const_of_deriv_eq_zero (fun x => (hderiv x).differentiableAt)
    (fun x => (hderiv x).deriv)
  have := hconst p 0
  simp only [J.d0, J.s0] at this
  linarith

theorem d_sq_pos (p : ℝ) : 0 < J.d p ^ 2 := by
  rw [J.sd]
  have h1 : J.s p ^ 2 ≤ 1 := by nlinarith [J.sc p, sq_nonneg (J.c p)]
  have hk : J.k ^ 2 < 1 := by nlinarith [J.k_pos, J.k_lt_one]
  nlinarith [sq_nonneg (J.s p), sq_nonneg J.k]

theorem d_ne (p : ℝ) : J.d p ≠ 0 := by
  intro h; have := J.d_sq_pos p; rw [h] at this; simp at this

/-- `dn > 0`: `dn` never vanishes and `dn 0 = 1`, so it is positive by the intermediate value
theorem. -/
theorem d_pos (p : ℝ) : 0 < J.d p := by
  have hcont : Continuous J.d := continuous_iff_continuousAt.mpr fun x => (J.hd x).continuousAt
  by_contra hle
  have hle' : J.d p ≤ 0 := not_lt.mp hle
  have hlt : J.d p < 0 := lt_of_le_of_ne hle' (J.d_ne p)
  -- `d` takes the values `1` at `0` and a negative value at `p`; it vanishes in between
  have : ∃ x, J.d x = 0 := by
    rcases le_or_gt 0 p with hp | hp
    · obtain ⟨x, -, hx⟩ := intermediate_value_Icc' hp hcont.continuousOn
        (show (0 : ℝ) ∈ Icc (J.d p) (J.d 0) by rw [J.d0]; exact ⟨hlt.le, zero_le_one⟩)
      exact ⟨x, hx⟩
    · obtain ⟨x, -, hx⟩ := intermediate_value_Icc hp.le hcont.continuousOn
        (show (0 : ℝ) ∈ Icc (J.d p) (J.d 0) by rw [J.d0]; exact ⟨hlt.le, zero_le_one⟩)
      exact ⟨x, hx⟩
  obtain ⟨x, hx⟩ := this
  exact J.d_ne x hx

theorem abs_s_le_one (p : ℝ) : |J.s p| ≤ 1 := by
  rw [abs_le_one_iff_mul_self_le_one]; nlinarith [J.sc p, sq_nonneg (J.c p)]

theorem abs_c_le_one (p : ℝ) : |J.c p| ≤ 1 := by
  rw [abs_le_one_iff_mul_self_le_one]; nlinarith [J.sc p, sq_nonneg (J.s p)]

theorem abs_d_le_one (p : ℝ) : |J.d p| ≤ 1 := by
  rw [abs_le_one_iff_mul_self_le_one]
  have := J.sd p; nlinarith [sq_nonneg (J.s p), sq_nonneg J.k]

/-- The data as `JacobiData` (the two algebraic relations are now theorems). -/
def toJacobiData : JacobiData where
  k := J.k
  k_pos := J.k_pos
  k_lt_one := J.k_lt_one
  s := J.s
  c := J.c
  d := J.d
  eps := J.eps
  hs := J.hs
  hc := J.hc
  hd := J.hd
  heps := J.heps
  sc := J.sc
  sd := J.sd

/-- The data as `JacobiInit` (`dn > 0` is now a theorem). -/
def toJacobiInit : JacobiInit where
  toJacobiData := J.toJacobiData
  d_pos := J.d_pos
  s0 := J.s0
  c0 := J.c0
  eps0 := J.eps0

/-! ### Uniqueness for the ODE

Two triples `(S, C, D)` and `(s, c, d)` solving the ODE with all components bounded by one in
absolute value, and equal at one time `a`, are equal for all later times.  The argument is
Gronwall's inequality for `Φ = (S - s)² + (C - c)² + (D - d)²`, which satisfies `|Φ'| ≤ 4Φ`. -/

/-- A solution triple of the ODE of modulus `k`, with the unit bounds. -/
structure Sol (k : ℝ) where
  S : ℝ → ℝ
  C : ℝ → ℝ
  D : ℝ → ℝ
  hS : ∀ p, HasDerivAt S (C p * D p) p
  hC : ∀ p, HasDerivAt C (-(S p * D p)) p
  hD : ∀ p, HasDerivAt D (-(k ^ 2 * S p * C p)) p
  bS : ∀ p, |S p| ≤ 1
  bC : ∀ p, |C p| ≤ 1
  bD : ∀ p, |D p| ≤ 1

/-- `(s, c, d)` itself is a solution triple. -/
def sol : Sol J.k where
  S := J.s
  C := J.c
  D := J.d
  hS := J.hs
  hC := J.hc
  hD := J.hd
  bS := J.abs_s_le_one
  bC := J.abs_c_le_one
  bD := J.abs_d_le_one

/-- The squared distance of two solution triples. -/
def Φ {k : ℝ} (F G : Sol k) (p : ℝ) : ℝ :=
  (F.S p - G.S p) ^ 2 + (F.C p - G.C p) ^ 2 + (F.D p - G.D p) ^ 2

/-- Its derivative. -/
def Φ' {k : ℝ} (F G : Sol k) (p : ℝ) : ℝ :=
  2 * (F.S p - G.S p) * (F.C p * F.D p - G.C p * G.D p)
  + 2 * (F.C p - G.C p) * (-(F.S p * F.D p) + G.S p * G.D p)
  + 2 * (F.D p - G.D p) * (-(k ^ 2 * F.S p * F.C p) + k ^ 2 * G.S p * G.C p)

theorem hasDerivAt_Φ {k : ℝ} (F G : Sol k) (p : ℝ) : HasDerivAt (Φ F G) (Φ' F G p) p := by
  have h1 := ((F.hS p).sub (G.hS p)).pow 2
  have h2 := ((F.hC p).sub (G.hC p)).pow 2
  have h3 := ((F.hD p).sub (G.hD p)).pow 2
  have h := (h1.add h2).add h3
  refine h.congr_deriv ?_
  unfold Φ'
  norm_num <;> ring

/-- `|ab| ≤ (a² + b²)/2`. -/
theorem abs_mul_le_half_sq (a b : ℝ) : |a * b| ≤ (a ^ 2 + b ^ 2) / 2 := by
  rw [abs_mul]
  nlinarith [sq_nonneg (|a| - |b|), abs_nonneg a, abs_nonneg b, sq_abs a, sq_abs b]

/-- The Gronwall bound `|Φ'| ≤ 4 Φ`, using `|S|, |C|, |D|, |s|, |c|, |d| ≤ 1` and `k² ≤ 1`. -/
theorem abs_Φ'_le {k : ℝ} (hk0 : 0 ≤ k) (hk1 : k ≤ 1) (F G : Sol k) (p : ℝ) :
    |Φ' F G p| ≤ 4 * Φ F G p := by
  set a := F.S p - G.S p with ha
  set b := F.C p - G.C p with hb
  set e := F.D p - G.D p with he
  have hk2 : k ^ 2 ≤ 1 := by nlinarith
  have hCD : F.C p * F.D p - G.C p * G.D p = F.C p * e + G.D p * b := by rw [he, hb]; ring
  have hSD : -(F.S p * F.D p) + G.S p * G.D p = -(F.S p * e + G.D p * a) := by rw [he, ha]; ring
  have hSC : -(k ^ 2 * F.S p * F.C p) + k ^ 2 * G.S p * G.C p =
      -(k ^ 2 * (F.S p * b + G.C p * a)) := by rw [hb, ha]; ring
  have hΦ' : Φ' F G p = 2 * (a * (F.C p * e) + a * (G.D p * b) - b * (F.S p * e) - b * (G.D p * a)
      - k ^ 2 * (e * (F.S p * b)) - k ^ 2 * (e * (G.C p * a))) := by
    simp only [Φ', hCD, hSD, hSC]; ring
  have hΦ : Φ F G p = a ^ 2 + b ^ 2 + e ^ 2 := rfl
  -- each of the six terms is bounded by half a sum of two squares
  have t1 : |a * (F.C p * e)| ≤ (a ^ 2 + e ^ 2) / 2 := by
    calc |a * (F.C p * e)| = |F.C p| * |a * e| := by rw [show a * (F.C p * e) = F.C p * (a * e) by ring, abs_mul]
      _ ≤ 1 * |a * e| := by gcongr; exact F.bC p
      _ ≤ (a ^ 2 + e ^ 2) / 2 := by rw [one_mul]; exact abs_mul_le_half_sq a e
  have t2 : |a * (G.D p * b)| ≤ (a ^ 2 + b ^ 2) / 2 := by
    calc |a * (G.D p * b)| = |G.D p| * |a * b| := by rw [show a * (G.D p * b) = G.D p * (a * b) by ring, abs_mul]
      _ ≤ 1 * |a * b| := by gcongr; exact G.bD p
      _ ≤ (a ^ 2 + b ^ 2) / 2 := by rw [one_mul]; exact abs_mul_le_half_sq a b
  have t3 : |b * (F.S p * e)| ≤ (b ^ 2 + e ^ 2) / 2 := by
    calc |b * (F.S p * e)| = |F.S p| * |b * e| := by rw [show b * (F.S p * e) = F.S p * (b * e) by ring, abs_mul]
      _ ≤ 1 * |b * e| := by gcongr; exact F.bS p
      _ ≤ (b ^ 2 + e ^ 2) / 2 := by rw [one_mul]; exact abs_mul_le_half_sq b e
  have t4 : |b * (G.D p * a)| ≤ (a ^ 2 + b ^ 2) / 2 := by
    calc |b * (G.D p * a)| = |G.D p| * |a * b| := by rw [show b * (G.D p * a) = G.D p * (a * b) by ring, abs_mul]
      _ ≤ 1 * |a * b| := by gcongr; exact G.bD p
      _ ≤ (a ^ 2 + b ^ 2) / 2 := by rw [one_mul]; exact abs_mul_le_half_sq a b
  have t5 : |k ^ 2 * (e * (F.S p * b))| ≤ (b ^ 2 + e ^ 2) / 2 := by
    calc |k ^ 2 * (e * (F.S p * b))| = k ^ 2 * |F.S p| * |b * e| := by
          rw [show k ^ 2 * (e * (F.S p * b)) = k ^ 2 * (F.S p * (b * e)) by ring, abs_mul, abs_mul,
            abs_of_nonneg (sq_nonneg k)]; ring
      _ ≤ 1 * 1 * |b * e| := by gcongr; exact F.bS p
      _ ≤ (b ^ 2 + e ^ 2) / 2 := by rw [one_mul, one_mul]; exact abs_mul_le_half_sq b e
  have t6 : |k ^ 2 * (e * (G.C p * a))| ≤ (a ^ 2 + e ^ 2) / 2 := by
    calc |k ^ 2 * (e * (G.C p * a))| = k ^ 2 * |G.C p| * |a * e| := by
          rw [show k ^ 2 * (e * (G.C p * a)) = k ^ 2 * (G.C p * (a * e)) by ring, abs_mul, abs_mul,
            abs_of_nonneg (sq_nonneg k)]; ring
      _ ≤ 1 * 1 * |a * e| := by gcongr; exact G.bC p
      _ ≤ (a ^ 2 + e ^ 2) / 2 := by rw [one_mul, one_mul]; exact abs_mul_le_half_sq a e
  rw [hΦ', hΦ, abs_mul, abs_of_pos (by norm_num : (0 : ℝ) < 2)]
  have := abs_sub (a * (F.C p * e) + a * (G.D p * b) - b * (F.S p * e) - b * (G.D p * a)
      - k ^ 2 * (e * (F.S p * b))) (k ^ 2 * (e * (G.C p * a)))
  have h5 := abs_sub (a * (F.C p * e) + a * (G.D p * b) - b * (F.S p * e) - b * (G.D p * a))
      (k ^ 2 * (e * (F.S p * b)))
  have h4 := abs_sub (a * (F.C p * e) + a * (G.D p * b) - b * (F.S p * e)) (b * (G.D p * a))
  have h3 := abs_sub (a * (F.C p * e) + a * (G.D p * b)) (b * (F.S p * e))
  have h2 := abs_add_le (a * (F.C p * e)) (a * (G.D p * b))
  nlinarith

/-- Uniqueness forward in time: two bounded solution triples that agree at `a` agree on `[a, b]`. -/
theorem Φ_eq_zero_of_eq {k : ℝ} (hk0 : 0 ≤ k) (hk1 : k ≤ 1) (F G : Sol k) {a b : ℝ}
    (hab : a ≤ b) (h0 : Φ F G a = 0) : ∀ x ∈ Icc a b, Φ F G x = 0 := by
  have hcont : ContinuousOn (Φ F G) (Icc a b) :=
    fun x _ => (hasDerivAt_Φ F G x).continuousAt.continuousWithinAt
  have hderiv : ∀ x ∈ Ico a b, HasDerivWithinAt (Φ F G) (Φ' F G x) (Ici x) x :=
    fun x _ => (hasDerivAt_Φ F G x).hasDerivWithinAt
  have hbound : ∀ x ∈ Ico a b, ‖Φ' F G x‖ ≤ 4 * ‖Φ F G x‖ := by
    intro x _
    rw [Real.norm_eq_abs, Real.norm_eq_abs, abs_of_nonneg (by unfold Φ; positivity : 0 ≤ Φ F G x)]
    exact abs_Φ'_le hk0 hk1 F G x
  exact eq_zero_of_abs_deriv_le_mul_abs_self_of_eq_zero_right hcont hderiv h0 hbound

/-- Componentwise equality from `Φ = 0`. -/
theorem eq_of_Φ_eq_zero {k : ℝ} (F G : Sol k) {x : ℝ} (h : Φ F G x = 0) :
    F.S x = G.S x ∧ F.C x = G.C x ∧ F.D x = G.D x := by
  unfold Φ at h
  have ha : (F.S x - G.S x) ^ 2 = 0 := by nlinarith [sq_nonneg (F.S x - G.S x), sq_nonneg (F.C x - G.C x), sq_nonneg (F.D x - G.D x)]
  have hb : (F.C x - G.C x) ^ 2 = 0 := by nlinarith [sq_nonneg (F.S x - G.S x), sq_nonneg (F.C x - G.C x), sq_nonneg (F.D x - G.D x)]
  have he : (F.D x - G.D x) ^ 2 = 0 := by nlinarith [sq_nonneg (F.S x - G.S x), sq_nonneg (F.C x - G.C x), sq_nonneg (F.D x - G.D x)]
  refine ⟨?_, ?_, ?_⟩ <;> [have := pow_eq_zero_iff (n := 2) (by norm_num) |>.mp ha;
    have := pow_eq_zero_iff (n := 2) (by norm_num) |>.mp hb; have := pow_eq_zero_iff (n := 2) (by norm_num) |>.mp he] <;> linarith

/-- The time reversal of a solution triple about `t₀`: `(S(2t₀ - u), -C(2t₀ - u), D(2t₀ - u))`
solves the same ODE. -/
def Sol.reverse {k : ℝ} (F : Sol k) (t₀ : ℝ) : Sol k where
  S := fun u => F.S (2 * t₀ - u)
  C := fun u => -F.C (2 * t₀ - u)
  D := fun u => F.D (2 * t₀ - u)
  hS := fun u => by
    have h := (F.hS (2 * t₀ - u)).comp_const_sub (2 * t₀) u
    exact h.congr_deriv (by ring)
  hC := fun u => by
    have h := ((F.hC (2 * t₀ - u)).comp_const_sub (2 * t₀) u).neg
    exact h.congr_deriv (by ring)
  hD := fun u => by
    have h := (F.hD (2 * t₀ - u)).comp_const_sub (2 * t₀) u
    exact h.congr_deriv (by ring)
  bS := fun u => F.bS _
  bC := fun u => by simp only [abs_neg]; exact F.bC _
  bD := fun u => F.bD _

/-- The shift of a solution triple by `a` with the sign flip `(-S, -C, D)`; it solves the same ODE. -/
def Sol.shiftNeg {k : ℝ} (F : Sol k) (a : ℝ) : Sol k where
  S := fun u => -F.S (u + a)
  C := fun u => -F.C (u + a)
  D := fun u => F.D (u + a)
  hS := fun u => by
    have h := ((F.hS (u + a)).comp_add_const u a).neg
    exact h.congr_deriv (by ring)
  hC := fun u => by
    have h := ((F.hC (u + a)).comp_add_const u a).neg
    exact h.congr_deriv (by ring)
  hD := fun u => by
    have h := (F.hD (u + a)).comp_add_const u a
    exact h.congr_deriv (by ring)
  bS := fun u => by simp only [abs_neg]; exact F.bS _
  bC := fun u => by simp only [abs_neg]; exact F.bC _
  bD := fun u => F.bD _

/-- Two-sided uniqueness: solution triples equal at `t₀` are equal everywhere. -/
theorem Sol.eq_of_eq_at {k : ℝ} (hk0 : 0 ≤ k) (hk1 : k ≤ 1) (F G : Sol k) (t₀ : ℝ)
    (hS : F.S t₀ = G.S t₀) (hC : F.C t₀ = G.C t₀) (hD : F.D t₀ = G.D t₀) (u : ℝ) :
    F.S u = G.S u ∧ F.C u = G.C u ∧ F.D u = G.D u := by
  have h0 : Φ F G t₀ = 0 := by unfold Φ; rw [hS, hC, hD]; ring
  rcases le_or_gt t₀ u with hu | hu
  · exact eq_of_Φ_eq_zero F G (Φ_eq_zero_of_eq hk0 hk1 F G hu h0 u ⟨hu, le_rfl⟩)
  · -- run the reversed triples forward from `t₀` to `2t₀ - u`
    have h0' : Φ (F.reverse t₀) (G.reverse t₀) t₀ = 0 := by
      unfold Φ Sol.reverse; simp only
      rw [show 2 * t₀ - t₀ = t₀ by ring, hS, hC, hD]; ring
    have hle : t₀ ≤ 2 * t₀ - u := by linarith
    have := eq_of_Φ_eq_zero (F.reverse t₀) (G.reverse t₀)
      (Φ_eq_zero_of_eq hk0 hk1 (F.reverse t₀) (G.reverse t₀) hle h0' (2 * t₀ - u) ⟨hle, le_rfl⟩)
    simp only [Sol.reverse, show 2 * t₀ - (2 * t₀ - u) = u by ring, neg_inj] at this
    exact this

theorem k_nonneg : 0 ≤ J.k := J.k_pos.le
theorem k_le_one : J.k ≤ 1 := J.k_lt_one.le

/-! ### The reflection `u ↦ 2K - u` and the shift `u ↦ u + 2K` -/

theorem reflect (u : ℝ) : J.s (2 * J.K - u) = J.s u ∧ -J.c (2 * J.K - u) = J.c u ∧
    J.d (2 * J.K - u) = J.d u := by
  have h := Sol.eq_of_eq_at J.k_nonneg J.k_le_one (J.sol.reverse J.K) J.sol J.K
    (by simp only [Sol.reverse, sol]; rw [show 2 * J.K - J.K = J.K by ring])
    (by simp only [Sol.reverse, sol]; rw [show 2 * J.K - J.K = J.K by ring, J.cK]; ring)
    (by simp only [Sol.reverse, sol]; rw [show 2 * J.K - J.K = J.K by ring]) u
  simpa only [Sol.reverse, sol] using h

theorem s_reflect (u : ℝ) : J.s (2 * J.K - u) = J.s u := (J.reflect u).1
theorem c_reflect (u : ℝ) : J.c (2 * J.K - u) = -J.c u := by have := (J.reflect u).2.1; linarith
theorem d_reflect (u : ℝ) : J.d (2 * J.K - u) = J.d u := (J.reflect u).2.2

theorem s_2K : J.s (2 * J.K) = 0 := by have := J.s_reflect 0; simpa [J.s0] using this
theorem c_2K : J.c (2 * J.K) = -1 := by have := J.c_reflect 0; simpa [J.c0] using this
theorem d_2K : J.d (2 * J.K) = 1 := by have := J.d_reflect 0; simpa [J.d0] using this

theorem shift (u : ℝ) : -J.s (u + 2 * J.K) = J.s u ∧ -J.c (u + 2 * J.K) = J.c u ∧
    J.d (u + 2 * J.K) = J.d u := by
  have h := Sol.eq_of_eq_at J.k_nonneg J.k_le_one (J.sol.shiftNeg (2 * J.K)) J.sol 0
    (by simp only [Sol.shiftNeg, sol]; rw [zero_add, J.s_2K, J.s0]; ring)
    (by simp only [Sol.shiftNeg, sol]; rw [zero_add, J.c_2K, J.c0]; ring)
    (by simp only [Sol.shiftNeg, sol]; rw [zero_add, J.d_2K, J.d0]) u
  simpa only [Sol.shiftNeg, sol] using h

theorem s_shift (u : ℝ) : J.s (u + 2 * J.K) = -J.s u := by have := (J.shift u).1; linarith
theorem c_shift (u : ℝ) : J.c (u + 2 * J.K) = -J.c u := by have := (J.shift u).2.1; linarith
theorem d_shift (u : ℝ) : J.d (u + 2 * J.K) = J.d u := (J.shift u).2.2

/-- Iterated shift: `s (u + 2nK) = (-1)^n s u`, and the same for `c`; `d` is `2K`-periodic. -/
theorem s_shift_n (n : ℕ) (u : ℝ) : J.s (u + 2 * n * J.K) = (-1) ^ n * J.s u := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [show u + 2 * ((n + 1 : ℕ) : ℝ) * J.K = (u + 2 * n * J.K) + 2 * J.K by push_cast; ring,
      J.s_shift, ih, pow_succ]; ring

theorem c_shift_n (n : ℕ) (u : ℝ) : J.c (u + 2 * n * J.K) = (-1) ^ n * J.c u := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [show u + 2 * ((n + 1 : ℕ) : ℝ) * J.K = (u + 2 * n * J.K) + 2 * J.K by push_cast; ring,
      J.c_shift, ih, pow_succ]; ring

theorem d_shift_n (n : ℕ) (u : ℝ) : J.d (u + 2 * n * J.K) = J.d u := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [show u + 2 * ((n + 1 : ℕ) : ℝ) * J.K = (u + 2 * n * J.K) + 2 * J.K by push_cast; ring,
      J.d_shift, ih]

/-! ### `sn` on the first quarter period -/

theorem s_strictMonoOn : StrictMonoOn J.s (Icc 0 J.K) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc 0 J.K)
  · exact fun x _ => (J.hs x).continuousAt.continuousWithinAt
  · intro x hx
    rw [interior_Icc] at hx
    rw [(J.hs x).deriv]
    exact mul_pos (J.c_pos x ⟨hx.1.le, hx.2⟩) (J.d_pos x)

theorem s_pos_of_mem_Ioc {u : ℝ} (hu : u ∈ Ioc 0 J.K) : 0 < J.s u := by
  have := J.s_strictMonoOn ⟨le_rfl, J.K_pos.le⟩ ⟨hu.1.le, hu.2⟩ hu.1
  rwa [J.s0] at this

theorem sK : J.s J.K = 1 := by
  have h1 : J.s J.K ^ 2 = 1 := by have := J.sc J.K; rw [J.cK] at this; linarith
  have h2 : 0 < J.s J.K := J.s_pos_of_mem_Ioc ⟨J.K_pos, le_rfl⟩
  nlinarith

theorem dK : J.d J.K = Real.sqrt (1 - J.k ^ 2) := by
  have h : J.d J.K ^ 2 = 1 - J.k ^ 2 := by rw [J.sd, J.sK]; ring
  rw [← h, Real.sqrt_sq (J.d_pos J.K).le]

/-! ### Values at the multiples of `K` -/

theorem s_even (n : ℕ) : J.s (2 * n * J.K) = 0 := by
  have := J.s_shift_n n 0; rw [zero_add, J.s0] at this; simpa using this
theorem c_even (n : ℕ) : J.c (2 * n * J.K) = (-1) ^ n := by
  have := J.c_shift_n n 0; rw [zero_add, J.c0] at this; simpa using this
theorem s_odd (n : ℕ) : J.s ((2 * n + 1) * J.K) = (-1) ^ n := by
  have := J.s_shift_n n J.K; rw [J.sK] at this
  rw [show (2 * (n : ℝ) + 1) * J.K = J.K + 2 * n * J.K by ring, this]; ring
theorem c_odd (n : ℕ) : J.c ((2 * n + 1) * J.K) = 0 := by
  have := J.c_shift_n n J.K; rw [J.cK] at this
  rw [show (2 * (n : ℝ) + 1) * J.K = J.K + 2 * n * J.K by ring, this]; ring
theorem d_odd (n : ℕ) : J.d ((2 * n + 1) * J.K) = Real.sqrt (1 - J.k ^ 2) := by
  have := J.d_shift_n n J.K
  rw [show (2 * (n : ℝ) + 1) * J.K = J.K + 2 * n * J.K by ring, this, J.dK]

/-! ### Jacobi's epsilon at the multiples of `K` -/

/-- `E := ℰ(K)`. -/
def E : ℝ := J.eps J.K

theorem eps_reflect (u : ℝ) : J.eps (2 * J.K - u) + J.eps u = 2 * J.E := by
  have hderiv : ∀ x, HasDerivAt (fun x => J.eps (2 * J.K - x) + J.eps x) 0 x := by
    intro x
    have h := ((J.heps (2 * J.K - x)).comp_const_sub (2 * J.K) x).add (J.heps x)
    refine h.congr_deriv ?_
    rw [J.d_reflect]; ring
  have hconst := is_const_of_deriv_eq_zero (fun x => (hderiv x).differentiableAt)
    (fun x => (hderiv x).deriv)
  have := hconst u J.K
  rw [this, show 2 * J.K - J.K = J.K by ring, E]; ring

theorem eps_2K : J.eps (2 * J.K) = 2 * J.E := by
  have := J.eps_reflect 0; simpa [J.eps0] using this

theorem eps_shift (u : ℝ) : J.eps (u + 2 * J.K) = J.eps u + 2 * J.E := by
  have hderiv : ∀ x, HasDerivAt (fun x => J.eps (x + 2 * J.K) - J.eps x) 0 x := by
    intro x
    have h := ((J.heps (x + 2 * J.K)).comp_add_const x (2 * J.K)).sub (J.heps x)
    refine h.congr_deriv ?_
    rw [J.d_shift]; ring
  have hconst := is_const_of_deriv_eq_zero (fun x => (hderiv x).differentiableAt)
    (fun x => (hderiv x).deriv)
  have := hconst u 0
  simp only [zero_add, J.eps0, sub_zero, J.eps_2K] at this
  linarith

theorem eps_even (n : ℕ) : J.eps (2 * n * J.K) = 2 * n * J.E := by
  induction n with
  | zero => simp [J.eps0]
  | succ n ih =>
    rw [show 2 * ((n + 1 : ℕ) : ℝ) * J.K = (2 * n * J.K) + 2 * J.K by push_cast; ring, J.eps_shift, ih]
    push_cast; ring

theorem eps_odd (n : ℕ) : J.eps ((2 * n + 1) * J.K) = (2 * n + 1) * J.E := by
  induction n with
  | zero => simp [E]
  | succ n ih =>
    rw [show (2 * ((n + 1 : ℕ) : ℝ) + 1) * J.K = ((2 * n + 1) * J.K) + 2 * J.K by push_cast; ring,
      J.eps_shift, ih]
    push_cast; ring

theorem eps_strictMono : StrictMono J.eps := by
  apply strictMono_of_deriv_pos
  intro x; rw [(J.heps x).deriv]; exact J.d_sq_pos x

theorem E_pos : 0 < J.E := by
  have := J.eps_strictMono J.K_pos; rwa [J.eps0] at this

theorem E_lt_K : J.E < J.K := by
  -- `u - ℰ(u)` is strictly increasing on `[0, K]` since its derivative `k² sn²` is positive inside
  have hmono : StrictMonoOn (fun u => u - J.eps u) (Icc 0 J.K) := by
    have hd : ∀ x, HasDerivAt (fun u => u - J.eps u) (1 - J.d x ^ 2) x :=
      fun x => (hasDerivAt_id x).sub (J.heps x)
    apply strictMonoOn_of_deriv_pos (convex_Icc 0 J.K)
    · exact fun x _ => (hd x).continuousAt.continuousWithinAt
    · intro x hx
      rw [interior_Icc] at hx
      rw [(hd x).deriv, J.sd]
      have hs := J.s_pos_of_mem_Ioc ⟨hx.1, hx.2.le⟩
      have := mul_pos (pow_pos J.k_pos 2) (pow_pos hs 2)
      linarith
  have := hmono ⟨le_rfl, J.K_pos.le⟩ ⟨J.K_pos.le, le_rfl⟩ J.K_pos
  simp only [J.eps0, sub_zero] at this
  unfold E; linarith

/-! ### Signs -/

theorem s_pos_first (u : ℝ) (hu : u ∈ Ioo 0 (2 * J.K)) : 0 < J.s u := by
  rcases le_or_gt u J.K with h | h
  · exact J.s_pos_of_mem_Ioc ⟨hu.1, h⟩
  · rw [← J.s_reflect]; exact J.s_pos_of_mem_Ioc ⟨by linarith [hu.2], by linarith⟩

theorem c_neg_first (u : ℝ) (hu : u ∈ Ioo J.K (3 * J.K)) : J.c u < 0 := by
  rcases lt_trichotomy u (2 * J.K) with h | h | h
  · rw [← neg_neg (J.c u), ← J.c_reflect]
    have := J.c_pos (2 * J.K - u) ⟨by linarith, by linarith [hu.1]⟩; linarith
  · rw [h, J.c_2K]; norm_num
  · have := J.c_shift (u - 2 * J.K); rw [sub_add_cancel] at this; rw [this]
    have := J.c_pos (u - 2 * J.K) ⟨by linarith, by linarith [hu.2]⟩; linarith

theorem s_sign (n : ℕ) (p : ℝ) (hp : p ∈ Ioo (2 * n * J.K) ((2 * n + 2) * J.K)) :
    0 < (-1) ^ n * J.s p := by
  have h := J.s_shift_n n (p - 2 * n * J.K); rw [sub_add_cancel] at h
  have hpos := J.s_pos_first (p - 2 * n * J.K) ⟨by linarith [hp.1], by linarith [hp.2]⟩
  rw [h, show (-1 : ℝ) ^ n * ((-1) ^ n * J.s (p - 2 * n * J.K)) = ((-1) ^ n) ^ 2 * J.s (p - 2 * n * J.K) by ring,
    neg_one_pow_sq, one_mul]
  exact hpos

theorem c_sign (n : ℕ) (p : ℝ) (hp : p ∈ Ioo ((2 * n + 1) * J.K) ((2 * n + 3) * J.K)) :
    0 < (-1) ^ (n + 1) * J.c p := by
  have h := J.c_shift_n n (p - 2 * n * J.K); rw [sub_add_cancel] at h
  have hneg := J.c_neg_first (p - 2 * n * J.K) ⟨by linarith [hp.1], by linarith [hp.2]⟩
  rw [h, show (-1 : ℝ) ^ (n + 1) * ((-1) ^ n * J.c (p - 2 * n * J.K)) = ((-1) ^ n) ^ 2 * (-J.c (p - 2 * n * J.K)) by ring,
    neg_one_pow_sq, one_mul]
  linarith

/-- The data as `JacobiPeriodic`: every one of its twelve extra hypotheses is now a theorem. -/
def toJacobiPeriodic : JacobiPeriodic where
  toJacobiInit := J.toJacobiInit
  K := J.K
  E := J.E
  K_pos := J.K_pos
  E_pos := J.E_pos
  E_lt_K := J.E_lt_K
  s_even := J.s_even
  s_odd := J.s_odd
  c_even := J.c_even
  c_odd := J.c_odd
  d_odd := J.d_odd
  eps_even := J.eps_even
  eps_odd := J.eps_odd
  s_sign := J.s_sign
  c_sign := J.c_sign

/-! ### The phase lift `Finv`: the inverse of `sn²` on `[0, K]` -/

/-- `sn²`. -/
def s2 (u : ℝ) : ℝ := J.s u ^ 2

theorem hasDerivAt_s2 (u : ℝ) : HasDerivAt J.s2 (2 * J.s u * (J.c u * J.d u)) u := by
  have h := (J.hs u).pow 2
  refine h.congr_deriv ?_
  norm_num <;> ring

theorem s2_continuous : Continuous J.s2 :=
  continuous_iff_continuousAt.mpr fun u => (J.hasDerivAt_s2 u).continuousAt

theorem s_nonneg_of_mem_Icc {u : ℝ} (hu : u ∈ Icc 0 J.K) : 0 ≤ J.s u := by
  rcases eq_or_lt_of_le hu.1 with h | h
  · rw [← h, J.s0]
  · exact (J.s_pos_of_mem_Ioc ⟨h, hu.2⟩).le

theorem s2_strictMonoOn : StrictMonoOn J.s2 (Icc 0 J.K) := by
  intro x hx y hy hxy
  have h := J.s_strictMonoOn hx hy hxy
  have hx0 := J.s_nonneg_of_mem_Icc hx
  unfold s2
  nlinarith [J.s_nonneg_of_mem_Icc hy]

theorem s2_zero : J.s2 0 = 0 := by simp [s2, J.s0]
theorem s2_K : J.s2 J.K = 1 := by simp [s2, J.sK]

theorem s2_mem_Icc {u : ℝ} (hu : u ∈ Icc 0 J.K) : J.s2 u ∈ Icc 0 1 := by
  constructor
  · exact sq_nonneg _
  · have := J.s2_strictMonoOn.monotoneOn hu ⟨J.K_pos.le, le_rfl⟩ hu.2
    rwa [J.s2_K] at this

theorem exists_preimage {r : ℝ} (hr : r ∈ Icc (0 : ℝ) 1) : ∃ u ∈ Icc 0 J.K, J.s2 u = r := by
  have := intermediate_value_Icc J.K_pos.le J.s2_continuous.continuousOn
  rw [J.s2_zero, J.s2_K] at this
  exact this hr

/-- The phase lift: for `r ∈ [0, 1]`, the unique `u ∈ [0, K]` with `sn² u = r`. -/
def Finv (r : ℝ) : ℝ :=
  if h : r ∈ Icc (0 : ℝ) 1 then Classical.choose (J.exists_preimage h) else 0

theorem Finv_mem {r : ℝ} (hr : r ∈ Icc (0 : ℝ) 1) : J.Finv r ∈ Icc 0 J.K := by
  unfold Finv; rw [dif_pos hr]; exact (Classical.choose_spec (J.exists_preimage hr)).1

theorem s2_Finv {r : ℝ} (hr : r ∈ Icc (0 : ℝ) 1) : J.s2 (J.Finv r) = r := by
  unfold Finv; rw [dif_pos hr]; exact (Classical.choose_spec (J.exists_preimage hr)).2

theorem Finv_spec {r : ℝ} (hr : r ∈ Icc (0 : ℝ) 1) : J.s (J.Finv r) ^ 2 = r := J.s2_Finv hr

theorem Finv_unique {u r : ℝ} (hu : u ∈ Icc 0 J.K) (hr : J.s2 u = r) : J.Finv r = u := by
  have hr' : r ∈ Icc (0 : ℝ) 1 := hr ▸ J.s2_mem_Icc hu
  exact J.s2_strictMonoOn.injOn (J.Finv_mem hr') hu (by rw [J.s2_Finv hr', hr])

theorem Finv_zero : J.Finv 0 = 0 := J.Finv_unique ⟨le_rfl, J.K_pos.le⟩ J.s2_zero
theorem Finv_one : J.Finv 1 = J.K := J.Finv_unique ⟨J.K_pos.le, le_rfl⟩ J.s2_K

theorem Finv_strictMonoOn : StrictMonoOn J.Finv (Icc 0 1) := by
  intro r hr r' hr' hlt
  by_contra hge
  have hge' : J.Finv r' ≤ J.Finv r := not_lt.mp hge
  have := J.s2_strictMonoOn.monotoneOn (J.Finv_mem hr') (J.Finv_mem hr) hge'
  rw [J.s2_Finv hr, J.s2_Finv hr'] at this
  linarith

/-- Continuity from the right at `a ∈ [0, 1)`. -/
theorem Finv_continuousWithinAt_right {a : ℝ} (ha : a ∈ Ico (0 : ℝ) 1) :
    ContinuousWithinAt J.Finv (Ici a) a := by
  apply J.Finv_strictMonoOn.continuousWithinAt_right_of_exists_between (Icc_mem_nhdsGE_of_mem ha)
  intro b hb
  -- `u₀ = Finv a < K`; pick `u` strictly between `u₀` and `min b K`
  have hu₀ := J.Finv_mem ⟨ha.1, ha.2.le⟩
  have hu₀K : J.Finv a < J.K := by
    rcases eq_or_lt_of_le hu₀.2 with h | h
    · have := J.s2_Finv ⟨ha.1, ha.2.le⟩; rw [h, J.s2_K] at this; linarith [ha.2]
    · exact h
  set u := (J.Finv a + min b J.K) / 2 with hu
  have hmin : J.Finv a < min b J.K := lt_min hb hu₀K
  have huI : u ∈ Icc 0 J.K := ⟨by linarith [hu₀.1, min_le_right b J.K, min_le_left b J.K], by linarith [min_le_right b J.K]⟩
  refine ⟨J.s2 u, J.s2_mem_Icc huI, ?_⟩
  rw [J.Finv_unique huI rfl]
  exact ⟨by linarith, by linarith [min_le_left b J.K]⟩

/-- Continuity from the left at `a ∈ (0, 1]`. -/
theorem Finv_continuousWithinAt_left {a : ℝ} (ha : a ∈ Ioc (0 : ℝ) 1) :
    ContinuousWithinAt J.Finv (Iic a) a := by
  apply J.Finv_strictMonoOn.continuousWithinAt_left_of_exists_between (Icc_mem_nhdsLE_of_mem ha)
  intro b hb
  have hu₀ := J.Finv_mem ⟨ha.1.le, ha.2⟩
  have hu₀0 : 0 < J.Finv a := by
    rcases eq_or_lt_of_le hu₀.1 with h | h
    · have := J.s2_Finv ⟨ha.1.le, ha.2⟩; rw [← h, J.s2_zero] at this; linarith [ha.1]
    · exact h
  set u := (J.Finv a + max b 0) / 2 with hu
  have hmax : max b 0 < J.Finv a := max_lt hb hu₀0
  have huI : u ∈ Icc 0 J.K := ⟨by linarith [le_max_right b 0], by linarith [hu₀.2, le_max_left b 0, le_max_right b 0]⟩
  refine ⟨J.s2 u, J.s2_mem_Icc huI, ?_⟩
  rw [J.Finv_unique huI rfl]
  exact ⟨by linarith [le_max_left b 0], by linarith⟩

theorem Finv_cont : ContinuousOn J.Finv (Icc 0 1) := by
  intro a ha
  rcases eq_or_lt_of_le ha.1 with h0 | h0
  · subst h0
    exact (J.Finv_continuousWithinAt_right ⟨le_rfl, by norm_num⟩).mono fun x hx => hx.1
  rcases eq_or_lt_of_le ha.2 with h1 | h1
  · subst h1
    exact (J.Finv_continuousWithinAt_left ⟨h0, le_rfl⟩).mono fun x hx => hx.2
  · have := (J.Finv_continuousWithinAt_left ⟨h0, h1.le⟩).union (J.Finv_continuousWithinAt_right ⟨h0.le, h1⟩)
    exact this.mono fun x hx => by rcases le_or_gt x a with h | h; exact Or.inl h; exact Or.inr h.le

theorem Finv_continuousAt {r : ℝ} (hr : r ∈ Ioo (0 : ℝ) 1) : ContinuousAt J.Finv r :=
  continuousAt_iff_continuous_left_right.2
    ⟨J.Finv_continuousWithinAt_left ⟨hr.1, hr.2.le⟩, J.Finv_continuousWithinAt_right ⟨hr.1.le, hr.2⟩⟩

theorem Finv_mem_Ioo {r : ℝ} (hr : r ∈ Ioo (0 : ℝ) 1) : J.Finv r ∈ Ioo 0 J.K := by
  have hm := J.Finv_mem ⟨hr.1.le, hr.2.le⟩
  have hs := J.s2_Finv ⟨hr.1.le, hr.2.le⟩
  constructor
  · rcases eq_or_lt_of_le hm.1 with h | h
    · rw [← h, J.s2_zero] at hs; linarith [hr.1]
    · exact h
  · rcases eq_or_lt_of_le hm.2 with h | h
    · rw [h, J.s2_K] at hs; linarith [hr.2]
    · exact h

theorem Finv_deriv {r : ℝ} (hr : r ∈ Ioo (0 : ℝ) 1) :
    HasDerivAt J.Finv (1 / (2 * Real.sqrt (r * (1 - r) * (1 - J.k ^ 2 * r)))) r := by
  set u := J.Finv r with hu
  have huI := J.Finv_mem_Ioo hr
  have hs : 0 < J.s u := J.s_pos_of_mem_Ioc ⟨huI.1, huI.2.le⟩
  have hc : 0 < J.c u := J.c_pos u ⟨huI.1.le, huI.2⟩
  have hd : 0 < J.d u := J.d_pos u
  have hr' : J.s2 u = r := J.s2_Finv ⟨hr.1.le, hr.2.le⟩
  have hf' : 2 * J.s u * (J.c u * J.d u) ≠ 0 := by positivity
  have hfg : ∀ᶠ y in nhds r, J.s2 (J.Finv y) = y := by
    filter_upwards [Ioo_mem_nhds hr.1 hr.2] with y hy
    exact J.s2_Finv ⟨hy.1.le, hy.2.le⟩
  have h := HasDerivAt.of_local_left_inverse (J.Finv_continuousAt hr) (J.hasDerivAt_s2 u) hf' hfg
  refine h.congr_deriv ?_
  -- `s = √r`, `c = √(1 - r)`, `d = √(1 - k² r)` at `u`
  have hsq : J.s u = Real.sqrt r := by rw [← hr']; unfold s2; rw [Real.sqrt_sq hs.le]
  have hcq : J.c u = Real.sqrt (1 - r) := by
    have : J.c u ^ 2 = 1 - r := by have := J.sc u; unfold s2 at hr'; linarith
    rw [← this, Real.sqrt_sq hc.le]
  have hdq : J.d u = Real.sqrt (1 - J.k ^ 2 * r) := by
    have : J.d u ^ 2 = 1 - J.k ^ 2 * r := by rw [J.sd]; unfold s2 at hr'; rw [hr']
    rw [← this, Real.sqrt_sq hd.le]
  rw [hsq, hcq, hdq, inv_eq_one_div]
  congr 1
  rw [Real.sqrt_mul (by nlinarith [hr.1, hr.2] : 0 ≤ r * (1 - r)), Real.sqrt_mul hr.1.le]
  ring

/-! ### `sn² x = sn² y` exactly when `x ≡ ±y (mod 2K)` -/

/-- Time reversal about `0` with the sign flip `(-S, C, D)`: a solution triple. -/
def Sol.negTime {k : ℝ} (F : Sol k) : Sol k where
  S := fun u => -F.S (-u)
  C := fun u => F.C (-u)
  D := fun u => F.D (-u)
  hS := fun u => by
    have h := ((F.hS (0 - u)).comp_const_sub 0 u).neg
    simp only [zero_sub] at h
    exact h.congr_deriv (by ring)
  hC := fun u => by
    have h := (F.hC (0 - u)).comp_const_sub 0 u
    simp only [zero_sub] at h
    exact h.congr_deriv (by ring)
  hD := fun u => by
    have h := (F.hD (0 - u)).comp_const_sub 0 u
    simp only [zero_sub] at h
    exact h.congr_deriv (by ring)
  bS := fun u => by simp only [abs_neg]; exact F.bS _
  bC := fun u => F.bC _
  bD := fun u => F.bD _

theorem s_neg (u : ℝ) : J.s (-u) = -J.s u := by
  have h := Sol.eq_of_eq_at J.k_nonneg J.k_le_one J.sol.negTime J.sol 0
    (by simp only [Sol.negTime, sol]; rw [neg_zero, J.s0]; ring)
    (by simp only [Sol.negTime, sol]; rw [neg_zero])
    (by simp only [Sol.negTime, sol]; rw [neg_zero]) u
  have := h.1; simp only [Sol.negTime, sol] at this; linarith

theorem s_sub_2K (u : ℝ) : J.s (u - 2 * J.K) = -J.s u := by
  have := J.s_shift (u - 2 * J.K); rw [sub_add_cancel] at this; linarith

theorem s2_shift_int (n : ℤ) (u : ℝ) : J.s2 (u + 2 * J.K * n) = J.s2 u := by
  induction n using Int.induction_on with
  | zero => simp
  | succ n ih =>
    rw [show u + 2 * J.K * ((n + 1 : ℤ) : ℝ) = (u + 2 * J.K * n) + 2 * J.K by push_cast; ring]
    unfold s2 at ih ⊢; rw [J.s_shift, neg_sq, ← ih]; rfl
  | pred n ih =>
    rw [show u + 2 * J.K * ((-(n : ℤ) - 1 : ℤ) : ℝ) = (u + 2 * J.K * ((-(n : ℤ) : ℤ) : ℝ)) - 2 * J.K by
      push_cast; ring]
    unfold s2 at ih ⊢; rw [J.s_sub_2K, neg_sq, ← ih]

theorem s2_reflect (u : ℝ) : J.s2 (2 * J.K - u) = J.s2 u := by unfold s2; rw [J.s_reflect]
theorem s2_neg (u : ℝ) : J.s2 (-u) = J.s2 u := by unfold s2; rw [J.s_neg, neg_sq]

/-- The reduction of `x` modulo `2K` into `[0, 2K)`. -/
theorem reduce (x : ℝ) : ∃ m : ℤ, x - 2 * J.K * m ∈ Ico 0 (2 * J.K) := by
  refine ⟨⌊x / (2 * J.K)⌋, ?_, ?_⟩
  · have := Int.floor_le (x / (2 * J.K))
    have h2K : 0 < 2 * J.K := by linarith [J.K_pos]
    have := (le_div_iff₀ h2K).mp this
    linarith
  · have := Int.lt_floor_add_one (x / (2 * J.K))
    have h2K : 0 < 2 * J.K := by linarith [J.K_pos]
    have := (div_lt_iff₀ h2K).mp this
    linarith

/-- Folding `[0, 2K)` onto `[0, K]` by the reflection. -/
theorem fold {t : ℝ} (ht : t ∈ Ico 0 (2 * J.K)) :
    ∃ t' ∈ Icc 0 J.K, J.s2 t' = J.s2 t ∧ (t' = t ∨ t' = 2 * J.K - t) := by
  rcases le_or_gt t J.K with h | h
  · exact ⟨t, ⟨ht.1, h⟩, rfl, Or.inl rfl⟩
  · exact ⟨2 * J.K - t, ⟨by linarith [ht.2], by linarith⟩, J.s2_reflect t, Or.inr rfl⟩

theorem sn_sq_eq_iff (x y : ℝ) :
    J.s x ^ 2 = J.s y ^ 2 ↔ ∃ n : ℤ, x = y + 2 * J.K * n ∨ x = -y + 2 * J.K * n := by
  constructor
  · intro h
    obtain ⟨m, hm⟩ := J.reduce x
    obtain ⟨n, hn⟩ := J.reduce y
    have hx : J.s2 (x - 2 * J.K * m) = J.s2 x := by
      have := J.s2_shift_int (-m) x; push_cast at this; rw [← this]; ring_nf
    have hy : J.s2 (y - 2 * J.K * n) = J.s2 y := by
      have := J.s2_shift_int (-n) y; push_cast at this; rw [← this]; ring_nf
    obtain ⟨x', hx'I, hx's, hx'e⟩ := J.fold hm
    obtain ⟨y', hy'I, hy's, hy'e⟩ := J.fold hn
    have heq : x' = y' := J.s2_strictMonoOn.injOn hx'I hy'I (by
      rw [hx's, hy's, hx, hy]; exact h)
    rcases hx'e with hx'e | hx'e <;> rcases hy'e with hy'e | hy'e
    · exact ⟨m - n, Or.inl (by push_cast; linarith)⟩
    · exact ⟨m + n + 1, Or.inr (by push_cast; linarith)⟩
    · exact ⟨m + n + 1, Or.inr (by push_cast; linarith)⟩
    · exact ⟨m - n, Or.inl (by push_cast; linarith)⟩
  · rintro ⟨n, h | h⟩
    · have := J.s2_shift_int n y; unfold s2 at this; rw [h, this]
    · have := J.s2_shift_int n (-y); unfold s2 at this; rw [h, this, J.s_neg, neg_sq]

/-- Every hypothesis of `JacobiFull` is now a theorem of the 13-hypothesis core. -/
def toJacobiFull : JacobiFull where
  toJacobiPeriodic := J.toJacobiPeriodic
  Finv := J.Finv
  Finv_deriv := fun r hr => J.Finv_deriv hr
  Finv_cont := J.Finv_cont
  Finv_zero := J.Finv_zero
  Finv_one := J.Finv_one
  Finv_spec := fun r hr => J.Finv_spec hr
  sn_sq_eq_iff := J.sn_sq_eq_iff

end JacobiCore
