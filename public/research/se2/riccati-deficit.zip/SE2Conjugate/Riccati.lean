import SE2Conjugate.Identities

/-!
# Lemma 3.2 (Riccati slope bound)

With `a = f₁/q` and `b = -β₁/ℰ` one has `z = ab = -β/ℓ`, the Riccati pair
`a' = (dn² + cn a + k² sn² a²)/(dn sn)`, `b' = ((1-k²) sn² - cn b - dn² b²)/(dn sn)`,
hence `z' = (T₁ + T₂)/(dn sn)` with `T₁ = dn² b (1-z)`, `T₂ = sn² a 𝖣`, `𝖣 = 1 - k² + k² z`,
`T₁ T₂ = dn² sn² z (1-z) 𝖣`, and by the arithmetic–geometric mean inequality
`|z'| ≥ 2 √(z (1-z) 𝖣)`.

The derivatives are stated with cleared denominators (polynomial numerators over `dn sn q²` and
`dn sn ℰ²`), which is what `linear_combination` can check; `a_deriv_form`/`b_deriv_form` convert
them to the paper's form.
-/

namespace JacobiData

noncomputable section

variable (J : JacobiData)

/-- `a = f₁/q`. -/
def a (p : ℝ) : ℝ := J.f1 p / J.q p

/-- `b = -β₁/ℰ`. -/
def b (p : ℝ) : ℝ := -J.β1 p / J.eps p

/-- `z = a b`. -/
def z (p : ℝ) : ℝ := J.a p * J.b p

/-- `𝖣 = 1 - k² + k² z`. -/
def Dz (p : ℝ) : ℝ := 1 - J.k ^ 2 + J.k ^ 2 * J.z p

/-- `T₁ = dn² b (1 - z)`. -/
def T1 (p : ℝ) : ℝ := J.d p ^ 2 * J.b p * (1 - J.z p)

/-- `T₂ = sn² a 𝖣`. -/
def T2 (p : ℝ) : ℝ := J.s p ^ 2 * J.a p * J.Dz p

theorem z_eq_neg_beta_div_ell (p : ℝ) (hq : J.q p ≠ 0) (he : J.eps p ≠ 0) :
    J.z p = -J.β p / J.ell p := by
  unfold z a b β ell
  field_simp

/-- The Riccati equation for `a`, with cleared denominators. -/
theorem hasDerivAt_a (p : ℝ) (hq : J.q p ≠ 0) (hs : J.s p ≠ 0) (hd : J.d p ≠ 0) :
    HasDerivAt J.a
      ((J.d p ^ 2 * J.q p ^ 2 + J.c p * J.f1 p * J.q p + J.k ^ 2 * J.s p ^ 2 * J.f1 p ^ 2)
        / (J.d p * J.s p * J.q p ^ 2)) p := by
  have h := (J.hasDerivAt_f1 p).div (J.hasDerivAt_q p) hq
  unfold a
  refine h.congr_deriv ?_
  rw [div_eq_div_iff (pow_ne_zero 2 hq) (mul_ne_zero (mul_ne_zero hd hs) (pow_ne_zero 2 hq))]
  unfold f1 q
  linear_combination
    (-((-(J.eps p) + p) ^ 4 * (J.k * J.s p - 1) * (J.k * J.s p + 1))) * J.sc p
    + ((-(J.eps p) + p) ^ 3 * (-(J.c p * J.d p * J.s p) - J.eps p * J.s p ^ 2 + J.eps p
        + p * J.s p ^ 2 - p)) * J.sd p

/-- The Riccati equation for `b`, with cleared denominators. -/
theorem hasDerivAt_b (p : ℝ) (he : J.eps p ≠ 0) (hs : J.s p ≠ 0) (hd : J.d p ≠ 0) :
    HasDerivAt J.b
      (((1 - J.k ^ 2) * J.s p ^ 2 * J.eps p ^ 2 + J.c p * J.β1 p * J.eps p - J.d p ^ 2 * J.β1 p ^ 2)
        / (J.d p * J.s p * J.eps p ^ 2)) p := by
  have h := (J.hasDerivAt_β1 p).neg.div (J.heps p) he
  unfold b
  refine h.congr_deriv ?_
  rw [div_eq_div_iff (pow_ne_zero 2 he) (mul_ne_zero (mul_ne_zero hd hs) (pow_ne_zero 2 he))]
  unfold β1
  simp only [Pi.neg_apply]
  linear_combination (J.eps p ^ 4 * (J.d p - 1) * (J.d p + 1)) * J.sc p
    + (-(J.eps p ^ 3 * (J.c p * J.d p * J.s p - J.eps p))) * J.sd p

/-- The paper's form `a' = (dn² + cn a + k² sn² a²)/(dn sn)`. -/
theorem a_deriv_form (p : ℝ) (hq : J.q p ≠ 0) (hs : J.s p ≠ 0) (hd : J.d p ≠ 0) :
    (J.d p ^ 2 * J.q p ^ 2 + J.c p * J.f1 p * J.q p + J.k ^ 2 * J.s p ^ 2 * J.f1 p ^ 2)
        / (J.d p * J.s p * J.q p ^ 2)
      = (J.d p ^ 2 + J.c p * J.a p + J.k ^ 2 * J.s p ^ 2 * J.a p ^ 2) / (J.d p * J.s p) := by
  unfold a
  field_simp

/-- The paper's form `b' = ((1-k²) sn² - cn b - dn² b²)/(dn sn)`. -/
theorem b_deriv_form (p : ℝ) (he : J.eps p ≠ 0) (hs : J.s p ≠ 0) (hd : J.d p ≠ 0) :
    ((1 - J.k ^ 2) * J.s p ^ 2 * J.eps p ^ 2 + J.c p * J.β1 p * J.eps p - J.d p ^ 2 * J.β1 p ^ 2)
        / (J.d p * J.s p * J.eps p ^ 2)
      = ((1 - J.k ^ 2) * J.s p ^ 2 - J.c p * J.b p - J.d p ^ 2 * J.b p ^ 2) / (J.d p * J.s p) := by
  unfold b
  field_simp
  ring

/-- `z' = (T₁ + T₂)/(dn sn)`: the mixed terms of `(ab)'` cancel. -/
theorem hasDerivAt_z (p : ℝ) (hq : J.q p ≠ 0) (he : J.eps p ≠ 0) (hs : J.s p ≠ 0)
    (hd : J.d p ≠ 0) :
    HasDerivAt J.z ((J.T1 p + J.T2 p) / (J.d p * J.s p)) p := by
  have h := (J.hasDerivAt_a p hq hs hd).mul (J.hasDerivAt_b p he hs hd)
  unfold z
  refine h.congr_deriv ?_
  rw [J.a_deriv_form p hq hs hd, J.b_deriv_form p he hs hd]
  unfold T1 T2 Dz z
  field_simp
  ring

theorem T1_mul_T2 (p : ℝ) :
    J.T1 p * J.T2 p = (J.d p * J.s p) ^ 2 * (J.z p * (1 - J.z p) * J.Dz p) := by
  unfold T1 T2 z
  ring

/-- Two-variable arithmetic–geometric mean inequality. -/
theorem two_sqrt_mul_le_add {x y : ℝ} (hx : 0 ≤ x) (hy : 0 ≤ y) :
    2 * Real.sqrt (x * y) ≤ x + y := by
  rw [Real.sqrt_mul hx]
  nlinarith [sq_nonneg (Real.sqrt x - Real.sqrt y), Real.sq_sqrt hx, Real.sq_sqrt hy,
    Real.sqrt_nonneg x, Real.sqrt_nonneg y]

theorem Dz_pos (p : ℝ) (hz : 0 ≤ J.z p) : 0 < J.Dz p := by
  unfold Dz
  have hk1 : 0 < 1 - J.k ^ 2 := by nlinarith [J.k_pos, J.k_lt_one]
  have : 0 ≤ J.k ^ 2 * J.z p := mul_nonneg (sq_nonneg _) hz
  linarith

/-- The slope bound of Lemma 3.2 on the first bracket, where `a, b, sn > 0`:
`z' ≥ 2 √(z (1-z) 𝖣)`. -/
theorem slope_bound_pos (p : ℝ) (ha : 0 < J.a p) (hb : 0 < J.b p) (hz1 : J.z p < 1)
    (hd : 0 < J.d p) (hs : 0 < J.s p) :
    2 * Real.sqrt (J.z p * (1 - J.z p) * J.Dz p) ≤ (J.T1 p + J.T2 p) / (J.d p * J.s p) := by
  have hz : 0 < J.z p := mul_pos ha hb
  have hD : 0 < J.Dz p := J.Dz_pos p hz.le
  have hT1 : 0 ≤ J.T1 p := by
    unfold T1
    exact mul_nonneg (mul_nonneg (sq_nonneg _) hb.le) (by linarith)
  have hT2 : 0 ≤ J.T2 p := by
    unfold T2
    exact mul_nonneg (mul_nonneg (sq_nonneg _) ha.le) hD.le
  have amgm := two_sqrt_mul_le_add hT1 hT2
  have hds : 0 < J.d p * J.s p := mul_pos hd hs
  rw [J.T1_mul_T2 p, Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq hds.le] at amgm
  rw [le_div_iff₀ hds]
  linarith

/-- Signs: if `a b > 0` then `T₁` and `T₂` have the common sign of `a` and `b`. -/
theorem T1_T2_same_sign (p : ℝ) (hab : 0 < J.a p * J.b p) (hz1 : J.z p < 1) (hd : 0 < J.d p)
    (hs : J.s p ≠ 0) : (0 < J.a p ∧ 0 < J.b p ∧ 0 ≤ J.T1 p ∧ 0 ≤ J.T2 p)
      ∨ (J.a p < 0 ∧ J.b p < 0 ∧ J.T1 p ≤ 0 ∧ J.T2 p ≤ 0) := by
  have hz : 0 < J.z p := hab
  have hD : 0 < J.Dz p := J.Dz_pos p hz.le
  have hs2 : 0 < J.s p ^ 2 := by positivity
  have hd2 : 0 < J.d p ^ 2 := by positivity
  have h1z : 0 < 1 - J.z p := by linarith
  rcases lt_or_gt_of_ne (show J.a p ≠ 0 from fun h => by rw [h, zero_mul] at hab; exact lt_irrefl _ hab)
    with ha | ha
  · right
    have hb : J.b p < 0 := by
      by_contra hb
      rw [not_lt] at hb
      nlinarith [mul_nonneg (neg_nonneg.mpr ha.le) hb]
    refine ⟨ha, hb, ?_, ?_⟩
    · unfold T1; nlinarith [mul_pos hd2 h1z]
    · unfold T2; nlinarith [mul_pos hs2 hD]
  · left
    have hb : 0 < J.b p := by
      by_contra hb
      rw [not_lt] at hb
      nlinarith [mul_nonneg ha.le (neg_nonneg.mpr hb)]
    refine ⟨ha, hb, ?_, ?_⟩
    · unfold T1; positivity
    · unfold T2; positivity

/-- **Lemma 3.2, general sign**: `|z'| ≥ 2 √(z (1-z) 𝖣)` whenever `a, b` have a common sign. -/
theorem slope_bound_abs (p : ℝ) (hab : 0 < J.a p * J.b p) (hz1 : J.z p < 1) (hd : 0 < J.d p)
    (hs : J.s p ≠ 0) :
    2 * Real.sqrt (J.z p * (1 - J.z p) * J.Dz p) ≤ |(J.T1 p + J.T2 p) / (J.d p * J.s p)| := by
  have hz : 0 < J.z p := hab
  have hD : 0 < J.Dz p := J.Dz_pos p hz.le
  have hds : 0 < J.d p * |J.s p| := mul_pos hd (abs_pos.mpr hs)
  have hprod : |J.T1 p| * |J.T2 p| = (J.d p * |J.s p|) ^ 2 * (J.z p * (1 - J.z p) * J.Dz p) := by
    have h1z : 0 < 1 - J.z p := by linarith
    rw [← abs_mul, J.T1_mul_T2 p,
      abs_of_nonneg (mul_nonneg (sq_nonneg _) (mul_nonneg (mul_nonneg hz.le h1z.le) hD.le))]
    rw [mul_pow, mul_pow, sq_abs]
  have amgm := two_sqrt_mul_le_add (abs_nonneg (J.T1 p)) (abs_nonneg (J.T2 p))
  rw [hprod, Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq hds.le] at amgm
  have hsum : |J.T1 p + J.T2 p| = |J.T1 p| + |J.T2 p| := by
    rcases J.T1_T2_same_sign p hab hz1 hd hs with ⟨_, _, h1, h2⟩ | ⟨_, _, h1, h2⟩
    · rw [abs_of_nonneg h1, abs_of_nonneg h2, abs_of_nonneg (by linarith)]
    · rw [abs_of_nonpos h1, abs_of_nonpos h2, abs_of_nonpos (by linarith)]; ring
  rw [abs_div, abs_mul, abs_of_pos hd, hsum, le_div_iff₀ hds]
  linarith

end

end JacobiData
