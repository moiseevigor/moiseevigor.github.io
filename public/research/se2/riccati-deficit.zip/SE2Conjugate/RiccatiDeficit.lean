import SE2Conjugate.Reduction
import SE2Conjugate.Tangency

noncomputable section
namespace JacobiCore.RiccatiDeficit

variable (J : JacobiCore)
local notation "A" => J.toJacobiFull.toJacobiData

def ratio (p : ℝ) := (A).z p / (A).Dz p
def lift (p : ℝ) := J.Finv (ratio J p)
def weight (p : ℝ) := (1 - J.k ^ 2) /
  (2 * (A).Dz p ^ 2 * |J.s p| * J.d p *
    Real.sqrt (ratio J p * (1 - ratio J p) * (1 - J.k ^ 2 * ratio J p)))

theorem squared_deficit {p : ℝ} (hp : 0 < p) (hs : J.s p ≠ 0)
    (hz : 0 < (A).z p) (hz1 : (A).z p < 1) :
    0 < weight J p ∧ |deriv (lift J) p| - 1 =
      weight J p * (Real.sqrt |(A).T1 p| - Real.sqrt |(A).T2 p|) ^ 2 := by
  have hd := J.d_pos p
  have hk : 0 < 1 - J.k ^ 2 := by nlinarith [J.k_pos, J.k_lt_one]
  have hD := (A).Dz_pos p hz.le
  have hDval : (A).Dz p = 1 - J.k ^ 2 + J.k ^ 2 * (A).z p := rfl
  have hz' := (A).hasDerivAt_z p (J.toJacobiFull.q_pos hp).ne'
    (J.toJacobiFull.eps_pos hp).ne' hs hd.ne'
  change HasDerivAt (A).z (((A).T1 p + (A).T2 p) / (J.d p * J.s p)) p at hz'
  have hDz := (hz'.const_mul (J.k ^ 2)).const_add (1 - J.k ^ 2)
  have hr : HasDerivAt (ratio J) ((1-J.k^2) *
      (((A).T1 p + (A).T2 p) / (J.d p * J.s p)) / (A).Dz p ^ 2) p := by
    apply (hz'.div hDz hD.ne').congr_deriv
    change (_ * (A).Dz p - _ * _) / (A).Dz p ^ 2 = _
    rw [hDval]
    ring
  have hr0 : 0 < ratio J p := div_pos hz hD
  have hr1 : ratio J p < 1 := by
    apply (div_lt_one hD).2
    nlinarith [mul_pos hk (sub_pos.mpr hz1)]
  let Q := Real.sqrt (ratio J p * (1-ratio J p) * (1-J.k^2*ratio J p))
  have hQ : 0 < Q := by
    apply Real.sqrt_pos.mpr
    exact mul_pos (mul_pos hr0 (sub_pos.mpr hr1)) (by nlinarith [mul_nonneg (sq_nonneg J.k) (sub_nonneg.mpr hr1.le)])
  have hder := ((J.Finv_deriv ⟨hr0,hr1⟩).comp p hr).deriv
  change deriv (lift J) p = 1 / (2 * Q) * _ at hder
  have hw : 0 < weight J p := div_pos hk (by change 0 < 2 * (A).Dz p ^ 2 * |J.s p| * J.d p * Q; positivity)
  have hsum : |(A).T1 p + (A).T2 p| = |(A).T1 p| + |(A).T2 p| := by
    rcases (A).T1_T2_same_sign p hz hz1 hd hs with ⟨_,_,h,g⟩ | ⟨_,_,h,g⟩
    · rw [abs_of_nonneg h, abs_of_nonneg g, abs_of_nonneg (add_nonneg h g)]
    · rw [abs_of_nonpos h, abs_of_nonpos g, abs_of_nonpos (add_nonpos h g)]; ring
  have hmag : |deriv (lift J) p| = weight J p * (|(A).T1 p| + |(A).T2 p|) := by
    rw [hder, abs_mul, abs_of_pos (by positivity : 0 < 1 / (2 * Q)), abs_div,
      abs_mul, abs_of_pos hk, abs_div, hsum, abs_mul, abs_of_pos hd, abs_of_nonneg (sq_nonneg ((A).Dz p))]
    unfold weight
    change _ = ((1-J.k^2) / (2 * (A).Dz p ^ 2 * |J.s p| * J.d p * Q)) * _
    ring
  have hrad : ((A).Dz p ^ 2 * Q)^2 =
      (1-J.k^2)^2 * ((A).z p * (1-(A).z p) * (A).Dz p) := by
    rw [mul_pow, show Q^2 = _ from Real.sq_sqrt (Real.sqrt_pos.mp hQ).le]
    unfold ratio
    field_simp [hD.ne']
    rw [hDval]
    ring
  have ht := (A).T1_mul_T2 p
  change (A).T1 p * (A).T2 p = (J.d p * J.s p)^2 * _ at ht
  have hprod : 0 ≤ (A).T1 p * (A).T2 p := by rw [ht]; positivity
  let x := Real.sqrt |(A).T1 p|
  let y := Real.sqrt |(A).T2 p|
  have hx : x^2 = |(A).T1 p| := Real.sq_sqrt (abs_nonneg _)
  have hy : y^2 = |(A).T2 p| := Real.sq_sqrt (abs_nonneg _)
  have hxy : ((1-J.k^2)*x*y)^2 = ((A).Dz p^2 * Q * |J.s p| * J.d p)^2 := by
    simp only [mul_pow, hx, hy, sq_abs] at hrad ⊢
    rw [show (1-J.k^2)^2 * |(A).T1 p| * |(A).T2 p| = (1-J.k^2)^2 * ((A).T1 p * (A).T2 p) by
      rw [mul_assoc, ← abs_mul, abs_of_nonneg hprod], ht]
    linear_combination - (J.s p^2 * J.d p^2) * hrad
  have hbalance : (1-J.k^2)*x*y = (A).Dz p^2 * Q * |J.s p| * J.d p :=
    (sq_eq_sq₀ (by dsimp [x,y]; positivity) (by positivity)).mp hxy
  have hunit : weight J p * (2*x*y) = 1 := by
    unfold weight
    change ((1-J.k^2) / (2 * (A).Dz p ^ 2 * |J.s p| * J.d p * Q)) * _ = _
    field_simp [hD.ne', hd.ne', hQ.ne', abs_ne_zero.mpr hs]
    linarith only [hbalance]
  refine ⟨hw, ?_⟩
  change _ = weight J p * (x-y)^2
  rw [hmag, ← hx, ← hy, ← hunit]
  ring

theorem unit_slope_iff {p : ℝ} (hp : 0 < p) (hs : J.s p ≠ 0)
    (hz : 0 < (A).z p) (hz1 : (A).z p < 1) :
    1 ≤ |deriv (lift J) p| ∧ (|deriv (lift J) p| = 1 ↔ |(A).T1 p| = |(A).T2 p|) := by
  obtain ⟨hw,h⟩ := squared_deficit J hp hs hz hz1
  constructor
  · linarith [mul_nonneg hw.le (sq_nonneg (Real.sqrt |(A).T1 p| - Real.sqrt |(A).T2 p|))]
  constructor
  · intro he
    rw [he, sub_self, eq_comm, mul_eq_zero] at h
    have hd := sub_eq_zero.mp (pow_eq_zero_iff (by decide : 2 ≠ 0) |>.mp (h.resolve_left hw.ne'))
    exact (Real.sqrt_inj (abs_nonneg _) (abs_nonneg _)).mp hd
  · intro he
    rw [he, sub_self] at h
    linarith

/-- Lemma 3.2 on its original domain, with y = X/ℓ. -/
theorem article_slope {p : ℝ} (hp : 0 < p) (hs : J.s p ≠ 0)
    (hy : (A).X p / (A).ell p ∈ Set.Ioo (0 : ℝ) 1) :
    2 * Real.sqrt ((A).z p * (1 - (A).z p) * (A).Dz p) ≤ |deriv (A).z p| ∧
    1 ≤ |deriv (lift J) p| ∧
    (|deriv (lift J) p| = 1 ↔ |(A).T1 p| = |(A).T2 p|) ∧
    ((A).H p = 0 → deriv (A).H p ≠ 0) := by
  have hq := (J.toJacobiFull.q_pos hp).ne'
  have he := (J.toJacobiFull.eps_pos hp).ne'
  have hd := J.d_pos p
  have hl : (A).ell p ≠ 0 := by unfold JacobiData.ell; exact mul_ne_zero he hq
  have hzy : (A).z p = 1 - (A).X p / (A).ell p := by
    rw [(A).z_eq_neg_beta_div_ell p hq he, (A).collapse_beta p]
    field_simp
    ring
  have hz : 0 < (A).z p := by rw [hzy]; exact sub_pos.mpr hy.2
  have hz1 : (A).z p < 1 := by rw [hzy]; linarith [hy.1]
  obtain ⟨hbound, hiff⟩ := unit_slope_iff J hp hs hz hz1
  refine ⟨?_, hbound, hiff, ?_⟩
  · rw [((A).hasDerivAt_z p hq he hs hd.ne').deriv]
    exact (A).slope_bound_abs p hz hz1 hd hs
  · intro h
    rw [((A).hasDerivAt_H p hq he hs hd.ne').deriv]
    exact (A).Hp_ne_of_H_zero p hq hs hd.ne' hz h

end JacobiCore.RiccatiDeficit
