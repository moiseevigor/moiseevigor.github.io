import SE2Conjugate.ArticleExtension

noncomputable section
namespace JacobiCore
variable (J : JacobiCore)

def marginCoeffs (x b σ : ℝ) : ℝ × ℝ × ℝ :=
  let e := J.eps x
  let q := x-e
  let t := J.s x*J.c x*J.d x
  (b*(4*J.E*(J.K-J.E))+σ*(2*(J.K-2*J.E)*t),
   b*(2*(J.E*q+(J.K-J.E)*e)/5)+σ*(t*(x-2*e)+J.s x^2*J.d x^2)/5,
   b*e*q/25)

/-- Three inequalities per sign suffice for *all* subsequent integer cells. -/
theorem profile_bound_all (n : ℕ) (hn : 5 ≤ n) (x b : ℝ) (hb : 0<b)
    (cert : ∀ σ ∈ ({-1,1} : Set ℝ),
      let c := J.marginCoeffs x b σ
      0<c.1 ∧ 0<c.1+c.2.1/2 ∧ 0<c.1+c.2.1+c.2.2) :
    |(n:ℝ)*(J.toJacobiData.X (x+2*n*J.K)/J.toJacobiData.ell (x+2*n*J.K)-J.s x^2)| < b := by
  have hn' : (5:ℝ) ≤ n := by exact_mod_cast hn
  have hpos : 0<(n:ℝ) := by linarith
  have hv : 5/(n:ℝ) ≤ 1 := (div_le_one hpos).mpr hn'
  have hmargin (σ : ℝ) (hs : σ ∈ ({-1,1}:Set ℝ)) :
      0 < b*J.periodWeight n x + σ*n*J.profileCorrection n x := by
    let c := J.marginCoeffs x b σ
    obtain ⟨h0,h1,h2⟩ := cert σ hs
    have hp := se2_quadratic_positive c.1 c.2.1 c.2.2 (5/n) (by positivity) hv h0 h1 h2
    have h := mul_pos hp (sq_pos_of_pos hpos)
    have eqn : b*J.periodWeight n x+σ*n*J.profileCorrection n x =
        (c.1+c.2.1*(5/n)+c.2.2*(5/n)^2)*(n:ℝ)^2 := by
      dsimp [c,marginCoeffs,periodWeight,profileCorrection]
      field_simp [hpos.ne']
      ring
    rwa [eqn]
  have hm := hmargin (-1) (by simp)
  have hp := hmargin 1 (by simp)
  have hw : 0 < J.periodWeight n x := by
    by_contra! bad
    have := mul_nonpos_of_nonneg_of_nonpos hb.le bad
    linarith
  rw [J.profile_exact n x hw.ne',← mul_div_assoc,abs_lt]
  constructor
  · apply (lt_div_iff₀ hw).mpr
    linarith
  · apply (div_lt_iff₀ hw).mpr
    linarith
end JacobiCore
