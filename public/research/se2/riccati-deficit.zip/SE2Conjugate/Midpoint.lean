import SE2Conjugate.Addition
import SE2Conjugate.RectifiedEndpoint
noncomputable section
namespace JacobiConcrete.AmplitudeChart
set_option maxHeartbeats 4000000

def midpointJ (k s c d h C p e : ℝ) : ℝ := C ^ 2 * (c * e - d * s) * (c * (e - p) - d * s) + h ^ 2 * s * (1 - k ^ 2) * (c * d * (-2 * e + p) + s * (d ^ 2 + e * (-e + p)))

def midpointNumerator (k s c d h C D p e : ℝ) : ℝ := -(2 - 2 * k ^ 2) * (-h ^ 2 * k ^ 2 * s ^ 2 + 1) ^ 4 + (C * c - D * d * h * s) * (C * c + D * d * h * s) * (-2 * k ^ 2 * (-h ^ 2 * k ^ 2 * s ^ 2 + 1) ^ 2 + (-C * c * h * k ^ 2 * s + D * d) ^ 2 + (C * c * h * k ^ 2 * s + D * d) ^ 2 + (-2 * c * d * h ^ 2 * k ^ 2 * s + 2 * e * (-h ^ 2 * k ^ 2 * s ^ 2 + 1)) * (2 * c * d * h ^ 2 * k ^ 2 * s - 2 * e * (-h ^ 2 * k ^ 2 * s ^ 2 + 1) + 2 * p * (-h ^ 2 * k ^ 2 * s ^ 2 + 1))) + (-2 * C * D * s + 2 * c * d * h) * (C * D * s + c * d * h) * (-C * c * h * k ^ 2 * s + D * d) * (C * c * h * k ^ 2 * s + D * d) + (-(C * c - D * d * h * s) * (-C * D * s + c * d * h) * (C * c * h * k ^ 2 * s + D * d) + (C * c + D * d * h * s) * (C * D * s + c * d * h) * (-C * c * h * k ^ 2 * s + D * d)) * (-4 * c * d * h ^ 2 * k ^ 2 * s + 4 * e * (-h ^ 2 * k ^ 2 * s ^ 2 + 1) - 2 * p * (-h ^ 2 * k ^ 2 * s ^ 2 + 1))

theorem midpoint_polynomial (k s c d h C D p e : ℝ)
    (hd : d^2 + k^2*s^2 = 1) (hD : D^2 + k^2*h^2 = 1)
    (hc : c^2+s^2=1) (hC : C^2+h^2=1) :
    midpointNumerator k s c d h C D p e +
      4 * midpointJ k s c d h C p e * (1-k^2*s^2*h^2)^3 = 0 := by
  dsimp [midpointNumerator, midpointJ]
  linear_combination (-2 * C ^ 2 * D ^ 4 * s ^ 2 + 6 * C ^ 2 * D ^ 2 * c ^ 2 * h ^ 4 * k ^ 4 * s ^ 4 - 8 * C ^ 2 * D ^ 2 * c ^ 2 * h ^ 2 * k ^ 2 * s ^ 2 + 2 * C ^ 2 * D ^ 2 * c ^ 2 + 2 * C ^ 2 * c ^ 4 * h ^ 4 * k ^ 4 * s ^ 2 - 4 * C ^ 2 * h ^ 6 * k ^ 6 * s ^ 8 + 12 * C ^ 2 * h ^ 4 * k ^ 4 * s ^ 6 - 12 * C ^ 2 * h ^ 2 * k ^ 2 * s ^ 4 + 4 * C ^ 2 * s ^ 2 - 2 * D ^ 4 * d ^ 2 * h ^ 2 * s ^ 2 + 2 * D ^ 4 * h ^ 2 * k ^ 2 * s ^ 4 - 2 * D ^ 4 * h ^ 2 * s ^ 2 + 4 * D ^ 2 * c ^ 2 * d ^ 2 * h ^ 6 * k ^ 4 * s ^ 4 - 8 * D ^ 2 * c ^ 2 * d ^ 2 * h ^ 4 * k ^ 2 * s ^ 2 + 2 * D ^ 2 * c ^ 2 * d ^ 2 * h ^ 2 - 4 * D ^ 2 * c ^ 2 * h ^ 6 * k ^ 6 * s ^ 6 + 4 * D ^ 2 * c ^ 2 * h ^ 6 * k ^ 4 * s ^ 4 + 8 * D ^ 2 * c ^ 2 * h ^ 4 * k ^ 4 * s ^ 4 - 8 * D ^ 2 * c ^ 2 * h ^ 4 * k ^ 2 * s ^ 2 - 2 * D ^ 2 * c ^ 2 * h ^ 2 * k ^ 2 * s ^ 2 + 2 * D ^ 2 * c ^ 2 * h ^ 2 + 8 * D ^ 2 * c * d * e * h ^ 6 * k ^ 4 * s ^ 5 - 16 * D ^ 2 * c * d * e * h ^ 4 * k ^ 2 * s ^ 3 + 8 * D ^ 2 * c * d * e * h ^ 2 * s - 4 * D ^ 2 * c * d * h ^ 6 * k ^ 4 * p * s ^ 5 + 8 * D ^ 2 * c * d * h ^ 4 * k ^ 2 * p * s ^ 3 - 4 * D ^ 2 * c * d * h ^ 2 * p * s + 4 * D ^ 2 * e ^ 2 * h ^ 6 * k ^ 4 * s ^ 6 - 8 * D ^ 2 * e ^ 2 * h ^ 4 * k ^ 2 * s ^ 4 + 4 * D ^ 2 * e ^ 2 * h ^ 2 * s ^ 2 - 4 * D ^ 2 * e * h ^ 6 * k ^ 4 * p * s ^ 6 + 8 * D ^ 2 * e * h ^ 4 * k ^ 2 * p * s ^ 4 - 4 * D ^ 2 * e * h ^ 2 * p * s ^ 2 + 2 * D ^ 2 * h ^ 6 * k ^ 6 * s ^ 6 - 4 * D ^ 2 * h ^ 4 * k ^ 4 * s ^ 4 + 2 * D ^ 2 * h ^ 2 * k ^ 2 * s ^ 2 + 4 * h ^ 8 * k ^ 8 * s ^ 8 - 4 * h ^ 8 * k ^ 6 * s ^ 8 - 12 * h ^ 6 * k ^ 6 * s ^ 6 + 12 * h ^ 6 * k ^ 4 * s ^ 6 + 12 * h ^ 4 * k ^ 4 * s ^ 4 - 12 * h ^ 4 * k ^ 2 * s ^ 4 - 4 * h ^ 2 * k ^ 2 * s ^ 2 + 4 * h ^ 2 * s ^ 2) * hd + (2 * C ^ 4 * c ^ 2 * h ^ 2 * k ^ 4 * s ^ 4 + 2 * C ^ 2 * D ^ 2 * k ^ 2 * s ^ 4 - 2 * C ^ 2 * D ^ 2 * s ^ 2 - 6 * C ^ 2 * c ^ 2 * h ^ 4 * k ^ 6 * s ^ 6 + 6 * C ^ 2 * c ^ 2 * h ^ 4 * k ^ 4 * s ^ 4 + 8 * C ^ 2 * c ^ 2 * h ^ 2 * k ^ 4 * s ^ 4 - 8 * C ^ 2 * c ^ 2 * h ^ 2 * k ^ 2 * s ^ 2 - 2 * C ^ 2 * c ^ 2 * k ^ 2 * s ^ 2 + 2 * C ^ 2 * c ^ 2 + 8 * C ^ 2 * c * d * e * h ^ 4 * k ^ 4 * s ^ 5 - 16 * C ^ 2 * c * d * e * h ^ 2 * k ^ 2 * s ^ 3 + 8 * C ^ 2 * c * d * e * s - 4 * C ^ 2 * c * d * h ^ 4 * k ^ 4 * p * s ^ 5 + 8 * C ^ 2 * c * d * h ^ 2 * k ^ 2 * p * s ^ 3 - 4 * C ^ 2 * c * d * p * s - 2 * C ^ 2 * h ^ 2 * k ^ 4 * s ^ 4 + 2 * C ^ 2 * h ^ 2 * k ^ 2 * s ^ 2 + 2 * C ^ 2 * k ^ 2 * s ^ 4 - 2 * C ^ 2 * s ^ 2 - 2 * D ^ 2 * h ^ 2 * k ^ 4 * s ^ 6 + 4 * D ^ 2 * h ^ 2 * k ^ 2 * s ^ 4 - 2 * D ^ 2 * h ^ 2 * s ^ 2 + 4 * c ^ 2 * h ^ 6 * k ^ 8 * s ^ 8 - 8 * c ^ 2 * h ^ 6 * k ^ 6 * s ^ 6 + 4 * c ^ 2 * h ^ 6 * k ^ 4 * s ^ 4 - 8 * c ^ 2 * h ^ 4 * k ^ 6 * s ^ 6 + 16 * c ^ 2 * h ^ 4 * k ^ 4 * s ^ 4 - 8 * c ^ 2 * h ^ 4 * k ^ 2 * s ^ 2 + 2 * c ^ 2 * h ^ 2 * k ^ 4 * s ^ 4 - 4 * c ^ 2 * h ^ 2 * k ^ 2 * s ^ 2 + 2 * c ^ 2 * h ^ 2 - 8 * c * d * e * h ^ 6 * k ^ 6 * s ^ 7 + 8 * c * d * e * h ^ 6 * k ^ 4 * s ^ 5 + 16 * c * d * e * h ^ 4 * k ^ 4 * s ^ 5 - 16 * c * d * e * h ^ 4 * k ^ 2 * s ^ 3 - 8 * c * d * e * h ^ 2 * k ^ 2 * s ^ 3 + 8 * c * d * e * h ^ 2 * s + 4 * c * d * h ^ 6 * k ^ 6 * p * s ^ 7 - 4 * c * d * h ^ 6 * k ^ 4 * p * s ^ 5 - 8 * c * d * h ^ 4 * k ^ 4 * p * s ^ 5 + 8 * c * d * h ^ 4 * k ^ 2 * p * s ^ 3 + 4 * c * d * h ^ 2 * k ^ 2 * p * s ^ 3 - 4 * c * d * h ^ 2 * p * s - 4 * e ^ 2 * h ^ 6 * k ^ 6 * s ^ 8 + 4 * e ^ 2 * h ^ 6 * k ^ 4 * s ^ 6 + 8 * e ^ 2 * h ^ 4 * k ^ 4 * s ^ 6 - 8 * e ^ 2 * h ^ 4 * k ^ 2 * s ^ 4 - 4 * e ^ 2 * h ^ 2 * k ^ 2 * s ^ 4 + 4 * e ^ 2 * h ^ 2 * s ^ 2 + 4 * e * h ^ 6 * k ^ 6 * p * s ^ 8 - 4 * e * h ^ 6 * k ^ 4 * p * s ^ 6 - 8 * e * h ^ 4 * k ^ 4 * p * s ^ 6 + 8 * e * h ^ 4 * k ^ 2 * p * s ^ 4 + 4 * e * h ^ 2 * k ^ 2 * p * s ^ 4 - 4 * e * h ^ 2 * p * s ^ 2 - 2 * h ^ 6 * k ^ 8 * s ^ 8 + 2 * h ^ 6 * k ^ 6 * s ^ 6 + 6 * h ^ 4 * k ^ 6 * s ^ 6 - 8 * h ^ 4 * k ^ 4 * s ^ 4 + 2 * h ^ 4 * k ^ 2 * s ^ 2 - 2 * h ^ 2 * k ^ 4 * s ^ 6 - 2 * h ^ 2 * k ^ 4 * s ^ 4 + 4 * h ^ 2 * k ^ 2 * s ^ 4 + 2 * h ^ 2 * k ^ 2 * s ^ 2 - 2 * h ^ 2 * s ^ 2) * hD + (2 * C ^ 4 * c ^ 2 * h ^ 2 * k ^ 4 * s ^ 2 - 2 * C ^ 4 * h ^ 4 * k ^ 6 * s ^ 4 + 2 * C ^ 4 * h ^ 2 * k ^ 4 * s ^ 2 - 2 * C ^ 2 * c ^ 2 * h ^ 4 * k ^ 6 * s ^ 4 + 2 * C ^ 2 * c ^ 2 * h ^ 4 * k ^ 4 * s ^ 2 - 4 * C ^ 2 * e ^ 2 * h ^ 6 * k ^ 6 * s ^ 6 + 8 * C ^ 2 * e ^ 2 * h ^ 4 * k ^ 4 * s ^ 4 - 4 * C ^ 2 * e ^ 2 * h ^ 2 * k ^ 2 * s ^ 2 + 4 * C ^ 2 * e * h ^ 6 * k ^ 6 * p * s ^ 6 - 8 * C ^ 2 * e * h ^ 4 * k ^ 4 * p * s ^ 4 + 4 * C ^ 2 * e * h ^ 2 * k ^ 2 * p * s ^ 2 + 6 * C ^ 2 * h ^ 6 * k ^ 8 * s ^ 6 - 6 * C ^ 2 * h ^ 6 * k ^ 6 * s ^ 4 - 4 * C ^ 2 * h ^ 4 * k ^ 6 * s ^ 6 - 12 * C ^ 2 * h ^ 4 * k ^ 6 * s ^ 4 + 4 * C ^ 2 * h ^ 4 * k ^ 4 * s ^ 4 + 10 * C ^ 2 * h ^ 4 * k ^ 4 * s ^ 2 + 8 * C ^ 2 * h ^ 2 * k ^ 4 * s ^ 4 + 6 * C ^ 2 * h ^ 2 * k ^ 4 * s ^ 2 - 8 * C ^ 2 * h ^ 2 * k ^ 2 * s ^ 2 - 2 * C ^ 2 * h ^ 2 * k ^ 2 - 2 * C ^ 2 * k ^ 2 * s ^ 2 - 2 * C ^ 2 * k ^ 2 + 2 * C ^ 2 - 4 * h ^ 8 * k ^ 10 * s ^ 8 + 8 * h ^ 8 * k ^ 8 * s ^ 6 - 4 * h ^ 8 * k ^ 6 * s ^ 4 + 4 * h ^ 6 * k ^ 8 * s ^ 8 + 8 * h ^ 6 * k ^ 8 * s ^ 6 - 8 * h ^ 6 * k ^ 6 * s ^ 6 - 16 * h ^ 6 * k ^ 6 * s ^ 4 + 4 * h ^ 6 * k ^ 4 * s ^ 4 + 8 * h ^ 6 * k ^ 4 * s ^ 2 - 8 * h ^ 4 * k ^ 6 * s ^ 6 - 2 * h ^ 4 * k ^ 6 * s ^ 4 + 16 * h ^ 4 * k ^ 4 * s ^ 4 + 4 * h ^ 4 * k ^ 4 * s ^ 2 - 8 * h ^ 4 * k ^ 2 * s ^ 2 - 2 * h ^ 4 * k ^ 2 + 2 * h ^ 2 * k ^ 4 * s ^ 4 - 4 * h ^ 2 * k ^ 2 * s ^ 2 + 2 * h ^ 2) * hc + (2 * C ^ 2 * h ^ 4 * k ^ 6 * s ^ 6 - 2 * C ^ 2 * h ^ 4 * k ^ 6 * s ^ 4 - 2 * C ^ 2 * h ^ 2 * k ^ 4 * s ^ 4 + 2 * C ^ 2 * h ^ 2 * k ^ 4 * s ^ 2 + 8 * c * d * e * h ^ 6 * k ^ 6 * s ^ 7 - 8 * c * d * e * h ^ 6 * k ^ 6 * s ^ 5 - 16 * c * d * e * h ^ 4 * k ^ 4 * s ^ 5 + 16 * c * d * e * h ^ 4 * k ^ 4 * s ^ 3 + 8 * c * d * e * h ^ 2 * k ^ 2 * s ^ 3 - 8 * c * d * e * h ^ 2 * k ^ 2 * s - 4 * c * d * h ^ 6 * k ^ 6 * p * s ^ 7 + 4 * c * d * h ^ 6 * k ^ 6 * p * s ^ 5 + 8 * c * d * h ^ 4 * k ^ 4 * p * s ^ 5 - 8 * c * d * h ^ 4 * k ^ 4 * p * s ^ 3 - 4 * c * d * h ^ 2 * k ^ 2 * p * s ^ 3 + 4 * c * d * h ^ 2 * k ^ 2 * p * s + 4 * e ^ 2 * h ^ 6 * k ^ 6 * s ^ 8 - 4 * e ^ 2 * h ^ 6 * k ^ 6 * s ^ 6 - 8 * e ^ 2 * h ^ 4 * k ^ 4 * s ^ 6 + 8 * e ^ 2 * h ^ 4 * k ^ 4 * s ^ 4 + 4 * e ^ 2 * h ^ 2 * k ^ 2 * s ^ 4 - 4 * e ^ 2 * h ^ 2 * k ^ 2 * s ^ 2 - 4 * e * h ^ 6 * k ^ 6 * p * s ^ 8 + 4 * e * h ^ 6 * k ^ 6 * p * s ^ 6 + 8 * e * h ^ 4 * k ^ 4 * p * s ^ 6 - 8 * e * h ^ 4 * k ^ 4 * p * s ^ 4 - 4 * e * h ^ 2 * k ^ 2 * p * s ^ 4 + 4 * e * h ^ 2 * k ^ 2 * p * s ^ 2 + 4 * h ^ 6 * k ^ 8 * s ^ 10 - 6 * h ^ 6 * k ^ 8 * s ^ 8 + 6 * h ^ 6 * k ^ 8 * s ^ 6 - 4 * h ^ 6 * k ^ 6 * s ^ 8 + 4 * h ^ 6 * k ^ 6 * s ^ 6 - 4 * h ^ 6 * k ^ 6 * s ^ 4 - 8 * h ^ 4 * k ^ 6 * s ^ 8 + 10 * h ^ 4 * k ^ 6 * s ^ 6 - 12 * h ^ 4 * k ^ 6 * s ^ 4 + 8 * h ^ 4 * k ^ 4 * s ^ 6 - 4 * h ^ 4 * k ^ 4 * s ^ 4 + 6 * h ^ 4 * k ^ 4 * s ^ 2 + 4 * h ^ 2 * k ^ 4 * s ^ 6 - 4 * h ^ 2 * k ^ 4 * s ^ 4 + 8 * h ^ 2 * k ^ 4 * s ^ 2 - 4 * h ^ 2 * k ^ 2 * s ^ 4 - 2 * h ^ 2 * k ^ 2 * s ^ 2 - 2 * h ^ 2 * k ^ 2 - 2 * k ^ 2 + 2) * hC

theorem midpoint_compact (k s c d h C D p e : ℝ)
    (hq : 1-k^2*s^2*h^2 ≠ 0)
    (hd : d^2 + k^2*s^2 = 1) (hD : D^2 + k^2*h^2 = 1)
    (hc : c^2+s^2=1) (hC : C^2+h^2=1) :
    let q := 1-k^2*s^2*h^2
    let V := 2*e-2*k^2*h^2*s*c*d/q
    compact k ((h*c*d-s*C*D)/q) ((C*c+h*s*D*d)/q) ((D*d+k^2*h*s*C*c)/q)
      ((h*c*d+s*C*D)/q) ((C*c-h*s*D*d)/q) ((D*d-k^2*h*s*C*c)/q)
      (2*p-V) V = -4*midpointJ k s c d h C p e/q := by
  dsimp
  have hscale :
    compact k ((h*c*d-s*C*D)/(1-k^2*s^2*h^2))
      ((C*c+h*s*D*d)/(1-k^2*s^2*h^2)) ((D*d+k^2*h*s*C*c)/(1-k^2*s^2*h^2))
      ((h*c*d+s*C*D)/(1-k^2*s^2*h^2)) ((C*c-h*s*D*d)/(1-k^2*s^2*h^2))
      ((D*d-k^2*h*s*C*c)/(1-k^2*s^2*h^2))
      (2*p-(2*e-2*k^2*h^2*s*c*d/(1-k^2*s^2*h^2)))
      (2*e-2*k^2*h^2*s*c*d/(1-k^2*s^2*h^2)) =
      midpointNumerator k s c d h C D p e / (1-k^2*s^2*h^2)^4 := by
    dsimp [compact, midpointNumerator]
    have hq2 : 1-k^2*h^2*s^2 ≠ 0 := by
      convert hq using 1
      ring
    field_simp [hq, hq2]
    ring
  rw [hscale]
  have hp := midpoint_polynomial k s c d h C D p e hd hD hc hC
  field_simp [hq]
  linear_combination hp


/-- Midpoint reduction for any constructed Jacobi core; addition identities are proved. -/
theorem core_midpoint (J : JacobiCore) (tau p : ℝ) :
    let V := J.eps (tau+p) - J.eps (tau-p)
    compact J.k (J.s (tau-p)) (J.c (tau-p)) (J.d (tau-p))
      (J.s (tau+p)) (J.c (tau+p)) (J.d (tau+p)) (2*p-V) V =
      -4 * midpointJ J.k (J.s p) (J.c p) (J.d p) (J.s tau) (J.c tau) p (J.eps p) /
        (1-J.k^2 * J.s p^2 * J.s tau^2) := by
  dsimp
  rw [JacobiCore.Addition.epsilon_midpoint]
  rcases JacobiCore.Addition.addition J tau p with ⟨hs, hc, hd⟩
  rcases JacobiCore.Addition.addition J tau (-p) with ⟨hsn, hcn, hdn⟩
  simp only [← sub_eq_add_neg] at hsn hcn hdn
  rw [hs, hc, hd, hsn, hcn, hdn]
  simp only [JacobiCore.Addition.addS, JacobiCore.Addition.addC, JacobiCore.Addition.addD,
    JacobiCore.Addition.numS, JacobiCore.Addition.numC, JacobiCore.Addition.numD,
    JacobiCore.Addition.delta, J.s_neg, (JacobiCore.Addition.even_cd J p).1,
    (JacobiCore.Addition.even_cd J p).2, neg_sq]
  have hq : 1-J.k^2 * J.s p^2 * J.s tau^2 ≠ 0 :=
    (JacobiCore.Addition.delta_pos J p tau).ne'
  have h := midpoint_compact J.k (J.s p) (J.c p) (J.d p) (J.s tau) (J.c tau) (J.d tau)
    p (J.eps p) hq (by linarith [J.sd p]) (by linarith [J.sd tau]) (J.sc p) (J.sc tau)
  convert h using 1
  congr 1 <;> ring


/-- The polynomial used in the exact reduction is the counting library's actual J2. -/
theorem midpointJ_eq (k : ℝ) (h0 : 0 < k) (h1 : k < 1) (tau p : ℝ) :
    midpointJ k (sn k h0 h1 p) (cn k h0 h1 p) (dn k h0 h1 p)
      (sn k h0 h1 tau) (cn k h0 h1 tau) p (epsilon k h0 h1 p) =
      (full k h0 h1).J2 tau p := by
  change _ = (1-k^2) * sn k h0 h1 p *
    (cn k h0 h1 p * dn k h0 h1 p * (p-2*epsilon k h0 h1 p) +
      sn k h0 h1 p * (dn k h0 h1 p^2 + epsilon k h0 h1 p*(p-epsilon k h0 h1 p))) *
      sn k h0 h1 tau^2 +
    (cn k h0 h1 p*(epsilon k h0 h1 p-p)-dn k h0 h1 p*sn k h0 h1 p) *
      (cn k h0 h1 p*epsilon k h0 h1 p-dn k h0 h1 p*sn k h0 h1 p) * cn k h0 h1 tau^2
  dsimp [midpointJ]
  ring

theorem b_midpoint (k : ℝ) (h0 : 0 < k) (h1 : k < 1) (tau p : ℝ) :
    bPolynomial ![amplitude k h0 h1 (tau-p), amplitude k h0 h1 (tau+p), k] =
      -4 * (full k h0 h1).J2 tau p /
        (1-k^2 * sn k h0 h1 p^2 * sn k h0 h1 tau^2) := by
  have h := core_midpoint (core k h0 h1) tau p
  change compact k (sn k h0 h1 (tau-p)) (cn k h0 h1 (tau-p)) (dn k h0 h1 (tau-p))
    (sn k h0 h1 (tau+p)) (cn k h0 h1 (tau+p)) (dn k h0 h1 (tau+p))
    (2*p-(epsilon k h0 h1 (tau+p)-epsilon k h0 h1 (tau-p)))
    (epsilon k h0 h1 (tau+p)-epsilon k h0 h1 (tau-p)) = _ at h
  dsimp only [core] at h
  rw [midpointJ_eq] at h
  convert h using 1
  dsimp [bPolynomial, w, first, second]
  congr 1
  simp [integral_amplitude, epsilon]
  ring

/-- The full signed J2 formula for the actual endpoint differential, in (t,varphi,k) order. -/
theorem rectified_det_J2 (sigma : ℝ) (hsigma : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    let p := y 0 / (2*y 2)
    let tau := y 1 / y 2 + p
    (jacobian (rectifiedEndpoint sigma) y).det =
      (-4*y 2 / ((1-(y 2)^2) *
        (1-(y 2)^2 * sn (y 2) h0 h1 p^2 * sn (y 2) h0 h1 tau^2))) *
        (full (y 2) h0 h1).J2 tau p := by
  dsimp
  rw [rectified_det sigma hsigma y h0 h1]
  have hi : inverseSource y =
      ![amplitude (y 2) h0 h1 (y 1 / y 2 + y 0/(2*y 2) - y 0/(2*y 2)),
        amplitude (y 2) h0 h1 (y 1 / y 2 + y 0/(2*y 2) + y 0/(2*y 2)), y 2] := by
    rw [inverseSource, dif_pos ⟨h0,h1⟩]
    have he : (y 1+y 0)/y 2 = y 1/y 2+y 0/(2*y 2)+y 0/(2*y 2) := by
      field_simp [h0.ne']
      ring
    simp only [add_sub_cancel_right, he]
  rw [hi, b_midpoint]
  simp only [div_eq_mul_inv, mul_inv_rev]
  ring

theorem rectified_det_J2_zero_iff (sigma : ℝ) (hsigma : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    (jacobian (rectifiedEndpoint sigma) y).det = 0 ↔
      (full (y 2) h0 h1).J2 (y 1/y 2+y 0/(2*y 2)) (y 0/(2*y 2)) = 0 := by
  rw [rectified_det_J2 sigma hsigma y h0 h1]
  apply mul_eq_zero_iff_left
  apply div_ne_zero (mul_ne_zero (by norm_num) h0.ne')
  apply mul_ne_zero (by nlinarith [h0,h1])
  exact (JacobiCore.Addition.delta_pos (core (y 2) h0 h1)
    (y 0/(2*y 2)) (y 1/y 2+y 0/(2*y 2))).ne'

end JacobiConcrete.AmplitudeChart
