import SE2Conjugate.Tangency

/-!
# Exactly one conjugate time on a signed bracket

For a bracket of either sign and orientation (`SBracket`): the oriented lift `ũ` is continuous
on the closed bracket with `ũ p₀ = 0`, `ũ p₁ = K`; `ũ - id` is monotone, strictly so because the
AM-GM equality expression cannot vanish on an interval, and `-ũ - id` is strictly decreasing.  The crossing
principle, applied to the phase `ψ - (1-ε)K/2`, gives exactly one `p ∈ [p₀, p₁]` with
`J₂(ψ + p, p) = 0`.  Theorem 3.4 is the case `ε = 1`; Theorem 4.1 uses both cases.
-/

noncomputable section

namespace SBracket

variable (B : SBracket)

def J2 (τ p : ℝ) : ℝ := B.toJacobiData.α p * B.s τ ^ 2 + B.toJacobiData.β p * B.c τ ^ 2

/-! ### Values at the ends -/

theorem z_of_β_zero {p : ℝ} (hp : p ∈ Set.Icc B.p0 B.p1)
    (h : B.toJacobiData.f1 p * B.toJacobiData.β1 p = 0) : B.toJacobiData.z p = 0 := by
  have hq : B.toJacobiData.q p ≠ 0 := by rw [B.q_eq]; exact (B.q_pos _ hp).ne'
  have he : B.eps p ≠ 0 := (B.eps_pos _ hp).ne'
  have : B.toJacobiData.z p
      = -(B.toJacobiData.f1 p * B.toJacobiData.β1 p) / (B.toJacobiData.q p * B.eps p) := by
    unfold JacobiData.z JacobiData.a JacobiData.b
    field_simp
  rw [this, h, neg_zero, zero_div]

theorem z_of_X_zero {p : ℝ} (hp : p ∈ Set.Icc B.p0 B.p1) (h : B.toJacobiData.X p = 0) :
    B.toJacobiData.z p = 1 := by
  have hq : B.toJacobiData.q p ≠ 0 := by rw [B.q_eq]; exact (B.q_pos _ hp).ne'
  have he : B.eps p ≠ 0 := (B.eps_pos _ hp).ne'
  rw [B.toJacobiData.z_eq_neg_beta_div_ell _ hq he, B.toJacobiData.collapse_beta, h]
  have hℓ := (B.ell_pos_Icc hp).ne'
  field_simp
  ring

theorem z_p0 : B.toJacobiData.z B.p0 = (1 - B.ε) / 2 := by
  rcases B.hε with hε | hε
  · rw [B.z_of_β_zero B.Icc_mem_p0 (B.β_lo hε), hε]; ring
  · rw [B.z_of_X_zero B.Icc_mem_p0 (B.X_lo hε), hε]; ring

theorem z_p1 : B.toJacobiData.z B.p1 = (1 + B.ε) / 2 := by
  rcases B.hε with hε | hε
  · rw [B.z_of_X_zero B.Icc_mem_p1 (B.X_hi hε), hε]; ring
  · rw [B.z_of_β_zero B.Icc_mem_p1 (B.β_hi hε), hε]; ring

theorem z_nonneg_Icc {p : ℝ} (hp : p ∈ Set.Icc B.p0 B.p1) : 0 ≤ B.toJacobiData.z p := by
  rcases eq_or_lt_of_le hp.1 with h0 | h0
  · rw [← h0, B.z_p0]; rcases B.hε with hε | hε <;> rw [hε] <;> norm_num
  rcases eq_or_lt_of_le hp.2 with h1 | h1
  · rw [h1, B.z_p1]; rcases B.hε with hε | hε <;> rw [hε] <;> norm_num
  exact (B.z_pos ⟨h0, h1⟩).le

theorem z_le_one_Icc {p : ℝ} (hp : p ∈ Set.Icc B.p0 B.p1) : B.toJacobiData.z p ≤ 1 := by
  rcases eq_or_lt_of_le hp.1 with h0 | h0
  · rw [← h0, B.z_p0]; rcases B.hε with hε | hε <;> rw [hε] <;> norm_num
  rcases eq_or_lt_of_le hp.2 with h1 | h1
  · rw [h1, B.z_p1]; rcases B.hε with hε | hε <;> rw [hε] <;> norm_num
  exact (B.z_lt_one ⟨h0, h1⟩).le

theorem Dz_pos_Icc {p : ℝ} (hp : p ∈ Set.Icc B.p0 B.p1) : 0 < B.toJacobiData.Dz p :=
  B.toJacobiData.Dz_pos p (B.z_nonneg_Icc hp)

theorem r_mem_Icc {p : ℝ} (hp : p ∈ Set.Icc B.p0 B.p1) : B.r p ∈ Set.Icc (0 : ℝ) 1 := by
  have hD := B.Dz_pos_Icc hp
  unfold r
  constructor
  · exact div_nonneg (B.z_nonneg_Icc hp) hD.le
  · rw [div_le_one hD]
    unfold JacobiData.Dz
    have := B.z_le_one_Icc hp
    have hk : 0 < 1 - B.k ^ 2 := by nlinarith [B.k_pos, B.k_lt_one]
    nlinarith

theorem r_of_z_zero {p : ℝ} (h : B.toJacobiData.z p = 0) : B.r p = 0 := by
  unfold r; rw [h, zero_div]

theorem r_of_z_one {p : ℝ} (h : B.toJacobiData.z p = 1) : B.r p = 1 := by
  unfold r JacobiData.Dz
  rw [h]
  have hk : 1 - B.k ^ 2 + B.k ^ 2 * 1 = 1 := by ring
  rw [hk, div_one]

theorem uu_p0 : B.uu B.p0 = 0 := by
  unfold uu u
  rcases B.hε with hε | hε
  · have hz : B.toJacobiData.z B.p0 = 0 := by rw [B.z_p0, hε]; ring
    rw [B.r_of_z_zero hz, B.Finv_zero, hε]; ring
  · have hz : B.toJacobiData.z B.p0 = 1 := by rw [B.z_p0, hε]; ring
    rw [B.r_of_z_one hz, B.Finv_one, hε]; ring

theorem uu_p1 : B.uu B.p1 = B.K := by
  unfold uu u
  rcases B.hε with hε | hε
  · have hz : B.toJacobiData.z B.p1 = 1 := by rw [B.z_p1, hε]; ring
    rw [B.r_of_z_one hz, B.Finv_one, hε]; ring
  · have hz : B.toJacobiData.z B.p1 = 0 := by rw [B.z_p1, hε]; ring
    rw [B.r_of_z_zero hz, B.Finv_zero, hε]; ring

/-! ### Continuity -/

theorem continuousOn_z : ContinuousOn B.toJacobiData.z (Set.Icc B.p0 B.p1) := by
  have hf1 : ContinuousOn B.toJacobiData.f1 (Set.Icc B.p0 B.p1) :=
    fun p _ => (B.toJacobiData.hasDerivAt_f1 p).continuousAt.continuousWithinAt
  have hq : ContinuousOn B.toJacobiData.q (Set.Icc B.p0 B.p1) :=
    fun p _ => (B.toJacobiData.hasDerivAt_q p).continuousAt.continuousWithinAt
  have hβ1 : ContinuousOn B.toJacobiData.β1 (Set.Icc B.p0 B.p1) :=
    fun p _ => (B.toJacobiData.hasDerivAt_β1 p).continuousAt.continuousWithinAt
  have he : ContinuousOn B.eps (Set.Icc B.p0 B.p1) :=
    fun p _ => (B.heps p).continuousAt.continuousWithinAt
  have ha : ContinuousOn B.toJacobiData.a (Set.Icc B.p0 B.p1) := by
    unfold JacobiData.a
    exact hf1.div hq (fun p hp => by rw [B.q_eq]; exact (B.q_pos p hp).ne')
  have hb : ContinuousOn B.toJacobiData.b (Set.Icc B.p0 B.p1) := by
    unfold JacobiData.b
    exact hβ1.neg.div he (fun p hp => (B.eps_pos p hp).ne')
  unfold JacobiData.z
  exact ha.mul hb

theorem continuousOn_r : ContinuousOn B.r (Set.Icc B.p0 B.p1) := by
  have hz := B.continuousOn_z
  have hD : ContinuousOn B.toJacobiData.Dz (Set.Icc B.p0 B.p1) := by
    unfold JacobiData.Dz
    exact continuousOn_const.add (continuousOn_const.mul hz)
  unfold r
  exact hz.div hD (fun p hp => (B.Dz_pos_Icc hp).ne')

theorem continuousOn_u : ContinuousOn B.u (Set.Icc B.p0 B.p1) := by
  unfold u
  exact B.Finv_cont.comp B.continuousOn_r (fun p hp => B.r_mem_Icc hp)

theorem continuousOn_uu : ContinuousOn B.uu (Set.Icc B.p0 B.p1) := by
  unfold uu
  exact (continuousOn_const.mul B.continuousOn_u).add continuousOn_const

/-! ### The branches -/

/-- The oriented derivative `ũ' = ε u'`. -/
def uup (p : ℝ) : ℝ :=
  B.ε * (B.zp p / (2 * Real.sqrt (B.toJacobiData.z p * (1 - B.toJacobiData.z p)
    * B.toJacobiData.Dz p)))

theorem hasDerivAt_uu {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : HasDerivAt B.uu (B.uup p) p := by
  have h := ((B.hasDerivAt_u hp).const_mul B.ε).add_const ((1 - B.ε) * B.K / 2)
  unfold uu uup
  exact h

theorem one_le_uup {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : 1 ≤ B.uup p := B.one_le_ε_deriv_u hp

theorem psiP_monotone : MonotoneOn (fun p => B.uu p - p) (Set.Icc B.p0 B.p1) := by
  apply monotoneOn_of_deriv_nonneg (convex_Icc _ _)
  · exact B.continuousOn_uu.sub continuousOn_id
  · rw [interior_Icc]
    intro x hx
    have hd : HasDerivAt (fun p => B.uu p - p) (B.uup x - 1) x :=
      (B.hasDerivAt_uu hx).sub (hasDerivAt_id' x)
    exact hd.differentiableAt.differentiableWithinAt
  · rw [interior_Icc]
    intro x hx
    have hd : HasDerivAt (fun p => B.uu p - p) (B.uup x - 1) x :=
      (B.hasDerivAt_uu hx).sub (hasDerivAt_id' x)
    rw [hd.deriv]
    have := B.one_le_uup hx
    linarith

theorem psiM_strictAnti : StrictAntiOn (fun p => -B.uu p - p) (Set.Icc B.p0 B.p1) := by
  apply strictAntiOn_of_deriv_neg (convex_Icc _ _)
  · exact B.continuousOn_uu.neg.sub continuousOn_id
  · rw [interior_Icc]
    intro x hx
    have hd : HasDerivAt (fun p => -B.uu p - p) (-B.uup x - 1) x :=
      (B.hasDerivAt_uu hx).neg.sub (hasDerivAt_id' x)
    rw [hd.deriv]
    have := B.one_le_uup hx
    linarith

/-- The tangency set: the phases where `ũ' = 1`. -/
def tangencies : Set ℝ := {p ∈ Set.Ioo B.p0 B.p1 | deriv B.uu p = 1}

theorem psiP_strictMono :
    StrictMonoOn (fun p => B.uu p - p) (Set.Icc B.p0 B.p1) := by
  have hmono := B.psiP_monotone
  refine hmono.strictMonoOn_of_injOn ?_
  intro x hx y hy hxy
  by_contra hne
  have key : ∀ a b, a ∈ Set.Icc B.p0 B.p1 → b ∈ Set.Icc B.p0 B.p1 → a < b →
      B.uu a - a = B.uu b - b → False := by
    intro a b ha hb hab heq
    have hconst : ∀ t ∈ Set.Icc a b, B.uu t - t = B.uu a - a := by
      intro t ht
      have h1 := hmono ha ⟨ht.1.trans' ha.1, ht.2.trans hb.2⟩ ht.1
      have h2 := hmono ⟨ht.1.trans' ha.1, ht.2.trans hb.2⟩ hb ht.2
      simp only at h1 h2 heq
      linarith
    have hsub : Set.Ioo a b ⊆ B.tangencies := by
      intro t ht
      have htI : t ∈ Set.Ioo B.p0 B.p1 := ⟨lt_of_le_of_lt ha.1 ht.1, lt_of_lt_of_le ht.2 hb.2⟩
      refine ⟨htI, ?_⟩
      have hd : HasDerivAt (fun p => B.uu p - p) (B.uup t - 1) t :=
        (B.hasDerivAt_uu htI).sub (hasDerivAt_id' t)
      have hev : (fun p => B.uu p - p) =ᶠ[nhds t] fun _ => B.uu a - a :=
        Filter.eventuallyEq_of_mem (Ioo_mem_nhds ht.1 ht.2)
          (fun s hs => hconst s (Set.Ioo_subset_Icc_self hs))
      have hd0 := hd.congr_of_eventuallyEq hev.symm
      have := (hasDerivAt_const t (B.uu a - a)).unique hd0
      rw [(B.hasDerivAt_uu htI).deriv]
      linarith
    apply B.no_interval_H_zero hab
      (fun t ht => ⟨lt_of_le_of_lt ha.1 ht.1, lt_of_lt_of_le ht.2 hb.2⟩)
    intro t ht
    have htB := (hsub ht).1
    apply B.H_zero_of_unit_slope htB
    change B.uup t = 1
    rw [← (B.hasDerivAt_uu htB).deriv]
    exact (hsub ht).2
  rcases lt_or_gt_of_ne hne with h | h
  · exact key x y hx hy h hxy
  · exact key y x hy hx h hxy.symm

/-! ### `J₂ = 0 ↔ sn² τ = r` -/

theorem alpha_sub_beta {p : ℝ} (hp : p ∈ Set.Icc B.p0 B.p1) :
    B.toJacobiData.α p - B.toJacobiData.β p = B.toJacobiData.ell p * B.toJacobiData.Dz p := by
  have hq : B.toJacobiData.q p ≠ 0 := by rw [B.q_eq]; exact (B.q_pos p hp).ne'
  have he : B.eps p ≠ 0 := (B.eps_pos p hp).ne'
  rw [B.toJacobiData.collapse_diff p]
  unfold JacobiData.Dz
  rw [B.toJacobiData.z_eq_neg_beta_div_ell p hq he, B.toJacobiData.collapse_beta p]
  have hℓ := (B.ell_pos_Icc hp).ne'
  field_simp
  ring

theorem J2_eq_zero_iff {p : ℝ} (hp : p ∈ Set.Icc B.p0 B.p1) (τ : ℝ) :
    B.J2 τ p = 0 ↔ B.s τ ^ 2 = B.r p := by
  have hc : B.c τ ^ 2 = 1 - B.s τ ^ 2 := by have := B.sc τ; linarith
  have hab := B.alpha_sub_beta hp
  have hℓ := B.ell_pos_Icc hp
  have hD := B.Dz_pos_Icc hp
  have hq : B.toJacobiData.q p ≠ 0 := by rw [B.q_eq]; exact (B.q_pos p hp).ne'
  have he : B.eps p ≠ 0 := (B.eps_pos p hp).ne'
  have hz := B.toJacobiData.z_eq_neg_beta_div_ell p hq he
  unfold J2 r
  rw [hc]
  constructor
  · intro h
    rw [hz]
    field_simp
    nlinarith [hab, h]
  · intro h
    rw [hz] at h
    field_simp at h
    nlinarith [hab, h]

/-- `u` in terms of the oriented lift: `u = ε ũ + ε(ε-1)K/2`, i.e. `u = ũ` or `u = K - ũ`. -/
theorem u_eq_uu (p : ℝ) : B.u p = B.ε * B.uu p - B.ε * (1 - B.ε) * B.K / 2 := by
  unfold uu
  have := B.ε_sq
  linear_combination (-(B.u p)) * this

/-- **Exactly one conjugate time on a signed bracket.** -/
theorem exact_time (ψ : ℝ) :
    ∃! p, p ∈ Set.Icc B.p0 B.p1 ∧ B.J2 (ψ + p) p = 0 := by
  obtain ⟨C, hK, hlo, hhi, hu⟩ : ∃ C : CrossingData,
      C.K = B.K ∧ C.lo = B.p0 ∧ C.hi = B.p1 ∧ C.u = B.uu :=
    ⟨{ K := B.K, K_pos := B.K_pos, lo := B.p0, hi := B.p1, lo_lt_hi := B.p0_lt_p1, u := B.uu,
        u_cont := B.continuousOn_uu, u_lo := B.uu_p0, u_hi := B.uu_p1,
        plus_mono := B.psiP_strictMono, minus_anti := B.psiM_strictAnti },
      rfl, rfl, rfl, rfl⟩
  -- the shifted phase: ψ for ε = 1, ψ - K for ε = -1
  set ψ' := ψ - (1 - B.ε) * B.K / 2 with hψ'
  have equiv : ∀ p ∈ Set.Icc B.p0 B.p1,
      (B.J2 (ψ + p) p = 0 ↔ ∃ σ : ℝ, (σ = 1 ∨ σ = -1) ∧
        ∃ n : ℤ, C.branch σ p = ψ' + 2 * C.K * n) := by
    intro p hp
    have hu' : B.Finv (B.r p) = B.u p := rfl
    rw [B.J2_eq_zero_iff hp, ← B.Finv_spec (B.r p) (B.r_mem_Icc hp), hu', B.sn_sq_eq_iff]
    simp only [CrossingData.branch, hK, hu]
    have hue := B.u_eq_uu p
    rcases B.hε with hε | hε
    · rw [hε] at hue; simp only [one_mul, sub_self, zero_mul, zero_div, sub_zero] at hue
      rw [hψ', hε]
      simp only [sub_self, zero_mul, zero_div, sub_zero]
      constructor
      · rintro ⟨n, h | h⟩
        · exact ⟨1, Or.inl rfl, -n, by push_cast; linarith⟩
        · exact ⟨-1, Or.inr rfl, -n, by push_cast; linarith⟩
      · rintro ⟨σ, hσ, n, h⟩
        rcases hσ with rfl | rfl
        · exact ⟨-n, Or.inl (by push_cast; linarith)⟩
        · exact ⟨-n, Or.inr (by push_cast; linarith)⟩
    · rw [hε] at hue
      have hue' : B.u p = B.K - B.uu p := by rw [hue]; ring
      rw [hψ', hε]
      have hsh : ψ - (1 - -1) * B.K / 2 = ψ - B.K := by ring
      rw [hsh]
      constructor
      · rintro ⟨n, h | h⟩
        · exact ⟨-1, Or.inr rfl, -n, by push_cast; linarith⟩
        · exact ⟨1, Or.inl rfl, -n + 1, by push_cast; linarith⟩
      · rintro ⟨σ, hσ, n, h⟩
        rcases hσ with rfl | rfl
        · exact ⟨-n + 1, Or.inr (by push_cast; linarith)⟩
        · exact ⟨-n, Or.inl (by push_cast; linarith)⟩
  obtain ⟨p, ⟨hp, hpred⟩, huniq⟩ := C.crossing ψ'
  rw [hlo, hhi] at hp
  refine ⟨p, ⟨hp, (equiv p hp).mpr hpred⟩, ?_⟩
  rintro p' ⟨hp', h'⟩
  exact huniq p' ⟨by rw [hlo, hhi]; exact hp', (equiv p' hp').mp h'⟩

end SBracket

end
