import SE2Conjugate.CellCount

/-!
# Theorem 3.4, the clause "no conjugate time before `p₀`"

On `(0, p₀)`: `cn > 0` on `[0, K)` (it decreases from `1` to `0`, since `cn' = -sn dn < 0` on
`(0, 2K)`), so `f₁ = cn (ℰ - p) - dn sn < 0` on `(0, K)`; `f₁(K) = -k' < 0`; `f₁ < 0` on `(K, p₀)`
by the sign chart.  `β₁ < 0` on `(0, 2K]` (it decreases from `β₁(0) = 0`).  Hence `β = f₁ β₁ > 0`,
`α = (1-k²)(β + ℓ) > 0`, `J₂ > 0`: the first conjugate time is at least `p₀`.  Together with
Theorem 3.4 (the left bracket of cell `0`, `[p₀, p₁]`) this gives exactly one conjugate time in
`(0, p₁]` for every phase.  (The paper cites Sachkov for this clause; here it follows from the
axioms.)  The file ends with the global count, `2N` conjugate times before `p_{N+1}^1`.
-/

noncomputable section

namespace JacobiFull

variable (J : JacobiFull)

theorem c_strictAntiOn : StrictAntiOn J.c (Set.Icc 0 (2 * J.K)) := by
  apply strictAntiOn_of_deriv_neg (convex_Icc _ _)
  · exact fun p _ => (J.hc p).continuousAt.continuousWithinAt
  · rw [interior_Icc]
    intro x hx
    rw [(J.hc x).deriv]
    have := mul_pos (J.s_pos_first hx) (J.d_pos x)
    linarith

theorem cast_K : (2 * ((0 : ℕ) : ℝ) + 1) * J.K = J.K := by push_cast; ring

theorem c_K : J.c J.K = 0 := by
  have h := J.c_odd 0
  rw [J.cast_K] at h
  exact h

/-- `cn > 0` on `[0, K)`. -/
theorem c_pos_first {p : ℝ} (hp : p ∈ Set.Ico 0 J.K) : 0 < J.c p := by
  have hK := J.K_pos
  have := J.c_strictAntiOn ⟨hp.1, by linarith [hp.2]⟩ ⟨hK.le, by linarith⟩ hp.2
  rw [J.c_K] at this
  exact this

/-- `f₁ < 0` on `(0, p₀)`. -/
theorem f1_neg_first {p : ℝ} (hp : p ∈ Set.Ioo 0 J.p0) : J.toJacobiData.f1 p < 0 := by
  have hK := J.K_pos
  have hp0 := J.p0_mem
  rcases lt_trichotomy p J.K with h | h | h
  · have hc := J.c_pos_first ⟨hp.1.le, h⟩
    have hs := J.s_pos_first ⟨hp.1, by linarith⟩
    have hd := J.d_pos p
    have hq := J.toJacobiInit.q_pos hp.1
    have hq' : J.eps p - p < 0 := by
      have : J.toJacobiData.q p = p - J.eps p := rfl
      linarith
    show J.c p * (J.eps p - p) - J.d p * J.s p < 0
    nlinarith [mul_pos hc (neg_pos.mpr hq'), mul_pos hd hs]
  · have hf := J.toJacobiPeriodic.f1_odd 0
    rw [J.cast_K, pow_zero, one_mul] at hf
    rw [h, hf]
    exact neg_neg_of_pos J.toJacobiPeriodic.k'_pos
  · have hf := J.toJacobiPeriodic.f1_sign_before 0 (p := p) ⟨by rw [J.cast_K]; exact h, hp.2⟩
    rw [zero_add, pow_one] at hf
    linarith

theorem β1_zero : J.toJacobiData.β1 0 = 0 := by
  show J.c 0 * J.eps 0 - J.d 0 * J.s 0 = 0
  rw [J.s0, J.eps0]; ring

/-- `β₁ < 0` on `(0, 2K]`. -/
theorem β1_neg_Ioc {p : ℝ} (hp : p ∈ Set.Ioc 0 (2 * J.K)) : J.toJacobiData.β1 p < 0 := by
  have hK := J.K_pos
  have hanti : StrictAntiOn J.toJacobiData.β1 (Set.Icc 0 (2 * J.K)) := by
    apply J.toJacobiInit.β1_strictAntiOn (convex_Icc _ _)
    · rw [interior_Icc]; intro x hx; exact hx.1
    · rw [interior_Icc]; intro x hx; exact J.s_pos_first hx
  have := hanti ⟨le_refl 0, by linarith⟩ ⟨hp.1.le, hp.2⟩ hp.1
  rw [J.β1_zero] at this
  exact this

theorem β_pos_before_p0 {p : ℝ} (hp : p ∈ Set.Ioo 0 J.p0) : 0 < J.toJacobiData.β p :=
  mul_pos_of_neg_of_neg (J.f1_neg_first hp)
    (J.β1_neg_Ioc ⟨hp.1, by linarith [hp.2, J.p0_mem.2]⟩)

/-- No conjugate time before `p₀`: `J₂ > 0` on `(0, p₀)` for every phase. -/
theorem J2_pos_before_p0 {p : ℝ} (hp : p ∈ Set.Ioo 0 J.p0) (τ : ℝ) : 0 < J.J2 τ p :=
  J.J2_pos_of_β_pos hp.1 (J.β_pos_before_p0 hp) τ

/-! ### Theorem 3.4: the first cell is the left bracket of cell `0` -/

/-- `p₁ = min(2K, p₁^{α₁})`, the right end of the first bracket. -/
def p1 : ℝ := J.eL 0

theorem pL_zero : J.pL 0 = J.p0 := rfl

theorem p0_lt_p1 : J.p0 < J.p1 := J.pL_lt_eL 0

theorem p1_le : J.p1 ≤ 2 * J.K := by
  have h := J.eL_le 0
  simp only [Nat.cast_zero, mul_zero, zero_add] at h
  exact h

/-- **Theorem 3.4 (uniqueness)**: exactly one `p ∈ [p₀, p₁]` with `J₂(ψ + p, p) = 0`, for every
phase, given finitely many tangencies. -/
theorem exact_first_time (ψ : ℝ) :
    ∃! p, p ∈ Set.Icc J.p0 J.p1 ∧ J.J2 (ψ + p) p = 0 :=
  J.left_exact_time 0 ψ

/-- **Theorem 3.4, complete**: for every phase, exactly one conjugate time in `(0, p₁]`, and it
lies in `[p₀, p₁]`. -/
theorem first_time_complete (ψ : ℝ) :
    ∃! p, p ∈ Set.Ioc 0 J.p1 ∧ J.J2 (ψ + p) p = 0 := by
  obtain ⟨p, ⟨hpI, hp0⟩, hpu⟩ := J.exact_first_time ψ
  refine ⟨p, ⟨⟨by linarith [hpI.1, J.p0_pos], hpI.2⟩, hp0⟩, ?_⟩
  rintro x ⟨hx, hx0⟩
  rcases lt_or_ge x J.p0 with h | h
  · exact absurd hx0 (J.J2_pos_before_p0 ⟨hx.1, h⟩ _).ne'
  · exact hpu x ⟨⟨h, hx.2⟩, hx0⟩

/-! ### The global count: `2N` conjugate times before `p_{N+1}^1` -/

theorem pL_lt_succ (m : ℕ) : J.pL m < J.pL (m + 1) := by
  have := J.K_pos
  linarith [(J.pL_mem m).2, (J.pL_succ_mem m).1]

/-- The conjugate times in `(0, p_N^1)` (the interval before the `N`-th Maxwell cell). -/
def roots (ψ : ℝ) (N : ℕ) : Set ℝ := {x | x ∈ Set.Ioo 0 (J.pL N) ∧ J.J2 (ψ + x) x = 0}

theorem roots_zero (ψ : ℝ) : J.roots ψ 0 = ∅ := by
  ext x
  simp only [roots, Set.mem_ofPred_eq, Set.mem_empty_iff_false, iff_false]
  rintro ⟨hx, hx0⟩
  exact (J.J2_pos_before_p0 hx _).ne' hx0

theorem roots_succ (ψ : ℝ) (N : ℕ) : J.roots ψ (N + 1)
    = J.roots ψ N ∪ {x | x ∈ Set.Ico (J.pL N) (J.pL (N + 1)) ∧ J.J2 (ψ + x) x = 0} := by
  have h := J.pL_lt_succ N
  ext x
  simp only [roots, Set.mem_ofPred_eq, Set.mem_union]
  constructor
  · rintro ⟨hx, hx0⟩
    rcases lt_or_ge x (J.pL N) with h1 | h1
    · exact Or.inl ⟨⟨hx.1, h1⟩, hx0⟩
    · exact Or.inr ⟨⟨h1, hx.2⟩, hx0⟩
  · rintro (⟨hx, hx0⟩ | ⟨hx, hx0⟩)
    · exact ⟨⟨hx.1, by linarith [hx.2]⟩, hx0⟩
    · exact ⟨⟨by linarith [hx.1, J.pL_pos N], hx.2⟩, hx0⟩

/-- **Theorem 4.1, globally**: for `K ≠ 2E` every phase has exactly `2N` conjugate times in
`(0, p_{N+1}^1)`, i.e. two per Maxwell cell, none before the first. -/
theorem roots_ncard (hk : J.K ≠ 2 * J.E) (ψ : ℝ) (N : ℕ) :
    (J.roots ψ N).Finite ∧ (J.roots ψ N).ncard = 2 * N := by
  induction N with
  | zero => rw [J.roots_zero]; simp
  | succ N ih =>
    obtain ⟨p, -, q, -, hC, -⟩ := J.cell_roots N ψ
    have hfin : {x | x ∈ Set.Ico (J.pL N) (J.pL (N + 1)) ∧ J.J2 (ψ + x) x = 0}.Finite := by
      rw [hC]; exact (Set.finite_singleton q).insert p
    have hdisj : Disjoint (J.roots ψ N)
        {x | x ∈ Set.Ico (J.pL N) (J.pL (N + 1)) ∧ J.J2 (ψ + x) x = 0} := by
      rw [Set.disjoint_left]
      rintro x ⟨hx, -⟩ ⟨hx', -⟩
      linarith [hx.2, hx'.1]
    rw [J.roots_succ]
    refine ⟨ih.1.union hfin, ?_⟩
    rw [Set.ncard_union_eq hdisj ih.1 hfin, ih.2, J.two_per_cell_of_ne N hk ψ]
    ring


/-! ### The coincident root is met only by the phase `ψ ≡ K` -/

/-- At `p = 2nK`, `n ≥ 1`: `J₂(τ, 2nK) = β(2nK) cn²τ` with `β(2nK) = -4n²E(K-E) < 0`, so it
vanishes exactly for `τ ≡ K (mod 2K)`.  Hence the two conjugate times of a cell, which can only
coincide at `p = 2nK` (`coincide_imp`), do so only for the phase `ψ + 2nK ≡ K`, i.e. `ψ ≡ K`. -/
theorem J2_even_eq_zero_iff {n : ℕ} (hn : 1 ≤ n) (τ : ℝ) :
    J.J2 τ (2 * n * J.K) = 0 ↔ ∃ j : ℤ, τ = J.K + 2 * J.K * j := by
  have hK := J.K_pos
  have hE := J.E_pos
  have hEK := J.E_lt_K
  have hn' : (1 : ℝ) ≤ n := by exact_mod_cast hn
  have hα : J.toJacobiData.α (2 * n * J.K) = 0 := by
    unfold JacobiData.α; rw [J.s_even]; ring
  have hβ : J.toJacobiData.β (2 * n * J.K) < 0 := by
    unfold JacobiData.β
    rw [J.toJacobiPeriodic.f1_even, J.toJacobiPeriodic.β1_even]
    have e : (-1 : ℝ) ^ n * (2 * n * (J.E - J.K)) * ((-1) ^ n * (2 * n * J.E))
        = ((-1) ^ n) ^ 2 * (4 * n ^ 2 * J.E * (J.E - J.K)) := by ring
    rw [e, neg_one_pow_sq, one_mul]
    have : 0 < 4 * (n : ℝ) ^ 2 * J.E := by positivity
    nlinarith
  have hsK : J.s J.K = 1 := by
    have h := J.s_odd 0
    simp only [Nat.cast_zero, mul_zero, zero_add, one_mul, pow_zero] at h
    exact h
  have hcz : J.c τ = 0 ↔ J.s τ ^ 2 = J.s J.K ^ 2 := by
    rw [hsK, one_pow]
    have := J.sc τ
    constructor
    · intro h; rw [h] at this; linarith
    · intro h; rw [h] at this; nlinarith
  unfold J2
  rw [hα, zero_mul, zero_add, mul_eq_zero, or_iff_right hβ.ne, pow_eq_zero_iff (by norm_num),
    hcz, J.sn_sq_eq_iff]
  constructor
  · rintro ⟨j, h | h⟩
    · exact ⟨j, h⟩
    · exact ⟨j - 1, by rw [h]; push_cast; ring⟩
  · rintro ⟨j, h⟩
    exact ⟨j, Or.inl h⟩

end JacobiFull

end
