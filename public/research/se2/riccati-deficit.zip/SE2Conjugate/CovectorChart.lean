import SE2Conjugate.Midpoint

/-! Regular coordinates on the normalized rotating initial-covector cylinder.
The angle gamma is a local real lift of a 4*pi-periodic coordinate.
These results do not identify the second-variation definition of conjugacy. -/
noncomputable section
namespace JacobiConcrete.AmplitudeChart
set_option maxHeartbeats 1200000

def dSpeed (i : Fin 3) (z : V3) : V3 →L[ℝ] ℝ :=
  (-(z 2)^2 * Real.sin (z i) * Real.cos (z i) / speed (z 2) (z i)) • coord i +
  (-(z 2) * Real.sin (z i)^2 / speed (z 2) (z i)) • coord 2

theorem speed_strict (i : Fin 3) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    HasStrictFDerivAt (fun z : V3 => speed (z 2) (z i)) (dSpeed i z) z := by
  have h := (((hasStrictFDerivAt_apply (𝕜 := ℝ) 2 z).pow 2).mul
    (((hasStrictFDerivAt_apply (𝕜 := ℝ) i z).sin).pow 2)).const_sub 1
  have hh := h.sqrt (radicand_pos (z 2) h0 h1 (z i)).ne'
  refine hh.congr_fderiv ?_
  ext v
  simp [dSpeed, coord, speed]
  ring

/-- From (a,b,k) to (t,gamma0,w0), with gamma0=2*sigma*a. -/
def initialChart (sigma : ℝ) (z : V3) : V3 :=
  ![source z 0, 2*sigma*z 0, 2*sigma*speed (z 2) (z 0)/z 2]

def dInitialChart (sigma : ℝ) (z : V3) : V3 →L[ℝ] V3 := ContinuousLinearMap.pi
  ![(coord 0).comp (dSource z), (2*sigma) • coord 0,
    (2*sigma/z 2) • dSpeed 0 z - (2*sigma*speed (z 2) (z 0)/(z 2)^2) • coord 2]

theorem initialChart_strict (sigma : ℝ) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    HasStrictFDerivAt (initialChart sigma) (dInitialChart sigma z) z := by
  apply hasStrictFDerivAt_pi.mpr
  intro i
  fin_cases i
  · exact (hasStrictFDerivAt_apply 0 (source z)).comp z (source_strict z h0 h1)
  · exact (hasStrictFDerivAt_apply 0 z).const_mul (2*sigma)
  · have hi := (hasStrictFDerivAt_inv (𝕜 := ℝ) (x := z 2) h0.ne').comp z
      (hasStrictFDerivAt_apply (𝕜 := ℝ) 2 z)
    have h := ((speed_strict 0 z h0 h1).const_mul (2*sigma)).mul hi
    simp only [div_eq_mul_inv] at ⊢
    refine h.congr_fderiv ?_
    ext v
    simp [coord]
    ring

theorem initialChart_det (sigma : ℝ) (hs : sigma^2=1) (z : V3)
    (h0 : 0 < z 2) (h1 : z 2 < 1) :
    (jacobian (initialChart sigma) z).det =
      4/(z 2 * speed (z 2) (z 0) * speed (z 2) (z 1)) := by
  unfold jacobian
  rw [(initialChart_strict sigma z h0 h1).hasFDerivAt.fderiv]
  erw [Matrix.det_fin_three]
  simp [dInitialChart, dSource, dFirst, dSpeed, coord, weight]
  have hd := speed_sq (z 2) (z 0) h0 h1
  field_simp [h0.ne', (speed_pos (z 2) h0 h1 (z 0)).ne',
    (speed_pos (z 2) h0 h1 (z 1)).ne']
  linear_combination 4 * hd + 4 * (speed (z 2) (z 0)^2 + (z 2)^2 * Real.sin (z 0)^2) * hs

/-- Original elliptic source coordinates to normalized initial covector coordinates. -/
def covectorCoords (sigma : ℝ) (y : V3) : V3 := initialChart sigma (inverseSource y)

theorem covectorCoords_strict (sigma : ℝ) (y : V3) (h0 : 0 < y 2) (h1 : y 2 < 1) :
    HasStrictFDerivAt (covectorCoords sigma)
      ((dInitialChart sigma (inverseSource y)).comp (dInverse (inverseSource y))) y := by
  have hm := inverse_source_modulus y h0 h1
  exact (initialChart_strict sigma (inverseSource y) (by rwa [hm]) (by rwa [hm])).comp y
    (inverse_source_strict y h0 h1)

theorem covectorCoords_eq (sigma : ℝ) (y : V3) (h0 : 0 < y 2) (h1 : y 2 < 1) :
    covectorCoords sigma y =
      ![y 0, 2*sigma*amplitude (y 2) h0 h1 (y 1/y 2),
        2*sigma*dn (y 2) h0 h1 (y 1/y 2)/y 2] := by
  have ht := congrFun (source_inverse y h0 h1) 0
  unfold covectorCoords initialChart
  rw [ht]
  rw [inverseSource, dif_pos ⟨h0,h1⟩]
  rfl

theorem covectorCoords_chain (sigma : ℝ) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    jacobian (covectorCoords sigma) (source z) * jacobian source z =
      jacobian (initialChart sigma) z := by
  rw [jacobian_eq_linearMatrix, jacobian_eq_linearMatrix, jacobian_eq_linearMatrix,
    (covectorCoords_strict sigma (source z) h0 h1).hasFDerivAt.fderiv,
    inverse_source z h0 h1, (source_strict z h0 h1).hasFDerivAt.fderiv,
    (initialChart_strict sigma z h0 h1).hasFDerivAt.fderiv, ← linearMatrix_comp]
  congr 1
  ext v
  simp [inverse_linear_left z v h0 h1]

theorem covectorCoords_det (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    (jacobian (covectorCoords sigma) y).det = -4/(y 2)^3 := by
  let z := inverseSource y
  have hz : z 2 = y 2 := inverse_source_modulus y h0 h1
  have h := congrArg Matrix.det (covectorCoords_chain sigma z (by rwa [hz]) (by rwa [hz]))
  rw [Matrix.det_mul, source_inverse y h0 h1,
    initialChart_det sigma hs z (by rwa [hz]) (by rwa [hz]),
    source_det z (by rwa [hz]) (by rwa [hz])] at h
  have hda := (speed_pos (z 2) (by rwa [hz]) (by rwa [hz]) (z 0)).ne'
  have hdb := (speed_pos (z 2) (by rwa [hz]) (by rwa [hz]) (z 1)).ne'
  have hk : z 2 ≠ 0 := by rw [hz]; exact h0.ne'
  field_simp [hda,hdb,hk] at h
  rw [← hz]
  field_simp [hk]
  nlinarith [h]


/-- A square real differential has a nontrivial kernel exactly when its determinant vanishes. -/
theorem nontrivial_kernel_iff (f : V3 → V3) (y : V3) :
    (∃ v : V3, v ≠ 0 ∧ fderiv ℝ f y v = 0) ↔ (jacobian f y).det = 0 := by
  rw [jacobian_eq_linearMatrix]
  change (∃ v : V3, v ≠ 0 ∧ (fderiv ℝ f y).toLinearMap v = 0) ↔
    (LinearMap.toMatrix' (fderiv ℝ f y).toLinearMap).det = 0
  rw [LinearMap.det_toMatrix', LinearMap.det_eq_zero_iff_ker_ne_bot]
  constructor
  · rintro ⟨v,hv,hz⟩ hbot
    exact hv (LinearMap.ker_eq_bot'.mp hbot v hz)
  · intro h
    obtain ⟨v,hv,hne⟩ := (LinearMap.ker (fderiv ℝ f y).toLinearMap).ne_bot_iff.mp h
    exact ⟨v,hne,hv⟩

theorem covectorCoords_kernel (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (v : V3) :
    fderiv ℝ (covectorCoords sigma) y v = 0 ↔ v = 0 := by
  constructor
  · intro hv
    by_contra hn
    have h := (nontrivial_kernel_iff (covectorCoords sigma) y).mp ⟨v,hn,hv⟩
    rw [covectorCoords_det sigma hs y h0 h1] at h
    exact (div_ne_zero (by norm_num : (-4:ℝ) ≠ 0) (pow_ne_zero 3 h0.ne')) h
  · rintro rfl
    exact map_zero _

abbrev V4 := Fin 4 → ℝ

/-- Embedded SE(2) endpoint: heading is represented by its unit-circle coordinates. -/
def headingEmbedding (q : V3) : V4 := ![q 0,q 1,Real.cos (q 2),Real.sin (q 2)]
def dHeadingEmbedding (q : V3) : V3 →L[ℝ] V4 := ContinuousLinearMap.pi
  ![coord 0,coord 1,(-Real.sin (q 2)) • coord 2,Real.cos (q 2) • coord 2]

theorem headingEmbedding_deriv (q : V3) :
    HasFDerivAt headingEmbedding (dHeadingEmbedding q) q := by
  apply hasFDerivAt_pi.mpr
  intro i
  fin_cases i
  · exact hasFDerivAt_apply 0 q
  · exact hasFDerivAt_apply 1 q
  · exact (hasFDerivAt_apply 2 q).cos
  · exact (hasFDerivAt_apply 2 q).sin

theorem headingEmbedding_kernel (q v : V3) : dHeadingEmbedding q v = 0 ↔ v = 0 := by
  constructor
  · intro h
    have hx := congrFun h 0
    have hy := congrFun h 1
    have hc := congrFun h 2
    have hs := congrFun h 3
    simp [dHeadingEmbedding, coord] at hx hy hc hs
    have hz : v 2 = 0 := by
      by_contra hn
      have hc0 := hc.resolve_right hn
      have hs0 := hs.resolve_right hn
      have hsc := Real.sin_sq_add_cos_sq (q 2)
      rw [hc0,hs0] at hsc
      norm_num at hsc
    ext i
    fin_cases i <;> assumption
  · rintro rfl
    exact map_zero _

/-- Time and normalized initial covector in the published (h1,h2,h3) convention. -/
def normalizedEmbedding (q : V3) : V4 := ![q 0,Real.sin (q 1/2),-Real.cos (q 1/2),q 2/2]
def dNormalizedEmbedding (q : V3) : V3 →L[ℝ] V4 := ContinuousLinearMap.pi
  ![coord 0,(Real.cos (q 1/2)/2) • coord 1,(Real.sin (q 1/2)/2) • coord 1,(1/2:ℝ) • coord 2]

theorem normalizedEmbedding_deriv (q : V3) :
    HasFDerivAt normalizedEmbedding (dNormalizedEmbedding q) q := by
  simp only [dNormalizedEmbedding, div_eq_mul_inv]
  apply hasFDerivAt_pi.mpr
  intro i
  fin_cases i
  · exact hasFDerivAt_apply 0 q
  · have h := ((hasFDerivAt_apply (𝕜 := ℝ) 1 q).mul_const ((2:ℝ)⁻¹)).sin
    refine h.congr_fderiv ?_
    ext v
    simp [coord]
    ring
  · have h := (((hasFDerivAt_apply (𝕜 := ℝ) 1 q).mul_const ((2:ℝ)⁻¹)).cos).neg
    refine h.congr_fderiv ?_
    ext v
    simp [coord]
    ring
  · have h := (hasFDerivAt_apply (𝕜 := ℝ) 2 q).mul_const ((2:ℝ)⁻¹)
    refine h.congr_fderiv ?_
    ext v
    simp [coord]

theorem normalizedEmbedding_unit (q : V3) :
    (normalizedEmbedding q 1)^2+(normalizedEmbedding q 2)^2=1 := by
  simp [normalizedEmbedding, Real.sin_sq_add_cos_sq]

theorem normalizedEmbedding_kernel (q v : V3) : dNormalizedEmbedding q v = 0 ↔ v = 0 := by
  constructor
  · intro h
    have ht := congrFun h 0
    have hc := congrFun h 1
    have hs := congrFun h 2
    have hw := congrFun h 3
    simp [dNormalizedEmbedding, coord] at ht hc hs hw
    have hg : v 1 = 0 := by
      by_contra hn
      have hc0 := hc.resolve_right hn
      have hs0 := hs.resolve_right hn
      have hsc := Real.sin_sq_add_cos_sq (q 1/2)
      rw [hc0,hs0] at hsc
      norm_num at hsc
    ext i
    fin_cases i
    · exact ht
    · exact hg
    · exact hw
  · rintro rfl
    exact map_zero _

def physicalSource (sigma : ℝ) (y : V3) : V4 := normalizedEmbedding (covectorCoords sigma y)
def physicalEndpoint (sigma : ℝ) (y : V3) : V4 := headingEmbedding (rectifiedEndpoint sigma y)

theorem physicalSource_deriv (sigma : ℝ) (y : V3) (h0 : 0 < y 2) (h1 : y 2 < 1) :
    HasFDerivAt (physicalSource sigma)
      ((dNormalizedEmbedding (covectorCoords sigma y)).comp (fderiv ℝ (covectorCoords sigma) y)) y :=
  (normalizedEmbedding_deriv _).comp y (covectorCoords_strict sigma y h0 h1).hasFDerivAt.differentiableAt.hasFDerivAt

theorem physicalEndpoint_deriv (sigma : ℝ) (y : V3) (h0 : 0 < y 2) (h1 : y 2 < 1) :
    HasFDerivAt (physicalEndpoint sigma)
      ((dHeadingEmbedding (rectifiedEndpoint sigma y)).comp (fderiv ℝ (rectifiedEndpoint sigma) y)) y :=
  (headingEmbedding_deriv _).comp y (rectified_deriv sigma y h0 h1).differentiableAt.hasFDerivAt

theorem physicalSource_kernel (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (v : V3) :
    fderiv ℝ (physicalSource sigma) y v = 0 ↔ v = 0 := by
  rw [(physicalSource_deriv sigma y h0 h1).fderiv]
  change dNormalizedEmbedding _ (fderiv ℝ (covectorCoords sigma) y v) = 0 ↔ v=0
  rw [normalizedEmbedding_kernel, covectorCoords_kernel sigma hs y h0 h1]

theorem physicalEndpoint_kernel (sigma : ℝ) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) (v : V3) :
    fderiv ℝ (physicalEndpoint sigma) y v = 0 ↔ fderiv ℝ (rectifiedEndpoint sigma) y v = 0 := by
  rw [(physicalEndpoint_deriv sigma y h0 h1).fderiv]
  exact headingEmbedding_kernel _ _

/-- A nonzero variation of time and normalized covector with stationary embedded endpoint.
This is a differential condition, not a definition using the scalar J2 or its determinant. -/
def StationaryVariation (sigma : ℝ) (y : V3) : Prop :=
  ∃ v : V3, fderiv ℝ (physicalSource sigma) y v ≠ 0 ∧ fderiv ℝ (physicalEndpoint sigma) y v = 0

theorem stationaryVariation_iff_J2 (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    StationaryVariation sigma y ↔
      (full (y 2) h0 h1).J2 (y 1/y 2+y 0/(2*y 2)) (y 0/(2*y 2)) = 0 := by
  simp only [StationaryVariation, ne_eq, physicalSource_kernel sigma hs y h0 h1,
    physicalEndpoint_kernel sigma y h0 h1]
  rw [nontrivial_kernel_iff, rectified_det_J2_zero_iff sigma hs y h0 h1]


/-- The strict derivative is a continuous linear equivalence, so these are genuine local coordinates. -/
def covectorLinearEquiv (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) : V3 ≃L[ℝ] V3 :=
  (LinearMap.equivOfIsUnitDet (f := (fderiv ℝ (covectorCoords sigma) y).toLinearMap) (by
    apply isUnit_iff_ne_zero.mpr
    rw [← LinearMap.det_toMatrix']
    change (jacobian (covectorCoords sigma) y).det ≠ 0
    rw [covectorCoords_det sigma hs y h0 h1]
    exact div_ne_zero (by norm_num) (pow_ne_zero 3 h0.ne'))).toContinuousLinearEquiv

theorem covectorLinearEquiv_coe (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    (covectorLinearEquiv sigma hs y h0 h1 : V3 →L[ℝ] V3) = fderiv ℝ (covectorCoords sigma) y := by
  ext v
  simp [covectorLinearEquiv, LinearMap.equivOfIsUnitDet_apply]

theorem covectorEquiv_strict (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    HasStrictFDerivAt (covectorCoords sigma)
      (covectorLinearEquiv sigma hs y h0 h1 : V3 →L[ℝ] V3) y := by
  rw [covectorLinearEquiv_coe]
  have h := covectorCoords_strict sigma y h0 h1
  rwa [h.hasFDerivAt.fderiv]

def covectorLocalChart (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) : OpenPartialHomeomorph V3 V3 :=
  (covectorEquiv_strict sigma hs y h0 h1).toOpenPartialHomeomorph (covectorCoords sigma)

theorem covectorLocalChart_coe (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    (covectorLocalChart sigma hs y h0 h1 : V3 → V3) = covectorCoords sigma := rfl

theorem covectorLocalChart_mem (sigma : ℝ) (hs : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) : y ∈ (covectorLocalChart sigma hs y h0 h1).source :=
  (covectorEquiv_strict sigma hs y h0 h1).mem_toOpenPartialHomeomorph_source

theorem physicalSource_eq (sigma : ℝ) (hs : sigma = 1 ∨ sigma = -1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    physicalSource sigma y = ![y 0, sigma*sn (y 2) h0 h1 (y 1/y 2),
      -cn (y 2) h0 h1 (y 1/y 2), sigma*dn (y 2) h0 h1 (y 1/y 2)/y 2] := by
  unfold physicalSource
  rw [covectorCoords_eq sigma y h0 h1]
  rcases hs with rfl | rfl
  all_goals ext i; fin_cases i <;> simp [normalizedEmbedding, sn, cn] <;> ring_nf <;> simp

theorem normalizedEmbedding_period (t gamma w : ℝ) :
    normalizedEmbedding ![t,gamma+4*Real.pi,w] = normalizedEmbedding ![t,gamma,w] := by
  have he : (gamma+4*Real.pi)/2 = gamma/2+2*Real.pi := by ring
  ext i
  fin_cases i <;> simp [normalizedEmbedding, he, Real.sin_add_two_pi, Real.cos_add_two_pi]

theorem headingEmbedding_period (x y theta : ℝ) :
    headingEmbedding ![x,y,theta+2*Real.pi] = headingEmbedding ![x,y,theta] := by
  ext i
  fin_cases i <;> simp [headingEmbedding, Real.sin_add_two_pi, Real.cos_add_two_pi]

/-- The endpoint criterion along the scaled-time parameter used by the counting proofs. -/
theorem stationaryVariation_scaled (sigma : ℝ) (hs : sigma^2=1) (k : ℝ)
    (h0 : 0 < k) (h1 : k < 1) (psi p : ℝ) :
    StationaryVariation sigma ![2*k*p,k*psi,k] ↔ (full k h0 h1).J2 (psi+p) p=0 := by
  rw [stationaryVariation_iff_J2 sigma hs _ h0 h1]
  have ht : 2*k*p/(2*k)=p := by field_simp [h0.ne']
  have hp : k*psi/k=psi := by field_simp [h0.ne']
  simp [ht, hp]

/-- The unique scalar first root is a unique stationary endpoint variation at physical time. -/
theorem first_stationary_time_unique (sigma : ℝ) (hs : sigma^2=1) (k : ℝ)
    (h0 : 0 < k) (h1 : k < 1) (psi : ℝ) :
    ∃! t, t ∈ Set.Ioc (0:ℝ) (2*k*(full k h0 h1).p1) ∧
      StationaryVariation sigma ![t,k*psi,k] := by
  obtain ⟨p,hp,hunique⟩ := first_time_unique k h0 h1 psi
  refine ⟨2*k*p, ⟨⟨mul_pos (by positivity) hp.1.1,
    mul_le_mul_of_nonneg_left hp.1.2 (by positivity)⟩,
    (stationaryVariation_scaled sigma hs k h0 h1 psi p).mpr hp.2⟩, ?_⟩
  intro t ht
  have hpos : 0 < 2*k := by positivity
  have hmul : 2*k*(t/(2*k))=t := by field_simp [h0.ne']
  have ht' : t/(2*k) ∈ Set.Ioc (0:ℝ) (full k h0 h1).p1 :=
    ⟨div_pos ht.1.1 hpos, (div_le_iff₀ hpos).mpr (by nlinarith [ht.1.2])⟩
  have hz : (full k h0 h1).J2 (psi+t/(2*k)) (t/(2*k))=0 := by
    apply (stationaryVariation_scaled sigma hs k h0 h1 psi (t/(2*k))).mp
    rw [hmul]
    exact ht.2
  have he := hunique (t/(2*k)) ⟨ht',hz⟩
  rw [← hmul,he]


/-- The chart lies in the rotating pendulum energy stratum, for both signs. -/
theorem amplitude_energy (sigma : ℝ) (hs : sigma=1 ∨ sigma = -1)
    (k a : ℝ) (h0 : 0 < k) (h1 : k < 1) :
    (2*sigma*speed k a/k)^2/2 - Real.cos (2*sigma*a) = 2/k^2-1 := by
  have hd := speed_sq k a h0 h1
  have hsc := Real.sin_sq_add_cos_sq a
  rcases hs with rfl | rfl
  all_goals simp only [mul_one, mul_neg_one, neg_mul, Real.cos_neg, Real.cos_two_mul]
  all_goals field_simp [h0.ne']
  all_goals nlinarith [hd,hsc]

theorem covector_energy (sigma : ℝ) (hs : sigma=1 ∨ sigma = -1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    (covectorCoords sigma y 2)^2/2 - Real.cos (covectorCoords sigma y 1) = 2/(y 2)^2-1 := by
  rw [covectorCoords_eq sigma y h0 h1]
  exact amplitude_energy sigma hs (y 2) (amplitude (y 2) h0 h1 (y 1/y 2)) h0 h1

theorem covector_rotating (sigma : ℝ) (hs : sigma=1 ∨ sigma = -1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    1 < (covectorCoords sigma y 2)^2/2 - Real.cos (covectorCoords sigma y 1) := by
  rw [covector_energy sigma hs y h0 h1]
  have hk : 0 < (y 2)^2 := sq_pos_of_pos h0
  have hb : (y 2)^2 < 1 := by nlinarith [h0,h1]
  have hdiv : 2 < 2/(y 2)^2 := (lt_div_iff₀ hk).mpr (by nlinarith)
  linarith

end JacobiConcrete.AmplitudeChart
