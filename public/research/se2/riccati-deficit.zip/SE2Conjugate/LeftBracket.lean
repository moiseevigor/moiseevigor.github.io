import SE2Conjugate.FirstCell
import SE2Conjugate.SignedTime

/-!
# Theorem 4.1, the left brackets `Bₙ⁻`

For every `m ≥ 0` (cell `n = m + 1`): the left end is the Maxwell time `p_{m+1}^1 ∈ ((2m+1)K,
(2m+2)K)`, the right end `eL = min((2m+2)K, p^α)` is the first zero of `α₁` after it (or
`(2m+2)K`).  On the open bracket `(-1)^m f₁ > 0`, `(-1)^m β₁ < 0`, `(-1)^m sn > 0`,
`(-1)^m α₁ > 0`, so it is an `SBracket` with `σ = (-1)^m`, `ε = 1`, and the signed bracket
theorem gives exactly one conjugate time on it, for every phase and every modulus (including
`k₀`, where `eL = (2m+2)K`).
-/

noncomputable section

namespace JacobiFull

variable (J : JacobiFull) (m : ℕ)

/-- `(-1)^m β₁ < 0` on `[(2m+1)K, (2m+2)K]`. -/
theorem signed_β1_neg_odd {p : ℝ}
    (hp : p ∈ Set.Icc ((2 * m + 1) * J.K) ((2 * m + 2) * J.K)) :
    (-1) ^ m * J.toJacobiData.β1 p < 0 := by
  have hK := J.K_pos
  have hanti : StrictAntiOn (fun p => (-1) ^ m * J.toJacobiData.β1 p)
      (Set.Icc ((2 * m + 1) * J.K) ((2 * m + 2) * J.K)) := by
    apply strictAntiOn_of_deriv_neg (convex_Icc _ _)
    · exact (continuousOn_const.mul
        (fun p _ => (J.toJacobiData.hasDerivAt_β1 p).continuousAt.continuousWithinAt))
    · rw [interior_Icc]
      intro x hx
      have hd : HasDerivAt (fun p => (-1) ^ m * J.toJacobiData.β1 p)
          ((-1) ^ m * (-(J.s x * J.d x * J.toJacobiData.Γ x))) x := by
        have := (J.toJacobiData.hasDerivAt_β1 x).const_mul ((-1 : ℝ) ^ m)
        rw [J.toJacobiData.β1_deriv_eq_Γ x (J.d_ne x)] at this
        exact this
      rw [hd.deriv]
      have hxpos : 0 < x := by nlinarith [hx.1]
      have hΓ := J.toJacobiInit.Γ_pos hxpos
      have hs := J.s_sign m x ⟨by nlinarith [hx.1], hx.2⟩
      have hdx := J.d_pos x
      have : 0 < ((-1) ^ m * J.s x) * J.d x * J.toJacobiData.Γ x := by positivity
      nlinarith
  have hga : (-1 : ℝ) ^ m * J.toJacobiData.β1 ((2 * m + 1) * J.K) = -Real.sqrt (1 - J.k ^ 2) := by
    rw [J.toJacobiPeriodic.β1_odd]; ring_nf; simp
  have hmono := hanti.antitoneOn
  have h1 := hmono (Set.left_mem_Icc.mpr (by nlinarith)) hp hp.1
  simp only at h1
  rw [hga] at h1
  linarith [J.toJacobiPeriodic.k'_pos]

/-- The left end `p_{m+1}^1`. -/
def pL : ℝ := J.toJacobiPeriodic.pM m

theorem pL_mem : J.pL m ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 2) * J.K) :=
  (J.toJacobiPeriodic.pM_spec m).1

theorem f1_pL : J.toJacobiData.f1 (J.pL m) = 0 := (J.toJacobiPeriodic.pM_spec m).2

theorem pL_pos : 0 < J.pL m := by
  have := (J.pL_mem m).1
  have hK := J.K_pos
  have : (0 : ℝ) ≤ m := Nat.cast_nonneg m
  nlinarith

/-- `(-1)^m sn > 0` on `((2m+1)K, (2m+2)K)`. -/
theorem signed_s_pos {p : ℝ} (hp : p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 2) * J.K)) :
    0 < (-1) ^ m * J.s p :=
  J.s_sign m p ⟨by have := J.K_pos; nlinarith [hp.1], hp.2⟩

theorem sign_transfer {σ x y : ℝ} (hxy : 0 < x * y) (hσx : 0 < σ * x) : 0 < σ * y := by
  have hx : x ≠ 0 := fun h => by rw [h, zero_mul] at hxy; exact lt_irrefl _ hxy
  have hx2 : 0 < x ^ 2 := by positivity
  have : σ * y * x ^ 2 = (σ * x) * (x * y) := by ring
  have hpos : 0 < σ * y * x ^ 2 := by rw [this]; exact mul_pos hσx hxy
  exact (mul_pos_iff_of_pos_right hx2).mp hpos

/-- `(-1)^m α₁(p_{m+1}^1) > 0`. -/
theorem signed_α1_pL_pos : 0 < (-1) ^ m * J.toJacobiData.α1 (J.pL m) := by
  have hβ : J.toJacobiData.β (J.pL m) = 0 := by
    unfold JacobiData.β; rw [J.f1_pL, zero_mul]
  have hX : J.toJacobiData.X (J.pL m) = J.toJacobiData.ell (J.pL m) := by
    have := J.toJacobiData.collapse_beta (J.pL m)
    rw [hβ] at this
    linarith
  have hℓ : 0 < J.toJacobiData.ell (J.pL m) :=
    mul_pos (J.toJacobiInit.eps_pos (J.pL_pos m)) (J.toJacobiInit.q_pos (J.pL_pos m))
  have hXpos : 0 < J.s (J.pL m) * J.toJacobiData.α1 (J.pL m) := by
    have : J.toJacobiData.X (J.pL m) = J.s (J.pL m) * J.toJacobiData.α1 (J.pL m) := rfl
    rw [← this, hX]; exact hℓ
  exact sign_transfer hXpos (J.signed_s_pos m (J.pL_mem m))

/-- The zeros of `α₁` on `[p_{m+1}^1, (2m+2)K]`, together with `(2m+2)K`. -/
def ZL : Set ℝ :=
  {p | p ∈ Set.Icc (J.pL m) ((2 * m + 2) * J.K) ∧ J.toJacobiData.α1 p = 0} ∪ {(2 * m + 2) * J.K}

/-- The right end of the left bracket, `min((2m+2)K, p^α)`. -/
def eL : ℝ := sInf (J.ZL m)

theorem ZL_nonempty : (J.ZL m).Nonempty := ⟨(2 * m + 2) * J.K, Or.inr rfl⟩

theorem ZL_bddBelow : BddBelow (J.ZL m) := by
  refine ⟨J.pL m, ?_⟩
  rintro p (⟨hp, _⟩ | hp)
  · exact hp.1
  · rw [Set.mem_singleton_iff] at hp; rw [hp]; exact (J.pL_mem m).2.le

theorem ZL_isClosed : IsClosed (J.ZL m) := by
  unfold ZL
  apply IsClosed.union
  · have : {p | p ∈ Set.Icc (J.pL m) ((2 * m + 2) * J.K) ∧ J.toJacobiData.α1 p = 0}
        = Set.Icc (J.pL m) ((2 * m + 2) * J.K) ∩ J.toJacobiData.α1 ⁻¹' {0} := by
      ext p; simp
    rw [this]
    exact isClosed_Icc.inter (isClosed_singleton.preimage J.continuous_α1)
  · exact isClosed_singleton

theorem eL_mem_ZL : J.eL m ∈ J.ZL m :=
  (J.ZL_isClosed m).csInf_mem (J.ZL_nonempty m) (J.ZL_bddBelow m)

theorem eL_le : J.eL m ≤ (2 * m + 2) * J.K := csInf_le (J.ZL_bddBelow m) (Or.inr rfl)

theorem pL_le_eL : J.pL m ≤ J.eL m := by
  apply le_csInf (J.ZL_nonempty m)
  rintro p (⟨hp, _⟩ | hp)
  · exact hp.1
  · rw [Set.mem_singleton_iff] at hp; rw [hp]; exact (J.pL_mem m).2.le

theorem pL_lt_eL : J.pL m < J.eL m := by
  rcases eq_or_lt_of_le (J.pL_le_eL m) with h | h
  · exfalso
    have hmem := J.eL_mem_ZL m
    rw [← h] at hmem
    rcases hmem with ⟨_, h0⟩ | h0
    · have := J.signed_α1_pL_pos m; rw [h0, mul_zero] at this; exact lt_irrefl _ this
    · rw [Set.mem_singleton_iff] at h0; linarith [(J.pL_mem m).2]
  · exact h

/-- An `eL` strictly before `(2m+2)K` is a zero of `α₁`. -/
theorem α1_eL_of_lt (h : J.eL m < (2 * m + 2) * J.K) : J.toJacobiData.α1 (J.eL m) = 0 := by
  rcases J.eL_mem_ZL m with ⟨_, h0⟩ | h0
  · exact h0
  · rw [Set.mem_singleton_iff] at h0; linarith

/-- `(-1)^m α₁ > 0` on `(p_{m+1}^1, eL)`, by minimality of `eL`. -/
theorem signed_α1_pos {p : ℝ} (hp : p ∈ Set.Ioo (J.pL m) (J.eL m)) :
    0 < (-1) ^ m * J.toJacobiData.α1 p := by
  by_contra hle
  rw [not_lt] at hle
  obtain ⟨z, hz, hα⟩ := J.exists_α1_zero m hp.1.le
    (mul_nonpos_of_nonneg_of_nonpos (J.signed_α1_pL_pos m).le hle)
  have hzZ : z ∈ J.ZL m := Or.inl ⟨⟨hz.1, by linarith [hz.2, hp.2, J.eL_le m]⟩, hα⟩
  have : J.eL m ≤ z := csInf_le (J.ZL_bddBelow m) hzZ
  linarith [hz.2, hp.2]

theorem X_eL : J.s (J.eL m) * J.toJacobiData.α1 (J.eL m) = 0 := by
  rcases J.eL_mem_ZL m with ⟨_, h0⟩ | h0
  · rw [h0, mul_zero]
  · rw [Set.mem_singleton_iff] at h0
    rw [h0]
    have h2 : (2 * m + 2 : ℝ) * J.K = 2 * ((m + 1 : ℕ) : ℝ) * J.K := by push_cast; ring
    rw [h2, J.s_even, zero_mul]

/-- The left bracket `B_{m+1}^-` as a signed bracket, `σ = (-1)^m`, `ε = 1`. -/
def leftBracket : SBracket where
  toJacobiData := J.toJacobiData
  K := J.K
  K_pos := J.K_pos
  p0 := J.pL m
  p1 := J.eL m
  p0_lt_p1 := J.pL_lt_eL m
  σ := (-1) ^ m
  hσ := neg_one_pow_eq_or ℝ m
  ε := 1
  hε := Or.inl rfl
  d_pos := J.d_pos
  eps_pos := fun p hp => J.toJacobiInit.eps_pos (by linarith [hp.1, J.pL_pos m])
  q_pos := fun p hp => J.toJacobiInit.q_pos (by linarith [hp.1, J.pL_pos m])
  f1_sign := fun p hp => by
    have hK := J.K_pos
    have hmem : p ∈ Set.Ioo (J.toJacobiPeriodic.pM m) ((2 * m + 3) * J.K) :=
      ⟨hp.1, by linarith [hp.2, J.eL_le m]⟩
    exact J.toJacobiPeriodic.f1_sign_after m hmem
  β1_sign := fun p hp => by
    have h : (-1 : ℝ) ^ m * J.toJacobiData.β1 p < 0 :=
      J.signed_β1_neg_odd m (p := p)
        ⟨by linarith [hp.1, (J.pL_mem m).1], by linarith [hp.2, J.eL_le m]⟩
    exact h
  s_sign := fun p hp => by
    have h : 0 < (-1 : ℝ) ^ m * J.s p :=
      J.signed_s_pos m (p := p)
        ⟨by linarith [hp.1, (J.pL_mem m).1], by linarith [hp.2, J.eL_le m]⟩
    rw [one_mul]
    exact h
  α1_sign := fun p hp => by
    have h := J.signed_α1_pos m hp
    rw [one_mul]
    exact h
  β_lo := fun _ => by
    show J.toJacobiData.f1 (J.pL m) * J.toJacobiData.β1 (J.pL m) = 0
    rw [J.f1_pL, zero_mul]
  X_lo := fun h => absurd h (by norm_num)
  X_hi := fun _ => J.X_eL m
  β_hi := fun h => absurd h (by norm_num)
  Finv := J.Finv
  Finv_deriv := J.Finv_deriv
  Finv_cont := J.Finv_cont
  Finv_zero := J.Finv_zero
  Finv_one := J.Finv_one
  Finv_spec := J.Finv_spec
  sn_sq_eq_iff := J.sn_sq_eq_iff

/-- **Theorem 4.1, left brackets**: exactly one conjugate time on `B_{m+1}^- = [p_{m+1}^1, eL]`. -/
theorem left_exact_time (ψ : ℝ) :
    ∃! p, p ∈ Set.Icc (J.pL m) (J.eL m) ∧ (J.leftBracket m).J2 (ψ + p) p = 0 :=
  (J.leftBracket m).exact_time ψ

end JacobiFull

end
