import SE2Conjugate.ArticleExtension
import SE2Conjugate.CriticalContact

noncomputable section
open Set

namespace JacobiCore.LargeIndex
variable (J : JacobiCore)

/-- The quadratic leading coefficient vanishes at a terminal quarter period. -/
theorem leading_factor (t s : ℝ) :
    J.phaseWeight t * J.s s ^ 2 - J.c t ^ 2 =
      -Addition.delta J t s * J.c (t-s) * J.c (t+s) := by
  have h := (Addition.addition J t s).2.1
  have hm := (Addition.addition J t (-s)).2.1
  rw [← sub_eq_add_neg] at hm
  rw [hm, h]
  simp only [Addition.addC,Addition.numC,Addition.delta,(Addition.even_cd J s).1,
    (Addition.even_cd J s).2,J.s_neg,neg_sq]
  have hden := (Addition.delta_pos J t s).ne'
  unfold Addition.delta at hden
  field_simp [hden]
  unfold phaseWeight
  ring_nf
  simp only [show J.c t^2=1-J.s t^2 by linarith [J.sc t],
    show J.c s^2=1-J.s s^2 by linarith [J.sc s], J.sd]
  field_simp [hden]
  ring

/-- The chord under sn on a quarter period gives a uniform inverse estimate. -/
theorem sn_chord {x : ℝ} (hx : x ∈ Icc 0 J.K) : x ≤ J.K * J.s x := by
  have hd (t : ℝ) : HasDerivAt (deriv J.s)
      (-(J.s t*J.d t)*J.d t+J.c t*(-(J.k^2*J.s t*J.c t))) t := by
    have h := (J.hc t).mul (J.hd t)
    convert h using 1 <;> first | rfl | (funext w; exact (J.hs w).deriv)
  have conc : ConcaveOn ℝ (Icc 0 J.K) J.s := by
    apply AntitoneOn.concaveOn_of_deriv (convex_Icc _ _)
      (fun t _ => (J.hs t).continuousAt.continuousWithinAt)
      (fun t _ => (J.hs t).differentiableAt.differentiableWithinAt)
    apply antitoneOn_of_deriv_nonpos ((convex_Icc (0:ℝ) J.K).interior)
      (fun t _ => (hd t).continuousAt.continuousWithinAt)
      (fun t _ => (hd t).differentiableAt.differentiableWithinAt)
    intro t ht
    have hi : t ∈ Icc 0 J.K := interior_subset (interior_subset ht)
    have hs := J.s_strictMonoOn.monotoneOn (show 0 ∈ Icc 0 J.K from ⟨le_rfl,J.K_pos.le⟩) hi hi.1
    rw [J.s0] at hs
    rw [(hd t).deriv]
    nlinarith [mul_nonneg hs (sq_nonneg (J.d t)), mul_nonneg (mul_nonneg (sq_nonneg J.k) hs) (sq_nonneg (J.c t))]
  have h := conc.2 (show 0 ∈ Icc 0 J.K from ⟨le_rfl,J.K_pos.le⟩)
    (show J.K ∈ Icc 0 J.K from ⟨J.K_pos.le,le_rfl⟩)
    (show 0 ≤ 1-x/J.K from sub_nonneg.mpr ((div_le_one J.K_pos).mpr hx.2))
    (div_nonneg hx.1 J.K_pos.le) (by ring)
  simp [smul_eq_mul,J.s0,J.sK,J.K_pos.ne'] at h
  linarith [(div_le_iff₀ J.K_pos).mp h]

private theorem sn_window {x η : ℝ} (hη : 0 < η) (hη1 : η ≤ 1)
    (hx : |x| ≤ (2-η)*J.K) : η*|x| ≤ 2*J.K*|J.s x| := by
  have hs : J.s |x| ≤ |J.s x| := by
    rcases le_or_gt 0 x with hp|hn
    · rw [abs_of_nonneg hp]; exact le_abs_self _
    · rw [abs_of_neg hn,J.s_neg]; exact neg_le_abs _
  by_cases h : |x| ≤ J.K
  · have e := sn_chord J ⟨abs_nonneg x,h⟩
    nlinarith [mul_le_mul_of_nonneg_left hs J.K_pos.le,
      mul_le_mul_of_nonneg_right hη1 (abs_nonneg x),mul_nonneg J.K_pos.le (abs_nonneg (J.s x))]
  · have e := sn_chord J (x := 2*J.K-|x|) ⟨by nlinarith [mul_nonneg hη.le J.K_pos.le],by linarith⟩
    rw [J.s_reflect] at e
    nlinarith [mul_le_mul_of_nonneg_left hs J.K_pos.le,
      mul_le_mul_of_nonneg_left (show |x| ≤ 2*J.K by nlinarith [mul_nonneg hη.le J.K_pos.le]) hη.le]

private theorem quarter_lower (u : ℝ) :
    J.d J.K * |J.s u| ≤ |J.c (u+J.K)| := by
  rw [(J.quarter_values u).2,abs_div,abs_neg,abs_mul,abs_of_pos (J.d_pos J.K),abs_of_pos (J.d_pos u)]
  apply (le_div_iff₀ (J.d_pos u)).mpr
  have hd := (abs_le.mp (J.abs_d_le_one u)).2
  nlinarith [mul_le_mul_of_nonneg_left hd (mul_nonneg (J.d_pos J.K).le (abs_nonneg (J.s u)))]

private theorem eps_window {s : ℝ} (hs : |s| ≤ J.K) :
    |J.eps s| ≤ J.E ∧ |s-J.eps s| ≤ J.K-J.E := by
  have bounds := abs_le.mp hs
  have a := J.eps_strictMono.monotone bounds.1
  have b := J.eps_strictMono.monotone bounds.2
  have c := J.toJacobiFull.toJacobiInit.q_monotone bounds.1
  have d := J.toJacobiFull.toJacobiInit.q_monotone bounds.2
  change -J.K - J.eps (-J.K) ≤ s-J.eps s at c
  change s-J.eps s ≤ J.K-J.eps J.K at d
  rw [Addition.epsilon_neg] at a c
  change |J.eps s| ≤ J.eps J.K ∧ |s-J.eps s| ≤ J.K-J.eps J.K
  exact ⟨abs_le.mpr ⟨a,b⟩,abs_le.mpr ⟨by linarith,d⟩⟩

private theorem weight_lower {s N : ℝ} (hs : |s| ≤ J.K) (hn : 1 ≤ N) :
    (N*J.E)*(N*(J.K-J.E)) ≤ J.periodWeight N s := by
  obtain ⟨he,hq⟩ := eps_window J hs
  have hE := J.E_pos
  have hKE := sub_pos.mpr J.E_lt_K
  apply mul_le_mul
  · nlinarith [(abs_le.mp he).1,mul_nonneg (sub_nonneg.mpr hn) hE.le]
  · nlinarith [(abs_le.mp hq).1,mul_nonneg (sub_nonneg.mpr hn) hKE.le]
  · positivity
  · nlinarith [(abs_le.mp he).1,mul_nonneg (sub_nonneg.mpr hn) hE.le]

private theorem correction_upper {s N : ℝ} (hs : |s| ≤ J.K) (hn : 1 ≤ N) :
    |J.profileCorrection N s| ≤ 3*J.K+1+2*N*|J.K-2*J.E| := by
  have he := (eps_window J hs).1.trans J.E_lt_K.le
  have hscd : |J.s s*J.c s*J.d s| ≤ 1 := by
    rw [abs_mul,abs_mul]
    have h := mul_le_mul (mul_le_mul (J.abs_s_le_one s) (J.abs_c_le_one s) (abs_nonneg _) zero_le_one)
      (J.abs_d_le_one s) (abs_nonneg _) (by norm_num)
    simpa using h
  have hsd : |J.s s^2*J.d s^2| ≤ 1 := by
    rw [abs_mul,abs_pow,abs_pow]
    have h1 := pow_le_pow_left₀ (abs_nonneg _) (J.abs_s_le_one s) 2
    have h2 := pow_le_pow_left₀ (abs_nonneg _) (J.abs_d_le_one s) 2
    simpa using mul_le_mul h1 h2 (sq_nonneg _) (by norm_num)
  have hmid : |s-2*J.eps s+2*N*(J.K-2*J.E)| ≤ 3*J.K+2*N*|J.K-2*J.E| := by
    calc
      _ ≤ |s|+|2*J.eps s|+|2*N*(J.K-2*J.E)| := by
        rw [sub_eq_add_neg]; grw [abs_add_le,abs_add_le]; rw [abs_neg]
      _ ≤ _ := by simp only [abs_mul,abs_of_pos (by norm_num : (0:ℝ)<2),abs_of_nonneg (by linarith : 0≤N)]; linarith
  unfold profileCorrection
  apply (abs_add_le ..).trans
  rw [abs_mul]
  linarith [mul_le_mul hscd hmid (abs_nonneg _) zero_le_one]

private theorem phase_window {ψ η : ℝ} (hη : 0<η) (h1 : η≤1) (hψ : |ψ| ≤ (1-η)*J.K) :
    J.d J.K * η^2 ≤ 2*|J.c ψ| := by
  have pp := abs_le.mp hψ
  have hs : |ψ-J.K| ≤ (2-η)*J.K := abs_le.mpr ⟨by linarith,by linarith [J.K_pos]⟩
  have h := sn_window J hη h1 hs
  have hq := quarter_lower J (ψ-J.K)
  rw [sub_add_cancel] at hq
  have lower : η*J.K ≤ |ψ-J.K| := by linarith [neg_abs_le (ψ-J.K)]
  have hh := mul_le_mul_of_nonneg_left (mul_le_mul_of_nonneg_left lower hη.le |>.trans h) (J.d_pos J.K).le
  exact le_of_mul_le_mul_right (a := J.K) (by nlinarith [mul_le_mul_of_nonneg_right hq J.K_pos.le]) J.K_pos

/-- Quantitative estimate at an actual cell root; u is the angular distance
of the terminal phase from the selected quarter period. -/
private theorem root_error {n : ℕ} (hn : 1 ≤ (n:ℝ)) {s ψ η u : ℝ}
    (hs : |s| ≤ J.K) (hη : 0<η) (h1 : η≤1) (hψ : |ψ| ≤ (1-η)*J.K)
    (hu : |u| ≤ (2-η)*J.K)
    (hshift : |J.c (u+J.K)| = |J.c (ψ+2*s)|)
    (hz : J.toJacobiFull.J2 (ψ+s+2*n*J.K) (s+2*n*J.K) = 0) :
    (1-J.k^2)^2*η^3*J.E*(J.K-J.E)*(n:ℝ)^2*|u| ≤
      4*J.K*(3*J.K+1+2*n*|J.K-2*J.E|) := by
  let Δ := Addition.delta J (ψ+s) s
  let W := J.periodWeight n s
  have hd := Addition.delta_lower J (ψ+s) s
  have hk : 0 < 1-J.k^2 := by nlinarith [J.k_pos,J.k_lt_one]
  have hw := weight_lower J hs hn
  have hw0 : 0 ≤ W := (show 0 ≤ ((n:ℝ)*J.E)*(n*(J.K-J.E)) by
    have := J.E_lt_K; have := J.E_pos; positivity).trans hw
  have hcoef : J.phaseWeight (ψ+s) = (J.d (ψ+s))^2 := by
    unfold phaseWeight; nlinarith [J.sd (ψ+s),J.sc (ψ+s)]
  have hph : |J.phaseWeight (ψ+s)| ≤ 1 := by
    rw [hcoef,abs_pow]; simpa using pow_le_pow_left₀ (abs_nonneg _) (J.abs_d_le_one (ψ+s)) 2
  rw [J.J2_periods] at hz
  unfold periodPolynomial at hz
  rw [leading_factor,add_sub_cancel_right,show ψ+s+s=ψ+2*s by ring] at hz
  have eqn : Δ*J.c ψ*J.c (ψ+2*s)*W = J.phaseWeight (ψ+s)*J.profileCorrection n s := by
    dsimp [Δ,W]; linarith
  have ab := congrArg abs eqn
  simp only [abs_mul,abs_of_nonneg hw0] at ab
  have upper := mul_le_mul hph (correction_upper J hs hn) (abs_nonneg _) zero_le_one
  have up : Δ*|J.c ψ| * |J.c (ψ+2*s)| * W ≤ 3*J.K+1+2*n*|J.K-2*J.E| := by
    change |Δ| * _ * _ * _ = _ at ab
    rw [abs_of_pos (Addition.delta_pos J (ψ+s) s)] at ab
    rw [ab]; simpa using upper
  have hp := phase_window J hη h1 hψ
  have ht := mul_le_mul_of_nonneg_left (sn_window J hη h1 hu) (J.d_pos J.K).le
  have hq := quarter_lower J u
  rw [hshift] at hq
  have ht' : J.d J.K*η*|u| ≤ 2*J.K*|J.c (ψ+2*s)| := by
    nlinarith [mul_le_mul_of_nonneg_left hq J.K_pos.le]
  have hdpos := J.d_pos J.K
  have hdelt : 0<Δ := Addition.delta_pos ..
  have low := mul_le_mul (mul_le_mul hd hp (by positivity) (Addition.delta_pos J (ψ+s) s).le)
    ht' (by positivity) (by positivity : 0 ≤ Δ*(2*|J.c ψ|))
  have both := mul_le_mul low hw (by have := J.E_pos; have := J.E_lt_K; positivity)
    (by have := J.K_pos; have : 0<Δ := Addition.delta_pos ..; positivity)
  have dk : J.d J.K^2 = 1-J.k^2 := by simp [J.sd,J.sK]
  calc
    _ = (1-J.k^2)*(J.d J.K*η^2)*(J.d J.K*η*|u|)*((n*J.E)*(n*(J.K-J.E))) := by
      linear_combination -(1-J.k^2)*η^3*J.E*(J.K-J.E)*(n:ℝ)^2*|u| * dk
    _ ≤ _ := both.trans (by nlinarith [mul_le_mul_of_nonneg_left up J.K_pos.le])


def scale (η : ℝ) := (1-J.k^2)^2*η^3*J.E*(J.K-J.E)
def radius (η N : ℝ) :=
  (2*J.K / scale J η)*((3*J.K+1)/N^2 + 2*|J.K-2*J.E|/N)

private theorem scale_pos {η : ℝ} (hη : 0<η) : 0<scale J η := by
  have h := J.E_pos
  have h' := sub_pos.mpr J.E_lt_K
  have hk : 0<1-J.k^2 := by nlinarith [J.k_pos,J.k_lt_one]
  unfold scale
  positivity

private theorem offset_bound {n : ℕ} (hn : 1 ≤ (n:ℝ)) {s ψ η u : ℝ}
    (hs : |s| ≤ J.K) (hη : 0<η) (h1 : η≤1) (hψ : |ψ| ≤ (1-η)*J.K)
    (hu : |u| ≤ (2-η)*J.K) (hshift : |J.c (u+J.K)| = |J.c (ψ+2*s)|)
    (hz : J.toJacobiFull.J2 (ψ+s+2*n*J.K) (s+2*n*J.K) = 0) :
    |u|/2 ≤ radius J η n := by
  have e := root_error J hn hs hη h1 hψ hu hshift hz
  change scale J η * (n:ℝ)^2 * |u| ≤ _ at e
  have hscale := scale_pos J hη
  have hN : 0 < (n:ℝ) := by linarith
  unfold radius
  field_simp [hscale,hN]
  nlinarith only [e]

private theorem center_ne {ψ η : ℝ} (hη : 0<η) (h1 : η≤1) (hψ : |ψ| ≤ (1-η)*J.K)
    (n : ℕ) (hn : 0 < (n:ℝ)) :
    J.toJacobiFull.J2 (ψ+2*n*J.K) (2*n*J.K) ≠ 0 := by
  have h := phase_window J hη h1 hψ
  have hc : J.c ψ ≠ 0 := by intro e; rw [e,abs_zero,mul_zero] at h; exact
    (not_le_of_gt (mul_pos (J.d_pos J.K) (sq_pos_of_pos hη))) h
  have hh := J.J2_periods n ψ 0
  simp [J.s0,J.eps0,J.c0,periodPolynomial,periodWeight,profileCorrection] at hh
  rw [hh]
  have := J.E_pos
  have := sub_pos.mpr J.E_lt_K
  exact neg_ne_zero.mpr (mul_ne_zero (pow_ne_zero _ hc) (mul_ne_zero (mul_ne_zero (mul_ne_zero (by norm_num) hn.ne') J.E_pos.ne') (mul_ne_zero (mul_ne_zero (by norm_num) hn.ne') (sub_pos.mpr J.E_lt_K).ne')))

abbrev cell (m : ℕ) (ψ : ℝ) := {x | x ∈ Ico (J.toJacobiFull.pL m) (J.toJacobiFull.pL (m+1)) ∧
  J.toJacobiFull.J2 (ψ+x) x=0}

/-- m is zero-based: this is manuscript cell n=m+1. The bounds hold for
both actual roots even at the exceptional modulus, away from its corner phase. -/
theorem cell_estimate (m : ℕ) {ψ η : ℝ} (hη : 0<η) (h1 : η≤1) (hψ : |ψ| ≤ (1-η)*J.K) :
    let N := (m:ℝ)+1
    ∃ p q : ℝ, cell J m ψ = {p,q} ∧ p<q ∧
      |p-((2*N-1/2)*J.K-ψ/2)| ≤ radius J η N ∧
      |q-((2*N+1/2)*J.K-ψ/2)| ≤ radius J η N := by
  let F := J.toJacobiFull
  let P := (2*(m:ℝ)+2)*J.K
  have hK := J.K_pos
  obtain ⟨p,hp,q,hq,hset,hco⟩ := F.cell_roots m ψ
  have mp : p ∈ cell J m ψ := by rw [show cell J m ψ = _ from hset]; simp
  have mq : q ∈ cell J m ψ := by rw [show cell J m ψ = _ from hset]; simp
  have lp : (2*(m:ℝ)+1)*J.K < p := (F.pL_mem m).1.trans_le hp.1
  have rp : p ≤ P := hp.2.trans (F.eL_le m)
  have lq : P ≤ q := (F.eR_ge m).trans hq.1
  have rq : q < (2*(m:ℝ)+3)*J.K := hq.2.trans_lt (F.bR_mem m).2
  have per : 2*((m+1:ℕ):ℝ)*J.K = P := by dsimp [P]; push_cast; ring
  have hn : (1:ℝ) ≤ ((m+1:ℕ):ℝ) := by push_cast; linarith [Nat.cast_nonneg (α := ℝ) m]
  have hc := center_ne J hη h1 hψ (m+1) (by linarith)
  rw [per] at hc
  have hpq : p<q := lt_of_le_of_ne (rp.trans lq) (fun e => by
    have hc0 := mp.2
    rw [hco e] at hc0
    exact hc hc0)
  refine ⟨p,q,hset,hpq,?_,?_⟩
  · let s := p-P
    let u := ψ+2*s+J.K
    have hs : -J.K ≤ s ∧ s ≤ 0 := by dsimp [s,P] at *; constructor <;> linarith
    have hu : |u| ≤ (2-η)*J.K := by dsimp [u]; apply abs_le.mpr; constructor <;> linarith [(abs_le.mp hψ).1,(abs_le.mp hψ).2,hs.1,hs.2]
    have shift : |J.c (u+J.K)| = |J.c (ψ+2*s)| := by
      rw [show u+J.K = (ψ+2*s)+2*J.K by dsimp [u]; ring,J.c_shift,abs_neg]
    have hz : F.J2 (ψ+s+2*((m+1:ℕ):ℝ)*J.K) (s+2*((m+1:ℕ):ℝ)*J.K)=0 := by
      rw [per,show s+P=p by dsimp [s];ring, show ψ+s+P=ψ+p by dsimp [s];ring]; exact mp.2
    have e := offset_bound J hn (abs_le.mpr ⟨hs.1,hs.2.trans hK.le⟩) hη h1 hψ hu shift hz
    rw [show p-((2*((m:ℝ)+1)-1/2)*J.K-ψ/2)=u/2 by dsimp [u,s,P];ring,abs_div,show |(2:ℝ)|=2 by norm_num]
    exact_mod_cast e
  · let s := q-P
    let u := ψ+2*s-J.K
    have hs : 0 ≤ s ∧ s ≤ J.K := by dsimp [s,P] at *; constructor <;> linarith
    have hu : |u| ≤ (2-η)*J.K := by dsimp [u]; apply abs_le.mpr; constructor <;> linarith [(abs_le.mp hψ).1,(abs_le.mp hψ).2,hs.1,hs.2]
    have shift : |J.c (u+J.K)| = |J.c (ψ+2*s)| := by dsimp [u];rw [sub_add_cancel]
    have hz : F.J2 (ψ+s+2*((m+1:ℕ):ℝ)*J.K) (s+2*((m+1:ℕ):ℝ)*J.K)=0 := by
      rw [per,show s+P=q by dsimp [s];ring, show ψ+s+P=ψ+q by dsimp [s];ring]; exact mq.2
    have e := offset_bound J hn (abs_le.mpr ⟨by linarith [hs.1],hs.2⟩) hη h1 hψ hu shift hz
    rw [show q-((2*((m:ℝ)+1)+1/2)*J.K-ψ/2)=u/2 by dsimp [u,s,P];ring,abs_div,show |(2:ℝ)|=2 by norm_num]
    exact_mod_cast e


/-- Rank j counts distinct positive determinant zeros, beginning at j=1. -/
def hasRank (ψ p : ℝ) (j : ℕ) : Prop :=
  0<p ∧ J.toJacobiFull.J2 (ψ+p) p=0 ∧
  let before := {t | t ∈ Ioo 0 p ∧ J.toJacobiFull.J2 (ψ+t) t=0}
  before.Finite ∧ before.ncard+1=j

private theorem earlier_cells (m : ℕ) {ψ η : ℝ} (hη : 0<η) (h1 : η≤1)
    (hψ : |ψ| ≤ (1-η)*J.K) :
    (J.toJacobiFull.roots ψ m).Finite ∧ (J.toJacobiFull.roots ψ m).ncard=2*m := by
  let F := J.toJacobiFull
  induction m with
  | zero => rw [F.roots_zero]; simp
  | succ m ih =>
    obtain ⟨p,q,hset,hpq,_,_⟩ := cell_estimate J m hη h1 hψ
    have dis : Disjoint (F.roots ψ m) (cell J m ψ) := by
      rw [Set.disjoint_left]; rintro t ⟨ht,_⟩ ⟨hs,_⟩; exact (not_lt_of_ge hs.1) ht.2
    change (F.roots ψ (m+1)).Finite ∧ (F.roots ψ (m+1)).ncard=2*(m+1)
    rw [F.roots_succ]
    change ((F.roots ψ m) ∪ cell J m ψ).Finite ∧ ((F.roots ψ m) ∪ cell J m ψ).ncard=2*(m+1)
    rw [hset] at dis ⊢
    have hf := (finite_singleton q).insert p
    refine ⟨ih.1.union hf,?_⟩
    rw [ncard_union_eq dis ih.1 hf,ih.2,ncard_pair hpq.ne]
    omega

theorem ranked_cell_estimate (m : ℕ) {ψ η : ℝ} (hη : 0<η) (h1 : η≤1)
    (hψ : |ψ| ≤ (1-η)*J.K) :
    let N := (m:ℝ)+1
    ∃ p q : ℝ, hasRank J ψ p (2*m+1) ∧ hasRank J ψ q (2*m+2) ∧ p<q ∧
      |p-((2*N-1/2)*J.K-ψ/2)| ≤ radius J η N ∧
      |q-((2*N+1/2)*J.K-ψ/2)| ≤ radius J η N := by
  obtain ⟨p,q,hset,hpq,ep,eq⟩ := cell_estimate J m hη h1 hψ
  let F := J.toJacobiFull
  have hp : p ∈ cell J m ψ := by rw [hset]; simp
  have hq : q ∈ cell J m ψ := by rw [hset]; simp
  have old := earlier_cells J m hη h1 hψ
  let before := fun u : ℝ => {t | t ∈ Ioo 0 u ∧ F.J2 (ψ+t) t=0}
  have classify {t} (ht : F.pL m ≤ t) (hu : t < F.pL (m+1)) (hz : F.J2 (ψ+t) t=0) :
      t=p ∨ t=q := by
    have h : t ∈ cell J m ψ := ⟨⟨ht,hu⟩,hz⟩
    simpa [hset] using h
  have prev : before p = F.roots ψ m := by
    ext t; constructor
    · rintro ⟨⟨ht,htp⟩,hz⟩
      refine ⟨⟨ht,?_⟩,hz⟩
      by_contra! hh
      rcases classify hh (htp.trans hp.1.2) hz with e|e <;> linarith
    · rintro ⟨⟨ht,htp⟩,hz⟩; exact ⟨⟨ht,htp.trans_le hp.1.1⟩,hz⟩
  have next : before q = insert p (F.roots ψ m) := by
    ext t; constructor
    · rintro ⟨⟨ht,htq⟩,hz⟩
      by_cases h : t < F.pL m
      · exact Or.inr ⟨⟨ht,h⟩,hz⟩
      · exact Or.inl ((classify (le_of_not_gt h) (htq.trans hq.1.2) hz).resolve_right htq.ne)
    · rintro (rfl|⟨⟨ht,htp⟩,hz⟩)
      · exact ⟨⟨(F.pL_pos m).trans_le hp.1.1,hpq⟩,hp.2⟩
      · exact ⟨⟨ht,htp.trans_le hq.1.1⟩,hz⟩
  have hn : p ∉ F.roots ψ m := fun h => (not_lt_of_ge hp.1.1) h.1.2
  refine ⟨p,q,⟨(F.pL_pos m).trans_le hp.1.1,hp.2,?_⟩,⟨(F.pL_pos m).trans_le hq.1.1,hq.2,?_⟩,hpq,ep,eq⟩
  · change (before p).Finite ∧ (before p).ncard + 1 = _
    rw [prev,old.2]; exact ⟨old.1,rfl⟩
  · change (before q).Finite ∧ (before q).ncard + 1 = _
    rw [next,ncard_insert_of_notMem hn old.1,old.2]
    exact ⟨old.1.insert p,by omega⟩

/-- At the critical modulus the linear remainder vanishes in both ranked estimates. -/
theorem critical_ranked_law (m : ℕ) {ψ η : ℝ} (hη : 0<η) (h1 : η≤1)
    (hψ : |ψ| ≤ (1-η)*J.K) (hc : J.K=2*J.E) :
    let N := (m:ℝ)+1
    let C := 2*J.K / scale J η * (3*J.K+1)
    ∃ p q : ℝ, hasRank J ψ p (2*m+1) ∧ hasRank J ψ q (2*m+2) ∧ p<q ∧
      |p-((2*N-1/2)*J.K-ψ/2)| ≤ C/N^2 ∧
      |q-((2*N+1/2)*J.K-ψ/2)| ≤ C/N^2 := by
  simpa only [radius, sub_eq_zero.mpr hc, abs_zero, mul_zero, zero_div, add_zero,
    mul_div_assoc] using ranked_cell_estimate J m hη h1 hψ

end JacobiCore.LargeIndex

namespace JacobiConcrete.LargeIndex
open JacobiCore.LargeIndex

/-- A continuous majorant on the interior modulus range for j times the error. -/
def majorant (η k : ℝ) :=
  let K₀ := JacobiConcrete.K k
  let E₀ := secondIntegral k (Real.pi/2)
  4*K₀ / ((1-k^2)^2*η^3*E₀*(K₀-E₀)) *
    (3*K₀+1+2*|K₀-2*E₀|)

private theorem normalize {k η : ℝ} (hk : k ∈ Ioo (0:ℝ) 1) (hη : 0<η)
    {N j : ℝ} (hn : 1≤N) (hj : 0<j) (hjn : j≤2*N) :
    radius (core k hk.1 hk.2) η N ≤ majorant η k / j := by
  let J := core k hk.1 hk.2
  have sp := scale_pos J hη
  have hN : 0<N := by linarith
  have e : secondIntegral k (Real.pi/2)=J.E := (full_E k hk.1 hk.2).symm
  unfold majorant
  dsimp only
  rw [e]
  change radius J η N ≤ (4*J.K/scale J η*(3*J.K+1+2*|J.K-2*J.E|))/j
  have nonneg : 0 ≤ radius J η N := by
    unfold radius; have := J.K_pos; positivity
  apply (le_div_iff₀ hj).mpr
  refine (mul_le_mul_of_nonneg_left hjn nonneg).trans ?_
  unfold radius
  field_simp [sp,hN]
  nlinarith [mul_nonneg (sub_nonneg.mpr hn) (show 0 ≤ J.K*(3*J.K+1) by have := J.K_pos; positivity)]

/-- The article's increasing positive-root index. The bound includes the
first cell and every interior modulus, including K=2E. -/
theorem indexed_law {k ψ η : ℝ} (hk : k ∈ Ioo (0:ℝ) 1) (hη : 0<η) (h1 : η≤1)
    (hψ : |ψ| ≤ (1-η)*K k) (j : ℕ) (hj : 1≤j) :
    ∃ p : ℝ, hasRank (core k hk.1 hk.2) ψ p j ∧
      |p-(((j:ℝ)+1/2)*K k-ψ/2)| ≤ majorant η k / j := by
  let J := core k hk.1 hk.2
  let m := (j-1)/2
  obtain ⟨p,q,hp,hq,_,ep,eq⟩ := ranked_cell_estimate J m hη h1 hψ
  have hm : j=2*m+1 ∨ j=2*m+2 := by dsimp [m]; omega
  have hN : (1:ℝ) ≤ (m:ℝ)+1 := by linarith [Nat.cast_nonneg (α := ℝ) m]
  have hj' : (0:ℝ)<j := by exact_mod_cast (show 0<j by omega)
  have le : (j:ℝ) ≤ 2*((m:ℝ)+1) := by rcases hm with h|h <;> rw [h] <;> push_cast <;> linarith
  have hb := normalize hk hη hN hj' le
  rcases hm with h|h
  · refine ⟨p,h ▸ hp,?_⟩
    have hc : (j:ℝ)=2*(m:ℝ)+1 := by exact_mod_cast h
    have cent : ((j:ℝ)+1/2)*K k-ψ/2=(2*((m:ℝ)+1)-1/2)*J.K-ψ/2 := by
      change ((j:ℝ)+1/2)*J.K-ψ/2=_; rw [hc]; ring
    rw [cent]; exact ep.trans hb
  · refine ⟨q,h ▸ hq,?_⟩
    have hc : (j:ℝ)=2*(m:ℝ)+2 := by exact_mod_cast h
    have cent : ((j:ℝ)+1/2)*K k-ψ/2=(2*((m:ℝ)+1)+1/2)*J.K-ψ/2 := by
      change ((j:ℝ)+1/2)*J.K-ψ/2=_; rw [hc]; ring
    rw [cent]; exact eq.trans hb

/-- One constant works for all moduli in any compact interior set and
all normalized phases in [-1+η,1-η]. -/
theorem compact_indexed_law {S : Set ℝ} (hs : IsCompact S) (sub : S ⊆ Ioo (0:ℝ) 1)
    {η : ℝ} (hη : 0<η) (h1 : η≤1) : ∃ C : ℝ, 0<C ∧
    ∀ k (hk : k ∈ S) ψ, |ψ| ≤ (1-η)*K k → ∀ j : ℕ, 1≤j →
      ∃ p : ℝ, hasRank (core k (sub hk).1 (sub hk).2) ψ p j ∧
        |p-(((j:ℝ)+1/2)*K k-ψ/2)| ≤ C/j := by
  have hc : ContinuousOn (majorant η) S := by
    intro k hk
    have hi := sub hk
    have hK := (hasDerivAt_K k hi.1 hi.2).continuousAt
    have hE := (hasDerivAt_completeSecond k hi.1 hi.2).continuousAt
    have e := full_E k hi.1 hi.2
    have hden : (1-k^2)^2*η^3*secondIntegral k (Real.pi/2)*(K k-secondIntegral k (Real.pi/2)) ≠ 0 := by
      rw [← e]; exact (scale_pos (core k hi.1 hi.2) hη).ne'
    apply ContinuousAt.continuousWithinAt
    unfold majorant
    fun_prop (disch := assumption)
  obtain ⟨B,hB⟩ := hs.bddAbove_image hc
  refine ⟨max B 1,lt_of_lt_of_le zero_lt_one (le_max_right ..),?_⟩
  intro k hk ψ hψ j hj
  obtain ⟨p,hp,he⟩ := indexed_law (sub hk) hη h1 hψ j hj
  exact ⟨p,hp,he.trans (div_le_div_of_nonneg_right ((hB ⟨k,hk,rfl⟩).trans (le_max_left ..)) (Nat.cast_nonneg j))⟩
end JacobiConcrete.LargeIndex
