import SE2Conjugate.CovectorChart
import Mathlib.Analysis.ODE.ExistUnique
import Mathlib.Analysis.Calculus.ContDiff.RCLike

/-! The classical six Hamiltonian equations in a real heading lift.
Uniqueness is derived from smoothness on compact trajectory images. -/
noncomputable section
namespace JacobiConcrete
open Set
abbrev State := Fin 6 → ℝ

def hamiltonianField (z : State) : State :=
  ![z 3*Real.cos (z 2), z 3*Real.sin (z 2), z 4,
    -z 4*z 5, z 3*z 5, z 3*z 4]

theorem hamiltonianField_smooth : ContDiff ℝ 1 hamiltonianField := by
  apply contDiff_pi.mpr
  intro i
  fin_cases i <;> dsimp [hamiltonianField] <;> fun_prop

/-- Uniqueness requires the ODE only on the interval under consideration. -/
theorem hamiltonian_unique_on {f g : ℝ → State} {a b : ℝ}
    (hfc : ContinuousOn f (Icc a b)) (hgc : ContinuousOn g (Icc a b))
    (hf : ∀ t ∈ Ico a b, HasDerivAt f (hamiltonianField (f t)) t)
    (hg : ∀ t ∈ Ico a b, HasDerivAt g (hamiltonianField (g t)) t)
    (hinit : f a=g a) : EqOn f g (Icc a b) := by
  have hc : IsCompact (f '' Icc a b ∪ g '' Icc a b) :=
    (isCompact_Icc.image_of_continuousOn hfc).union (isCompact_Icc.image_of_continuousOn hgc)
  obtain ⟨R,hR⟩ := hc.isBounded.subset_closedBall (0:State)
  obtain ⟨K,hK⟩ := hamiltonianField_smooth.contDiffOn.exists_lipschitzOnWith
    (by norm_num) (convex_closedBall (0:State) R) (isCompact_closedBall (0:State) R)
  apply ODE_solution_unique_of_mem_Icc_right (v := fun _ => hamiltonianField)
    (s := fun _ => Metric.closedBall (0:State) R) (fun _ _ => hK)
    hfc (fun t ht => (hf t ht).hasDerivWithinAt) _
    hgc (fun t ht => (hg t ht).hasDerivWithinAt) _ hinit
  · intro t ht
    exact hR (Or.inl ⟨t,⟨ht.1,ht.2.le⟩,rfl⟩)
  · intro t ht
    exact hR (Or.inr ⟨t,⟨ht.1,ht.2.le⟩,rfl⟩)

theorem hamiltonian_unique {f g : ℝ → State} {a b : ℝ}
    (hf : ∀ t, HasDerivAt f (hamiltonianField (f t)) t)
    (hg : ∀ t, HasDerivAt g (hamiltonianField (g t)) t)
    (hinit : f a=g a) : EqOn f g (Icc a b) :=
  hamiltonian_unique_on (fun t _ => (hf t).continuousAt.continuousWithinAt)
    (fun t _ => (hg t).continuousAt.continuousWithinAt)
    (fun t _ => hf t) (fun t _ => hg t) hinit

variable (k : ℝ) (hk0 : 0 < k) (hk1 : k < 1)

def rotatingState (sigma psi t : ℝ) : State :=
  let J := full k hk0 hk1
  let u := psi+t/k
  ![J.endpointX sigma psi t, J.endpointY sigma psi t, J.endpointTheta psi t,
    sigma*sn k hk0 hk1 u, -cn k hk0 hk1 u, sigma*dn k hk0 hk1 u/k]

theorem rotatingState_solves (sigma psi t : ℝ) (hs : sigma^2=1) :
    HasDerivAt (rotatingState k hk0 hk1 sigma psi)
      (hamiltonianField (rotatingState k hk0 hk1 sigma psi t)) t := by
  apply hasDerivAt_pi.mpr
  intro i
  have hu : HasDerivAt (fun t : ℝ => psi+t/k) (1/k) t :=
    ((hasDerivAt_id' t).div_const k).const_add psi
  fin_cases i
  · exact (full k hk0 hk1).hasDerivAt_endpointX sigma psi t
  · exact (full k hk0 hk1).hasDerivAt_endpointY sigma psi t
  · exact (full k hk0 hk1).hasDerivAt_endpointTheta psi t
  · have h := ((hasDerivAt_sn k hk0 hk1 _).comp t hu).const_mul sigma
    refine h.congr_deriv ?_
    simp [hamiltonianField, rotatingState]
    ring
  · have h := ((hasDerivAt_cn k hk0 hk1 _).comp t hu).neg
    refine h.congr_deriv ?_
    simp [hamiltonianField, rotatingState]
    field_simp [hk0.ne']
    ring_nf
    rw [hs]
    ring
  · have h := (((hasDerivAt_dn k hk0 hk1 _).comp t hu).const_mul sigma).div_const k
    refine h.congr_deriv ?_
    simp [hamiltonianField, rotatingState]
    field_simp [hk0.ne']

/-- Identification with every solution of the published Hamiltonian ODE with these initial data. -/
theorem rotatingState_unique (sigma psi T : ℝ) (hs : sigma^2=1) (hT : 0 ≤ T)
    (f : ℝ → State) (hf : ∀ t, HasDerivAt f (hamiltonianField (f t)) t)
    (hinit : f 0=rotatingState k hk0 hk1 sigma psi 0) :
    f T=rotatingState k hk0 hk1 sigma psi T :=
  hamiltonian_unique hf (fun t => rotatingState_solves k hk0 hk1 sigma psi t hs)
    hinit ⟨hT,le_rfl⟩

/-- Rescale covectors but leave positions and heading unchanged. -/
def scaleState (r : ℝ) (z : State) : State :=
  ![z 0,z 1,z 2,r*z 3,r*z 4,r*z 5]

/-- Homogeneity converts elapsed time r*s into elapsed time s and covector r*h. -/
theorem scaleState_solves (r : ℝ) (f : ℝ → State)
    (hf : ∀ t, HasDerivAt f (hamiltonianField (f t)) t) (s : ℝ) :
    HasDerivAt (fun s => scaleState r (f (r*s)))
      (hamiltonianField (scaleState r (f (r*s)))) s := by
  have hi : HasDerivAt (fun s : ℝ => r*s) r s := by
    simpa using (hasDerivAt_id' s).const_mul r
  apply hasDerivAt_pi.mpr
  intro i
  have h (j : Fin 6) := ((hasDerivAt_pi.mp (hf (r*s))) j).comp s hi
  fin_cases i
  · exact (h 0).congr_deriv (by simp [hamiltonianField,scaleState]; ring)
  · exact (h 1).congr_deriv (by simp [hamiltonianField,scaleState]; ring)
  · exact (h 2).congr_deriv (by simp [hamiltonianField,scaleState]; ring)
  · exact ((h 3).const_mul r).congr_deriv (by simp [hamiltonianField,scaleState]; ring)
  · exact ((h 4).const_mul r).congr_deriv (by simp [hamiltonianField,scaleState]; ring)
  · exact ((h 5).const_mul r).congr_deriv (by simp [hamiltonianField,scaleState]; ring)


/-- Every solution with radially scaled initial data has the scaled endpoint, for every real r. -/
theorem scaleState_unique_on (r : ℝ) (f g : ℝ → State)
    (hf : ∀ t, HasDerivAt f (hamiltonianField (f t)) t)
    (hgc : ContinuousOn g (Icc 0 1))
    (hg : ∀ s ∈ Ico 0 1, HasDerivAt g (hamiltonianField (g s)) s)
    (hinit : g 0=scaleState r (f 0)) : g 1=scaleState r (f r) := by
  have hd := scaleState_solves r f hf
  have h := hamiltonian_unique_on hgc
    (fun s _ => (hd s).continuousAt.continuousWithinAt) hg (fun s _ => hd s)
    (by simpa using hinit)
  simpa using h (show (1:ℝ) ∈ Icc 0 1 by constructor <;> norm_num)

end JacobiConcrete
