import SE2Conjugate.Construction
import SE2Conjugate.Modulus

/-! Exact period polynomial for the reduced determinant, and the large-cell
profile. Every JacobiCore below can be instantiated by JacobiConcrete.core. -/
noncomputable section
namespace JacobiCore
variable (J : JacobiCore)

theorem epsilon_periods (n : ℕ) (x : ℝ) :
    J.eps (x+2*n*J.K) = J.eps x + 2*n*J.E := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [show x+2*(↑(n+1):ℝ)*J.K = (x+2*n*J.K)+2*J.K by push_cast; ring,
      J.eps_shift, ih]
    push_cast
    ring

def periodWeight (v x : ℝ) : ℝ :=
  (J.eps x + 2*v*J.E)*(x-J.eps x+2*v*(J.K-J.E))

def profileCorrection (v x : ℝ) : ℝ :=
  J.s x*J.c x*J.d x*(x-2*J.eps x+2*v*(J.K-2*J.E)) + J.s x^2*J.d x^2

theorem weight_at_period (n : ℕ) (x : ℝ) :
    J.toJacobiData.ell (x+2*n*J.K) = J.periodWeight n x := by
  change J.eps _ * ((x+2*n*J.K)-J.eps _) = _
  rw [J.epsilon_periods]
  unfold periodWeight
  ring

theorem X_at_period (n : ℕ) (x : ℝ) :
    J.toJacobiData.X (x+2*n*J.K) =
      J.s x^2*J.periodWeight n x + J.profileCorrection n x := by
  change J.s _ * (J.c _ * J.d _ * ((x+2*n*J.K)-2*J.eps _) +
    J.s _ * (J.d _ ^ 2 + J.eps _ * ((x+2*n*J.K)-J.eps _))) = _
  rw [J.s_shift_n, J.c_shift_n, J.d_shift_n, J.epsilon_periods]
  unfold periodWeight profileCorrection
  linear_combination (norm := ring)
    (J.s x * (J.c x * J.d x * (x+2*n*J.K-2*(J.eps x+2*n*J.E)) +
      J.s x * (J.d x^2+(J.eps x+2*n*J.E)*(x+2*n*J.K-(J.eps x+2*n*J.E))))) *
      neg_one_pow_sq n

def phaseWeight (τ : ℝ) : ℝ := (1-J.k^2)*J.s τ^2+J.c τ^2

def periodPolynomial (v τ x : ℝ) : ℝ :=
  (J.phaseWeight τ * J.s x^2-J.c τ^2)*J.periodWeight v x +
    J.phaseWeight τ*J.profileCorrection v x

theorem J2_periods (n : ℕ) (τ x : ℝ) :
    J.toJacobiFull.J2 (τ+2*n*J.K) (x+2*n*J.K) = J.periodPolynomial n τ x := by
  let p := x+2*n*J.K
  change (1-J.k^2)*J.s p*J.toJacobiData.α1 p * J.s (τ+2*n*J.K)^2 +
    J.toJacobiData.β p * J.c (τ+2*n*J.K)^2 = _
  rw [J.toJacobiData.collapse_beta, J.s_shift_n n τ, J.c_shift_n n τ]
  simp only [mul_pow,neg_one_pow_sq,one_mul]
  have hx : J.s p*J.toJacobiData.α1 p = J.toJacobiData.X p := rfl
  rw [show (1-J.k^2)*J.s p*J.toJacobiData.α1 p =
    (1-J.k^2)*J.toJacobiData.X p by rw [mul_assoc, hx]]
  dsimp only [p]
  rw [J.X_at_period, J.weight_at_period]
  unfold periodPolynomial phaseWeight
  ring

/-- Including odd shifts and arbitrary starting period. -/
theorem J2_third_difference (n : ℕ) (τ x : ℝ) :
    let f := fun (j : ℕ) => J.toJacobiFull.J2 (τ+2*j*J.K) (x+2*j*J.K)
    f (n+3)-3*f (n+2)+3*f (n+1)-f n = 0 := by
  dsimp only
  simp only [J.J2_periods]
  unfold periodPolynomial periodWeight profileCorrection
  push_cast
  ring

theorem profile_exact (n : ℕ) (x : ℝ) (h : J.periodWeight n x ≠ 0) :
    J.toJacobiData.X (x+2*n*J.K)/J.toJacobiData.ell (x+2*n*J.K)-J.s x^2 =
      J.profileCorrection n x / J.periodWeight n x := by
  rw [J.X_at_period,J.weight_at_period]
  field_simp
  ring

/-- On the critical modulus the numerator of the profile error has no n term. -/
theorem profile_critical (n : ℕ) (x : ℝ) (hk : J.K=2*J.E)
    (h : J.periodWeight n x ≠ 0) :
    J.toJacobiData.X (x+2*n*J.K)/J.toJacobiData.ell (x+2*n*J.K)-J.s x^2 =
      J.profileCorrection 0 x / J.periodWeight n x := by
  rw [J.profile_exact n x h]
  simp [profileCorrection,hk]

end JacobiCore

/-- Positivity of a quadratic on the closed unit interval follows from its
three positive degree-two Bernstein coefficients. -/
theorem se2_quadratic_positive (a b c u : ℝ) (hu : 0≤u) (hv : u≤1)
    (h0 : 0<a) (h1 : 0<a+b/2) (h2 : 0<a+b+c) :
    0<a+b*u+c*u^2 := by
  have hid : a+b*u+c*u^2 = a*(1-u)^2 + (a+b/2)*2*u*(1-u)+(a+b+c)*u^2 := by ring
  rw [hid]
  have hw : 0 ≤ 1-u := sub_nonneg.mpr hv
  rcases eq_or_lt_of_le hu with hz | hpos
  · subst u; simpa using h0
  · positivity
