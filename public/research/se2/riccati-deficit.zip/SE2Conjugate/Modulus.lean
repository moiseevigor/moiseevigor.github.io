import SE2Conjugate.Endpoint

/-! Modulus derivatives of the real elliptic integrals, with a proved local
uniform bound. All amplitudes are real and integrals are oriented. -/
noncomputable section
open Set Filter MeasureTheory
open scoped Topology
namespace JacobiConcrete

def speedModulus (k phi : ℝ) : ℝ := -k * Real.sin phi ^ 2 / speed k phi
def weightModulus (k phi : ℝ) : ℝ := k * Real.sin phi ^ 2 / speed k phi ^ 3

theorem hasDerivAt_speed_modulus (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (fun q => speed q phi) (speedModulus k phi) k := by
  have h := ((hasDerivAt_const k (1 : ℝ)).sub
    (((hasDerivAt_id' k).pow 2).mul_const (Real.sin phi ^ 2))).sqrt
      (radicand_pos k hk0 hk1 phi).ne'
  exact h.congr_deriv (by dsimp [speedModulus, speed]; ring)

theorem hasDerivAt_weight_modulus (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (fun q => weight q phi) (weightModulus k phi) k := by
  have h := (hasDerivAt_const k (1 : ℝ)).div
    (hasDerivAt_speed_modulus k phi hk0 hk1) (speed_pos k hk0 hk1 phi).ne'
  refine h.congr_deriv ?_
  unfold speedModulus weightModulus
  field_simp [(speed_pos k hk0 hk1 phi).ne']
  ring

/-- A uniform lower bound, valid for all amplitudes and 0<q<r<1. -/
theorem speed_lower (q r phi : ℝ) (hq : 0 < q) (hqr : q < r) (_hr : r < 1) :
    Real.sqrt (1 - r ^ 2) ≤ speed q phi := by
  unfold speed
  apply Real.sqrt_le_sqrt
  have hsin := Real.sin_sq_le_one phi
  have hq2 : q ^ 2 ≤ r ^ 2 := by nlinarith
  nlinarith [mul_nonneg (sq_nonneg q) (sub_nonneg.mpr hsin)]

theorem modulus_numerator_le (q phi : ℝ) (hq : 0 < q) (hq1 : q < 1) :
    0 ≤ q * Real.sin phi ^ 2 ∧ q * Real.sin phi ^ 2 ≤ 1 := by
  constructor
  · positivity
  · nlinarith [Real.sin_sq_le_one phi,
      mul_nonneg hq.le (sub_nonneg.mpr (Real.sin_sq_le_one phi))]

theorem speedModulus_bound (q r phi : ℝ) (hq : 0 < q) (hqr : q < r) (hr : r < 1) :
    ‖speedModulus q phi‖ ≤ 1 / Real.sqrt (1 - r ^ 2) := by
  have hq1 := hqr.trans hr
  have hr0 : 0 < r := hq.trans hqr
  have hdelta : 0 < Real.sqrt (1 - r ^ 2) := Real.sqrt_pos.mpr (by nlinarith)
  have hd := speed_pos q hq hq1 phi
  have hn := modulus_numerator_le q phi hq hq1
  rw [Real.norm_eq_abs, speedModulus, abs_div, abs_of_pos hd]
  rw [show -q * Real.sin phi ^ 2 = -(q * Real.sin phi ^ 2) by ring, abs_neg, abs_of_nonneg hn.1]
  exact div_le_div₀ (by norm_num) hn.2 hdelta (speed_lower q r phi hq hqr hr)

theorem weightModulus_bound (q r phi : ℝ) (hq : 0 < q) (hqr : q < r) (hr : r < 1) :
    ‖weightModulus q phi‖ ≤ 1 / Real.sqrt (1 - r ^ 2) ^ 3 := by
  have hq1 := hqr.trans hr
  have hr0 : 0 < r := hq.trans hqr
  have hdelta : 0 < Real.sqrt (1 - r ^ 2) := Real.sqrt_pos.mpr (by nlinarith)
  have hd := speed_pos q hq hq1 phi
  have hn := modulus_numerator_le q phi hq hq1
  have hp : Real.sqrt (1 - r ^ 2) ^ 3 ≤ speed q phi ^ 3 :=
    pow_le_pow_left₀ hdelta.le (speed_lower q r phi hq hqr hr) 3
  rw [Real.norm_eq_abs, weightModulus, abs_of_nonneg (div_nonneg hn.1 (pow_nonneg hd.le 3))]
  exact div_le_div₀ (by norm_num) hn.2 (pow_pos hdelta 3) hp

theorem speedModulus_continuous (k : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    Continuous (speedModulus k) := by
  apply Continuous.div _ (speed_continuous k) (fun phi => (speed_pos k hk0 hk1 phi).ne')
  fun_prop

theorem weightModulus_continuous (k : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    Continuous (weightModulus k) := by
  apply Continuous.div _ ((speed_continuous k).pow 3) (fun phi => pow_ne_zero 3 (speed_pos k hk0 hk1 phi).ne')
  fun_prop

theorem hasDerivAt_secondIntegral_modulus_integral (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (fun q => secondIntegral q phi) (∫ t in (0 : ℝ)..phi, speedModulus k t) k := by
  let r := (k + 1) / 2
  have hkr : k < r := by dsimp [r]; linarith
  have hr : r < 1 := by dsimp [r]; linarith
  have hs : Ioo 0 r ∈ 𝓝 k := Ioo_mem_nhds hk0 hkr
  apply (intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (F := speed) (F' := speedModulus) (bound := fun _ => 1 / Real.sqrt (1 - r ^ 2)) hs
    ?_ ((speed_continuous k).intervalIntegrable _ _) ?_ ?_ (intervalIntegrable_const) ?_).2
  · exact Eventually.of_forall (fun q => (speed_continuous q).aestronglyMeasurable)
  · exact (speedModulus_continuous k hk0 hk1).aestronglyMeasurable
  · exact Eventually.of_forall fun t _ q hq => speedModulus_bound q r t hq.1 hq.2 hr
  · exact Eventually.of_forall fun t _ q hq => hasDerivAt_speed_modulus q t hq.1 (hq.2.trans hr)

theorem hasDerivAt_firstIntegral_modulus_integral (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (fun q => firstIntegral q phi) (∫ t in (0 : ℝ)..phi, weightModulus k t) k := by
  let r := (k + 1) / 2
  have hkr : k < r := by dsimp [r]; linarith
  have hr : r < 1 := by dsimp [r]; linarith
  have hs : Ioo 0 r ∈ 𝓝 k := Ioo_mem_nhds hk0 hkr
  apply (intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_deriv_le
    (F := weight) (F' := weightModulus) (bound := fun _ => 1 / Real.sqrt (1 - r ^ 2) ^ 3) hs
    ?_ ((weight_continuous k hk0 hk1).intervalIntegrable _ _) ?_ ?_ (intervalIntegrable_const) ?_).2
  · filter_upwards [Ioo_mem_nhds hk0 hk1] with q hq
    exact (weight_continuous q hq.1 hq.2).aestronglyMeasurable
  · exact (weightModulus_continuous k hk0 hk1).aestronglyMeasurable
  · exact Eventually.of_forall fun t _ q hq => weightModulus_bound q r t hq.1 hq.2 hr
  · exact Eventually.of_forall fun t _ q hq => hasDerivAt_weight_modulus q t hq.1 (hq.2.trans hr)

theorem speed_sq (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    speed k phi ^ 2 = 1 - k ^ 2 * Real.sin phi ^ 2 :=
  Real.sq_sqrt (radicand_pos k hk0 hk1 phi).le

def boundaryTerm (k phi : ℝ) : ℝ := Real.sin phi * Real.cos phi / speed k phi

theorem hasDerivAt_speed_amplitude (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (speed k) (-k ^ 2 * Real.sin phi * Real.cos phi / speed k phi) phi := by
  have h := ((hasDerivAt_const phi (1 : ℝ)).sub
    (((Real.hasDerivAt_sin phi).pow 2).const_mul (k ^ 2))).sqrt (radicand_pos k hk0 hk1 phi).ne'
  exact h.congr_deriv (by dsimp [speed]; ring)

theorem hasDerivAt_boundaryTerm (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (boundaryTerm k)
      ((Real.cos phi ^ 2 - Real.sin phi ^ 2) / speed k phi +
        k ^ 2 * Real.sin phi ^ 2 * Real.cos phi ^ 2 / speed k phi ^ 3) phi := by
  have h := ((Real.hasDerivAt_sin phi).mul (Real.hasDerivAt_cos phi)).div
    (hasDerivAt_speed_amplitude k phi hk0 hk1) (speed_pos k hk0 hk1 phi).ne'
  exact h.congr_deriv (by dsimp only [Pi.mul_apply]; field_simp [(speed_pos k hk0 hk1 phi).ne']; ring)

def firstModulusPrimitive (k phi : ℝ) : ℝ :=
  secondIntegral k phi / (k * (1 - k ^ 2)) - firstIntegral k phi / k -
    k / (1 - k ^ 2) * boundaryTerm k phi

def secondModulusPrimitive (k phi : ℝ) : ℝ :=
  (secondIntegral k phi - firstIntegral k phi) / k

theorem hasDerivAt_secondModulusPrimitive (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (secondModulusPrimitive k) (speedModulus k phi) phi := by
  have h := ((hasDerivAt_secondIntegral k phi).sub (hasDerivAt_firstIntegral k hk0 hk1 phi)).div_const k
  refine h.congr_deriv ?_
  unfold weight speedModulus
  field_simp [hk0.ne', (speed_pos k hk0 hk1 phi).ne']
  nlinarith [speed_sq k phi hk0 hk1]

theorem first_primitive_algebra (k s c d : ℝ) (hk : k ≠ 0) (hk1 : 1-k^2 ≠ 0) (hd : d ≠ 0)
    (hsc : c^2+s^2=1) (hsd : d^2=1-k^2*s^2) :
    d / (k*(1-k^2)) - (1/d)/k - k/(1-k^2)*((c^2-s^2)/d+k^2*s^2*c^2/d^3) =
      k*s^2/d^3 := by
  field_simp [hk, hk1, hd]
  linear_combination (d^2+k^2*s^2)*hsd - k^2*(d^2+k^2*s^2)*hsc

theorem hasDerivAt_firstModulusPrimitive (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (firstModulusPrimitive k) (weightModulus k phi) phi := by
  have h := (((hasDerivAt_secondIntegral k phi).div_const (k*(1-k^2))).sub
    ((hasDerivAt_firstIntegral k hk0 hk1 phi).div_const k)).sub
      ((hasDerivAt_boundaryTerm k phi hk0 hk1).const_mul (k/(1-k^2)))
  refine h.congr_deriv ?_
  exact first_primitive_algebra k (Real.sin phi) (Real.cos phi) (speed k phi)
    hk0.ne' (by nlinarith [hk0, hk1]) (speed_pos k hk0 hk1 phi).ne'
    (Real.cos_sq_add_sin_sq phi) (speed_sq k phi hk0 hk1)

theorem hasDerivAt_firstIntegral_modulus (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (fun q => firstIntegral q phi) (firstModulusPrimitive k phi) k := by
  have hi := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun x (_ : x ∈ uIcc (0 : ℝ) phi) => hasDerivAt_firstModulusPrimitive k x hk0 hk1)
    ((weightModulus_continuous k hk0 hk1).intervalIntegrable 0 phi)
  have hz : firstModulusPrimitive k 0 = 0 := by
    simp [firstModulusPrimitive, firstIntegral_zero, secondIntegral_zero, boundaryTerm]
  rw [hz, sub_zero] at hi
  simpa only [hi] using hasDerivAt_firstIntegral_modulus_integral k phi hk0 hk1

theorem hasDerivAt_secondIntegral_modulus (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (fun q => secondIntegral q phi) (secondModulusPrimitive k phi) k := by
  have hi := intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun x (_ : x ∈ uIcc (0 : ℝ) phi) => hasDerivAt_secondModulusPrimitive k x hk0 hk1)
    ((speedModulus_continuous k hk0 hk1).intervalIntegrable 0 phi)
  have hz : secondModulusPrimitive k 0 = 0 := by
    simp [secondModulusPrimitive, firstIntegral_zero, secondIntegral_zero]
  rw [hz, sub_zero] at hi
  simpa only [hi] using hasDerivAt_secondIntegral_modulus_integral k phi hk0 hk1


theorem speed_joint_continuous : Continuous (fun v : ℝ × ℝ => speed v.1 v.2) := by
  unfold speed
  fun_prop

theorem secondIntegral_joint_continuous : Continuous (fun v : ℝ × ℝ => secondIntegral v.1 v.2) :=
  intervalIntegral.continuous_parametric_primitive_of_continuous speed_joint_continuous

theorem firstIntegral_joint_continuousAt (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    ContinuousAt (fun v : ℝ × ℝ => firstIntegral v.1 v.2) (k, phi) := by
  let r := (k+1)/2
  have hkr : k < r := by dsimp [r]; linarith
  have hr : r < 1 := by dsimp [r]; linarith
  have hr0 : 0 < r := hk0.trans hkr
  have hdelta : 0 < Real.sqrt (1-r^2) := Real.sqrt_pos.mpr (by nlinarith)
  apply intervalIntegral.continuousAt_parametric_primitive_of_dominated
    (F := weight) (fun _ => 1/Real.sqrt (1-r^2)) (min 0 phi-1) (max 0 phi+1)
  · intro q
    exact (measurable_const.div (speed_continuous q).measurable).aestronglyMeasurable
  · filter_upwards [Ioo_mem_nhds hk0 hkr] with q hq
    exact Eventually.of_forall fun t => by
      rw [Real.norm_eq_abs, abs_of_pos (weight_pos q hq.1 (hq.2.trans hr) t), weight]
      exact one_div_le_one_div_of_le hdelta (speed_lower q r t hq.1 hq.2 hr)
  · exact intervalIntegrable_const
  · exact Eventually.of_forall fun t => (hasDerivAt_weight_modulus k t hk0 hk1).continuousAt
  · constructor <;> linarith [min_le_left (0 : ℝ) phi, le_max_left (0 : ℝ) phi]
  · constructor <;> linarith [min_le_right (0 : ℝ) phi, le_max_right (0 : ℝ) phi]
  · simp

theorem boundaryTerm_joint_continuousAt (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    ContinuousAt (fun v : ℝ × ℝ => boundaryTerm v.1 v.2) (k, phi) := by
  apply ContinuousAt.div _ speed_joint_continuous.continuousAt (speed_pos k hk0 hk1 phi).ne'
  fun_prop

theorem firstModulusPrimitive_joint_continuousAt (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    ContinuousAt (fun v : ℝ × ℝ => firstModulusPrimitive v.1 v.2) (k, phi) := by
  have hk2 : 1-k^2 ≠ 0 := by nlinarith [hk0,hk1]
  have hden : ContinuousAt (fun v : ℝ × ℝ => v.1*(1-v.1^2)) (k,phi) := by fun_prop
  exact ((secondIntegral_joint_continuous.continuousAt.div hden (mul_ne_zero hk0.ne' hk2)).sub
    ((firstIntegral_joint_continuousAt k phi hk0 hk1).div continuousAt_fst hk0.ne')).sub
    ((continuousAt_fst.div (by fun_prop) hk2).mul (boundaryTerm_joint_continuousAt k phi hk0 hk1))

theorem secondModulusPrimitive_joint_continuousAt (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    ContinuousAt (fun v : ℝ × ℝ => secondModulusPrimitive v.1 v.2) (k, phi) :=
  (secondIntegral_joint_continuous.continuousAt.sub
    (firstIntegral_joint_continuousAt k phi hk0 hk1)).div continuousAt_fst hk0.ne'

theorem weight_joint_continuousAt (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    ContinuousAt (fun v : ℝ × ℝ => weight v.1 v.2) (k, phi) :=
  continuousAt_const.div speed_joint_continuous.continuousAt (speed_pos k hk0 hk1 phi).ne'

def integralDifferential (u v : ℝ) : (ℝ × ℝ) →L[ℝ] ℝ :=
  ((1 : ℝ →L[ℝ] ℝ).smulRight u).coprod ((1 : ℝ →L[ℝ] ℝ).smulRight v)

theorem integralDifferential_apply (u v : ℝ) (z : ℝ × ℝ) :
    integralDifferential u v z = u*z.1+v*z.2 := by
  simp [integralDifferential, mul_comm]

theorem hasStrictFDerivAt_firstIntegral (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasStrictFDerivAt (fun v : ℝ × ℝ => firstIntegral v.1 v.2)
      (integralDifferential (firstModulusPrimitive k phi) (weight k phi)) (k,phi) := by
  have hb : ∀ᶠ v : ℝ × ℝ in 𝓝 (k,phi), v.1 ∈ Ioo (0 : ℝ) 1 :=
    continuousAt_fst (Ioo_mem_nhds hk0 hk1)
  unfold integralDifferential
  apply hasStrictFDerivAt_uncurry_coprod (f := firstIntegral) (u := (k,phi))
    (f₁ := fun q a => (1 : ℝ →L[ℝ] ℝ).smulRight (firstModulusPrimitive q a))
    (f₂ := fun q a => (1 : ℝ →L[ℝ] ℝ).smulRight (weight q a))
  · filter_upwards [hb] with v hv
    exact (hasDerivAt_firstIntegral_modulus v.1 v.2 hv.1 hv.2).hasFDerivAt
  · filter_upwards [hb] with v hv
    exact (hasDerivAt_firstIntegral v.1 hv.1 hv.2 v.2).hasFDerivAt
  · exact (ContinuousLinearMap.smulRightL ℝ ℝ ℝ (1 : ℝ →L[ℝ] ℝ)).continuous.continuousAt.comp
      (firstModulusPrimitive_joint_continuousAt k phi hk0 hk1)
  · exact (ContinuousLinearMap.smulRightL ℝ ℝ ℝ (1 : ℝ →L[ℝ] ℝ)).continuous.continuousAt.comp
      (weight_joint_continuousAt k phi hk0 hk1)

theorem hasStrictFDerivAt_secondIntegral (k phi : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasStrictFDerivAt (fun v : ℝ × ℝ => secondIntegral v.1 v.2)
      (integralDifferential (secondModulusPrimitive k phi) (speed k phi)) (k,phi) := by
  have hb : ∀ᶠ v : ℝ × ℝ in 𝓝 (k,phi), v.1 ∈ Ioo (0 : ℝ) 1 :=
    continuousAt_fst (Ioo_mem_nhds hk0 hk1)
  unfold integralDifferential
  apply hasStrictFDerivAt_uncurry_coprod (f := secondIntegral) (u := (k,phi))
    (f₁ := fun q a => (1 : ℝ →L[ℝ] ℝ).smulRight (secondModulusPrimitive q a))
    (f₂ := fun q a => (1 : ℝ →L[ℝ] ℝ).smulRight (speed q a))
  · filter_upwards [hb] with v hv
    exact (hasDerivAt_secondIntegral_modulus v.1 v.2 hv.1 hv.2).hasFDerivAt
  · exact Eventually.of_forall fun v => (hasDerivAt_secondIntegral v.1 v.2).hasFDerivAt
  · exact (ContinuousLinearMap.smulRightL ℝ ℝ ℝ (1 : ℝ →L[ℝ] ℝ)).continuous.continuousAt.comp
      (secondModulusPrimitive_joint_continuousAt k phi hk0 hk1)
  · exact (ContinuousLinearMap.smulRightL ℝ ℝ ℝ (1 : ℝ →L[ℝ] ℝ)).continuous.continuousAt.comp
      speed_joint_continuous.continuousAt


/-- Complete first-kind integral derivative, in modulus rather than parameter m=k^2. -/
theorem hasDerivAt_K (k : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt K (secondIntegral k (Real.pi/2) / (k*(1-k^2)) - K k/k) k := by
  change HasDerivAt (fun q => firstIntegral q (Real.pi/2))
    (secondIntegral k (Real.pi/2) / (k*(1-k^2)) - firstIntegral k (Real.pi/2)/k) k
  simpa [firstModulusPrimitive, boundaryTerm] using
    hasDerivAt_firstIntegral_modulus k (Real.pi/2) hk0 hk1

/-- Complete second-kind integral derivative. -/
theorem hasDerivAt_completeSecond (k : ℝ) (hk0 : 0 < k) (hk1 : k < 1) :
    HasDerivAt (fun q => secondIntegral q (Real.pi/2))
      ((secondIntegral k (Real.pi/2)-K k)/k) k :=
  hasDerivAt_secondIntegral_modulus k (Real.pi/2) hk0 hk1

end JacobiConcrete
end
