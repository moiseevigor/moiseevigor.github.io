import SE2Conjugate.ArticleExtension
import SE2Conjugate.Addition

noncomputable section
open Filter Set
open scoped Topology
namespace JacobiCore
variable (J : JacobiCore)

/-- Pole-free near zero, and regular on each open quarter-period interval. -/
def exceptionalPrimitive (x : ℝ) := J.toJacobiData.q x - J.toJacobiData.β1 x / J.c x

theorem primitive_deriv (x : ℝ) (hc : J.c x ≠ 0) :
    HasDerivAt J.exceptionalPrimitive (J.s x^2*J.d x^2/J.c x^2) x := by
  have h := (J.toJacobiData.hasDerivAt_q x).sub (J.toJacobiData.hasDerivAt_β1_div_c x hc)
  apply h.congr_deriv
  change J.k^2*J.s x^2 - (-((1-J.k^2)*J.s x^2)/J.c x^2) = _
  field_simp [hc]
  linear_combination J.k^2*J.s x^2 * J.sc x - J.s x^2 * J.sd x

theorem primitive_zero : J.exceptionalPrimitive 0 = 0 := by
  change (0-J.eps 0)-(J.c 0*(J.eps 0)-J.d 0*J.s 0)/J.c 0 = 0
  simp [J.eps0,J.s0,J.c0]

theorem sn_linear_limit :
    Tendsto (fun x => J.s x/x) (𝓝[≠] 0) (𝓝 1) := by
  simpa [J.s0,J.c0,J.d0,smul_eq_mul,div_eq_inv_mul] using (J.hs 0).tendsto_slope_zero

theorem primitive_cubic_limit :
    Tendsto (fun x => J.exceptionalPrimitive x / x^3) (𝓝[≠] 0) (𝓝 (1/3 : ℝ)) := by
  have hc0 : J.c 0 ≠ 0 := by simp [J.c0]
  have hc : ∀ᶠ x in 𝓝[≠] (0:ℝ), J.c x ≠ 0 :=
    ((J.hc 0).continuousAt.eventually_ne hc0).filter_mono nhdsWithin_le_nhds
  have hdlim : Tendsto J.d (𝓝[≠] 0) (𝓝 1) := by
    rw [← J.d0]; exact (J.hd 0).continuousAt.tendsto.mono_left nhdsWithin_le_nhds
  have hclim : Tendsto J.c (𝓝[≠] 0) (𝓝 1) := by
    rw [← J.c0]; exact (J.hc 0).continuousAt.tendsto.mono_left nhdsWithin_le_nhds
  apply HasDerivAt.lhopital_zero_nhdsNE (f' := fun x => J.s x^2*J.d x^2/J.c x^2)
    (g' := fun x => 3*x^2)
  · filter_upwards [hc] with x hx using J.primitive_deriv x hx
  · exact Eventually.of_forall fun x => by simpa [Pi.pow_def] using (hasDerivAt_id' x).pow 3
  · filter_upwards [self_mem_nhdsWithin] with x hx
    have h : x ≠ 0 := hx
    positivity
  · have hz : Tendsto J.exceptionalPrimitive (𝓝[≠] 0) (𝓝 (J.exceptionalPrimitive 0)) :=
      (J.primitive_deriv 0 hc0).continuousAt.tendsto.mono_left nhdsWithin_le_nhds
    rwa [J.primitive_zero] at hz
  · have h : Tendsto (fun x : ℝ => x^3) (𝓝[≠] 0) (𝓝 ((0:ℝ)^3)) :=
      (tendsto_id.mono_left nhdsWithin_le_nhds).pow 3
    simpa using h
  · have h := (((J.sn_linear_limit.pow 2).mul (hdlim.pow 2)).div (hclim.pow 2)
        (by norm_num)).div_const 3
    convert h using 1
    · funext x; simp only [Pi.div_apply]; ring
    · norm_num

theorem quarter_values (x : ℝ) :
    J.s (x+J.K) = J.c x/J.d x ∧ J.c (x+J.K) = -(J.s x*J.d J.K)/J.d x := by
  have h := Addition.addition J x J.K
  have hd := (J.d_pos x).ne'
  have de : Addition.delta J x J.K = J.d x^2 := by simp [Addition.delta,J.sK,J.sd]
  constructor
  · rw [h.1, Addition.addS, Addition.numS,de,J.sK,J.cK]
    field_simp; ring
  · rw [h.2.1, Addition.addC, Addition.numC,de,J.sK,J.cK]
    field_simp; ring

theorem J2_exceptional (n : ℕ) (x : ℝ) (hc : J.c x ≠ 0) :
    J.toJacobiFull.J2 (x+J.K+2*n*J.K) (x+2*n*J.K) =
    (1-J.k^2)*J.s x*J.c x/J.d x*(2*n*(J.K-2*J.E)+J.exceptionalPrimitive x) := by
  have hdk : J.d J.K ^ 2 = 1-J.k^2 := by simp [J.sd,J.sK]
  have hd := (J.d_pos x).ne'
  have hphase : J.phaseWeight (x+J.K) = (1-J.k^2)/J.d x^2 := by
    unfold phaseWeight
    rw [(J.quarter_values x).1,(J.quarter_values x).2]
    simp only [div_pow,neg_sq,mul_pow,hdk]
    field_simp [hd]
    linear_combination (1-J.k^2)*J.sc x
  rw [J.J2_periods]
  unfold periodPolynomial
  rw [hphase,(J.quarter_values x).2]
  simp only [div_pow,neg_sq,mul_pow,hdk]
  have hz : (1-J.k^2)/J.d x^2*J.s x^2-J.s x^2*(1-J.k^2)/J.d x^2 = 0 := by ring
  rw [hz,zero_mul,zero_add]
  change _ = (1-J.k^2)*J.s x*J.c x/J.d x*(2*n*(J.K-2*J.E)+
    ((x-J.eps x)-(J.c x*J.eps x-J.d x*J.s x)/J.c x))
  unfold profileCorrection
  field_simp [hd,hc]
  ring

/-- The signed coefficient is strictly positive for every admissible modulus. -/
theorem critical_quartic_limit (n : ℕ) (hcrit : J.K = 2*J.E) :
    Tendsto (fun x => J.toJacobiFull.J2 (x+J.K+2*n*J.K) (x+2*n*J.K)/x^4)
      (𝓝[≠] 0) (𝓝 ((1-J.k^2)/3)) := by
  have hd := (J.hd 0).continuousAt.continuousWithinAt (s := ({0}ᶜ : Set ℝ))
  have hc := (J.hc 0).continuousAt.continuousWithinAt (s := ({0}ᶜ : Set ℝ))
  have h := ((((tendsto_const_nhds (x := 1-J.k^2)).mul J.sn_linear_limit).mul hc).div hd
    (by simp [J.d0])).mul J.primitive_cubic_limit
  have he : ∀ᶠ x in 𝓝[≠] (0:ℝ), J.c x ≠ 0 :=
    ((J.hc 0).continuousAt.eventually_ne (by simp [J.c0])).filter_mono nhdsWithin_le_nhds
  apply Tendsto.congr' (f₁ := fun x => ((1-J.k^2)*(J.s x/x)*J.c x/J.d x)*
      (J.exceptionalPrimitive x/x^3)) _ (by simpa [J.c0,J.d0,div_eq_mul_inv] using h)
  filter_upwards [he] with x hx
  rw [J.J2_exceptional n x hx,hcrit]
  simp only [sub_self,mul_zero,zero_add]
  ring

end JacobiCore
