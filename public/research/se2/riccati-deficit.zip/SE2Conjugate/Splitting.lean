import SE2Conjugate.CriticalContact
import SE2Conjugate.CriticalModulus

noncomputable section
open Set
namespace JacobiCore.Splitting

/-- Taking a primitive increases the order of a uniform error by one. -/
private theorem primitiveBound {f d : ℝ → ℝ} {C r : ℝ} {n : ℕ} (_hr : 0 ≤ r)
    (hC : 0 ≤ C) (hz : f 0 = 0)
    (hd : ∀ t, |t| ≤ r → HasDerivAt f (d t) t)
    (hb : ∀ t, |t| ≤ r → |d t| ≤ C*|t|^n) {x : ℝ} (hx : |x| ≤ r) :
    |f x| ≤ C*|x|^(n+1) := by
  let S := Icc (-|x|) |x|
  have sub (t : ℝ) (ht : t ∈ S) : |t| ≤ |x| := abs_le.mpr ht
  have h := (convex_Icc (-|x|) |x|).norm_image_sub_le_of_norm_hasDerivWithin_le
    (fun t ht => (hd t ((sub t ht).trans hx)).hasDerivWithinAt)
    (C := C*|x|^n) (fun t ht => by
      rw [Real.norm_eq_abs]
      exact (hb t ((sub t ht).trans hx)).trans
        (mul_le_mul_of_nonneg_left (pow_le_pow_left₀ (abs_nonneg _) (sub t ht) _) hC))
    (show (0:ℝ) ∈ S from ⟨neg_nonpos.mpr (abs_nonneg _),abs_nonneg _⟩)
    (show x ∈ S from abs_le.mp le_rfl)
  simpa [Real.norm_eq_abs,hz,pow_succ,mul_assoc] using h

variable (J : JacobiCore)

private theorem cnLower {t : ℝ} (ht : |t| ≤ 1/2) : 1/2 ≤ J.c t := by
  have h := primitiveBound (f := fun x => J.c x - 1) (d := fun x => -(J.s x*J.d x))
    (n := 0) (C := 1) (r := 1/2) (by norm_num) (by norm_num) (by simp [J.c0])
    (fun x _ => (J.hc x).sub_const 1)
    (fun x _ => by
      have h := mul_le_mul (J.abs_s_le_one x) (J.abs_d_le_one x) (abs_nonneg _) zero_le_one
      simpa [abs_mul] using h) ht
  have := (abs_le.mp h).1
  norm_num at this
  linarith

private def z (t : ℝ) := J.s t * J.d t / J.c t
private def y (t : ℝ) := J.k^2 * J.s t^2
private def v (t : ℝ) := J.k^2 * J.s t * J.c t * J.d t

private theorem dz {t : ℝ} (hc : J.c t ≠ 0) :
    HasDerivAt (z J) (1-2*y J t+(z J t)^2) t := by
  apply (((J.hs t).mul (J.hd t)).div (J.hc t) hc).congr_deriv
  dsimp [y,z]
  field_simp
  linear_combination (J.c t)^2 * J.sd t

private theorem dy (t : ℝ) : HasDerivAt (y J) (2*v J t) t := by
  apply (((J.hs t).pow 2).const_mul (J.k^2)).congr_deriv
  simp [v]; ring

private theorem dv (t : ℝ) : HasDerivAt (v J)
    (J.k^2-2*(1+J.k^2)*y J t+3*(y J t)^2) t := by
  apply (((((J.hs t).const_mul (J.k^2)).mul (J.hc t)).mul (J.hd t))).congr_deriv
  dsimp [y]
  linear_combination J.k^2*(J.d t^2-J.k^2*J.s t^2)*J.sc t +
    J.k^2*(1-2*J.s t^2)*J.sd t

/-- Polynomial expressions in m=k², y=m sn², v=m sn cn dn and z=sn dn/cn.
The polynomial differential system gives uniform Taylor bounds without
differentiating any expression with a small denominator. -/
private inductive Poly where
  | num (n : ℤ) | m | Y | V | Z
  | add (a b : Poly) | mul (a b : Poly)
  deriving Inhabited

namespace Poly
private def eval (m y v z : ℝ) : Poly → ℝ
  | .num n => n | .m => m | .Y => y | .V => v | .Z => z
  | .add a b => eval m y v z a + eval m y v z b
  | .mul a b => eval m y v z a * eval m y v z b

private def D : Poly → Poly
  | .num _ | .m => .num 0
  | .Y => .mul (.num 2) .V
  | .V => .add .m (.add (.mul (.mul (.num (-2)) (.add (.num 1) .m)) .Y)
                          (.mul (.num 3) (.mul .Y .Y)))
  | .Z => .add (.num 1) (.add (.mul (.num (-2)) .Y) (.mul .Z .Z))
  | .add a b => .add (D a) (D b)
  | .mul a b => .add (.mul (D a) b) (.mul a (D b))

private def along (p : Poly) (t : ℝ) := eval (J.k^2) (y J t) (v J t) (z J t) p

private theorem diff (p : Poly) {t : ℝ} (hc : J.c t ≠ 0) :
    HasDerivAt (along J p) (along J (D p) t) t := by
  induction p with
  | num n => convert hasDerivAt_const t (n:ℝ) using 1 <;> first | rfl | norm_num [along,D,eval]
  | m => convert hasDerivAt_const t (J.k^2) using 1 <;> first | rfl | norm_num [along,D,eval]
  | Y => exact dy J t
  | V => apply (dv J t).congr_deriv; dsimp [along, D, eval]; ring
  | Z => apply (dz J hc).congr_deriv; dsimp [along, D, eval]; ring
  | add a b ha hb => exact ha.add hb
  | mul a b ha hb => exact ha.mul hb

private theorem bound (p : Poly) : ∃ C : ℝ, 0 ≤ C ∧ ∀ J t, |t| ≤ 1/2 → |along J p t| ≤ C := by
  induction p with
  | num n => exact ⟨|(n:ℝ)|,abs_nonneg _,fun _ _ _ => le_rfl⟩
  | m => exact ⟨1,by norm_num,fun J _ _ => by
      change |J.k^2| ≤ 1
      rw [abs_of_nonneg (sq_nonneg _)]
      nlinarith [J.k_pos,J.k_lt_one]⟩
  | Y => refine ⟨1,by norm_num,?_⟩; intro J t _
         change |J.k^2*J.s t^2| ≤ 1
         rw [abs_mul, abs_pow, abs_pow,abs_of_pos J.k_pos]
         nlinarith [J.k_lt_one,J.k_pos,J.abs_s_le_one t,abs_nonneg (J.s t),
           mul_le_mul (show J.k^2 ≤ 1 by nlinarith [J.k_lt_one,J.k_pos])
             (show |J.s t|^2 ≤ 1 by nlinarith [J.abs_s_le_one t,abs_nonneg (J.s t)]) (sq_nonneg _) zero_le_one]
  | V => refine ⟨1,by norm_num,?_⟩; intro J t _
         change |J.k^2*J.s t*J.c t*J.d t| ≤ 1
         simp only [abs_mul,abs_pow,abs_of_pos J.k_pos]
         have hm : J.k^2 ≤ 1 := by nlinarith [J.k_lt_one,J.k_pos]
         have h := mul_le_mul (mul_le_mul (mul_le_mul hm (J.abs_s_le_one t) (abs_nonneg _) zero_le_one)
           (J.abs_c_le_one t) (abs_nonneg _) (by norm_num)) (J.abs_d_le_one t) (abs_nonneg _) (by norm_num)
         simpa using h
  | Z => refine ⟨2,by norm_num,?_⟩; intro J t ht
         have hc := cnLower J ht
         change |J.s t * J.d t / J.c t| ≤ 2
         rw [abs_div,abs_mul,abs_of_pos (by linarith : 0<J.c t), div_le_iff₀ (by linarith)]
         have := mul_le_mul (J.abs_s_le_one t) (J.abs_d_le_one t) (abs_nonneg _) zero_le_one
         linarith
  | add a b ha hb =>
    obtain ⟨A,hA,ha⟩ := ha
    obtain ⟨B,hB,hb⟩ := hb
    exact ⟨A+B,add_nonneg hA hB,fun J t ht => (abs_add_le ..).trans (add_le_add (ha J t ht) (hb J t ht))⟩
  | mul a b ha hb =>
    obtain ⟨A,hA,ha⟩ := ha
    obtain ⟨B,hB,hb⟩ := hb
    refine ⟨A*B,mul_nonneg hA hB,fun J t ht => ?_⟩
    change |along J a t * along J b t| ≤ _
    rw [abs_mul]
    exact mul_le_mul (ha J t ht) (hb J t ht) (abs_nonneg _) hA
end Poly
private def p1 : Poly := (.mul .Z .Z)
private def p2 := Poly.D p1
private def p3 := Poly.D p2
private def p4 := Poly.D p3
private def p5 := Poly.D p4
private def p6 := Poly.D p5
private def p7 := Poly.D p6
private def a := (2-4*J.k^2)/15
private def r0 (t : ℝ) := J.exceptionalPrimitive t - ((a J)*t^5 + t^3/3)
private def r1 (t : ℝ) := Poly.along J p1 t - (5*(a J)*t^4 + t^2)
private def r2 (t : ℝ) := Poly.along J p2 t - (2*t*(10*(a J)*t^2 + 1))
private def r3 (t : ℝ) := Poly.along J p3 t - (2*(30*(a J)*t^2 + 1))
private def r4 (t : ℝ) := Poly.along J p4 t - (120*(a J)*t)
private def r5 (t : ℝ) := Poly.along J p5 t - (120*(a J))
private def r6 (t : ℝ) := Poly.along J p6 t - (0)
private def r7 (t : ℝ) := Poly.along J p7 t
private theorem dr0 (t : ℝ) (ht : |t| ≤ 1/2) : HasDerivAt (r0 J) (r1 J t) t := by
  have hc : J.c t ≠ 0 := by have := cnLower J ht; linarith
  have h := (J.primitive_deriv t hc).sub (((hasDerivAt_const t (a J)).mul ((hasDerivAt_id' t).pow 5)).add ((hasDerivAt_const t (1/3:ℝ)).mul ((hasDerivAt_id' t).pow 3)))
  convert h using 1 <;> first
    | rfl
    | (funext x; simp only [r0, Pi.sub_apply, Pi.add_apply, Pi.mul_apply, Pi.pow_apply]; ring)
    | (simp [r1, Poly.along, Poly.eval,p1,z] ; ring)
private theorem dr1 (t : ℝ) (ht : |t| ≤ 1/2) : HasDerivAt (r1 J) (r2 J t) t := by
  have hc : J.c t ≠ 0 := by have := cnLower J ht; linarith
  have h := (Poly.diff J p1 hc).sub ((((hasDerivAt_const t (5:ℝ)).mul (hasDerivAt_const t (a J))).mul ((hasDerivAt_id' t).pow 4)).add ((hasDerivAt_id' t).pow 2))
  convert h using 1 <;> first
    | rfl

    | (simp [r2, p2, Pi.pow_apply] ; ring)
private theorem dr2 (t : ℝ) (ht : |t| ≤ 1/2) : HasDerivAt (r2 J) (r3 J t) t := by
  have hc : J.c t ≠ 0 := by have := cnLower J ht; linarith
  have h := (Poly.diff J p2 hc).sub (((hasDerivAt_const t (2:ℝ)).mul (hasDerivAt_id' t)).mul ((((hasDerivAt_const t (10:ℝ)).mul (hasDerivAt_const t (a J))).mul ((hasDerivAt_id' t).pow 2)).add (hasDerivAt_const t (1:ℝ))))
  convert h using 1 <;> first
    | rfl

    | (simp [r3, p3, Pi.pow_apply] ; ring)
private theorem dr3 (t : ℝ) (ht : |t| ≤ 1/2) : HasDerivAt (r3 J) (r4 J t) t := by
  have hc : J.c t ≠ 0 := by have := cnLower J ht; linarith
  have h := (Poly.diff J p3 hc).sub ((hasDerivAt_const t (2:ℝ)).mul ((((hasDerivAt_const t (30:ℝ)).mul (hasDerivAt_const t (a J))).mul ((hasDerivAt_id' t).pow 2)).add (hasDerivAt_const t (1:ℝ))))
  convert h using 1 <;> first
    | rfl

    | (simp [r4, p4, Pi.pow_apply] ; ring)
private theorem dr4 (t : ℝ) (ht : |t| ≤ 1/2) : HasDerivAt (r4 J) (r5 J t) t := by
  have hc : J.c t ≠ 0 := by have := cnLower J ht; linarith
  have h := (Poly.diff J p4 hc).sub (((hasDerivAt_const t (120:ℝ)).mul (hasDerivAt_const t (a J))).mul (hasDerivAt_id' t))
  convert h using 1 <;> first
    | rfl

    | (simp [r5, p5])
private theorem dr5 (t : ℝ) (ht : |t| ≤ 1/2) : HasDerivAt (r5 J) (r6 J t) t := by
  have hc : J.c t ≠ 0 := by have := cnLower J ht; linarith
  have h := (Poly.diff J p5 hc).sub ((hasDerivAt_const t (120:ℝ)).mul (hasDerivAt_const t (a J)))
  convert h using 1 <;> first
    | rfl

    | (simp [r6, p6])
private theorem dr6 (t : ℝ) (ht : |t| ≤ 1/2) : HasDerivAt (r6 J) (r7 J t) t := by
  have hc : J.c t ≠ 0 := by have := cnLower J ht; linarith
  have h := (Poly.diff J p6 hc).sub (hasDerivAt_const t (0:ℝ))
  convert h using 1 <;> first
    | rfl

    | (simp [r7, p7])
/-- Uniform seventh-order primitive remainder, including both signs of the offset. -/
theorem primitive_taylor_uniform : ∃ C : ℝ, 0 ≤ C ∧ ∀ (J : JacobiCore) (h : ℝ), |h| ≤ 1/2 →
    |J.exceptionalPrimitive h - (h^3/3 + (2-4*J.k^2)/15*h^5)| ≤ C*|h|^7 := by
  obtain ⟨C,hC,hb⟩ := Poly.bound p7
  refine ⟨C,hC,?_⟩
  intro J
  have b7 (t : ℝ) (ht : |t| ≤ 1/2) : |r7 J t| ≤ C*|t|^0 := by simpa [r7] using hb J t ht
  have b6 (t : ℝ) (ht : |t| ≤ 1/2) : |r6 J t| ≤ C*|t|^1 := by
    apply primitiveBound (n := 0) (by norm_num : (0:ℝ) ≤ 1/2) hC _ (dr6 J) (b7) ht
    simp [r6,p1,p2,p3,p4,p5,p6, Poly.along, Poly.eval, Poly.D, z, v, y, J.s0, J.c0, J.d0]
  have b5 (t : ℝ) (ht : |t| ≤ 1/2) : |r5 J t| ≤ C*|t|^2 := by
    apply primitiveBound (n := 1) (by norm_num : (0:ℝ) ≤ 1/2) hC _ (dr5 J) (b6) ht
    simp [r5,p1,p2,p3,p4,p5, Poly.along, Poly.eval, Poly.D, a, z, v, y, J.s0, J.c0, J.d0]; ring
  have b4 (t : ℝ) (ht : |t| ≤ 1/2) : |r4 J t| ≤ C*|t|^3 := by
    apply primitiveBound (n := 2) (by norm_num : (0:ℝ) ≤ 1/2) hC _ (dr4 J) (b5) ht
    simp [r4,p1,p2,p3,p4, Poly.along, Poly.eval, Poly.D, a, z, v, y, J.s0, J.c0, J.d0]
  have b3 (t : ℝ) (ht : |t| ≤ 1/2) : |r3 J t| ≤ C*|t|^4 := by
    apply primitiveBound (n := 3) (by norm_num : (0:ℝ) ≤ 1/2) hC _ (dr3 J) (b4) ht
    simp [r3,p1,p2,p3, Poly.along, Poly.eval, Poly.D, a, z, v, y, J.s0, J.c0, J.d0]; ring
  have b2 (t : ℝ) (ht : |t| ≤ 1/2) : |r2 J t| ≤ C*|t|^5 := by
    apply primitiveBound (n := 4) (by norm_num : (0:ℝ) ≤ 1/2) hC _ (dr2 J) (b3) ht
    simp [r2,p1,p2, Poly.along, Poly.eval, Poly.D, a, z, v, y, J.s0, J.c0, J.d0]
  have b1 (t : ℝ) (ht : |t| ≤ 1/2) : |r1 J t| ≤ C*|t|^6 := by
    apply primitiveBound (n := 5) (by norm_num : (0:ℝ) ≤ 1/2) hC _ (dr1 J) (b2) ht
    simp [r1,p1, Poly.along, Poly.eval, a, z, v, y, J.s0, J.c0, J.d0]
  have b0 (t : ℝ) (ht : |t| ≤ 1/2) : |r0 J t| ≤ C*|t|^7 := by
    apply primitiveBound (n := 6) (by norm_num : (0:ℝ) ≤ 1/2) hC _ (dr0 J) (b1) ht
    simp [r0, a, J.primitive_zero]
  intro h hh
  simpa only [r0,a,add_comm] using b0 h hh

private theorem localSn : StrictMonoOn J.s (Icc (-(1/2:ℝ)) (1/2)) := by
  apply strictMonoOn_of_deriv_pos (convex_Icc _ _) (fun t _ => (J.hs t).continuousAt.continuousWithinAt)
  intro t ht
  have hm : t ∈ Icc (-(1/2:ℝ)) (1/2) := interior_subset ht
  have hc := cnLower J (t := t) (abs_le.mpr hm)
  rw [(J.hs t).deriv]
  exact mul_pos (by linarith) (J.d_pos _)

private theorem localPrimitive : StrictMonoOn J.exceptionalPrimitive (Icc (-(1/2:ℝ)) (1/2)) := by
  have diff (t : ℝ) (ht : |t| ≤ 1/2) := J.primitive_deriv t (by have := cnLower J ht; linarith)
  have strict (a b : ℝ) (ha : -(1/2) ≤ a) (hb : b ≤ 1/2) (hs : b ≤ 0 ∨ 0 ≤ a) :
      StrictMonoOn J.exceptionalPrimitive (Icc a b) := by
    have sub {t} (ht : t ∈ Icc a b) : |t| ≤ 1/2 := abs_le.mpr ⟨ha.trans ht.1,ht.2.trans hb⟩
    apply strictMonoOn_of_deriv_pos (convex_Icc _ _) (fun t ht => (diff t (sub ht)).continuousAt.continuousWithinAt)
    intro t ht
    have hi := interior_subset ht
    rw [interior_Icc] at ht
    have hn : t ≠ 0 := by rcases hs with h|h <;> intro e <;> linarith [ht.1,ht.2]
    have sn : J.s t ≠ 0 := by
      intro e
      exact hn ((localSn J).injOn (abs_le.mp (sub hi)) (by constructor <;> norm_num) (e.trans J.s0.symm))
    rw [(diff t (sub hi)).deriv]
    exact div_pos (mul_pos (sq_pos_of_ne_zero sn) (sq_pos_of_pos (J.d_pos _)))
      (sq_pos_of_pos (by have := cnLower J (sub hi); linarith))
  have l := strict (-(1/2)) 0 le_rfl (by norm_num) (Or.inl le_rfl)
  have r := strict 0 (1/2) (by norm_num) le_rfl (Or.inr le_rfl)
  rw [← Icc_union_Icc_eq_Icc (by norm_num : -(1/2:ℝ) ≤ 0) (by norm_num : (0:ℝ) ≤ 1/2)]
  exact l.union r ⟨⟨by norm_num,le_rfl⟩,fun _ h => h.2⟩ ⟨⟨le_rfl,by norm_num⟩,fun _ h => h.1⟩

private def correction := (4*J.k^2-2)/15

private theorem correctionBound : |correction J| ≤ 1 := by
  unfold correction
  rw [abs_le]
  constructor <;> nlinarith [J.k_pos,J.k_lt_one,sq_nonneg J.k]

private def trial (b x q : ℝ) := x*(1+(b+q*x^2)*x^2)

/-- A centered polynomial trial h=x+b x³+q x⁵. The normalized residual
differs from 3q by a fixed constant on the indicated box. -/
private theorem trialBound {C : ℝ} (hC : 0 ≤ C)
    (hG : ∀ h : ℝ, |h| ≤ 1/2 → |J.exceptionalPrimitive h -
      (h^3/3+(2-4*J.k^2)/15*h^5)| ≤ C*|h|^7)
    {x q : ℝ} (hx : x ≠ 0) (hs : |x| ≤ 1/4) (hq : |q| * |x|^2 ≤ 1) :
    let h := trial (correction J) x q
    |h| ≤ 1/2 ∧ |(3*J.exceptionalPrimitive h-x^3)/x^7-3*q| ≤ 220+384*C := by
  let b := correction J
  let l := b+q*x^2
  let u := 1+l*x^2
  let h := x*u
  have hb : |b| ≤ 1 := correctionBound J
  have hl : |l| ≤ 2 := calc
    _ ≤ |b|+|q*x^2| := abs_add_le _ _
    _ ≤ 2 := by rw [abs_mul,abs_pow]; linarith
  have hx2 : |x|^2 ≤ 1/4 := by nlinarith [sq_nonneg (|x|-1/4),mul_self_le_mul_self (abs_nonneg x) hs]
  have hu : |u| ≤ 2 := calc
    _ ≤ |(1:ℝ)|+|l*x^2| := abs_add_le _ _
    _ ≤ 2 := by rw [abs_mul,abs_pow,abs_one]; nlinarith [mul_le_mul hl hx2 (sq_nonneg _) (by norm_num)]
  have hh : |h| ≤ 1/2 := by
    dsimp [h]; rw [abs_mul]
    nlinarith [mul_le_mul hs hu (abs_nonneg _) (by norm_num)]
  refine ⟨hh,?_⟩
  let S := u^4+u^3+u^2+u+1
  have hS : |S| ≤ 31 := calc
    _ ≤ |u|^4+|u|^3+|u|^2+|u|+1 := by
      dsimp [S]; grw [abs_add_le,abs_add_le,abs_add_le,abs_add_le]; simp [abs_pow]
    _ ≤ 31 := by
      have h4 := pow_le_pow_left₀ (abs_nonneg u) hu 4
      have h3 := pow_le_pow_left₀ (abs_nonneg u) hu 3
      have h2 := pow_le_pow_left₀ (abs_nonneg u) hu 2
      norm_num at h4 h3 h2
      linarith [sq_abs u]
  let B := 3*l^2+l^3*x^2-3*b*l*S
  have hB : |B| ≤ 220 := calc
    _ ≤ |3*l^2|+|l^3*x^2|+|3*b*l*S| := by
      dsimp [B]; rw [sub_eq_add_neg]; grw [abs_add_le,abs_add_le]; rw [abs_neg]
    _ ≤ 220 := by
      simp only [abs_mul,abs_pow,show |(3:ℝ)|=3 by norm_num]
      calc
        3*|l|^2+|l|^3*|x|^2+3*|b| * |l| * |S| ≤ 3*2^2+2^3*(1/4)+3*1*2*31 := by gcongr
        _ ≤ 220 := by norm_num
  let e := 3*(J.exceptionalPrimitive h-(h^3/3-b*h^5))/x^7
  have he : |e| ≤ 384*C := by
    have he0 := hG h hh
    rw [show (2-4*J.k^2)/15 = -b by dsimp [b,correction]; ring] at he0
    simp only [neg_mul,←sub_eq_add_neg] at he0
    dsimp only [e]
    rw [abs_div,abs_mul,abs_pow,show |(3:ℝ)|=3 by norm_num,div_le_iff₀ (pow_pos (abs_pos.mpr hx) 7)]
    rw [show |h|^7 = |x|^7*|u|^7 by dsimp [h]; rw [abs_mul,mul_pow]] at he0
    have hp := pow_le_pow_left₀ (abs_nonneg u) hu 7
    norm_num at hp
    nlinarith [mul_le_mul_of_nonneg_left hp (mul_nonneg hC (pow_nonneg (abs_nonneg x) 7))]
  have eqn : (3*J.exceptionalPrimitive h-x^3)/x^7-3*q = B+e := by
    dsimp [B,e,S,h,u,l]
    field_simp [hx]
    ring
  change |(3*J.exceptionalPrimitive h-x^3)/x^7-3*q| ≤ _
  rw [eqn]
  exact (abs_add_le ..).trans (add_le_add hB he)

/-- For the real cube root x of -6n(K-2E), the two local zeros are zero
and a unique nonzero h. The cubic correction has a uniform fifth-order
error whenever x is sufficiently small. -/
theorem cube_root_splitting : ∃ D ρ : ℝ, 0 < D ∧ 0 < ρ ∧
    ∀ (J : JacobiCore) (n : ℕ) (x : ℝ), x^3 = -6*n*(J.K-2*J.E) →
    x ≠ 0 → |x| ≤ ρ → ∃ h : ℝ, h ≠ 0 ∧ |h| ≤ 1/2 ∧
      |h-(x+(4*J.k^2-2)/15*x^3)| ≤ D*|x|^5 ∧
      ∀ t : ℝ, |t| ≤ 1/2 →
        (J.toJacobiFull.J2 (t+J.K+2*n*J.K) (t+2*n*J.K)=0 ↔ t=0 ∨ t=h) := by
  obtain ⟨C,hC,hG⟩ := primitive_taylor_uniform
  let D := 221+384*C
  have hD : 1 ≤ D := by dsimp [D]; linarith
  refine ⟨D,min (1/4) (1/D),by linarith,lt_min (by norm_num) (by positivity),?_⟩
  intro J n x hcube hx hsmall
  have hs := (le_min_iff.mp hsmall).1
  have hDx : D*|x| ≤ 1 := by
    have := (le_div_iff₀ (by linarith : 0<D)).mp (le_min_iff.mp hsmall).2
    linarith
  let b := correction J
  let H := trial b x
  let F := fun q => (3*J.exceptionalPrimitive (H q)-x^3)/x^7
  have boundQ (q : ℝ) (hq : q ∈ Icc (-D) D) : |H q| ≤ 1/2 ∧ |F q-3*q| ≤ 220+384*C := by
    apply trialBound J hC (hG J) hx hs
    have h1 := mul_le_mul_of_nonneg_right (abs_le.mpr hq) (sq_nonneg |x|)
    have h2 := mul_le_mul_of_nonneg_right hDx (abs_nonneg x)
    nlinarith
  have hcontH : Continuous H := by change Continuous (fun q : ℝ => x*(1+(b+q*x^2)*x^2)); fun_prop
  have hc : ContinuousOn F (Icc (-D) D) := by
    intro q hq
    have low := cnLower J (boundQ q hq).1
    have hc := (J.primitive_deriv (H q) (by linarith)).continuousAt.comp hcontH.continuousAt
    exact (((continuousAt_const.mul hc).sub continuousAt_const).div_const _).continuousWithinAt
  have hleft := (abs_le.mp (boundQ (-D) ⟨le_rfl,by linarith⟩).2).2
  have hright := (abs_le.mp (boundQ D ⟨by linarith,le_rfl⟩).2).1
  obtain ⟨q,hq,hzero⟩ := intermediate_value_Icc (by linarith : -D ≤ D) hc
    (show 0 ∈ Icc (F (-D)) (F D) by constructor <;> dsimp [D] at hleft hright ⊢ <;> linarith)
  let h := H q
  have he : 3*J.exceptionalPrimitive h=x^3 := by
    exact sub_eq_zero.mp ((div_eq_zero_iff.mp hzero).resolve_right (pow_ne_zero _ hx))
  have hn : h ≠ 0 := by
    intro hz
    rw [hz,J.primitive_zero, mul_zero] at he
    exact (pow_ne_zero 3 hx) he.symm
  refine ⟨h,hn,(boundQ q hq).1,?_,?_⟩
  · change |trial b x q-(x+b*x^3)| ≤ _
    rw [show trial b x q-(x+b*x^3) = q*x^5 by unfold trial; ring,abs_mul,abs_pow]
    exact mul_le_mul_of_nonneg_right (abs_le.mpr hq) (by positivity)
  · intro t ht
    have hc := cnLower J ht
    have hc' : J.c t ≠ 0 := by linarith
    have hd := (J.d_pos t).ne'
    have hk : 1-J.k^2 ≠ 0 := by nlinarith [J.k_lt_one,J.k_pos]
    have sn : J.s t = 0 ↔ t = 0 := ⟨fun e =>
      (localSn J).injOn (abs_le.mp ht) (by constructor <;> norm_num) (e.trans J.s0.symm),
      fun e => e ▸ J.s0⟩
    have prim : 2*n*(J.K-2*J.E)+J.exceptionalPrimitive t=0 ↔ t=h := by
      constructor
      · intro e
        exact (localPrimitive J).injOn (abs_le.mp ht) (abs_le.mp (boundQ q hq).1) (by linarith)
      · rintro rfl; linarith
    rw [J.J2_exceptional n t hc']
    simp [mul_eq_zero,div_eq_zero_iff,hk,hd,hc',sn,prim]

end JacobiCore.Splitting

namespace JacobiConcrete
open Filter
open scoped Topology

def criticalGap (k : ℝ) := K k - 2*secondIntegral k (Real.pi/2)

theorem criticalGap_derivative {κ : ℝ} (hk : κ ∈ Ioo (0:ℝ) 1) (he : criticalGap κ=0) :
    HasDerivAt criticalGap (secondIntegral κ (Real.pi/2)/(κ*(1-κ^2))) κ := by
  have h := (hasDerivAt_K κ hk.1 hk.2).sub ((hasDerivAt_completeSecond κ hk.1 hk.2).const_mul 2)
  apply h.congr_deriv
  unfold criticalGap at he
  have den : 1-κ^2 ≠ 0 := by nlinarith [hk.1,hk.2]
  rw [sub_eq_zero.mp he]
  field_simp [den,hk.1.ne']
  ring

private def cubeMap : ℝ ≃o ℝ := StrictMono.orderIsoOfSurjective (fun t : ℝ => t^3)
  (Odd.strictMono_pow (by decide : Odd 3)) (by
    intro u
    let r := |u|+1
    have hr : 1 ≤ r := by dsimp [r]; linarith [abs_nonneg u]
    have hh : |u| ≤ r^3 := by
      have h1 := mul_self_le_mul_self (by norm_num : (0:ℝ) ≤ 1) hr
      have h2 := mul_le_mul hr h1 (by norm_num : (0:ℝ) ≤ 1*1) (by linarith : 0≤r)
      dsimp [r] at *
      nlinarith [mul_nonneg (abs_nonneg u) (sq_nonneg |u|)]
    obtain ⟨t,_,ht⟩ := intermediate_value_Icc (by linarith : -r ≤ r)
      (f := fun t : ℝ => t^3) (by fun_prop) (show u ∈ Icc ((-r)^3) (r^3) by
        constructor <;> nlinarith [le_abs_self u,neg_abs_le u])
    exact ⟨t,ht⟩)

/-- Signed real cube root (including negative arguments). -/
def signedCubeRoot (u : ℝ) := cubeMap.symm u

theorem signedCubeRoot_cube (u : ℝ) : (signedCubeRoot u)^3=u :=
  cubeMap.apply_symm_apply u

private theorem root0 : signedCubeRoot 0=0 :=
  cubeMap.injective (show cubeMap (signedCubeRoot 0)=cubeMap 0 by change _^3 = (0:ℝ)^3; rw [signedCubeRoot_cube]; norm_num)

/-- Fixed-cell formulation on an actual punctured modulus neighborhood. -/
theorem fixed_cell_splitting {κ : ℝ} (hk : κ ∈ Ioo (0:ℝ) 1) (he : criticalGap κ=0)
    (n : ℕ) (hn : 0<n) : ∃ D : ℝ, 0<D ∧ ∀ᶠ k in 𝓝[≠] κ,
    ∃ (hkr : k ∈ Ioo (0:ℝ) 1) (h : ℝ),
      let J := core k hkr.1 hkr.2
      let x := signedCubeRoot (-6*n*criticalGap k)
      h ≠ 0 ∧ |h| ≤ 1/2 ∧ |h-(x+(4*k^2-2)/15*x^3)| ≤ D*|x|^5 ∧
        ∀ t : ℝ, |t| ≤ 1/2 →
        (J.toJacobiFull.J2 (t+J.K+2*n*J.K) (t+2*n*J.K)=0 ↔ t=0 ∨ t=h) := by
  obtain ⟨D,ρ,hD,hρ,main⟩ := JacobiCore.Splitting.cube_root_splitting
  refine ⟨D,hD,?_⟩
  have hcont := (criticalGap_derivative hk he).continuousAt
  have rootCont : Continuous signedCubeRoot := cubeMap.symm.continuous
  have hlim : Tendsto (fun k : ℝ => signedCubeRoot (-6*n*criticalGap k)) (𝓝 κ) (𝓝 0) := by
    have hi : ContinuousAt (fun k : ℝ => -6*n*criticalGap k) κ := continuousAt_const.mul hcont
    have hh := rootCont.continuousAt.comp hi
    simpa [Function.comp_def,he,root0] using hh.tendsto
  have hnear := hlim (Ioo_mem_nhds (neg_lt_zero.mpr hρ) hρ)
  filter_upwards [mem_nhdsWithin_of_mem_nhds hnear,
    mem_nhdsWithin_of_mem_nhds (isOpen_Ioo.mem_nhds hk), self_mem_nhdsWithin] with k hs hkr hne
  have hgap : criticalGap k ≠ 0 := by
    intro h
    have hEq := JacobiConcrete.gap_strictAnti.injOn hkr hk
      (show normalizedGap k=normalizedGap κ by
        unfold criticalGap at he h
        simp [normalizedGap, sub_eq_zero.mp he,sub_eq_zero.mp h])
    exact hne hEq
  let x := signedCubeRoot (-6*n*criticalGap k)
  have hx := signedCubeRoot_cube (-6*n*criticalGap k)
  have hx0 : x ≠ 0 := by
    intro hz
    change x^3 = _ at hx
    rw [hz,zero_pow (by decide : 3≠0)] at hx
    exact (mul_ne_zero (mul_ne_zero (by norm_num) (Nat.cast_ne_zero.mpr hn.ne')) hgap) hx.symm
  let J := core k hkr.1 hkr.2
  have hE : J.E = secondIntegral k (Real.pi/2) := full_E k hkr.1 hkr.2
  have hxJ : x^3 = -6*n*(J.K-2*J.E) := by rw [hE]; exact hx
  obtain ⟨h,h0,hh,herr,hroots⟩ := main J n x hxJ hx0 (abs_le.mpr ⟨hs.1.le,hs.2.le⟩)
  exact ⟨hkr,h,h0,hh,herr,hroots⟩

end JacobiConcrete

namespace JacobiConcrete
open Filter
open scoped Topology

/-- The leading displacement in signed modulus units, from either side. -/
theorem signed_scale_limit {κ : ℝ} (hk : κ ∈ Ioo (0:ℝ) 1) (he : criticalGap κ=0) (n : ℕ) :
    Tendsto (fun k => signedCubeRoot (-6*n*criticalGap k)/signedCubeRoot (k-κ)) (𝓝[≠] κ)
      (𝓝 (signedCubeRoot (-6*n*(secondIntegral κ (Real.pi/2)/(κ*(1-κ^2)))))) := by
  have hg := (criticalGap_derivative hk he).tendsto_slope
  have hg' : Tendsto (fun k => criticalGap k/(k-κ)) (𝓝[≠] κ)
      (𝓝 (secondIntegral κ (Real.pi/2)/(κ*(1-κ^2)))) := by
    apply hg.congr
    intro k
    simp [slope,he,smul_eq_mul,div_eq_inv_mul]
  have hlim := (show Continuous signedCubeRoot from cubeMap.symm.continuous).continuousAt.tendsto.comp
    (hg'.const_mul (-6*(n:ℝ)))
  apply hlim.congr'
  filter_upwards with k
  apply cubeMap.injective
  change (signedCubeRoot _)^3 = (signedCubeRoot _/signedCubeRoot _)^3
  rw [div_pow,signedCubeRoot_cube,signedCubeRoot_cube,signedCubeRoot_cube]
  ring

end JacobiConcrete

namespace JacobiConcrete
open Filter
open scoped Topology

/-- Every selection of the noncentral local root has the same signed
two-sided separation coefficient in modulus units. -/
theorem moving_root_limit {κ : ℝ} (hk : κ ∈ Ioo (0:ℝ) 1) (he : criticalGap κ=0)
    (n : ℕ) (hn : 0<n) (h : ℝ → ℝ)
    (hroot : ∀ᶠ k in 𝓝[≠] κ, ∃ hk' : k ∈ Ioo (0:ℝ) 1,
      let J := core k hk'.1 hk'.2
      h k ≠ 0 ∧ |h k| ≤ 1/2 ∧
        J.toJacobiFull.J2 (h k+J.K+2*n*J.K) (h k+2*n*J.K)=0) :
    Tendsto (fun k => h k / signedCubeRoot (k-κ)) (𝓝[≠] κ)
      (𝓝 (signedCubeRoot (-6*n*(secondIntegral κ (Real.pi/2)/(κ*(1-κ^2)))))) := by
  let x := fun k : ℝ => signedCubeRoot (-6*n*criticalGap k)
  have hi : ContinuousAt (fun k : ℝ => -6*n*criticalGap k) κ :=
    continuousAt_const.mul (criticalGap_derivative hk he).continuousAt
  have xlim : Tendsto x (𝓝[≠] κ) (𝓝 0) := by
    have hh := (show Continuous signedCubeRoot from cubeMap.symm.continuous).continuousAt.comp hi
    simpa [x, Function.comp_def,he,root0] using hh.tendsto.mono_left nhdsWithin_le_nhds
  obtain ⟨D,hD,hfixed⟩ := fixed_cell_splitting hk he n hn
  have xne : ∀ᶠ k in 𝓝[≠] κ, x k ≠ 0 := by
    filter_upwards [hfixed] with k hfix
    obtain ⟨_,u,hu,_,herr,_⟩ := hfix
    intro hz
    change x k=0 at hz
    change |u-(x k+_*x k^3)| ≤ D*|x k|^5 at herr
    simp [hz,hu] at herr
  have ratio : Tendsto (fun k => h k / x k) (𝓝[≠] κ) (𝓝 1) := by
    suffices diff : Tendsto (fun k => h k / x k-1) (𝓝[≠] κ) (𝓝 0) by
      simpa using diff.add_const 1
    apply squeeze_zero_norm' (a := fun k => D*|x k|^4+|x k|^2)
    · filter_upwards [hfixed,hroot,xne] with k hf hr hnx
      obtain ⟨hkr,u,_,_,herr,hzeros⟩ := hf
      obtain ⟨_,hu,hh,hj⟩ := hr
      obtain rfl := ((hzeros (h k) hh).mp hj).resolve_left hu |>.symm
      let b := (4*k^2-2)/15
      have hb : |b| ≤ 1 := by dsimp [b]; rw [abs_le]; constructor <;> nlinarith [hkr.1,hkr.2,sq_nonneg k]
      change |h k-(x k+b*x k^3)| ≤ D*|x k|^5 at herr
      rw [Real.norm_eq_abs,show h k/x k-1 = (h k-x k)/x k by field_simp,abs_div,
        div_le_iff₀ (abs_pos.mpr hnx)]
      have hb' := mul_le_mul_of_nonneg_right hb (pow_nonneg (abs_nonneg (x k)) 3)
      have ht := abs_add_le (h k-(x k+b*x k^3)) (b*x k^3)
      rw [show h k-(x k+b*x k^3)+b*x k^3=h k-x k by ring,abs_mul,abs_pow] at ht
      linarith only [ht,herr,hb',show (D*|x k|^4+|x k|^2)*|x k|=D*|x k|^5+|x k|^3 by ring]
    · simpa using ((xlim.abs.pow 4).const_mul D).add (xlim.abs.pow 2)
  have lim := ratio.mul (signed_scale_limit hk he n)
  apply Tendsto.congr' _ (by simpa only [one_mul] using lim)
  filter_upwards [xne] with k hx
  change h k/x k*(x k/signedCubeRoot (k-κ)) = _
  rw [div_mul_div_cancel₀ hx]

end JacobiConcrete
