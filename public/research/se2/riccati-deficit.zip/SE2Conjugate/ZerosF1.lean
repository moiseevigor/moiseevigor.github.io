import SE2Conjugate.Zeros

/-!
# Lemma 3.1(iv), part 3: the zeros of `f₁`

On `I_m = ((2m+1)K, (2m+3)K)` the quotient `f₁/cn` is strictly decreasing (`cn ≠ 0` there), and
`f₁ = ∓k'` at the ends, `f₁/cn = 2(m+1)(E-K) < 0` at `(2m+2)K`.  Hence `f₁` has exactly one zero
`p_{m+1}^1` in `I_m`, it lies in `((2m+1)K, (2m+2)K)`, and `f₁` has the sign `(-1)^(m+1)` before
it and `(-1)^m` after it (Moiseev–Sachkov, Lemma 5.3 and Corollary 5.1).
-/

noncomputable section

namespace JacobiPeriodic

variable (J : JacobiPeriodic)

theorem f1_odd (m : ℕ) :
    J.toJacobiData.f1 ((2 * m + 1) * J.K) = -((-1) ^ m * Real.sqrt (1 - J.k ^ 2)) := by
  show J.c ((2 * m + 1) * J.K) * (J.eps ((2 * m + 1) * J.K) - (2 * m + 1) * J.K)
      - J.d ((2 * m + 1) * J.K) * J.s ((2 * m + 1) * J.K) = _
  rw [J.s_odd, J.c_odd, J.d_odd]
  ring

theorem f1_even (m : ℕ) :
    J.toJacobiData.f1 (2 * m * J.K) = (-1) ^ m * (2 * m * (J.E - J.K)) := by
  show J.c (2 * m * J.K) * (J.eps (2 * m * J.K) - 2 * m * J.K)
      - J.d (2 * m * J.K) * J.s (2 * m * J.K) = _
  rw [J.s_even, J.c_even, J.eps_even]
  ring

/-- `cn ≠ 0` on `I_m`. -/
theorem c_ne_on_I (m : ℕ) {p : ℝ} (hp : p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K)) :
    J.c p ≠ 0 := by
  intro h
  have := J.c_sign m p hp
  rw [h, mul_zero] at this
  exact lt_irrefl _ this

theorem f1_div_c_strictAntiOn_I (m : ℕ) :
    StrictAntiOn (fun p => J.toJacobiData.f1 p / J.c p)
      (Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K)) :=
  J.toJacobiInit.f1_div_c_strictAntiOn (convex_Ioo _ _) (fun _ hp => J.c_ne_on_I m hp)

/-- The value of `f₁/cn` at the midpoint `(2m+2)K` of `I_m`. -/
theorem f1_div_c_mid (m : ℕ) :
    J.toJacobiData.f1 ((2 * m + 2) * J.K) / J.c ((2 * m + 2) * J.K) = 2 * (m + 1) * (J.E - J.K) := by
  have h2 : (2 * m + 2 : ℝ) * J.K = 2 * ((m + 1 : ℕ) : ℝ) * J.K := by push_cast; ring
  rw [h2, J.f1_even, J.c_even]
  have : ((-1 : ℝ) ^ (m + 1)) ≠ 0 := pow_ne_zero _ (by norm_num)
  field_simp
  push_cast
  ring

theorem mid_mem_I (m : ℕ) :
    (2 * m + 2) * J.K ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K) := by
  have := J.K_pos
  constructor <;> nlinarith

/-- `f₁/cn < 0` on `[(2m+2)K, (2m+3)K)`. -/
theorem f1_div_c_neg_after (m : ℕ) {p : ℝ}
    (hp : p ∈ Set.Ico ((2 * m + 2) * J.K) ((2 * m + 3) * J.K)) :
    J.toJacobiData.f1 p / J.c p < 0 := by
  have hK := J.K_pos
  have hmid := J.f1_div_c_mid m
  have hneg : 2 * ((m : ℝ) + 1) * (J.E - J.K) < 0 := by
    have := J.E_lt_K
    have : (0 : ℝ) ≤ m := Nat.cast_nonneg m
    nlinarith
  rcases eq_or_lt_of_le hp.1 with h | h
  · rw [← h, hmid]; exact hneg
  · have hpI : p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K) := ⟨by nlinarith, hp.2⟩
    have := J.f1_div_c_strictAntiOn_I m (J.mid_mem_I m) hpI h
    simp only at this
    rw [hmid] at this
    linarith

/-- `f₁` does not vanish on `[(2m+2)K, (2m+3)K)`. -/
theorem f1_ne_zero_after (m : ℕ) {p : ℝ}
    (hp : p ∈ Set.Ico ((2 * m + 2) * J.K) ((2 * m + 3) * J.K)) : J.toJacobiData.f1 p ≠ 0 := by
  intro h
  have := J.f1_div_c_neg_after m hp
  rw [h, zero_div] at this
  exact lt_irrefl _ this

/-- Existence and uniqueness of the zero `p_{m+1}^1` of `f₁` in `((2m+1)K, (2m+2)K)`; it is the
only zero in `I_m`. -/
theorem exists_unique_f1_zero (m : ℕ) :
    ∃! p, p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 2) * J.K) ∧ J.toJacobiData.f1 p = 0 := by
  have hK := J.K_pos
  have hlt : (2 * m + 1) * J.K < (2 * m + 2) * J.K := by nlinarith
  -- the signed function g = (-1)^m f₁ goes from -k' < 0 to 2(m+1)(K-E) > 0
  set g := fun p => (-1) ^ m * J.toJacobiData.f1 p with hg
  have hcont : ContinuousOn g (Set.Icc ((2 * m + 1) * J.K) ((2 * m + 2) * J.K)) :=
    continuousOn_const.mul
      (fun p _ => (J.toJacobiData.hasDerivAt_f1 p).continuousAt.continuousWithinAt)
  have hga : g ((2 * m + 1) * J.K) = -Real.sqrt (1 - J.k ^ 2) := by
    rw [hg]; simp only; rw [J.f1_odd]; ring_nf; simp
  have hgb : g ((2 * m + 2) * J.K) = 2 * (m + 1) * (J.K - J.E) := by
    have h2 : (2 * m + 2 : ℝ) * J.K = 2 * ((m + 1 : ℕ) : ℝ) * J.K := by push_cast; ring
    rw [hg]; simp only; rw [h2, J.f1_even]; push_cast; ring_nf; simp
  have hneg : g ((2 * m + 1) * J.K) < 0 := by rw [hga]; linarith [J.k'_pos]
  have hpos : 0 < g ((2 * m + 2) * J.K) := by
    rw [hgb]
    have := J.E_lt_K
    have : (0 : ℝ) ≤ m := Nat.cast_nonneg m
    nlinarith
  have hmem : (0 : ℝ) ∈ Set.Icc (g ((2 * m + 1) * J.K)) (g ((2 * m + 2) * J.K)) :=
    ⟨hneg.le, hpos.le⟩
  obtain ⟨p, hp, hgp⟩ := intermediate_value_Icc hlt.le hcont hmem
  have hp_open : p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 2) * J.K) := by
    rcases eq_or_lt_of_le hp.1 with h | h
    · exfalso; rw [← h] at hgp; linarith
    rcases eq_or_lt_of_le hp.2 with h' | h'
    · exfalso; rw [h'] at hgp; linarith
    exact ⟨h, h'⟩
  have hf0 : J.toJacobiData.f1 p = 0 := by
    have : (-1 : ℝ) ^ m * J.toJacobiData.f1 p = 0 := hgp
    rcases mul_eq_zero.mp this with h | h
    · exfalso; exact pow_ne_zero m (by norm_num) h
    · exact h
  refine ⟨p, ⟨hp_open, hf0⟩, ?_⟩
  rintro p' ⟨hp', hf'⟩
  have hI : p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K) :=
    ⟨hp_open.1, by nlinarith [hp_open.2]⟩
  have hI' : p' ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K) :=
    ⟨hp'.1, by nlinarith [hp'.2]⟩
  apply (J.f1_div_c_strictAntiOn_I m).injOn hI' hI
  show J.toJacobiData.f1 p' / J.c p' = J.toJacobiData.f1 p / J.c p
  rw [hf', hf0, zero_div, zero_div]

/-- The unique zero of `f₁` in `((2m+1)K, (2m+2)K)`. -/
def pM (m : ℕ) : ℝ := Classical.choose (J.exists_unique_f1_zero m).exists

theorem pM_spec (m : ℕ) :
    J.pM m ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 2) * J.K) ∧ J.toJacobiData.f1 (J.pM m) = 0 :=
  Classical.choose_spec (J.exists_unique_f1_zero m).exists

theorem pM_unique (m : ℕ) {p : ℝ} (hp : p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 2) * J.K))
    (h0 : J.toJacobiData.f1 p = 0) : p = J.pM m :=
  (J.exists_unique_f1_zero m).unique ⟨hp, h0⟩ (J.pM_spec m)

/-- Sign of `f₁/cn` on `I_m`: positive before `p_{m+1}^1`, negative after. -/
theorem f1_div_c_pos_before (m : ℕ) {p : ℝ} (hp : p ∈ Set.Ioo ((2 * m + 1) * J.K) (J.pM m)) :
    0 < J.toJacobiData.f1 p / J.c p := by
  have hM := J.pM_spec m
  have hK := J.K_pos
  have hpI : p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K) :=
    ⟨hp.1, by nlinarith [hp.2, hM.1.2]⟩
  have hMI : J.pM m ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K) :=
    ⟨hM.1.1, by nlinarith [hM.1.2]⟩
  have := J.f1_div_c_strictAntiOn_I m hpI hMI hp.2
  simp only at this
  rw [hM.2, zero_div] at this
  exact this

theorem f1_div_c_neg_after' (m : ℕ) {p : ℝ} (hp : p ∈ Set.Ioo (J.pM m) ((2 * m + 3) * J.K)) :
    J.toJacobiData.f1 p / J.c p < 0 := by
  have hM := J.pM_spec m
  have hK := J.K_pos
  have hpI : p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K) :=
    ⟨by linarith [hp.1, hM.1.1], hp.2⟩
  have hMI : J.pM m ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K) :=
    ⟨hM.1.1, by nlinarith [hM.1.2]⟩
  have := J.f1_div_c_strictAntiOn_I m hMI hpI hp.1
  simp only at this
  rw [hM.2, zero_div] at this
  exact this

/-- `f₁` has the sign `(-1)^m` on `(p_{m+1}^1, (2m+3)K)`: for `m = 0`, `f₁ > 0` on `(p₁¹, 3K)`. -/
theorem f1_sign_after (m : ℕ) {p : ℝ} (hp : p ∈ Set.Ioo (J.pM m) ((2 * m + 3) * J.K)) :
    0 < (-1) ^ m * J.toJacobiData.f1 p := by
  have hM := J.pM_spec m
  have hK := J.K_pos
  have hpI : p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K) :=
    ⟨by linarith [hp.1, hM.1.1], hp.2⟩
  have hc := J.c_sign m p hpI
  have hq := J.f1_div_c_neg_after' m hp
  have hcne := J.c_ne_on_I m hpI
  have hf : J.toJacobiData.f1 p = (J.toJacobiData.f1 p / J.c p) * J.c p := by field_simp
  rw [hf]
  -- (-1)^m * (q * c) = -(q) * ((-1)^(m+1) * c) > 0
  have : (-1 : ℝ) ^ m * (J.toJacobiData.f1 p / J.c p * J.c p)
      = (-(J.toJacobiData.f1 p / J.c p)) * ((-1) ^ (m + 1) * J.c p) := by ring
  rw [this]
  exact mul_pos (by linarith) hc

/-- `f₁` has the sign `(-1)^(m+1)` on `((2m+1)K, p_{m+1}^1)`: for `m = 0`, `f₁ < 0` on `(K, p₁¹)`. -/
theorem f1_sign_before (m : ℕ) {p : ℝ} (hp : p ∈ Set.Ioo ((2 * m + 1) * J.K) (J.pM m)) :
    0 < (-1) ^ (m + 1) * J.toJacobiData.f1 p := by
  have hM := J.pM_spec m
  have hK := J.K_pos
  have hpI : p ∈ Set.Ioo ((2 * m + 1) * J.K) ((2 * m + 3) * J.K) :=
    ⟨hp.1, by nlinarith [hp.2, hM.1.2]⟩
  have hc := J.c_sign m p hpI
  have hq := J.f1_div_c_pos_before m hp
  have hcne := J.c_ne_on_I m hpI
  have hf : J.toJacobiData.f1 p = (J.toJacobiData.f1 p / J.c p) * J.c p := by field_simp
  rw [hf]
  have : (-1 : ℝ) ^ (m + 1) * (J.toJacobiData.f1 p / J.c p * J.c p)
      = (J.toJacobiData.f1 p / J.c p) * ((-1) ^ (m + 1) * J.c p) := by ring
  rw [this]
  exact mul_pos hq hc

end JacobiPeriodic

end
