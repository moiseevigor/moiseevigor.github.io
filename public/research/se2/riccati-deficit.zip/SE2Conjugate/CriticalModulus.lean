import SE2Conjugate.Modulus

noncomputable section
open Set MeasureTheory
namespace JacobiConcrete

def normalizedGap (k : ℝ) := (2*secondIntegral k (Real.pi/2)-K k)/k

theorem gap_deriv {k : ℝ} (hk : k ∈ Ioo (0:ℝ) 1) :
    HasDerivAt normalizedGap (-secondIntegral k (Real.pi/2)/(k^2*(1-k^2))) k := by
  have h := (((hasDerivAt_completeSecond k hk.1 hk.2).const_mul 2).sub
    (hasDerivAt_K k hk.1 hk.2)).div (hasDerivAt_id' k) hk.1.ne'
  apply h.congr_deriv
  have hden : 1-k^2 ≠ 0 := by nlinarith [hk.1,hk.2]
  simp only [Pi.sub_apply]
  field_simp [hden,hk.1.ne']
  ring

theorem completeSecond_ge_one {k : ℝ} (hk : k ∈ Ioo (0:ℝ) 1) :
    1 ≤ secondIntegral k (Real.pi/2) := by
  have h := intervalIntegral.integral_mono_on (μ := volume) (a := (0:ℝ)) (b := Real.pi/2)
    (by positivity) (Real.continuous_cos.intervalIntegrable _ _) ((speed_continuous k).intervalIntegrable _ _)
    (g := speed k) (f := Real.cos) (fun t _ => by
      have hh := Real.sq_sqrt (radicand_pos k hk.1 hk.2 t).le
      have h0 : 0≤1-k^2 := by nlinarith [hk.1,hk.2]
      have ht := mul_nonneg h0 (sq_nonneg (Real.sin t))
      change Real.cos t ≤ Real.sqrt _
      nlinarith [Real.sin_sq_add_cos_sq t, Real.sqrt_nonneg (1-k^2*Real.sin t^2)])
  simpa [secondIntegral] using h

theorem gap_strictAnti : StrictAntiOn normalizedGap (Ioo (0:ℝ) 1) := by
  apply strictAntiOn_of_deriv_neg (convex_Ioo _ _)
  · exact fun k hk => (gap_deriv hk).continuousAt.continuousWithinAt
  · intro k hk
    have h := interior_subset hk
    rw [(gap_deriv h).deriv]
    have hE := completeSecond_ge_one h
    have : 0<1-k^2 := by nlinarith [h.1,h.2]
    exact div_neg_of_neg_of_pos (by linarith) (mul_pos (sq_pos_of_pos h.1) this)

theorem gap_half_pos : 0 < normalizedGap (1/2) := by
  have hk : (1/2:ℝ) ∈ Ioo 0 1 := by constructor <;> norm_num
  have hcmp : ∀ t : ℝ, weight (1/2) t < 2*speed (1/2) t := by
    intro t
    apply (div_lt_iff₀ (speed_pos _ hk.1 hk.2 t)).mpr
    have hh : speed (1/2) t ^ 2 = _ := Real.sq_sqrt (radicand_pos _ hk.1 hk.2 t).le
    nlinarith [Real.sin_sq_le_one t]
  have h := intervalIntegral.integral_lt_integral_of_continuousOn_of_le_of_exists_lt
    (a := (0:ℝ)) (b := Real.pi/2) (by positivity)
    (weight_continuous _ hk.1 hk.2).continuousOn ((continuous_const.mul (speed_continuous (1/2))).continuousOn)
    (fun t _ => (hcmp t).le) ⟨0,⟨le_rfl,by positivity⟩,hcmp 0⟩
  simp only [Pi.mul_apply] at h
  rw [intervalIntegral.integral_const_mul] at h
  change 0 < (2*(∫ t in (0:ℝ)..Real.pi/2, speed (1/2) t)-
    (∫ t in (0:ℝ)..Real.pi/2, weight (1/2) t))/(1/2)
  exact div_pos (sub_pos.mpr h) (by norm_num)

/-- A logarithmic majorant forces the sign switch before modulus one. -/
theorem shiftedGap_antitone : AntitoneOn
    (fun k => normalizedGap k - Real.log (1-k)/2) (Ioo (0:ℝ) 1) := by
  have hder (k : ℝ) (hk : k ∈ Ioo (0:ℝ) 1) :=
    (gap_deriv hk).sub ((((hasDerivAt_id' k).const_sub 1).log (by linarith [hk.2])).div_const 2)
  apply antitoneOn_of_deriv_nonpos (convex_Ioo _ _)
  · exact fun k hk => (hder k hk).continuousAt.continuousWithinAt
  · exact fun k hk => (hder k (interior_subset hk)).differentiableAt.differentiableWithinAt
  · intro k hi
    have hk := interior_subset hi
    change deriv (normalizedGap - fun z => Real.log (1-z)/2) k ≤ 0
    rw [(hder k hk).deriv]
    have hE := completeSecond_ge_one hk
    have h1 : 0<1-k := by linarith [hk.2]
    have h2 : 0<1-k^2 := by nlinarith [hk.1,hk.2]
    have hsq := sq_pos_of_pos hk.1
    have hden : k^2*(1-k^2) ≤ 2*(1-k) := calc
      _ ≤ 1*(1-k^2) := mul_le_mul_of_nonneg_right (by nlinarith [hk.2,hk.1]) h2.le
      _ ≤ _ := by nlinarith [sq_nonneg (1-k)]
    have hh := mul_le_mul_of_nonneg_right hE (by linarith : 0≤2*(1-k))
    have hquot : 1 / (2*(1-k)) ≤ secondIntegral k (Real.pi/2) / (k^2*(1-k^2)) :=
      (div_le_div_iff₀ (by positivity) (mul_pos hsq h2)).mpr (by linarith)
    rw [show (-1 : ℝ)/(1-k)/2 = -(1/(2*(1-k))) by field_simp [h1.ne'], neg_div]
    exact sub_nonpos.mpr (neg_le_neg hquot)

theorem unique_critical_modulus :
    ∃! k : ℝ, k ∈ Ioo (0:ℝ) 1 ∧ K k = 2*secondIntegral k (Real.pi/2) := by
  let a : ℝ := 1/2
  let L := normalizedGap a
  have ha : a ∈ Ioo (0:ℝ) 1 := by constructor <;> norm_num [a]
  have hL : 0<L := gap_half_pos
  let δ := Real.exp (-(2*L+2))/2
  let b := 1-δ
  have hδ : 0<δ := by dsimp [δ]; positivity
  have hs : δ < 1/2 := by
    dsimp [δ]
    have : Real.exp (-(2*L+2)) < 1 := Real.exp_lt_one_iff.mpr (by linarith)
    linarith
  have hab : a < b := by dsimp [a,b]; linarith
  have hb : b ∈ Ioo (0:ℝ) 1 := ⟨ha.1.trans hab,by dsimp [b]; linarith⟩
  have hcomp := shiftedGap_antitone ha hb hab.le
  have hloga : Real.log (1-a) = -Real.log 2 := by norm_num [a,Real.log_div]
  have hlogb : Real.log (1-b) = -(2*L+2)-Real.log 2 := by
    simp [b,δ,Real.log_div,Real.exp_ne_zero]
  dsimp only at hcomp
  rw [hloga,hlogb] at hcomp
  have hneg : normalizedGap b < 0 := by
    change normalizedGap b - (-(2*L+2)-Real.log 2)/2 ≤ L - (-Real.log 2)/2 at hcomp
    linarith
  have sub : Icc a b ⊆ Ioo (0:ℝ) 1 := fun _ hk => ⟨ha.1.trans_le hk.1,hk.2.trans_lt hb.2⟩
  obtain ⟨k,hk,hzero⟩ := intermediate_value_Icc' hab.le
    (fun x hx => (gap_deriv (sub hx)).continuousAt.continuousWithinAt)
    (show 0 ∈ Icc (normalizedGap b) (normalizedGap a) from ⟨hneg.le,hL.le⟩)
  refine ⟨k,⟨sub hk,?_⟩,?_⟩
  · have := (div_eq_zero_iff.mp hzero).resolve_right (sub hk).1.ne'
    linarith
  · rintro y ⟨hy,he⟩
    apply gap_strictAnti.injOn hy (sub hk)
    rw [hzero]
    simp [normalizedGap,he]

end JacobiConcrete
