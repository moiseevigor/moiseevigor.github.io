import SE2Conjugate.AmplitudeChart
import Mathlib.Analysis.Calculus.InverseFunctionTheorem.FDeriv

/-! Transport the actual amplitude-chart endpoint differential to (t,varphi,k). -/
noncomputable section
open Filter Set
open scoped Topology
namespace JacobiConcrete
namespace AmplitudeChart

def dInverse (z : V3) : V3 →L[ℝ] V3 := ContinuousLinearMap.pi
  ![(speed (z 2) (z 0) / z 2) •
      (coord 1 - (first 0 z + z 2 * firstModulusPrimitive (z 2) (z 0)) • coord 2),
    (speed (z 2) (z 1) / z 2) •
      (coord 0 + coord 1 - (first 1 z + z 2 * firstModulusPrimitive (z 2) (z 1)) • coord 2),
    coord 2]

theorem inverse_linear_left (z v : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    dInverse z (dSource z v) = v := by
  have ha := (speed_pos (z 2) h0 h1 (z 0)).ne'
  have hb := (speed_pos (z 2) h0 h1 (z 1)).ne'
  ext i
  fin_cases i <;> simp [dInverse, dSource, dFirst, coord, weight] <;>
    field_simp [ha,hb,h0.ne'] <;> ring

theorem inverse_linear_right (z v : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    dSource z (dInverse z v) = v := by
  have ha := (speed_pos (z 2) h0 h1 (z 0)).ne'
  have hb := (speed_pos (z 2) h0 h1 (z 1)).ne'
  ext i
  fin_cases i <;> simp [dInverse, dSource, dFirst, coord, weight] <;>
    field_simp [ha,hb,h0.ne'] <;> ring

def sourceEquiv (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) : V3 ≃L[ℝ] V3 where
  toLinearEquiv :=
    { (dSource z).toLinearMap with
      invFun := dInverse z
      left_inv := fun v => inverse_linear_left z v h0 h1
      right_inv := fun v => inverse_linear_right z v h0 h1 }
  continuous_toFun := (dSource z).continuous
  continuous_invFun := (dInverse z).continuous

@[simp] theorem sourceEquiv_coe (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    (sourceEquiv z h0 h1 : V3 →L[ℝ] V3) = dSource z := rfl

@[simp] theorem sourceEquiv_symm_coe (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    ((sourceEquiv z h0 h1).symm : V3 →L[ℝ] V3) = dInverse z := rfl

/-- A total extension; only the open rotating modulus domain is used below. -/
def inverseSource (y : V3) : V3 :=
  if h : 0 < y 2 ∧ y 2 < 1 then
    ![amplitude (y 2) h.1 h.2 (y 1/y 2),
      amplitude (y 2) h.1 h.2 ((y 1+y 0)/y 2), y 2]
  else 0

theorem inverse_source (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    inverseSource (source z) = z := by
  have h : 0 < source z 2 ∧ source z 2 < 1 := ⟨h0,h1⟩
  rw [inverseSource, dif_pos h]
  have hfirst : source z 1 / source z 2 = firstIntegral (z 2) (z 0) := by
    simp [source, first, h0.ne']
  have hsecond : (source z 1 + source z 0) / source z 2 = firstIntegral (z 2) (z 1) := by
    simp [source, first]
    field_simp [h0.ne']
    ring
  rw [hfirst,hsecond]
  change ![amplitude (z 2) h0 h1 (firstIntegral (z 2) (z 0)),
    amplitude (z 2) h0 h1 (firstIntegral (z 2) (z 1)), z 2] = z
  simp only [amplitude_integral]
  ext i
  fin_cases i <;> rfl

theorem inverse_source_modulus (y : V3) (h0 : 0 < y 2) (h1 : y 2 < 1) :
    inverseSource y 2 = y 2 := by
  simp [inverseSource, h0, h1]

theorem source_inverse (y : V3) (h0 : 0 < y 2) (h1 : y 2 < 1) :
    source (inverseSource y) = y := by
  rw [inverseSource, dif_pos ⟨h0,h1⟩]
  ext i
  fin_cases i <;> simp [source, first, integral_amplitude] <;> field_simp [h0.ne']
  ring

theorem inverse_source_strict_at_image (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    HasStrictFDerivAt inverseSource (dInverse z) (source z) := by
  have hs : HasStrictFDerivAt source (sourceEquiv z h0 h1 : V3 →L[ℝ] V3) z :=
    source_strict z h0 h1
  apply hs.to_local_left_inverse
  have hn : ∀ᶠ v : V3 in 𝓝 z, v 2 ∈ Ioo (0 : ℝ) 1 :=
    (continuous_apply 2).continuousAt (Ioo_mem_nhds h0 h1)
  filter_upwards [hn] with v hv
  exact inverse_source v hv.1 hv.2

theorem inverse_source_strict (y : V3) (h0 : 0 < y 2) (h1 : y 2 < 1) :
    HasStrictFDerivAt inverseSource (dInverse (inverseSource y)) y := by
  have hm := inverse_source_modulus y h0 h1
  have h := inverse_source_strict_at_image (inverseSource y)
    (by rw [hm]; exact h0) (by rw [hm]; exact h1)
  simpa only [source_inverse y h0 h1] using h

/-- The endpoint in original source order (time, rectified initial phase, modulus). -/
def rectifiedEndpoint (sigma : ℝ) (y : V3) : V3 := endpoint sigma (inverseSource y)

theorem rectified_eq_concrete (sigma : ℝ) (y : V3) (h0 : 0 < y 2) (h1 : y 2 < 1) :
    let J := full (y 2) h0 h1
    rectifiedEndpoint sigma y =
      ![J.endpointX sigma (y 1/y 2) (y 0), J.endpointY sigma (y 1/y 2) (y 0),
        J.endpointTheta (y 1/y 2) (y 0)] := by
  dsimp only
  unfold rectifiedEndpoint
  rw [inverseSource, dif_pos ⟨h0,h1⟩, endpoint_eq_concrete sigma _ _ _ h0 h1]
  simp only [integral_amplitude]
  have ht : y 2 * ((y 1+y 0)/y 2-y 1/y 2) = y 0 := by
    field_simp [h0.ne']
    ring
  rw [ht]

theorem rectified_deriv (sigma : ℝ) (y : V3) (h0 : 0 < y 2) (h1 : y 2 < 1) :
    HasFDerivAt (rectifiedEndpoint sigma)
      ((dEndpoint sigma (inverseSource y)).comp (dInverse (inverseSource y))) y := by
  have hm := inverse_source_modulus y h0 h1
  exact (endpoint_deriv sigma (inverseSource y)
    (by rw [hm]; exact h0) (by rw [hm]; exact h1)).comp y
      (inverse_source_strict y h0 h1).hasFDerivAt

/-- Coordinate matrix of a continuous linear endomorphism. -/
def linearMatrix (L : V3 →L[ℝ] V3) : Matrix (Fin 3) (Fin 3) ℝ :=
  LinearMap.toMatrix' L.toLinearMap

theorem linearMatrix_comp (L M : V3 →L[ℝ] V3) :
    linearMatrix (L.comp M) = linearMatrix L * linearMatrix M :=
  LinearMap.toMatrix'_comp L.toLinearMap M.toLinearMap

theorem linearMatrix_id : linearMatrix (ContinuousLinearMap.id ℝ V3) = 1 :=
  LinearMap.toMatrix'_id

theorem jacobian_eq_linearMatrix (f : V3 → V3) (z : V3) :
    jacobian f z = linearMatrix (fderiv ℝ f z) := rfl

theorem rectified_jacobian_comp (sigma : ℝ) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    jacobian (rectifiedEndpoint sigma) (source z) * jacobian source z =
      jacobian (endpoint sigma) z := by
  rw [jacobian_eq_linearMatrix, jacobian_eq_linearMatrix, jacobian_eq_linearMatrix,
    (rectified_deriv sigma (source z) h0 h1).fderiv, inverse_source z h0 h1,
    (source_strict z h0 h1).hasFDerivAt.fderiv, (endpoint_deriv sigma z h0 h1).fderiv,
    ← linearMatrix_comp]
  congr 1
  ext v
  simp [inverse_linear_left z v h0 h1]

/-- Actual original-coordinate determinant, obtained by derivative transport. -/
theorem rectified_det_at_source (sigma : ℝ) (hsigma : sigma^2=1) (z : V3)
    (h0 : 0 < z 2) (h1 : z 2 < 1) :
    (jacobian (rectifiedEndpoint sigma) (source z)).det = z 2/(1-(z 2)^2)*bPolynomial z := by
  have h := congrArg Matrix.det (rectified_jacobian_comp sigma z h0 h1)
  rw [Matrix.det_mul] at h
  have he : (jacobian (rectifiedEndpoint sigma) (source z)).det =
      (jacobian (endpoint sigma) z).det / (jacobian source z).det :=
    (eq_div_iff (source_det_ne_zero z h0 h1)).mpr h
  rw [he, determinant_quotient sigma hsigma z h0 h1]

theorem rectified_det (sigma : ℝ) (hsigma : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    (jacobian (rectifiedEndpoint sigma) y).det = y 2/(1-(y 2)^2)*bPolynomial (inverseSource y) := by
  have hm := inverse_source_modulus y h0 h1
  have h := rectified_det_at_source sigma hsigma (inverseSource y)
    (by rw [hm]; exact h0) (by rw [hm]; exact h1)
  simpa only [source_inverse y h0 h1, hm] using h

theorem rectified_det_zero_iff (sigma : ℝ) (hsigma : sigma^2=1) (y : V3)
    (h0 : 0 < y 2) (h1 : y 2 < 1) :
    (jacobian (rectifiedEndpoint sigma) y).det = 0 ↔ bPolynomial (inverseSource y)=0 := by
  rw [rectified_det sigma hsigma y h0 h1]
  exact mul_eq_zero_iff_left (div_ne_zero h0.ne' (by nlinarith [h0,h1]))

end AmplitudeChart
end JacobiConcrete
