import SE2Conjugate.ZerosF1

/-!
# The full elliptic data

`JacobiFull` adds to `JacobiPeriodic` the inverse phase lift `Finv r = F(arcsin √r, k)` and the
characterisation of `sn² x = sn² y`.  This file also fixes `p₀ = p₁¹`, the first Maxwell time,
and the two facts about `α₁` (continuity, zeros by sign change) shared by the bracket files.
The first cell itself is the left bracket of cell `0` (`BeforeFirst.lean`).
-/

noncomputable section

structure JacobiFull extends JacobiPeriodic where
  Finv : ℝ → ℝ
  Finv_deriv : ∀ r ∈ Set.Ioo (0 : ℝ) 1,
    HasDerivAt Finv (1 / (2 * Real.sqrt (r * (1 - r) * (1 - k ^ 2 * r)))) r
  Finv_cont : ContinuousOn Finv (Set.Icc 0 1)
  Finv_zero : Finv 0 = 0
  Finv_one : Finv 1 = K
  Finv_spec : ∀ r ∈ Set.Icc (0 : ℝ) 1, s (Finv r) ^ 2 = r
  sn_sq_eq_iff : ∀ x y : ℝ, s x ^ 2 = s y ^ 2 ↔ ∃ n : ℤ, x = y + 2 * K * n ∨ x = -y + 2 * K * n

namespace JacobiFull

variable (J : JacobiFull)

/-- `p₀ = p₁¹`, the first Maxwell time. -/
def p0 : ℝ := J.toJacobiPeriodic.pM 0

theorem p0_mem : J.p0 ∈ Set.Ioo J.K (2 * J.K) := by
  have h := (J.toJacobiPeriodic.pM_spec 0).1
  unfold p0
  simpa using h

theorem f1_p0 : J.toJacobiData.f1 J.p0 = 0 := (J.toJacobiPeriodic.pM_spec 0).2

theorem p0_pos : 0 < J.p0 := by linarith [J.p0_mem.1, J.K_pos]

/-- `sn > 0` on `(0, 2K)`. -/
theorem s_pos_first {p : ℝ} (hp : p ∈ Set.Ioo 0 (2 * J.K)) : 0 < J.s p := by
  have h := J.s_sign 0 p (by simpa using hp)
  simpa using h

theorem continuous_α1 : Continuous J.toJacobiData.α1 :=
  continuous_iff_continuousAt.mpr (fun p => (J.toJacobiData.hasDerivAt_α1 p).continuousAt)

/-- A sign change of `(-1)^m α₁` on `[a, b]` locates a zero of `α₁`. -/
theorem exists_α1_zero (m : ℕ) {a b : ℝ} (hab : a ≤ b)
    (h : ((-1) ^ m * J.toJacobiData.α1 a) * ((-1) ^ m * J.toJacobiData.α1 b) ≤ 0) :
    ∃ z ∈ Set.Icc a b, J.toJacobiData.α1 z = 0 := by
  set g := fun p => (-1) ^ m * J.toJacobiData.α1 p with hg
  have hcont : ContinuousOn g (Set.Icc a b) := (continuous_const.mul J.continuous_α1).continuousOn
  have hzero : ∀ z, g z = 0 → J.toJacobiData.α1 z = 0 := fun z hz => by
    rcases mul_eq_zero.mp hz with h | h
    · exact absurd h (pow_ne_zero m (by norm_num))
    · exact h
  rcases lt_or_ge (g a) 0 with ha | ha
  · have hb : 0 ≤ g b := by
      by_contra hb; rw [not_le] at hb
      have := mul_pos_of_neg_of_neg ha hb; simp only [hg] at this; linarith
    obtain ⟨z, hz, hz0⟩ := intermediate_value_Icc hab hcont ⟨ha.le, hb⟩
    exact ⟨z, hz, hzero z hz0⟩
  · rcases eq_or_lt_of_le ha with ha0 | ha0
    · exact ⟨a, Set.left_mem_Icc.mpr hab, hzero a ha0.symm⟩
    · have hb : g b ≤ 0 := by
        by_contra hb; rw [not_le] at hb
        have := mul_pos ha0 hb; simp only [hg] at this; linarith
      obtain ⟨z, hz, hz0⟩ := intermediate_value_Icc' hab hcont ⟨hb, ha⟩
      exact ⟨z, hz, hzero z hz0⟩

end JacobiFull

end
