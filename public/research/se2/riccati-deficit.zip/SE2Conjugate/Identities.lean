import SE2Conjugate.Jacobi

/-!
# Lemma 3.1 (Identities), parts (i)–(iii)

(i) the coefficient collapse `β = X - ℓ`, `α = (1 - k²) X`, `α - β = ℓ - k² X`;
(ii) the three monotone quotients `(f₁/cn)' = -dn²/cn²`, `(β₁/cn)' = -(1-k²) sn²/cn²`,
`(α₁/dn)' = -ℰ f₁/dn²`;
(iii) `Γ' = (1-k²)/dn²` and `β₁' = -sn dn Γ`.
-/

namespace JacobiData

variable (J : JacobiData)

/-! ### (i) Coefficient collapse -/

theorem collapse_beta (p : ℝ) : J.β p = J.X p - J.ell p := by
  unfold β X ell f1 β1 α1 q
  linear_combination (-(J.eps p) * (-(J.eps p) + p)) * J.sc p

theorem collapse_alpha (p : ℝ) : J.α p = (1 - J.k ^ 2) * J.X p := by
  unfold α X
  ring

theorem collapse_diff (p : ℝ) : J.α p - J.β p = J.ell p - J.k ^ 2 * J.X p := by
  unfold α β X ell f1 β1 α1 q
  linear_combination (J.eps p * (-(J.eps p) + p)) * J.sc p

/-! ### (ii) The three monotone quotients -/

theorem hasDerivAt_f1_div_c (p : ℝ) (hc : J.c p ≠ 0) :
    HasDerivAt (fun y => J.f1 y / J.c y) (-(J.d p ^ 2) / J.c p ^ 2) p := by
  have h := (J.hasDerivAt_f1 p).div (J.hc p) hc
  refine h.congr_deriv ?_
  rw [div_left_inj' (pow_ne_zero 2 hc)]
  unfold f1 q
  linear_combination (-(J.d p ^ 2)) * J.sc p

theorem hasDerivAt_β1_div_c (p : ℝ) (hc : J.c p ≠ 0) :
    HasDerivAt (fun y => J.β1 y / J.c y) (-((1 - J.k ^ 2) * J.s p ^ 2) / J.c p ^ 2) p := by
  have h := (J.hasDerivAt_β1 p).div (J.hc p) hc
  refine h.congr_deriv ?_
  rw [div_left_inj' (pow_ne_zero 2 hc)]
  unfold β1
  linear_combination (J.k ^ 2 * J.s p ^ 2) * J.sc p + (-(J.s p ^ 2)) * J.sd p

theorem hasDerivAt_α1_div_d (p : ℝ) (hd : J.d p ≠ 0) :
    HasDerivAt (fun y => J.α1 y / J.d y) (-(J.eps p * J.f1 p) / J.d p ^ 2) p := by
  have h := (J.hasDerivAt_α1 p).div (J.hd p) hd
  refine h.congr_deriv ?_
  rw [div_left_inj' (pow_ne_zero 2 hd)]
  unfold f1 α1
  linear_combination (-(J.c p * (J.d p ^ 2 + J.eps p ^ 2 - J.eps p * p))) * J.sd p

/-! ### (iii) `Γ` -/

theorem hasDerivAt_Γ (p : ℝ) (hd : J.d p ≠ 0) :
    HasDerivAt J.Γ ((1 - J.k ^ 2) / J.d p ^ 2) p := by
  have h := (J.heps p).sub ((((J.hs p).mul (J.hc p)).const_mul (J.k ^ 2)).div (J.hd p) hd)
  unfold Γ
  refine h.congr_deriv ?_
  have hd2 : J.d p ^ 2 ≠ 0 := pow_ne_zero 2 hd
  rw [eq_div_iff hd2, sub_mul, div_mul_cancel₀ _ hd2]
  simp only [Pi.mul_apply]
  linear_combination (-(J.k ^ 2 * (J.d p ^ 2 + J.k ^ 2 * J.s p ^ 2))) * J.sc p + (J.d p ^ 2 + J.k ^ 2 * J.s p ^ 2 - J.k ^ 2 + 1) * J.sd p

theorem β1_deriv_eq_Γ (p : ℝ) (hd : J.d p ≠ 0) :
    -(J.s p * J.d p * J.eps p) + J.k ^ 2 * J.s p ^ 2 * J.c p = -(J.s p * J.d p * J.Γ p) := by
  unfold Γ
  field_simp
  ring

end JacobiData
