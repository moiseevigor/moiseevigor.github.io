import SE2Conjugate.Riccati
import SE2Conjugate.Crossing

/-!
# Signed brackets: Theorem 3.4 and Theorem 4.1 on one bracket of either type

`SBracket` generalizes `BracketData`: a sign `σ = ±1` (the common sign of `f₁`, `-β₁`) and an
orientation `ε = ±1` (`ε = 1`: `r` runs from `0` to `1`, the left type; `ε = -1`: from `1` to `0`,
the right type).  On the open bracket `σ f₁ > 0`, `σ β₁ < 0`, `ε σ sn > 0`, `ε σ α₁ > 0`; at the
end where `r = 0` the function `f₁` vanishes, at the end where `r = 1` the function `X = sn α₁`
vanishes.  The oriented lift `ũ = ε u + (1-ε) K/2` runs from `0` to `K` and satisfies
`ũ' = ε u' ≥ 1`, and the crossing principle applies to it.
-/

noncomputable section

structure SBracket extends JacobiData where
  K : ℝ
  K_pos : 0 < K
  p0 : ℝ
  p1 : ℝ
  p0_lt_p1 : p0 < p1
  σ : ℝ
  hσ : σ = 1 ∨ σ = -1
  ε : ℝ
  hε : ε = 1 ∨ ε = -1
  d_pos : ∀ p, 0 < d p
  eps_pos : ∀ p ∈ Set.Icc p0 p1, 0 < eps p
  q_pos : ∀ p ∈ Set.Icc p0 p1, 0 < p - eps p
  f1_sign : ∀ p ∈ Set.Ioo p0 p1, 0 < σ * (c p * (eps p - p) - d p * s p)
  β1_sign : ∀ p ∈ Set.Ioo p0 p1, σ * (c p * eps p - d p * s p) < 0
  s_sign : ∀ p ∈ Set.Ioo p0 p1, 0 < ε * σ * s p
  α1_sign : ∀ p ∈ Set.Ioo p0 p1,
    0 < ε * σ * (c p * d p * (p - 2 * eps p) + s p * (d p ^ 2 + eps p * (p - eps p)))
  β_lo : ε = 1 → (c p0 * (eps p0 - p0) - d p0 * s p0) * (c p0 * eps p0 - d p0 * s p0) = 0
  X_lo : ε = -1 → s p0 * (c p0 * d p0 * (p0 - 2 * eps p0) + s p0 * (d p0 ^ 2 + eps p0 * (p0 - eps p0))) = 0
  X_hi : ε = 1 → s p1 * (c p1 * d p1 * (p1 - 2 * eps p1) + s p1 * (d p1 ^ 2 + eps p1 * (p1 - eps p1))) = 0
  β_hi : ε = -1 → (c p1 * (eps p1 - p1) - d p1 * s p1) * (c p1 * eps p1 - d p1 * s p1) = 0
  Finv : ℝ → ℝ
  Finv_deriv : ∀ r ∈ Set.Ioo (0 : ℝ) 1,
    HasDerivAt Finv (1 / (2 * Real.sqrt (r * (1 - r) * (1 - k ^ 2 * r)))) r
  Finv_cont : ContinuousOn Finv (Set.Icc 0 1)
  Finv_zero : Finv 0 = 0
  Finv_one : Finv 1 = K
  Finv_spec : ∀ r ∈ Set.Icc (0 : ℝ) 1, s (Finv r) ^ 2 = r
  sn_sq_eq_iff : ∀ x y : ℝ, s x ^ 2 = s y ^ 2 ↔ ∃ n : ℤ, x = y + 2 * K * n ∨ x = -y + 2 * K * n

namespace SBracket

variable (B : SBracket)

def r (p : ℝ) : ℝ := B.toJacobiData.z p / B.toJacobiData.Dz p
def u (p : ℝ) : ℝ := B.Finv (B.r p)
/-- The oriented lift, from `0` to `K` for either orientation. -/
def uu (p : ℝ) : ℝ := B.ε * B.u p + (1 - B.ε) * B.K / 2

theorem q_eq (p : ℝ) : B.toJacobiData.q p = p - B.eps p := rfl
theorem f1_eq (p : ℝ) : B.toJacobiData.f1 p = B.c p * (B.eps p - p) - B.d p * B.s p := rfl
theorem β1_eq (p : ℝ) : B.toJacobiData.β1 p = B.c p * B.eps p - B.d p * B.s p := rfl
theorem α1_eq (p : ℝ) : B.toJacobiData.α1 p
    = B.c p * B.d p * (p - 2 * B.eps p) + B.s p * (B.d p ^ 2 + B.eps p * (p - B.eps p)) := rfl

theorem σ_sq : B.σ ^ 2 = 1 := by rcases B.hσ with h | h <;> rw [h] <;> norm_num
theorem ε_sq : B.ε ^ 2 = 1 := by rcases B.hε with h | h <;> rw [h] <;> norm_num
theorem σ_ne : B.σ ≠ 0 := by rcases B.hσ with h | h <;> rw [h] <;> norm_num
theorem ε_ne : B.ε ≠ 0 := by rcases B.hε with h | h <;> rw [h] <;> norm_num

theorem Icc_mem_p0 : B.p0 ∈ Set.Icc B.p0 B.p1 := Set.left_mem_Icc.mpr B.p0_lt_p1.le
theorem Icc_mem_p1 : B.p1 ∈ Set.Icc B.p0 B.p1 := Set.right_mem_Icc.mpr B.p0_lt_p1.le

theorem s_ne {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : B.s p ≠ 0 := by
  intro h
  have := B.s_sign p hp
  rw [h, mul_zero] at this
  exact lt_irrefl _ this

/-- `σ a > 0` on the open bracket. -/
theorem σa_pos {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : 0 < B.σ * B.toJacobiData.a p := by
  unfold JacobiData.a
  rw [B.f1_eq, B.q_eq, mul_div_assoc']
  exact div_pos (B.f1_sign p hp) (B.q_pos p (Set.Ioo_subset_Icc_self hp))

/-- `σ b > 0` on the open bracket. -/
theorem σb_pos {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : 0 < B.σ * B.toJacobiData.b p := by
  unfold JacobiData.b
  rw [B.β1_eq]
  have h1 := B.β1_sign p hp
  have h2 := B.eps_pos p (Set.Ioo_subset_Icc_self hp)
  rw [mul_div_assoc']
  exact div_pos (by linarith) h2

theorem ab_pos {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : 0 < B.toJacobiData.a p * B.toJacobiData.b p := by
  have h := mul_pos (B.σa_pos hp) (B.σb_pos hp)
  have : B.σ * B.toJacobiData.a p * (B.σ * B.toJacobiData.b p)
      = B.σ ^ 2 * (B.toJacobiData.a p * B.toJacobiData.b p) := by ring
  rw [this, B.σ_sq, one_mul] at h
  exact h

theorem z_pos {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : 0 < B.toJacobiData.z p := B.ab_pos hp

theorem X_pos {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : 0 < B.toJacobiData.X p := by
  have h := mul_pos (B.s_sign p hp) (B.α1_sign p hp)
  unfold JacobiData.X
  rw [B.α1_eq]
  have : B.ε * B.σ * B.s p * (B.ε * B.σ *
      (B.c p * B.d p * (p - 2 * B.eps p) + B.s p * (B.d p ^ 2 + B.eps p * (p - B.eps p))))
      = B.ε ^ 2 * B.σ ^ 2 * (B.s p *
      (B.c p * B.d p * (p - 2 * B.eps p) + B.s p * (B.d p ^ 2 + B.eps p * (p - B.eps p)))) := by
    ring
  rw [this, B.ε_sq, B.σ_sq, one_mul, one_mul] at h
  exact h

theorem ell_pos_Icc {p : ℝ} (hp : p ∈ Set.Icc B.p0 B.p1) : 0 < B.toJacobiData.ell p := by
  unfold JacobiData.ell
  rw [B.q_eq]
  exact mul_pos (B.eps_pos p hp) (B.q_pos p hp)

theorem z_lt_one {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : B.toJacobiData.z p < 1 := by
  have hq : B.toJacobiData.q p ≠ 0 := by rw [B.q_eq]; exact (B.q_pos p (Set.Ioo_subset_Icc_self hp)).ne'
  have he : B.eps p ≠ 0 := (B.eps_pos p (Set.Ioo_subset_Icc_self hp)).ne'
  rw [B.toJacobiData.z_eq_neg_beta_div_ell p hq he, B.toJacobiData.collapse_beta p]
  have hℓ := B.ell_pos_Icc (Set.Ioo_subset_Icc_self hp)
  have hX := B.X_pos hp
  rw [div_lt_one hℓ]
  linarith

theorem Dz_pos' {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : 0 < B.toJacobiData.Dz p :=
  B.toJacobiData.Dz_pos p (B.z_pos hp).le

theorem r_pos {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : 0 < B.r p :=
  div_pos (B.z_pos hp) (B.Dz_pos' hp)

theorem r_lt_one {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : B.r p < 1 := by
  unfold r
  rw [div_lt_one (B.Dz_pos' hp)]
  unfold JacobiData.Dz
  have hz := B.z_lt_one hp
  have hk : 0 < 1 - B.k ^ 2 := by nlinarith [B.k_pos, B.k_lt_one]
  nlinarith

theorem one_sub_k2_r {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) :
    1 - B.k ^ 2 * B.r p = (1 - B.k ^ 2) / B.toJacobiData.Dz p := by
  have hD := (B.Dz_pos' hp).ne'
  unfold r
  field_simp
  unfold JacobiData.Dz
  ring

theorem one_sub_r {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) :
    1 - B.r p = (1 - B.k ^ 2) * (1 - B.toJacobiData.z p) / B.toJacobiData.Dz p := by
  have hD := (B.Dz_pos' hp).ne'
  unfold r
  field_simp
  unfold JacobiData.Dz
  ring

theorem radicand_eq {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) :
    B.r p * (1 - B.r p) * (1 - B.k ^ 2 * B.r p)
      = ((1 - B.k ^ 2) / B.toJacobiData.Dz p ^ 2) ^ 2
        * (B.toJacobiData.z p * (1 - B.toJacobiData.z p) * B.toJacobiData.Dz p) := by
  rw [B.one_sub_r hp, B.one_sub_k2_r hp]
  have hD := (B.Dz_pos' hp).ne'
  unfold r
  field_simp

theorem hasDerivAt_Dz (p : ℝ) (hq : B.toJacobiData.q p ≠ 0) (he : B.eps p ≠ 0)
    (hs : B.s p ≠ 0) (hd : B.d p ≠ 0) :
    HasDerivAt B.toJacobiData.Dz
      (B.k ^ 2 * ((B.toJacobiData.T1 p + B.toJacobiData.T2 p) / (B.d p * B.s p))) p := by
  have h := ((B.toJacobiData.hasDerivAt_z p hq he hs hd).const_mul (B.k ^ 2)).const_add
    (1 - B.k ^ 2)
  unfold JacobiData.Dz
  exact h

/-- `z'` on the open bracket, abbreviated. -/
def zp (p : ℝ) : ℝ := (B.toJacobiData.T1 p + B.toJacobiData.T2 p) / (B.d p * B.s p)

theorem hasDerivAt_r {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) :
    HasDerivAt B.r ((1 - B.k ^ 2) * B.zp p / B.toJacobiData.Dz p ^ 2) p := by
  have hq : B.toJacobiData.q p ≠ 0 := by
    rw [B.q_eq]; exact (B.q_pos p (Set.Ioo_subset_Icc_self hp)).ne'
  have he : B.eps p ≠ 0 := (B.eps_pos p (Set.Ioo_subset_Icc_self hp)).ne'
  have hs : B.s p ≠ 0 := B.s_ne hp
  have hd : B.d p ≠ 0 := (B.d_pos p).ne'
  have hD : B.toJacobiData.Dz p ≠ 0 := (B.Dz_pos' hp).ne'
  have h := (B.toJacobiData.hasDerivAt_z p hq he hs hd).div (B.hasDerivAt_Dz p hq he hs hd) hD
  unfold r
  refine h.congr_deriv ?_
  unfold zp JacobiData.Dz
  field_simp
  ring

/-- `u' = z' / (2 √(z (1-z) 𝖣))`. -/
theorem hasDerivAt_u {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) :
    HasDerivAt B.u
      (B.zp p / (2 * Real.sqrt (B.toJacobiData.z p * (1 - B.toJacobiData.z p) * B.toJacobiData.Dz p)))
      p := by
  have hr : B.r p ∈ Set.Ioo (0 : ℝ) 1 := ⟨B.r_pos hp, B.r_lt_one hp⟩
  have h := (B.Finv_deriv (B.r p) hr).comp p (B.hasDerivAt_r hp)
  unfold u
  refine h.congr_deriv ?_
  have hD := B.Dz_pos' hp
  have hk : 0 < 1 - B.k ^ 2 := by nlinarith [B.k_pos, B.k_lt_one]
  have hfac : 0 ≤ (1 - B.k ^ 2) / B.toJacobiData.Dz p ^ 2 := by positivity
  rw [B.radicand_eq hp, Real.sqrt_mul (sq_nonneg _), Real.sqrt_sq hfac]
  have hsq : 0 < Real.sqrt (B.toJacobiData.z p * (1 - B.toJacobiData.z p) * B.toJacobiData.Dz p) := by
    apply Real.sqrt_pos.mpr
    have := B.z_pos hp
    have := B.z_lt_one hp
    positivity
  field_simp

/-- The sign of `z'` is `ε`: `ε z' > 0`. -/
theorem ε_zp_pos {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) : 0 < B.ε * B.zp p := by
  have hz1 := B.z_lt_one hp
  have hd := B.d_pos p
  have hs := B.s_ne hp
  have hab := B.ab_pos hp
  have hD := B.Dz_pos' hp
  have hs2 : 0 < B.s p ^ 2 := by positivity
  have key : B.ε * B.zp p
      = (B.ε * B.s p) * (B.toJacobiData.T1 p + B.toJacobiData.T2 p) / (B.d p * B.s p ^ 2) := by
    unfold zp
    field_simp
  rw [key]
  apply div_pos _ (by positivity)
  rcases B.toJacobiData.T1_T2_same_sign p hab hz1 hd hs with ⟨ha, _, h1, _⟩ | ⟨ha, _, h1, _⟩
  · have hσ : B.σ = 1 := by
      rcases B.hσ with h | h
      · exact h
      · exfalso; have := B.σa_pos hp; rw [h] at this; linarith
    have hεs : 0 < B.ε * B.s p := by
      have := B.s_sign p hp; rw [hσ, mul_one] at this; exact this
    have hT2 : 0 < B.toJacobiData.T2 p := by unfold JacobiData.T2; positivity
    exact mul_pos hεs (by linarith)
  · have hσ : B.σ = -1 := by
      rcases B.hσ with h | h
      · exfalso; have := B.σa_pos hp; rw [h] at this; linarith
      · exact h
    have hεs : B.ε * B.s p < 0 := by
      have := B.s_sign p hp; rw [hσ] at this; linarith
    have hT2 : B.toJacobiData.T2 p < 0 := by
      unfold JacobiData.T2; nlinarith [mul_pos hs2 hD]
    exact mul_pos_of_neg_of_neg hεs (by linarith)

/-- The oriented slope bound: `ε u' ≥ 1`. -/
theorem one_le_ε_deriv_u {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1) :
    1 ≤ B.ε * (B.zp p / (2 * Real.sqrt (B.toJacobiData.z p * (1 - B.toJacobiData.z p)
      * B.toJacobiData.Dz p))) := by
  have hsq : 0 < Real.sqrt (B.toJacobiData.z p * (1 - B.toJacobiData.z p) * B.toJacobiData.Dz p) := by
    apply Real.sqrt_pos.mpr
    have := B.z_pos hp
    have := B.z_lt_one hp
    have := B.Dz_pos' hp
    positivity
  have hbound := B.toJacobiData.slope_bound_abs p (B.ab_pos hp) (B.z_lt_one hp) (B.d_pos p) (B.s_ne hp)
  have hεz := B.ε_zp_pos hp
  have habs : |B.zp p| = B.ε * B.zp p := by
    rcases B.hε with h | h
    · rw [h, one_mul]; exact abs_of_pos (by rw [h, one_mul] at hεz; exact hεz)
    · rw [h] at hεz ⊢; rw [abs_of_neg (by linarith)]; ring
  rw [← mul_div_assoc, ← habs, le_div_iff₀ (by linarith), one_mul]
  exact hbound

end SBracket

end
