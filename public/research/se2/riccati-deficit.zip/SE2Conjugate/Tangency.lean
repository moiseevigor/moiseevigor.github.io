import SE2Conjugate.SignedBracket

/-!
# Non-flat equality in the Riccati slope bound

The AM-GM equality expression `H = T1 - T2` has a nonzero derivative at each
interior zero with `z > 0` and nonzero `q`, `sn`, `dn`. This follows from the
Jacobi ODE and its first integrals, without real analyticity or a finiteness
hypothesis. Consequently its equality set contains no open interval inside
a signed bracket. `SignedTime` uses this to prove strict phase monotonicity
and the counting results without an extra tangency-finiteness assumption.

The critical bracket endpoint has `sn = 0` and is outside this argument.
Scalar root multiplicity is derived in the manuscript, not formalized here.
-/

noncomputable section
namespace JacobiData
variable (J : JacobiData)

/-- Difference of the two same-sign AM-GM terms. -/
def H (p : ℝ) : ℝ := J.T1 p - J.T2 p

/-- The factor controlling the derivative at an equality point. -/
def V (p : ℝ) : ℝ := J.c p * J.Dz p + J.b p * J.d p ^ 2

/-- Polynomial derivative numerator divided by `dn sn`. -/
def Hp (p : ℝ) : ℝ :=
  ((2 * J.a p * J.k ^ 2 * J.s p ^ 2 - 2 * J.b p * J.d p ^ 2
      - 2 * J.c p * J.k ^ 2 * J.s p ^ 2 - J.c p) * J.H p
    - 4 * J.a p * J.s p ^ 2 * J.V p) / (J.d p * J.s p)

theorem hasDerivAt_H (p : ℝ) (hq : J.q p ≠ 0) (he : J.eps p ≠ 0)
    (hs : J.s p ≠ 0) (hd : J.d p ≠ 0) : HasDerivAt J.H (J.Hp p) p := by
  have ha := J.hasDerivAt_a p hq hs hd
  have hb := J.hasDerivAt_b p he hs hd
  rw [J.a_deriv_form p hq hs hd] at ha
  rw [J.b_deriv_form p he hs hd] at hb
  have hz := J.hasDerivAt_z p hq he hs hd
  have hD := (hz.const_mul (J.k ^ 2)).const_add (1 - J.k ^ 2)
  have h := (((J.hd p).pow 2).mul hb |>.mul ((hasDerivAt_const p (1 : ℝ)).sub hz)).sub
    ((((J.hs p).pow 2).mul ha).mul hD)
  change HasDerivAt J.H _ p at h
  refine h.congr_deriv ?_
  unfold Hp H V T1 T2 Dz z
  simp only [Pi.mul_apply, Pi.pow_apply, Pi.sub_apply]
  norm_num
  field_simp [hd, hs]
  linear_combination
    (-2 * J.a p * J.c p * J.s p ^ 2 * (1 - J.k ^ 2 + J.k ^ 2 * J.a p * J.b p)) * J.sd p

/-- Equality of the AM-GM terms cannot also make its derivative vanish. -/
theorem V_ne_of_H_zero (p : ℝ) (hq : J.q p ≠ 0) (hs : J.s p ≠ 0)
    (hd : J.d p ≠ 0) (hz : 0 < J.z p) (hH : J.H p = 0) : J.V p ≠ 0 := by
  intro hv
  have hD := J.Dz_pos p hz.le
  have hA0 : J.Dz p * (J.c p * (1 - J.z p) + J.s p ^ 2 * J.a p) = 0 := by
    unfold H T1 T2 at hH
    unfold V at hv
    linear_combination -hH + (1 - J.z p) * hv
  have hA : J.c p * (1 - J.z p) + J.s p ^ 2 * J.a p = 0 :=
    (mul_eq_zero.mp hA0).resolve_left hD.ne'
  have hB : J.s p ^ 2 * J.d p ^ 2 * J.z p
      - J.c p ^ 2 * J.Dz p * (1 - J.z p) = 0 := by
    unfold V at hv
    unfold z at hA ⊢
    linear_combination (J.b p * J.d p ^ 2) * hA - (J.c p * (1 - J.a p * J.b p)) * hv
  have hP : (J.z p - J.c p ^ 2) *
      (1 - J.k ^ 2 + J.k ^ 2 * J.c p ^ 2 * J.z p) = 0 := by
    unfold Dz at hB
    linear_combination hB - (J.s p ^ 2 * J.z p) * J.sd p
      + (J.z p * (-J.c p ^ 2 * J.k ^ 2 + J.k ^ 2 * J.s p ^ 2 + J.k ^ 2 - 1)) * J.sc p
  have hk : 0 < 1 - J.k ^ 2 := by nlinarith [J.k_pos, J.k_lt_one]
  have hfac : 0 < 1 - J.k ^ 2 + J.k ^ 2 * J.c p ^ 2 * J.z p := by positivity
  have hzc : J.z p = J.c p ^ 2 := by
    have := (mul_eq_zero.mp hP).resolve_right hfac.ne'
    linarith
  rw [hzc] at hA
  have hsum : J.s p ^ 2 * (J.a p + J.c p) = 0 := by
    linear_combination hA + (J.c p) * J.sc p
  have hac : J.a p + J.c p = 0 := (mul_eq_zero.mp hsum).resolve_left (pow_ne_zero 2 hs)
  have hrel : (J.a p + J.c p) * J.q p = -J.d p * J.s p := by
    unfold a
    field_simp [hq]
    unfold f1 q
    ring
  rw [hac, zero_mul] at hrel
  exact (mul_ne_zero (neg_ne_zero.mpr hd) hs) hrel.symm

theorem Hp_ne_of_H_zero (p : ℝ) (hq : J.q p ≠ 0)
    (hs : J.s p ≠ 0) (hd : J.d p ≠ 0) (hz : 0 < J.z p) (hH : J.H p = 0) : J.Hp p ≠ 0 := by
  have ha : J.a p ≠ 0 := by
    intro ha
    unfold z at hz
    rw [ha, zero_mul] at hz
    exact lt_irrefl _ hz
  have hv := J.V_ne_of_H_zero p hq hs hd hz hH
  unfold Hp
  rw [hH, mul_zero, zero_sub]
  exact div_ne_zero (neg_ne_zero.mpr (mul_ne_zero (mul_ne_zero (mul_ne_zero (by norm_num) ha)
    (pow_ne_zero 2 hs)) hv)) (mul_ne_zero hd hs)
end JacobiData

namespace SBracket
variable (B : SBracket)

theorem H_zero_of_unit_slope {p : ℝ} (hp : p ∈ Set.Ioo B.p0 B.p1)
    (hunit : B.ε * (B.zp p / (2 * Real.sqrt (B.toJacobiData.z p *
      (1 - B.toJacobiData.z p) * B.toJacobiData.Dz p))) = 1) : B.toJacobiData.H p = 0 := by
  have hs := B.s_ne hp
  have hd := (B.d_pos p).ne'
  have hrad : 0 ≤ B.toJacobiData.z p * (1 - B.toJacobiData.z p) * B.toJacobiData.Dz p := by
    have := B.z_pos hp
    have := B.z_lt_one hp
    have := B.Dz_pos' hp
    positivity
  have hsq := Real.sq_sqrt hrad
  have hroot : Real.sqrt (B.toJacobiData.z p * (1 - B.toJacobiData.z p) *
      B.toJacobiData.Dz p) ≠ 0 := by
    apply ne_of_gt
    apply Real.sqrt_pos.mpr
    have := B.z_pos hp
    have := B.z_lt_one hp
    have := B.Dz_pos' hp
    positivity
  unfold zp at hunit
  field_simp [hs, hd, hroot] at hunit
  have hnorm : (B.toJacobiData.T1 p + B.toJacobiData.T2 p) ^ 2 =
      4 * (B.d p * B.s p) ^ 2 * (B.toJacobiData.z p *
      (1 - B.toJacobiData.z p) * B.toJacobiData.Dz p) := by
    calc
      _ = (B.ε * (B.toJacobiData.T1 p + B.toJacobiData.T2 p)) ^ 2 := by rw [mul_pow, B.ε_sq, one_mul]
      _ = (2 * Real.sqrt (B.toJacobiData.z p * (1 - B.toJacobiData.z p) *
        B.toJacobiData.Dz p) * (B.d p * B.s p)) ^ 2 := by congr 1; nlinarith [hunit]
      _ = _ := by nlinarith [hsq]
  have hprod := B.toJacobiData.T1_mul_T2 p
  unfold JacobiData.H
  nlinarith [sq_nonneg (B.toJacobiData.T1 p - B.toJacobiData.T2 p)]

/-- The AM-GM equality set contains no nonempty open interval inside a signed bracket. -/
theorem no_interval_H_zero {a b : ℝ} (hab : a < b)
    (hsub : Set.Ioo a b ⊆ Set.Ioo B.p0 B.p1) :
    ¬ ∀ p ∈ Set.Ioo a b, B.toJacobiData.H p = 0 := by
  intro hz
  let t := (a + b) / 2
  have ht : t ∈ Set.Ioo a b := by dsimp [t]; constructor <;> linarith
  have hp := hsub ht
  have hq : B.toJacobiData.q t ≠ 0 := by rw [B.q_eq]; exact (B.q_pos t (Set.Ioo_subset_Icc_self hp)).ne'
  have he := (B.eps_pos t (Set.Ioo_subset_Icc_self hp)).ne'
  have hs := B.s_ne hp
  have hd := (B.d_pos t).ne'
  have h := B.toJacobiData.hasDerivAt_H t hq he hs hd
  have hev : B.toJacobiData.H =ᶠ[nhds t] fun _ => 0 :=
    Filter.eventuallyEq_of_mem (Ioo_mem_nhds ht.1 ht.2) (fun p hp => hz p hp)
  have h0 := h.congr_of_eventuallyEq hev.symm
  have heq := (hasDerivAt_const t (0 : ℝ)).unique h0
  exact (B.toJacobiData.Hp_ne_of_H_zero t hq hs hd (B.z_pos hp) (hz t ht)) heq.symm
end SBracket
end
