import SE2Conjugate.Modulus

/-! Actual parameter differentials in unwrapped amplitude coordinates (a,b,k).
The source chart has output order (t,varphi,k). -/
noncomputable section
namespace JacobiConcrete
namespace AmplitudeChart
abbrev V3 := Fin 3 → ℝ
def coord (i : Fin 3) : V3 →L[ℝ] ℝ := ContinuousLinearMap.proj i

def first (i : Fin 3) (z : V3) : ℝ := firstIntegral (z 2) (z i)
def second (i : Fin 3) (z : V3) : ℝ := secondIntegral (z 2) (z i)
def dFirst (i : Fin 3) (z : V3) : V3 →L[ℝ] ℝ :=
  firstModulusPrimitive (z 2) (z i) • coord 2 + weight (z 2) (z i) • coord i
def dSecond (i : Fin 3) (z : V3) : V3 →L[ℝ] ℝ :=
  secondModulusPrimitive (z 2) (z i) • coord 2 + speed (z 2) (z i) • coord i

theorem first_strict (i : Fin 3) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    HasStrictFDerivAt (first i) (dFirst i z) z := by
  have hp : HasStrictFDerivAt (fun v : V3 => (v 2, v i)) ((coord 2).prod (coord i)) z :=
    (hasStrictFDerivAt_apply (𝕜 := ℝ) 2 z).prodMk (hasStrictFDerivAt_apply (𝕜 := ℝ) i z)
  have h := (hasStrictFDerivAt_firstIntegral (z 2) (z i) h0 h1).comp z
    hp
  refine h.congr_fderiv ?_
  ext v
  simp [dFirst, coord, integralDifferential_apply]

theorem second_strict (i : Fin 3) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    HasStrictFDerivAt (second i) (dSecond i z) z := by
  have hp : HasStrictFDerivAt (fun v : V3 => (v 2, v i)) ((coord 2).prod (coord i)) z :=
    (hasStrictFDerivAt_apply (𝕜 := ℝ) 2 z).prodMk (hasStrictFDerivAt_apply (𝕜 := ℝ) i z)
  have h := (hasStrictFDerivAt_secondIntegral (z 2) (z i) h0 h1).comp z
    hp
  refine h.congr_fderiv ?_
  ext v
  simp [dSecond, coord, integralDifferential_apply]

def source (z : V3) : V3 := ![z 2 * (first 1 z - first 0 z), z 2 * first 0 z, z 2]
def dSource (z : V3) : V3 →L[ℝ] V3 := ContinuousLinearMap.pi
  ![z 2 • (dFirst 1 z - dFirst 0 z) + (first 1 z - first 0 z) • coord 2,
    z 2 • dFirst 0 z + first 0 z • coord 2, coord 2]

theorem source_strict (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    HasStrictFDerivAt source (dSource z) z := by
  apply hasStrictFDerivAt_pi.mpr
  intro i
  fin_cases i
  · exact (hasStrictFDerivAt_apply 2 z).mul ((first_strict 1 z h0 h1).sub (first_strict 0 z h0 h1))
  · exact (hasStrictFDerivAt_apply 2 z).mul (first_strict 0 z h0 h1)
  · exact hasStrictFDerivAt_apply 2 z

/-- Matrix of the actual differential in the standard coordinate bases. -/
def jacobian (f : V3 → V3) (z : V3) : Matrix (Fin 3) (Fin 3) ℝ :=
  fun i j => fderiv ℝ f z (Pi.single j 1) i

theorem source_det (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    (jacobian source z).det = -(z 2)^2 / (speed (z 2) (z 0) * speed (z 2) (z 1)) := by
  unfold jacobian
  rw [(source_strict z h0 h1).hasFDerivAt.fderiv]
  erw [Matrix.det_fin_three]
  simp [dSource, dFirst, coord, weight, first]
  ring

theorem source_det_ne_zero (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    (jacobian source z).det ≠ 0 := by
  rw [source_det z h0 h1]
  exact div_ne_zero (neg_ne_zero.mpr (pow_ne_zero 2 h0.ne'))
    (mul_ne_zero (speed_pos (z 2) h0 h1 (z 0)).ne' (speed_pos (z 2) h0 h1 (z 1)).ne')

def angle (i : Fin 3) (z : V3) : ℝ := Real.arcsin (z 2 * Real.sin (z i))
def dAngle (i : Fin 3) (z : V3) : V3 →L[ℝ] ℝ :=
  (Real.sin (z i) / speed (z 2) (z i)) • coord 2 +
  (z 2 * Real.cos (z i) / speed (z 2) (z i)) • coord i

theorem sine_mem (i : Fin 3) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    z 2 * Real.sin (z i) ∈ Set.Ioo (-1 : ℝ) 1 := by
  have h := radicand_pos (z 2) h0 h1 (z i)
  constructor <;> nlinarith [sq_nonneg (z 2 * Real.sin (z i) + 1),
    sq_nonneg (z 2 * Real.sin (z i) - 1)]

theorem angle_sin (i : Fin 3) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    Real.sin (angle i z) = z 2 * Real.sin (z i) :=
  Real.sin_arcsin (sine_mem i z h0 h1).1.le (sine_mem i z h0 h1).2.le

theorem angle_cos (i : Fin 3) (z : V3) : Real.cos (angle i z) = speed (z 2) (z i) := by
  unfold angle speed
  rw [Real.cos_arcsin]
  congr 2
  ring

theorem angle_deriv (i : Fin 3) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    HasFDerivAt (angle i) (dAngle i z) z := by
  have hp := (hasFDerivAt_apply (𝕜 := ℝ) 2 z).mul (hasFDerivAt_apply (𝕜 := ℝ) i z).sin
  have h := (Real.hasDerivAt_arcsin (sine_mem i z h0 h1).1.ne' (sine_mem i z h0 h1).2.ne).comp_hasFDerivAt z hp
  refine h.congr_fderiv ?_
  ext v
  have he : Real.sqrt (1-(z 2*Real.sin (z i))^2) = speed (z 2) (z i) := by
    unfold speed
    congr 2
    ring
  simp [dAngle, coord, he]
  ring

def w (z : V3) : ℝ := first 1 z - first 0 z - second 1 z + second 0 z
def q (z : V3) : ℝ := z 2 * (Real.cos (z 0) - Real.cos (z 1))
def dW (z : V3) : V3 →L[ℝ] ℝ := dFirst 1 z - dFirst 0 z - dSecond 1 z + dSecond 0 z
def dQ (z : V3) : V3 →L[ℝ] ℝ :=
  z 2 • ((-Real.sin (z 0)) • coord 0 - (-Real.sin (z 1)) • coord 1) +
  (Real.cos (z 0) - Real.cos (z 1)) • coord 2

theorem w_deriv (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) : HasFDerivAt w (dW z) z :=
  (((first_strict 1 z h0 h1).hasFDerivAt.sub (first_strict 0 z h0 h1).hasFDerivAt).sub
    (second_strict 1 z h0 h1).hasFDerivAt).add (second_strict 0 z h0 h1).hasFDerivAt

theorem q_deriv (z : V3) : HasFDerivAt q (dQ z) z :=
  (hasFDerivAt_apply (𝕜 := ℝ) 2 z).mul
    ((hasFDerivAt_apply (𝕜 := ℝ) 0 z).cos.sub (hasFDerivAt_apply (𝕜 := ℝ) 1 z).cos)

/-- The real heading lift is used in the third output coordinate. -/
def endpoint (sigma : ℝ) (z : V3) : V3 :=
  ![sigma * (q z * Real.cos (angle 0 z) + w z * Real.sin (angle 0 z)),
    sigma * (q z * Real.sin (angle 0 z) - w z * Real.cos (angle 0 z)),
    angle 0 z - angle 1 z]

def dX (z : V3) : V3 →L[ℝ] ℝ :=
  Real.cos (angle 0 z) • dQ z + Real.sin (angle 0 z) • dW z +
  (w z * Real.cos (angle 0 z) - q z * Real.sin (angle 0 z)) • dAngle 0 z

def dY (z : V3) : V3 →L[ℝ] ℝ :=
  Real.sin (angle 0 z) • dQ z - Real.cos (angle 0 z) • dW z +
  (q z * Real.cos (angle 0 z) + w z * Real.sin (angle 0 z)) • dAngle 0 z

def dEndpoint (sigma : ℝ) (z : V3) : V3 →L[ℝ] V3 :=
  ContinuousLinearMap.pi ![sigma • dX z, sigma • dY z, dAngle 0 z - dAngle 1 z]

theorem endpoint_deriv (sigma : ℝ) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    HasFDerivAt (endpoint sigma) (dEndpoint sigma z) z := by
  have ha := angle_deriv 0 z h0 h1
  have hw := w_deriv z h0 h1
  have hq := q_deriv z
  apply hasFDerivAt_pi.mpr
  intro i
  fin_cases i
  · have h := ((hq.mul ha.cos).add (hw.mul ha.sin)).const_mul sigma
    refine h.congr_fderiv ?_
    ext v
    simp [dX]
    ring
  · have h := ((hq.mul ha.sin).sub (hw.mul ha.cos)).const_mul sigma
    refine h.congr_fderiv ?_
    ext v
    simp [dY]
    ring
  · exact ha.sub (angle_deriv 1 z h0 h1)

/-- This is the already verified concrete trajectory, in amplitude coordinates. -/
theorem endpoint_eq_concrete (sigma a b k : ℝ) (h0 : 0 < k) (h1 : k < 1) :
    let J := full k h0 h1
    let psi := firstIntegral k a
    let t := k * (firstIntegral k b - firstIntegral k a)
    endpoint sigma ![a,b,k] = ![J.endpointX sigma psi t, J.endpointY sigma psi t, J.endpointTheta psi t] := by
  dsimp only
  have ht : firstIntegral k a + k * (firstIntegral k b - firstIntegral k a) / k = firstIntegral k b := by
    field_simp [h0.ne']
    ring
  have hs : (full k h0 h1).s = sn k h0 h1 := rfl
  have hc : (full k h0 h1).c = cn k h0 h1 := rfl
  have hd : (full k h0 h1).d = dn k h0 h1 := rfl
  have he : (full k h0 h1).eps = epsilon k h0 h1 := rfl
  have hk : (full k h0 h1).k = k := rfl
  ext i
  fin_cases i <;>
    simp only [endpoint,
      JacobiFull.endpointX, JacobiFull.endpointY, JacobiFull.endpointTheta,
      JacobiFull.endpointW, JacobiFull.terminalPhase, JacobiFull.rotationAngle,
      hs, hc, hd, he, hk, ht, sn, cn, dn, epsilon, amplitude_integral]
  · simp [q, w, first, second, angle_sin 0 ![a,b,k] h0 h1, angle_cos, h0.ne']
    ring_nf
  · simp [q, w, first, second, angle_sin 0 ![a,b,k] h0 h1, angle_cos, h0.ne']
    ring_nf
    simp
  · rfl

def frame (z : V3) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![Real.cos (angle 0 z), Real.sin (angle 0 z), 0],
    ![-Real.sin (angle 0 z), Real.cos (angle 0 z), 0], ![0,0,1]]

theorem frame_det (z : V3) : (frame z).det = 1 := by
  rw [Matrix.det_fin_three]
  simpa [frame, pow_two] using Real.cos_sq_add_sin_sq (angle 0 z)

theorem rotated_x (z v : V3) :
    Real.cos (angle 0 z) * dX z v + Real.sin (angle 0 z) * dY z v =
      dQ z v + w z * dAngle 0 z v := by
  simp only [dX, dY, add_apply, sub_apply,
    smul_apply, smul_eq_mul]
  linear_combination (dQ z v + w z*dAngle 0 z v) * Real.cos_sq_add_sin_sq (angle 0 z)

theorem rotated_y (z v : V3) :
    -Real.sin (angle 0 z) * dX z v + Real.cos (angle 0 z) * dY z v =
      -dW z v + q z * dAngle 0 z v := by
  simp only [dX, dY, add_apply, sub_apply,
    smul_apply, smul_eq_mul]
  linear_combination (-dW z v + q z*dAngle 0 z v) * Real.cos_sq_add_sin_sq (angle 0 z)

def rotated (z : V3) : Matrix (Fin 3) (Fin 3) ℝ := fun i j =>
  ![dQ z (Pi.single j 1) + w z * dAngle 0 z (Pi.single j 1),
    -dW z (Pi.single j 1) + q z * dAngle 0 z (Pi.single j 1),
    dAngle 0 z (Pi.single j 1) - dAngle 1 z (Pi.single j 1)] i

theorem frame_jacobian (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    frame z * jacobian (endpoint 1) z = rotated z := by
  unfold jacobian
  rw [(endpoint_deriv 1 z h0 h1).fderiv]
  ext i j
  change (∑ x : Fin 3, frame z i x * (dEndpoint 1 z (Pi.single j 1)) x) = rotated z i j
  fin_cases i <;> simp [frame, Fin.sum_univ_succ, dEndpoint, rotated, rotated_x]
  simpa only [neg_mul] using rotated_y z (Pi.single j 1)

theorem endpoint_det_rotated (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    (jacobian (endpoint 1) z).det = (rotated z).det := by
  rw [← frame_jacobian z h0 h1, Matrix.det_mul, frame_det, one_mul]

theorem endpoint_det_sign (sigma : ℝ) (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    (jacobian (endpoint sigma) z).det = sigma^2 * (jacobian (endpoint 1) z).det := by
  unfold jacobian
  rw [(endpoint_deriv sigma z h0 h1).fderiv, (endpoint_deriv 1 z h0 h1).fderiv]
  erw [Matrix.det_fin_three, Matrix.det_fin_three]
  simp [dEndpoint]
  ring

def wGradient (z : V3) : V3 :=
  ![-(z 2)^2 * Real.sin (z 0)^2 / speed (z 2) (z 0),
    (z 2)^2 * Real.sin (z 1)^2 / speed (z 2) (z 1),
    z 2 / (1-(z 2)^2) * (second 1 z - second 0 z -
      Real.sin (z 1)*Real.cos (z 1)/speed (z 2) (z 1) +
      Real.sin (z 0)*Real.cos (z 0)/speed (z 2) (z 0))]

theorem w_derivative_basis (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) (j : Fin 3) :
    dW z (Pi.single j 1) = wGradient z j := by
  have ha := (speed_pos (z 2) h0 h1 (z 0)).ne'
  have hb := (speed_pos (z 2) h0 h1 (z 1)).ne'
  have hk : 1-(z 2)^2 ≠ 0 := by nlinarith [h0,h1]
  fin_cases j
  · simp [dW, dFirst, dSecond, coord, wGradient, weight]
    field_simp [ha]
    nlinarith [speed_sq (z 2) (z 0) h0 h1]
  · simp [dW, dFirst, dSecond, coord, wGradient, weight]
    field_simp [hb]
    nlinarith [speed_sq (z 2) (z 1) h0 h1]
  · simp [dW, dFirst, dSecond, coord, wGradient, firstModulusPrimitive,
      secondModulusPrimitive, boundaryTerm, second]
    field_simp [ha,hb,hk,h0.ne']
    ring

/-- Explicit rotated differential, with columns a,b,k. -/
def rotatedMatrix (k sa ca da sb cb db W V : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  ![![-k*sa+W*(k*ca/da), k*sb, ca-cb+W*(sa/da)],
    ![k^2*sa^2/da+k*(ca-cb)*(k*ca/da), -k^2*sb^2/db,
      -k/(1-k^2)*(V-sb*cb/db+sa*ca/da)+k*(ca-cb)*(sa/da)],
    ![k*ca/da, -k*cb/db, sa/da-sb/db]]

theorem rotated_eq (z : V3) (h0 : 0 < z 2) (h1 : z 2 < 1) :
    rotated z = rotatedMatrix (z 2) (Real.sin (z 0)) (Real.cos (z 0)) (speed (z 2) (z 0))
      (Real.sin (z 1)) (Real.cos (z 1)) (speed (z 2) (z 1)) (w z) (second 1 z-second 0 z) := by
  ext i j
  fin_cases i <;> fin_cases j <;>
    simp [rotated, rotatedMatrix, w_derivative_basis z h0 h1, wGradient, dQ, dAngle, coord, q] <;> ring

def compact (k sa ca da sb cb db W V : ℝ) : ℝ :=
  (V*W+da^2+db^2-2*k^2)*ca*cb+(V-W)*(ca*sb*db-cb*sa*da)+2*sa*sb*da*db-2*(1-k^2)

theorem determinant_algebra (k sa ca da sb cb db W V : ℝ)
    (ha : da ≠ 0) (hb : db ≠ 0) (hk : 1-k^2 ≠ 0)
    (hsa : ca^2+sa^2=1) (hsb : cb^2+sb^2=1)
    (hda : da^2=1-k^2*sa^2) (hdb : db^2=1-k^2*sb^2) :
    (rotatedMatrix k sa ca da sb cb db W V).det =
      -k^3/((1-k^2)*da*db)*compact k sa ca da sb cb db W V := by
  rw [Matrix.det_fin_three]
  simp [rotatedMatrix, compact]
  field_simp [ha,hb,hk]
  linear_combination (k^3*(W*cb*db*sa + ca*cb*da*db - cb^2*sa*sb + 2*db^2*sa*sb + k^2*sa*sb^3 - sa*sb^3)) * hda +
    (-k^3*(W*ca*da*sb + ca^2*sa*sb - ca*cb*da*db + k^2*sa^3*sb + sa^3*sb - 2*sa*sb)) * hdb +
    (k^3*(-W*cb*db*sa + ca*cb*da*db*k^2 - ca*cb*da*db - 2*cb^2*da*db*k^2 + 2*cb^2*da*db - 2*da*db*k^2*sb^2 + 2*da*db*sb^2 + k^2*sa*sb^3 - sa*sb)) * hsa +
    (k^3*(W*ca*da*sb + ca*cb*da*db*k^2 - ca*cb*da*db - 2*da*db*k^2 + 2*da*db + k^2*sa^3*sb - sa*sb)) * hsb

def bPolynomial (z : V3) : ℝ := compact (z 2)
  (Real.sin (z 0)) (Real.cos (z 0)) (speed (z 2) (z 0))
  (Real.sin (z 1)) (Real.cos (z 1)) (speed (z 2) (z 1)) (w z) (second 1 z-second 0 z)

/-- Determinant of the actual endpoint Fréchet derivative in the amplitude chart. -/
theorem endpoint_det (sigma : ℝ) (hsigma : sigma^2=1) (z : V3)
    (h0 : 0 < z 2) (h1 : z 2 < 1) :
    (jacobian (endpoint sigma) z).det =
      -(z 2)^3 / ((1-(z 2)^2)*speed (z 2) (z 0)*speed (z 2) (z 1)) * bPolynomial z := by
  rw [endpoint_det_sign sigma z h0 h1, hsigma, one_mul, endpoint_det_rotated z h0 h1,
    rotated_eq z h0 h1]
  exact determinant_algebra _ _ _ _ _ _ _ _ _
    (speed_pos (z 2) h0 h1 (z 0)).ne' (speed_pos (z 2) h0 h1 (z 1)).ne'
    (by nlinarith [h0,h1]) (Real.cos_sq_add_sin_sq _) (Real.cos_sq_add_sin_sq _)
    (speed_sq (z 2) (z 0) h0 h1) (speed_sq (z 2) (z 1) h0 h1)

/-- Signed coordinate quotient. Transport to the inverse chart is a separate theorem. -/
theorem determinant_quotient (sigma : ℝ) (hsigma : sigma^2=1) (z : V3)
    (h0 : 0 < z 2) (h1 : z 2 < 1) :
    (jacobian (endpoint sigma) z).det / (jacobian source z).det =
      z 2/(1-(z 2)^2)*bPolynomial z := by
  rw [endpoint_det sigma hsigma z h0 h1, source_det z h0 h1]
  have ha := (speed_pos (z 2) h0 h1 (z 0)).ne'
  have hb := (speed_pos (z 2) h0 h1 (z 1)).ne'
  have hk : 1-(z 2)^2 ≠ 0 := by nlinarith [h0,h1]
  field_simp [ha,hb,hk,h0.ne']

theorem endpoint_det_zero_iff (sigma : ℝ) (hsigma : sigma^2=1) (z : V3)
    (h0 : 0 < z 2) (h1 : z 2 < 1) :
    (jacobian (endpoint sigma) z).det = 0 ↔ bPolynomial z = 0 := by
  rw [endpoint_det sigma hsigma z h0 h1]
  apply mul_eq_zero_iff_left
  apply div_ne_zero (neg_ne_zero.mpr (pow_ne_zero 3 h0.ne'))
  exact mul_ne_zero (mul_ne_zero (by nlinarith [h0,h1])
    (speed_pos (z 2) h0 h1 (z 0)).ne') (speed_pos (z 2) h0 h1 (z 1)).ne'

theorem source_time_pos (a b k : ℝ) (h0 : 0 < k) (h1 : k < 1) :
    0 < source ![a,b,k] 0 ↔ a < b := by
  change 0 < k * (firstIntegral k b - firstIntegral k a) ↔ a < b
  rw [mul_pos_iff_of_pos_left h0, sub_pos]
  exact (firstIntegral_strictMono k h0 h1).lt_iff_lt

end AmplitudeChart
end JacobiConcrete
