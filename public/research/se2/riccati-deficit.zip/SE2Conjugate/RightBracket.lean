import SE2Conjugate.LeftBracket

/-!
# Theorem 4.1, the right brackets `Bₙ⁺`

For every `m ≥ 0` (cell `n = m + 1`): the right end is the zero `bₙ ∈ (2nK, (2n+1)K)` of `β₁`, the
left end `eR = max(2nK, p_n^α)` is the last zero of `α₁` before `bₙ` (or `2nK`).  On the open
bracket `(-1)^m f₁ > 0`, `(-1)^m β₁ < 0`, `(-1)^(m+1) sn > 0`, `(-1)^(m+1) α₁ > 0`, so it is an
`SBracket` with `σ = (-1)^m`, `ε = -1`.
-/

noncomputable section

namespace JacobiFull

variable (J : JacobiFull) (m : ℕ)

theorem cast2 : (2 * ((m + 1 : ℕ) : ℝ)) * J.K = (2 * m + 2) * J.K := by push_cast; ring
theorem cast3 : (2 * ((m + 1 : ℕ) : ℝ) + 1) * J.K = (2 * m + 3) * J.K := by push_cast; ring
theorem cast4 : (2 * ((m + 1 : ℕ) : ℝ) + 2) * J.K = (2 * m + 4) * J.K := by push_cast; ring

/-- The right end `b_{m+1}`, the zero of `β₁` in `((2m+2)K, (2m+3)K)`. -/
def bR : ℝ := Classical.choose (J.toJacobiPeriodic.exists_unique_β1_zero (m + 1) (by omega)).exists

theorem bR_spec : J.bR m ∈ Set.Ioo ((2 * m + 2) * J.K) ((2 * m + 3) * J.K)
    ∧ J.toJacobiData.β1 (J.bR m) = 0 := by
  obtain ⟨hb, hβ⟩ := Classical.choose_spec
    (J.toJacobiPeriodic.exists_unique_β1_zero (m + 1) (by omega)).exists
  refine ⟨?_, hβ⟩
  rw [← J.cast2 m, ← J.cast3 m]
  exact hb

theorem bR_mem : J.bR m ∈ Set.Ioo ((2 * m + 2) * J.K) ((2 * m + 3) * J.K) := (J.bR_spec m).1
theorem β1_bR : J.toJacobiData.β1 (J.bR m) = 0 := (J.bR_spec m).2

theorem two_m_two_pos : 0 < (2 * m + 2) * J.K := by
  have := J.K_pos; have : (0 : ℝ) ≤ m := Nat.cast_nonneg m; nlinarith

/-- `(-1)^(m+1) β₁ > 0` on `[(2m+2)K, b_{m+1})`. -/
theorem signed_β1_pos_before_bR {p : ℝ} (hp : p ∈ Set.Ico ((2 * m + 2) * J.K) (J.bR m)) :
    0 < (-1) ^ (m + 1) * J.toJacobiData.β1 p := by
  have hanti := J.toJacobiPeriodic.signed_β1_strictAntiOn (m + 1) (by omega)
  rw [J.cast2 m, J.cast4 m] at hanti
  have hK := J.K_pos
  have hb := J.bR_mem m
  have hpI : p ∈ Set.Icc ((2 * m + 2) * J.K) ((2 * m + 4) * J.K) := ⟨hp.1, by linarith [hp.2, hb.2]⟩
  have hbI : J.bR m ∈ Set.Icc ((2 * m + 2) * J.K) ((2 * m + 4) * J.K) := ⟨hb.1.le, by linarith [hb.2]⟩
  have := hanti hpI hbI hp.2
  simp only at this
  rw [J.β1_bR, mul_zero] at this
  exact this

/-- `(-1)^(m+1) sn > 0` on `((2m+2)K, (2m+4)K)`. -/
theorem signed_s_pos_R {p : ℝ} (hp : p ∈ Set.Ioo ((2 * m + 2) * J.K) ((2 * m + 4) * J.K)) :
    0 < (-1) ^ (m + 1) * J.s p := by
  have h := J.s_sign (m + 1) p
  rw [J.cast2 m, J.cast4 m] at h
  exact h hp

/-- `(-1)^(m+1) α₁(b_{m+1}) > 0`. -/
theorem signed_α1_bR_pos : 0 < (-1) ^ (m + 1) * J.toJacobiData.α1 (J.bR m) := by
  have hb := J.bR_mem m
  have hbpos : 0 < J.bR m := by linarith [hb.1, J.two_m_two_pos m]
  have hβ : J.toJacobiData.β (J.bR m) = 0 := by
    unfold JacobiData.β; rw [J.β1_bR, mul_zero]
  have hX : J.toJacobiData.X (J.bR m) = J.toJacobiData.ell (J.bR m) := by
    have := J.toJacobiData.collapse_beta (J.bR m)
    rw [hβ] at this
    linarith
  have hℓ : 0 < J.toJacobiData.ell (J.bR m) :=
    mul_pos (J.toJacobiInit.eps_pos hbpos) (J.toJacobiInit.q_pos hbpos)
  have hXpos : 0 < J.s (J.bR m) * J.toJacobiData.α1 (J.bR m) := by
    have : J.toJacobiData.X (J.bR m) = J.s (J.bR m) * J.toJacobiData.α1 (J.bR m) := rfl
    rw [← this, hX]; exact hℓ
  have hK := J.K_pos
  exact sign_transfer hXpos (J.signed_s_pos_R m ⟨hb.1, by linarith [hb.2]⟩)

/-- The zeros of `α₁` on `[(2m+2)K, b_{m+1}]`, together with `(2m+2)K`. -/
def ZR : Set ℝ :=
  {p | p ∈ Set.Icc ((2 * m + 2) * J.K) (J.bR m) ∧ J.toJacobiData.α1 p = 0} ∪ {(2 * m + 2) * J.K}

/-- The left end of the right bracket, `max(2nK, p_n^α)`. -/
def eR : ℝ := sSup (J.ZR m)

theorem ZR_nonempty : (J.ZR m).Nonempty := ⟨(2 * m + 2) * J.K, Or.inr rfl⟩

theorem ZR_bddAbove : BddAbove (J.ZR m) := by
  refine ⟨J.bR m, ?_⟩
  rintro p (⟨hp, _⟩ | hp)
  · exact hp.2
  · rw [Set.mem_singleton_iff] at hp; rw [hp]; exact (J.bR_mem m).1.le

theorem ZR_isClosed : IsClosed (J.ZR m) := by
  unfold ZR
  apply IsClosed.union
  · have : {p | p ∈ Set.Icc ((2 * m + 2) * J.K) (J.bR m) ∧ J.toJacobiData.α1 p = 0}
        = Set.Icc ((2 * m + 2) * J.K) (J.bR m) ∩ J.toJacobiData.α1 ⁻¹' {0} := by
      ext p; simp
    rw [this]
    exact isClosed_Icc.inter (isClosed_singleton.preimage J.continuous_α1)
  · exact isClosed_singleton

theorem eR_mem_ZR : J.eR m ∈ J.ZR m :=
  (J.ZR_isClosed m).csSup_mem (J.ZR_nonempty m) (J.ZR_bddAbove m)

theorem eR_ge : (2 * m + 2) * J.K ≤ J.eR m := le_csSup (J.ZR_bddAbove m) (Or.inr rfl)

theorem eR_le_bR : J.eR m ≤ J.bR m := by
  apply csSup_le (J.ZR_nonempty m)
  rintro p (⟨hp, _⟩ | hp)
  · exact hp.2
  · rw [Set.mem_singleton_iff] at hp; rw [hp]; exact (J.bR_mem m).1.le

theorem eR_lt_bR : J.eR m < J.bR m := by
  rcases eq_or_lt_of_le (J.eR_le_bR m) with h | h
  · exfalso
    have hmem := J.eR_mem_ZR m
    rw [h] at hmem
    rcases hmem with ⟨_, h0⟩ | h0
    · have := J.signed_α1_bR_pos m; rw [h0, mul_zero] at this; exact lt_irrefl _ this
    · rw [Set.mem_singleton_iff] at h0; linarith [(J.bR_mem m).1]
  · exact h

/-- An `eR` strictly after `(2m+2)K` is a zero of `α₁`. -/
theorem α1_eR_of_gt (h : (2 * m + 2) * J.K < J.eR m) : J.toJacobiData.α1 (J.eR m) = 0 := by
  rcases J.eR_mem_ZR m with ⟨_, h0⟩ | h0
  · exact h0
  · rw [Set.mem_singleton_iff] at h0; linarith

/-- `(-1)^(m+1) α₁ > 0` on `(eR, b_{m+1})`, by maximality of `eR`. -/
theorem signed_α1_pos_R {p : ℝ} (hp : p ∈ Set.Ioo (J.eR m) (J.bR m)) :
    0 < (-1) ^ (m + 1) * J.toJacobiData.α1 p := by
  by_contra hle
  rw [not_lt] at hle
  have hb := J.signed_α1_bR_pos m
  rw [neg_one_pow_succ_mul] at hle hb
  obtain ⟨z, hz, hα⟩ := J.exists_α1_zero m hp.2.le
    (mul_nonpos_of_nonneg_of_nonpos (by linarith) (by linarith))
  have hzZ : z ∈ J.ZR m := Or.inl ⟨⟨by linarith [hz.1, hp.1, J.eR_ge m], hz.2⟩, hα⟩
  have : z ≤ J.eR m := le_csSup (J.ZR_bddAbove m) hzZ
  linarith [hz.1, hp.1]

theorem X_eR : J.s (J.eR m) * J.toJacobiData.α1 (J.eR m) = 0 := by
  rcases J.eR_mem_ZR m with ⟨_, h0⟩ | h0
  · rw [h0, mul_zero]
  · rw [Set.mem_singleton_iff] at h0
    rw [h0, ← J.cast2 m, J.s_even, zero_mul]

/-- The right bracket `B_{m+1}^+` as a signed bracket, `σ = (-1)^m`, `ε = -1`. -/
def rightBracket : SBracket where
  toJacobiData := J.toJacobiData
  K := J.K
  K_pos := J.K_pos
  p0 := J.eR m
  p1 := J.bR m
  p0_lt_p1 := J.eR_lt_bR m
  σ := (-1) ^ m
  hσ := neg_one_pow_eq_or ℝ m
  ε := -1
  hε := Or.inr rfl
  d_pos := J.d_pos
  eps_pos := fun p hp => J.toJacobiInit.eps_pos (by linarith [hp.1, J.eR_ge m, J.two_m_two_pos m])
  q_pos := fun p hp => J.toJacobiInit.q_pos (by linarith [hp.1, J.eR_ge m, J.two_m_two_pos m])
  f1_sign := fun p hp => by
    have hK := J.K_pos
    have hM := (J.toJacobiPeriodic.pM_spec m).1
    have hmem : p ∈ Set.Ioo (J.toJacobiPeriodic.pM m) ((2 * m + 3) * J.K) :=
      ⟨by linarith [hp.1, J.eR_ge m, hM.2], by linarith [hp.2, (J.bR_mem m).2]⟩
    exact J.toJacobiPeriodic.f1_sign_after m hmem
  β1_sign := fun p hp => by
    have h : 0 < (-1 : ℝ) ^ (m + 1) * J.toJacobiData.β1 p :=
      J.signed_β1_pos_before_bR m (p := p) ⟨by linarith [hp.1, J.eR_ge m], hp.2⟩
    show (-1 : ℝ) ^ m * J.toJacobiData.β1 p < 0
    rw [neg_one_pow_succ_mul] at h
    linarith
  s_sign := fun p hp => by
    have hK := J.K_pos
    have h : 0 < (-1 : ℝ) ^ (m + 1) * J.s p :=
      J.signed_s_pos_R m (p := p)
        ⟨by linarith [hp.1, J.eR_ge m], by linarith [hp.2, (J.bR_mem m).2]⟩
    rw [pow_succ] at h
    linarith
  α1_sign := fun p hp => by
    have h := J.signed_α1_pos_R m hp
    show 0 < (-1 : ℝ) * (-1) ^ m * J.toJacobiData.α1 p
    rw [pow_succ] at h
    linarith
  β_lo := fun h => absurd h (by norm_num)
  X_lo := fun _ => J.X_eR m
  X_hi := fun h => absurd h (by norm_num)
  β_hi := fun _ => by
    show J.toJacobiData.f1 (J.bR m) * J.toJacobiData.β1 (J.bR m) = 0
    rw [J.β1_bR, mul_zero]
  Finv := J.Finv
  Finv_deriv := J.Finv_deriv
  Finv_cont := J.Finv_cont
  Finv_zero := J.Finv_zero
  Finv_one := J.Finv_one
  Finv_spec := J.Finv_spec
  sn_sq_eq_iff := J.sn_sq_eq_iff

/-- **Theorem 4.1, right brackets**: exactly one conjugate time on `B_{m+1}^+ = [eR, b_{m+1}]`. -/
theorem right_exact_time (ψ : ℝ) :
    ∃! p, p ∈ Set.Icc (J.eR m) (J.bR m) ∧ (J.rightBracket m).J2 (ψ + p) p = 0 :=
  (J.rightBracket m).exact_time ψ

end JacobiFull

end
