# SE(2) Riccati slope deficit

RiccatiDeficit.squared_deficit gives the exact positive weight and square for the derivative of the inverse Jacobi phase. unit_slope_iff gives both directions of equality, and article_slope gives both slope bounds and simplicity of H zeros on the original open domain. The declarations are in the JacobiCore namespace.

Use the toolchain and dependency revisions supplied in this archive. From its root run

    lake exe cache get
    lake build
    lake env lean Audit.lean

Compare the final output with axioms.txt. SHA256SUMS identifies every input. The 66 declarations include the witnesses for the whole-paper claim ledger.
