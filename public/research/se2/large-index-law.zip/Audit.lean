import SE2Conjugate.LargeIndex
#print axioms JacobiCore.LargeIndex.leading_factor
#print axioms JacobiCore.LargeIndex.sn_chord
#print axioms JacobiCore.LargeIndex.cell_estimate
#print axioms JacobiCore.LargeIndex.ranked_cell_estimate
#print axioms JacobiCore.LargeIndex.critical_ranked_law
#print axioms JacobiConcrete.LargeIndex.indexed_law
#print axioms JacobiConcrete.LargeIndex.compact_indexed_law
