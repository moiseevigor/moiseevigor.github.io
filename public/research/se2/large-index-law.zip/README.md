# Ranked large-index law on SE(2)

Install the Lean toolchain specified in lean-toolchain. In this directory run:

    lake exe cache get
    lake build
    lake env lean Audit.lean

This archive contains the large-index module and its transitive project-source imports. Mathlib and its dependencies are pinned in lake-manifest.json. Compare the last command with axioms.txt. The main formal statements are indexed_law and compact_indexed_law in the JacobiConcrete.LargeIndex namespace. The critical cell estimate is JacobiCore.LargeIndex.critical_ranked_law. The website's historical manuscript downloads have their own snapshot manifest.
