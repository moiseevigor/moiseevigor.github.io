# Rotating SE(2) conjugate times · statement review, 21 November 2026

The source is the 29-page November version of *Conjugate Times on SE(2)*. The list below covers all eleven numbered results, including the three mathematical remarks. The coverage ledger also includes the setting, numerical section and appendices. Correctness assessments concern the stated domains. Elegance assessments concern the proof, independently of its formal status.

| Statement | Correctness and evidence | Elegance |
|---|---|---|
| Lemma 3.1 — coefficient identities and zero placement | The three collapses and three quotient derivatives follow by substitution. The derivative of Γ explains the sign of β₁′. The signs of the monotone quotients locate the indexed zeros, with the α₁ zero changing sides at K=2E. Its simplicity still has a written proof. | The quotients expose monotonicity directly. The subsequent sign table is lengthy because it tracks three different zeros. |
| Lemma 3.2 — Riccati inequality | The product rule, the common sign and AM–GM give the slope bound. The squared deficit detects equality, and a nonzero derivative of H makes its zeros simple. The ledger credits the matching formal subclaims individually. | The mixed terms cancel before the inequality is applied. This is the shortest explanation of why the phase slope has magnitude at least one. |
| Lemma 3.3 — one crossing | The phase branches cover the circle once and meet at the two corners. The article's former tangency wording omitted the sign. At an interior crossing the derivative of the phase difference is σu′−1. Only that signed equality yields odd order at least three. The other branch remains transverse there. The corner and finiteness conclusions use their stated endpoint hypotheses. | Unwrapping the phase circle turns existence and uniqueness into an interval argument. |
| Theorem 3.4 — first time | The unique first positive root gives t=2kp. The crossing argument establishes uniqueness, and compactness and uniqueness give continuity. The lower and upper endpoints have the stated unique phases. Equality with the published cut time uses its independent formula. Lean covers the first-root core. | Both extreme phases can be read off at the two corners. |
| Theorem 4.1 — every cell | Each closed bracket contributes one time. The common center is counted once when K=2E and ψ≡K. Scalar orders are simple, cubic at the matching interior tangent, or quartic at that common center. The full multiplicity classification still uses the analytic sign argument. | Reusing the one-crossing lemma is efficient. The half-open cell convention matters for the Maxwell endpoint. |
| Remark 4.2 — critical contact and splitting | The exceptional determinant factors through a primitive with nonnegative derivative. Its leading cubic term gives the quartic coefficient (1−k²)/3. The signed cube-root inverse gives the correction and modulus limits for fixed cell index, on both sides. These local statements have Lean witnesses. | One integral gives the order, sign and displacement with no fourth differentiation. |
| Proposition 4.3 — number of tangencies | There are none in the open brackets when k≤k₀. For k>k₀ each open bracket has exactly one, on its specified phase branch. The article uses a sign factorization, endpoint signs, and simple crossings. The formal proof of simple H zeros alone does not count them. | The sign argument is economical once the auxiliary factorization is known. Finding that factorization is the least transparent step. |
| Theorem 5.1 — Floquet structure and ordered law | The translation length is 4(K−E). The determinant is quadratic in the period index. The article also gives a profile correction, two limiting branches and three indexed endpoint expansions. The ranked law and joint compact uniformity now have complete Lean proofs. At K=2E the regular-phase error is O(j⁻²). The three endpoint expansions now share a Lean-verified quadratic remainder bound on compact interior modulus sets. The formal proof identifies the middle endpoint by its unique coefficient zero. | The terminal angular speed identifies each limiting root directly and explains the improved order by a single vanishing coefficient. |
| Remark 5.2 — exceptional phase | The center persists. The other root solves an odd strictly increasing integral equation. The two coincide at k₀, leaving distinct times pⱼ=2jK. Otherwise their order reverses across k₀, and the pole at ±K supplies the first inverse-index correction. The asymptotic correction has a human proof. | The same integral treats both ends by oddness. The choice of representative ψ=±K matters when quoting the ranked law at the boundary. |
| Proposition 5.3 — eventual folds | For both rotating signs and on compact sets of ordinary phases, the analytic proof controls the derivative of the endpoint determinant along its kernel. This additional step establishes a fold. Scalar root simplicity by itself would be insufficient. Full geometric recognition remains outside Lean. | The first-variation identity connects a computable determinant with the geometric fold criterion. |
| Remark 5.4 — separatrix | As k→1, K(p₀−K)→1 and 2K−p₁→(log 3)/2. Their first corrections are +1/K and −1/(2K), respectively. The argument uses elliptic-to-hyperbolic limits and simple-root expansions. The four separatrix checks in the 70-digit replay passed. The rates remain analytic. | Two shifted coordinates expose elementary limiting functions. Keeping the first corrections takes more work than finding the limits. |

## What the whole-paper coverage measures

The denominator is a fixed ledger of 34 groups of claims. Section 1 restates later results and is counted at their proof sites. Section 6 has one group for empirical checks. The other 33 groups are mathematical, including external inputs and appendix bridges. F means a kernel-checked match for the stated group, using the project’s concrete construction where applicable. P means matching formal subresults with an outstanding clause or hypothesis bridge. A means analytic or externally sourced with no full matching proof credited. N means finite numerical evidence. Partial groups receive zero credit in the strict percentage.

**16/33 mathematical groups (48.5%) are fully covered; 11/33 have partial coverage and 6/33 are analytic or external.** At least one substantive formal ingredient is mapped in 27/33 (81.8%). The second number includes partial work. The split is a versioned editorial choice. Splitting only the completed groups would inflate both rates. A change to the grouping requires explaining and recomputing the denominator. Correctness, elegance and numerical sampling density are separate judgements.

The accompanying claims.tsv names the witnesses, and CoverageAudit.lean prints their axioms. Reviewing their types against the paper remains a mathematical task. A future change that preserves a declaration's name can still change its meaning. For subsequent editions, compare the stated hypotheses, conclusions, normalization, multiplicity convention and quantified domains before reusing a credit. Related precedents include [LeanTrail's paper-to-Lean alignment audit](https://files.visualdslab.com/files/papers/2026-Leantrail-NeurIPS-MATH-AI.pdf) and [Formal Conjectures’ statement review](https://github.com/google-deepmind/formal-conjectures/blob/main/STATEMENTS.md).

## Unnumbered material and numerical claims

- Sections 1–2 use the unit-energy rotating model, the published cut-time formula and scaled time t=2kp. Source and target angles and scalar multiplicities must be kept distinct.
- Section 6 records 720 cell records from 120 geodesics, eight ODE time offsets for a Floquet fit, finite endpoint/profile/root-error grids and a 38,912-root illustration. The reported profile constants apply at four offsets. Previous interval certificates extend those four estimates to all n≥5 at their specified moduli. Full-offset bounds there are 0.5700 and 0.0481. The historical audit found one normalized first-root error of 2.51×10⁻⁵ near the rounded critical modulus. Sign-change sampling can miss the quartic contact.
- This review reran the 70-digit driver for nine endpoint cases, 54 ordinary roots, nine exceptional-phase cases, four separatrix cases and three Floquet cases. A second check evaluated 24 critical regular-phase roots using the original coefficients at n=8,32,128,512. The revised scalar and vectorized first-root solvers are checked against four independent 70-digit reference roots near the critical modulus. In particular, at k=0.9089085575485415 and ψ=−2.321050732530421 the scaled root is 4.610387575926939. Historical ODE integrations and the full first-root array were not regenerated.
- Appendix A constructs the Jacobi functions and specializes the formal results to them. Appendix B identifies the coordinate endpoint determinant with a nonzero factor times the reduced determinant. Appendix C checks the hypotheses for the classical variational criterion. Lean handles the coordinate flow, the ordinary adjoint zero-response result and an algebraic annihilator statement. The Hilbert-space endpoint derivative and the index theorem retain analytic inputs.

## Why the large-index proof works

Let p=2nK+s. The addition formula gives an exact product at a root. Its factors include cn ψ, the terminal angular speed up to sign cn(ψ+2s), and a positive weight bounded below by n²E(K−E). The remaining numerator is bounded by 3K+1+2n|K−2E|. On ordinary compact phase sets cn ψ is bounded away from zero. The left and right half-cell windows each contain precisely one simple zero of the terminal factor, respectively −K and K. Distance from that zero therefore satisfies the same estimate as the angular speed. The known two-root count fixes their ranks. This yields pⱼ=(j+½)K−ψ/2+O(1/j), improving to O(1/j²) at the critical modulus, uniformly away from the exceptional phase. In physical time the limiting spacing is 2kK, by subtraction of consecutive estimates.

The transferable argument is localization near a simple zero of the leading determinant coefficient. For a higher-dimensional periodic family one would need a leading determinant, uniform remainder control, transverse isolated zeros and a separate root count. Pure translation monodromy gives a conditional degree bound via the translation rows. Those hypotheses and the SE(2) root count have not been established here for another group.

## Claim-by-claim coverage

| Location | Claim group | Status | Lean declarations |
|---|---|---|---|
| §2 | Rotating Hamiltonian coordinate solution and uniqueness | F | `JacobiConcrete.rotatingState_solves`, `JacobiConcrete.rotatingState_unique` |
| §2 | Geometric Hamiltonian reduction and published cut-time formula | A | — |
| 3.1(i) | Collapse of beta, alpha and their difference | F | `JacobiData.collapse_beta`, `JacobiData.collapse_alpha`, `JacobiData.collapse_diff` |
| 3.1(ii) | Three quotient derivatives | F | `JacobiData.hasDerivAt_f1_div_c`, `JacobiData.hasDerivAt_β1_div_c`, `JacobiData.hasDerivAt_α1_div_d` |
| 3.1(iii) | Gamma derivative and beta derivative identity | F | `JacobiData.hasDerivAt_Γ`, `JacobiData.β1_deriv_eq_Γ` |
| 3.1(iv) | Sign chart, zero placement, simplicity of the alpha zero | P | `JacobiPeriodic.exists_unique_β1_zero`, `JacobiFull.eL_lt_iff` |
| 3.2 | Riccati product, derivative, common sign and slope bound | P | `JacobiData.hasDerivAt_z`, `JacobiData.T1_mul_T2`, `JacobiData.slope_bound_abs` |
| 3.2 | Exact squared deficit, equality condition and simplicity of H zeros | P | `JacobiData.Hp_ne_of_H_zero`, `SBracket.H_zero_of_unit_slope` |
| 3.3 | Strict bracket width and unique phase crossing from monotone branches | F | `CrossingData.hi_sub_lo_lt`, `CrossingData.crossing` |
| 3.3 | Analytic hypotheses, finite tangent set, branch and corner orders | P | `CrossingData.unique_branch` |
| 3.4 | First determinant root, uniqueness and absence of earlier roots | F | `JacobiConcrete.first_time_unique`, `JacobiFull.first_time_complete` |
| 3.4 | Joint continuity, unique extreme phases and equality with cut time | A | — |
| 4.1 | One root per bracket, exclusion elsewhere, distinct count and critical exception | P | `JacobiConcrete.two_per_cell`, `JacobiFull.coincide_imp`, `JacobiCore.LargeIndex.cell_estimate` |
| 4.1 | Simple, triple and quartic root classification | P | `JacobiCore.critical_quartic_limit` |
| 4.2 | Exceptional-phase factorization and derivative of the primitive | F | `JacobiCore.J2_exceptional`, `JacobiCore.primitive_deriv` |
| 4.2 | Critical quartic coefficient at every center | F | `JacobiCore.critical_quartic_limit` |
| 4.2 | Signed fixed-cell splitting, correction and modulus limit | F | `JacobiConcrete.fixed_cell_splitting`, `JacobiConcrete.moving_root_limit` |
| 4.3 | Global number of interior tangent phases, branch and order | P | `JacobiData.Hp_ne_of_H_zero` |
| 5.1(i) | Endpoint determinant polynomial in the period index | F | `JacobiConcrete.AmplitudeChart.endpoint_period_polynomial` |
| 5.1(i) | Translation length, angle derivative and geometric identification of its leading coefficient | P | `JacobiCore.LargeIndex.leading_factor` |
| 5.1(ii) | Profile expansion and limiting zero curves | P | `JacobiCore.profile_exact`, `JacobiCore.profile_critical` |
| 5.1(ii) | Three bracket endpoint expansions and uniformity | F | `JacobiCore.EndpointExpansion.alpha_endpoint_spec`, `JacobiCore.EndpointExpansion.compact_three_endpoints` |
| 5.1(ii) | Ordered root law with compact parameter uniformity | F | `JacobiConcrete.LargeIndex.indexed_law`, `JacobiConcrete.LargeIndex.compact_indexed_law` |
| 5.1(ii) | Critical quadratic improvement for both ranks | F | `JacobiCore.LargeIndex.critical_ranked_law` |
| 5.2 | Exceptional phase center, integral equation and ordering | P | `JacobiCore.J2_exceptional` |
| 5.2 | Noncritical endpoint offset with its first correction | A | — |
| 5.3 | Eventual geometric fold for both rotating signs on compact sets | A | — |
| 5.4 | Two separatrix limits and their first corrections | A | — |
| §6 | Sampled ODE, endpoint and profile checks, numerical maps | N | — |
| §6 | Extension of profile bounds via Bernstein inequalities and external intervals | P | `JacobiCore.profile_bound_all` |
| App. A | Concrete Jacobi construction, first root and modulus specialization | F | `JacobiConcrete.full_sn`, `JacobiConcrete.first_time_unique`, `JacobiConcrete.unique_critical_modulus` |
| App. B | Coordinate determinant and equivalence of its zero set with reduced J2 | F | `JacobiConcrete.AmplitudeChart.rectified_det_J2`, `JacobiConcrete.AmplitudeChart.rectified_det_J2_zero_iff` |
| App. C | Zero adjoint response for rotating controls and conditional augmented annihilator | F | `SE2Control.rotating_zero_energy`, `SE2Control.augmented_annihilator` |
| App. C | Hilbert endpoint derivative, variational conjugacy and index theorem | A | — |
