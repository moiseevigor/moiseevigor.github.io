"""Verify the ranked offsets against Article A's original coefficients."""
import json
import sys
from pathlib import Path

import mpmath as mp

# Run from the research checkout, or pass its research directory.
sys.path.insert(0, sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).parent))
from e154_asymptotic_check import J, root

mp.mp.dps = 70
k = mp.findroot(lambda x: mp.ellipk(x*x) - 2*mp.ellipe(x*x), (0.90, 0.92))
K = mp.ellipk(k*k)
samples = []
for phase in ['-0.7', '0.15', '0.65']:
    psi = mp.mpf(phase)*K
    for sign in [-1, 1]:
        errors = []
        for n in [8, 32, 128, 512]:
            target = (sign*K-psi)/2
            determinant = lambda h: J(h, psi, k, n)
            h = root(determinant, target, mp.mpf('0.001'))
            assert 0 < sign*h < K and abs(determinant(h)) < mp.mpf('1e-55')
            errors.append(float(n*n*abs(h-target)))
        assert abs(errors[-1]/errors[-2]-1) < 0.01
        samples.append(dict(phase=phase, side=sign, scaled_errors=errors))
print(json.dumps(samples, indent=2))
