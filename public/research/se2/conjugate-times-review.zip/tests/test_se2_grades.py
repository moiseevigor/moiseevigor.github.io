from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
PROGRAM = ROOT / "scripts/review/se2_grades.py"


def test_current_elegance_reviews():
    subprocess.run([sys.executable, PROGRAM], check=True)


def test_proof_edit_requires_individual_review(tmp_path):
    import shutil
    for name in ("manuscripts/conjugate_times_se2.tex", "notes/reviews/se2_large_index_assessment.md",
                 "notes/reviews/se2_elegance_fingerprints.json"):
        path = tmp_path / name
        path.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(ROOT / name, path)
    paper = tmp_path / "manuscripts/conjugate_times_se2.tex"
    paper.write_text(paper.read_text().replace(r"\end{proof}", "Changed argument.\n" + r"\end{proof}", 1))
    command = [sys.executable, PROGRAM, "--root", tmp_path]
    result = subprocess.run(command, capture_output=True, text=True)
    assert result.returncode == 1 and "lem:identities" in result.stdout
    subprocess.run(command + ["--accept", "lem:identities"], check=True)
