"""Generate the audit commands and count the reviewed SE(2) claim groups."""
import csv
from collections import Counter
from pathlib import Path
p = Path(__file__).resolve().parent
with (p/'claims.tsv').open() as f:
    rows = list(csv.DictReader(f, delimiter='\t'))
counts = Counter(row['Status'] for row in rows)
assert set(counts) == set('FPAN')
names = set()
for row in rows:
    if row['Status'] in ('F','P'):
        assert row['Lean witnesses'] != '-'
        names.update(row['Lean witnesses'].split())
print('Groups',len(rows),dict(counts),'audit declarations',len(names))
(p/'CoverageAudit.lean').write_text('import SE2Conjugate\n' + ''.join('#print axioms '+name+'\n' for name in sorted(names)))
