"""Track human elegance reviews for the numbered results in the SE(2) manuscript.

Run without arguments to check freshness. After reading a changed argument,
edit its grade and rationale in the assessment, then run --accept LABEL.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[2]
PAPER = "manuscripts/conjugate_times_se2.tex"
REPORT = "notes/reviews/se2_large_index_assessment.md"
RECORD = "notes/reviews/se2_elegance_fingerprints.json"
START = re.compile(r"\\begin\{(lemma|theorem|proposition|remark|corollary)\}")
CELL = re.compile(r"\*\*([ABCDF](?:[+−-])?)\*\*\. (.+?) <!-- grade:([\w:-]+) --> \|$")


def arguments(tex):
    tex = re.sub(r"(?<!\\)%[^\n]*", "", tex)
    starts = list(START.finditer(tex))
    results = {}
    for i, start in enumerate(starts):
        kind = start[1]
        block = tex[start.start():starts[i+1].start() if i+1 < len(starts) else None]
        statement, end, rest = block.partition(r"\end{" + kind + "}")
        label = re.search(r"\\label\{([^}]+)\}", statement)
        if not label or not end or label[1] in results:
            raise ValueError(f"missing or duplicate label or unterminated {kind}")
        source = statement + end
        if kind != "remark":
            proof, close, _ = rest.partition(r"\end{proof}")
            if not close or r"\begin{proof}" not in proof:
                raise ValueError(f"missing proof for {label[1]}")
            source += proof + close
        results[label[1]] = source
    if not results:
        raise ValueError("no numbered results found")
    return results


def fingerprints(root):
    texts = arguments((root / PAPER).read_text())
    cells = {}
    for line in (root / REPORT).read_text().splitlines():
        if line.startswith(("| Lemma ", "| Theorem ", "| Proposition ", "| Remark ", "| Corollary ")):
            match = CELL.search(line)
            if not match or match[3] in cells:
                raise ValueError(f"missing or duplicate grade or label in {line.split(' | ')[0]}")
            cells[match[3]] = match[1] + " " + match[2]
    if cells.keys() != texts.keys():
        raise ValueError("paper and review labels differ: " + ", ".join(sorted(cells.keys() ^ texts.keys())))
    return {label: hashlib.sha256((" ".join(source.split()) + "\n" + cells[label]).encode()).hexdigest()
            for label, source in texts.items()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--accept", metavar="LABEL", help="record an individually reviewed result")
    args = parser.parse_args()
    path = args.root / RECORD
    current = fingerprints(args.root)
    saved = json.loads(path.read_text()) if path.exists() else {}
    if args.accept:
        if args.accept not in current:
            parser.error("unknown result label")
        saved[args.accept] = current[args.accept]
        path.write_text(json.dumps(saved, indent=2, sort_keys=True) + "\n")
    stale = sorted(k for k in saved.keys() | current.keys() if saved.get(k) != current.get(k))
    if stale:
        print("Review required for " + ", ".join(stale))
        return 1
    print(f"{len(current)} numbered results have current elegance reviews")
    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except ValueError as error:
        sys.exit(str(error))
