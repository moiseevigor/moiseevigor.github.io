import SE2Conjugate.CrossingOrder

noncomputable section
open Filter Set
open scoped Topology

namespace JacobiCore

private theorem flat_corner_line (J : JacobiCore) {p ψ : ℝ}
    (h : J.s2 (ψ+p) = 0 ∨ J.s2 (ψ+p) = 1) :
    HasDerivAt (fun x => J.s2 (ψ+x)) 0 p := by
  have hzero : 2 * J.s (ψ+p) * (J.c (ψ+p) * J.d (ψ+p)) = 0 := by
    rcases h with h|h
    · have hs : J.s (ψ+p) = 0 := by unfold s2 at h; nlinarith
      rw [hs]; ring
    · have hc := J.sc (ψ+p)
      change J.s (ψ+p)^2 = 1 at h
      have hc0 : J.c (ψ+p) = 0 := by nlinarith
      rw [hc0]; ring
  have hd := (J.hasDerivAt_s2 (ψ+p)).comp p ((hasDerivAt_id' p).const_add ψ)
  rw [hzero,zero_mul] at hd
  exact hd

/-- At a zero-height corner, a simple one-sided zero of sn²(u) gives
a simple crossing with the opposite derivative. All period representatives are allowed. -/
theorem ordinary_corner_zero (J : JacobiCore) {u : ℝ → ℝ} {S : Set ℝ} {p ψ c : ℝ}
    (hu : u p = 0) (n : ℤ) (hψ : ψ+p = 2*J.K*n) (hc : c ≠ 0)
    (hr : HasDerivWithinAt (fun x => J.s2 (u x)) c S p) :
    J.s2 (ψ+p)-J.s2 (u p) = 0 ∧ -c ≠ 0 ∧
    HasDerivWithinAt (fun x => J.s2 (ψ+x)-J.s2 (u x)) (-c) S p := by
  have h : J.s2 (ψ+p) = 0 := by simpa [hψ,J.s2_zero] using J.s2_shift_int n 0
  refine ⟨by rw [hu,h,J.s2_zero,sub_self],neg_ne_zero.mpr hc,?_⟩
  have hd := (J.flat_corner_line (Or.inl h)).hasDerivWithinAt.sub hr
  rw [zero_sub] at hd
  exact hd

/-- At a K-corner the crossing has the derivative of 1-sn²(u). -/
theorem ordinary_corner_K (J : JacobiCore) {u : ℝ → ℝ} {S : Set ℝ} {p ψ c : ℝ}
    (hu : u p = J.K) (n : ℤ) (hψ : ψ+p = J.K+2*J.K*n) (hc : c ≠ 0)
    (hr : HasDerivWithinAt (fun x => 1-J.s2 (u x)) c S p) :
    J.s2 (ψ+p)-J.s2 (u p) = 0 ∧ c ≠ 0 ∧
    HasDerivWithinAt (fun x => J.s2 (ψ+x)-J.s2 (u x)) c S p := by
  have h : J.s2 (ψ+p) = 1 := by rw [hψ,J.s2_shift_int,J.s2_K]
  refine ⟨by rw [hu,h,J.s2_K,sub_self],hc,?_⟩
  have hd := ((J.flat_corner_line (Or.inr h)).hasDerivWithinAt.sub_const 1).add hr
  rw [zero_add] at hd
  change HasDerivWithinAt (fun x => (J.s2 (ψ+x)-1)+(1-J.s2 (u x))) c S p at hd
  simpa only [sub_add_sub_cancel] using hd

end JacobiCore

namespace CrossingData

/-- One-sided extension only constrains the lift inside its bracket. -/
def EndpointRegular (u : ℝ → ℝ) (I : Set ℝ) (e : ℝ) : Prop :=
  Tendsto (fun x => |deriv u x|) (𝓝[I] e) atTop ∨
    ∃ v : ℝ → ℝ, AnalyticAt ℝ v e ∧ u =ᶠ[𝓝[I] e] v

/-- Analytic continuation excludes a cluster of interior unit slopes, even when
the cluster point is an endpoint and the lift was defined arbitrarily outside. -/
private theorem no_cluster_extension {u v : ℝ → ℝ} {a b e : ℝ}
    (hu : AnalyticOnNhd ℝ u (Ioo a b)) (hv : AnalyticAt ℝ v e)
    (heq : u =ᶠ[𝓝[Ioo a b] e] v) (hbig : ∃ x ∈ Ioo a b, 1 < |deriv u x|)
    (hfreq : ∃ᶠ x in 𝓝[≠] e, x ∈ Ioo a b ∧ |deriv u x| = 1) : False := by
  let g := fun x => (deriv u x)^2 - 1
  let G := fun x => (deriv v x)^2 - 1
  have hg : AnalyticOnNhd ℝ g (Ioo a b) := fun x hx => ((hu x hx).deriv.pow 2).sub analyticAt_const
  have hG : AnalyticAt ℝ G e := (hv.deriv.pow 2).sub analyticAt_const
  have hmatch : ∀ᶠ x in 𝓝 e, x ∈ Ioo a b → g x = G x := by
    have h := eventually_nhdsWithin_iff.mp heq
    filter_upwards [eventually_eventually_nhds.mpr h] with x hx
    intro hi
    have hev : u =ᶠ[𝓝 x] v := by
      filter_upwards [hx,Ioo_mem_nhds hi.1 hi.2] with t ht htI using ht htI
    simp [g,G,hev.deriv_eq]
  have hz : ∀ᶠ x in 𝓝 e, G x = 0 := hG.frequently_zero_iff_eventually_zero.mp <| by
    apply (hfreq.and_eventually (hmatch.filter_mono nhdsWithin_le_nhds)).mono
    rintro x ⟨⟨hx,h1⟩,hm⟩
    rw [← hm hx]
    dsimp [g]
    rw [← sq_abs,h1]; norm_num
  have hloc : ∀ᶠ x in 𝓝 e, x ∈ Ioo a b → g x = 0 := by
    filter_upwards [hz,hmatch] with x hx hm hi using (hm hi).trans hx
  obtain ⟨x,⟨hi,_⟩,hnear⟩ := (hfreq.and_eventually
    ((eventually_eventually_nhds.mpr hloc).filter_mono nhdsWithin_le_nhds)).exists
  have hzero : g =ᶠ[𝓝 x] 0 := by
    filter_upwards [hnear,Ioo_mem_nhds hi.1 hi.2] with t ht htI using ht htI
  have hall := hg.eqOn_zero_of_preconnected_of_eventuallyEq_zero isPreconnected_Ioo hi hzero
  obtain ⟨y,hy,hgt⟩ := hbig
  have h1 : (deriv u y)^2 - 1 = 0 := hall hy
  nlinarith [sq_abs (deriv u y),mul_self_lt_mul_self (by norm_num : (0:ℝ) ≤ 1) hgt]

theorem finite_unit_slopes {u : ℝ → ℝ} {a b : ℝ}
    (hu : AnalyticOnNhd ℝ u (Ioo a b)) (hbig : ∃ x ∈ Ioo a b, 1 < |deriv u x|)
    (ha : EndpointRegular u (Ioo a b) a) (hb : EndpointRegular u (Ioo a b) b) :
    {x ∈ Ioo a b | |deriv u x| = 1}.Finite := by
  by_contra h
  obtain ⟨e,he,hacc⟩ := Set.Infinite.exists_accPt_of_subset_isCompact h isCompact_Icc
    (fun x hx => Ioo_subset_Icc_self hx.1)
  have hf := accPt_iff_frequently_nhdsNE.mp hacc
  have reg : EndpointRegular u (Ioo a b) e := by
    rcases he.1.eq_or_lt with heq|hlo
    · rwa [← heq]
    rcases he.2.eq_or_lt with heq|hhi
    · rwa [heq]
    exact Or.inr ⟨u,hu e ⟨hlo,hhi⟩,EventuallyEq.rfl⟩
  rcases reg with hinf|⟨v,hv,hev⟩
  · have high := eventually_nhdsWithin_iff.mp (hinf.eventually_gt_atTop 1)
    obtain ⟨x,⟨hi,h1⟩,hx⟩ := (hf.and_eventually (high.filter_mono nhdsWithin_le_nhds)).exists
    exact (ne_of_gt (hx hi)) h1
  · exact no_cluster_extension hu hv hev hbig hf

/-- Actual signed tangent phases, with their period representatives identified. -/
theorem finite_tangency_phases {u : ℝ → ℝ} {a b K : ℝ}
    (hu : AnalyticOnNhd ℝ u (Ioo a b)) (hbig : ∃ x ∈ Ioo a b, 1 < |deriv u x|)
    (ha : EndpointRegular u (Ioo a b) a) (hb : EndpointRegular u (Ioo a b) b) :
    {φ : AddCircle (2*K) | ∃ x ∈ Ioo a b, ∃ σ : ℝ, (σ = 1 ∨ σ = -1) ∧
      σ * deriv u x = 1 ∧ φ = ↑(σ*u x-x)}.Finite := by
  have h := finite_unit_slopes hu hbig ha hb
  let plus := fun x => ((u x-x : ℝ) : AddCircle (2*K))
  let minus := fun x => ((-u x-x : ℝ) : AddCircle (2*K))
  apply ((h.image plus).union (h.image minus)).subset
  rintro φ ⟨x,hx,σ,hσ,ht,rfl⟩
  rcases hσ with rfl|rfl
  · left
    simp only [one_mul] at ht ⊢
    exact ⟨x,⟨hx,by simp [ht]⟩,rfl⟩
  · right
    have hd : deriv u x = -1 := by linarith
    exact ⟨x,⟨hx,by simp [hd]⟩,by simp [minus]⟩

end CrossingData

namespace CrossingData

/-- Derive the monotone-arc hypotheses of the counting theorem from the analytic
lift. A constant segment of the slower branch would extend to the whole interior. -/
private theorem ascending_branches (u : ℝ → ℝ) {a b K : ℝ} (hab : a < b) (hK : 0 < K)
    (hc : ContinuousOn u (Icc a b)) (hu : AnalyticOnNhd ℝ u (Ioo a b))
    (h0 : u a = 0) (h1 : u b = K) (hs : ∀ x ∈ Ioo a b, 1 ≤ |deriv u x|)
    (hbig : ∃ x ∈ Ioo a b, 1 < |deriv u x|) :
    StrictMonoOn (fun x => u x-x) (Icc a b) ∧ StrictAntiOn (fun x => -u x-x) (Icc a b) := by
  obtain ⟨t,ht,hdt⟩ := exists_deriv_eq_slope u hab hc
    (fun x hx => (hu x hx).differentiableAt.differentiableWithinAt)
  have htpos : 0 < deriv u t := by rw [hdt,h0,h1,sub_zero]; exact div_pos hK (sub_pos.mpr hab)
  have hd (x : ℝ) (hx : x ∈ Ioo a b) : 1 ≤ deriv u x := by
    have hpos : 0 < deriv u x := by
      by_contra! hn
      obtain ⟨y,hy,hz⟩ := isPreconnected_Ioo.intermediate_value hx ht
        (fun z hz => (hu z hz).deriv.continuousAt.continuousWithinAt) (show 0 ∈ Icc _ _ from ⟨hn,htpos.le⟩)
      have := hs y hy
      norm_num [hz] at this
    simpa [abs_of_pos hpos] using hs x hx
  let f := fun x => u x - x
  have hf (x : ℝ) (hx : x ∈ Ioo a b) : HasDerivAt f (deriv u x-1) x :=
    (hu x hx).differentiableAt.hasDerivAt.sub (hasDerivAt_id' x)
  have hm : MonotoneOn f (Icc a b) := by
    apply monotoneOn_of_deriv_nonneg (convex_Icc _ _) (hc.sub continuousOn_id)
    · rw [interior_Icc]; exact fun x hx => (hf x hx).differentiableAt.differentiableWithinAt
    · rw [interior_Icc]; exact fun x hx => (hf x hx).deriv ▸ sub_nonneg.mpr (hd x hx)
  constructor
  · intro x hx y hy hxy
    refine lt_of_le_of_ne (hm hx hy hxy.le) ?_
    intro he
    let m := (x+y)/2
    have hmxy : m ∈ Ioo x y := by dsimp [m]; constructor <;> linarith
    have hma : m ∈ Ioo a b := ⟨hx.1.trans_lt hmxy.1,hmxy.2.trans_le hy.2⟩
    have hconst : f =ᶠ[𝓝 m] fun _ => f x := by
      filter_upwards [Ioo_mem_nhds hmxy.1 hmxy.2] with z hz
      have hzI : z ∈ Icc a b := ⟨hx.1.trans hz.1.le,hz.2.le.trans hy.2⟩
      exact le_antisymm ((hm hzI hy hz.2.le).trans_eq he.symm) (hm hx hzI hz.1.le)
    have hall := (show AnalyticOnNhd ℝ f (Ioo a b) from fun z hz => (hu z hz).sub analyticAt_id
      ).eqOn_of_preconnected_of_eventuallyEq analyticOnNhd_const isPreconnected_Ioo hma hconst
    obtain ⟨z,hz,hgt⟩ := hbig
    have hez : f =ᶠ[𝓝 z] fun _ => f x := Filter.eventuallyEq_of_mem (Ioo_mem_nhds hz.1 hz.2) fun w hw => hall hw
    have he1 := (hf z hz).unique ((hasDerivAt_const z (f x)).congr_of_eventuallyEq hez)
    rw [show deriv u z = 1 by linarith, abs_one] at hgt
    exact lt_irrefl _ hgt
  · apply strictAntiOn_of_deriv_neg (convex_Icc _ _) (hc.neg.sub continuousOn_id)
    rw [interior_Icc]
    intro x hx
    have hh : HasDerivAt (-u - id) (-deriv u x-1) x :=
      (hu x hx).differentiableAt.hasDerivAt.neg.sub (hasDerivAt_id x)
    rw [hh.deriv]
    linarith [hd x hx]

private def ascendingData (u : ℝ → ℝ) {a b K : ℝ} (hab : a < b) (hK : 0 < K)
    (hc : ContinuousOn u (Icc a b)) (hu : AnalyticOnNhd ℝ u (Ioo a b))
    (h0 : u a = 0) (h1 : u b = K) (hs : ∀ x ∈ Ioo a b, 1 ≤ |deriv u x|)
    (hbig : ∃ x ∈ Ioo a b, 1 < |deriv u x|) : CrossingData :=
  let H := ascending_branches u hab hK hc hu h0 h1 hs hbig
  ⟨K,hK,a,b,hab,u,hc,h0,h1,H.1,H.2⟩

private def hit (u : ℝ → ℝ) (K ψ x : ℝ) : Prop :=
  ∃ σ : ℝ, (σ = 1 ∨ σ = -1) ∧ ∃ n : ℤ, σ*u x-x = ψ+2*K*n

private theorem reflected_hit (u : ℝ → ℝ) (K ψ x : ℝ) :
    hit (fun z => K-u z) K (ψ+K) x ↔ hit u K ψ x := by
  constructor
  · rintro ⟨σ,hσ,n,hn⟩
    rcases hσ with rfl|rfl
    · exact ⟨-1,Or.inr rfl,n,by dsimp at hn; linarith⟩
    · exact ⟨1,Or.inl rfl,n+1,by push_cast; dsimp at hn; linarith⟩
  · rintro ⟨σ,hσ,n,hn⟩
    rcases hσ with rfl|rfl
    · exact ⟨-1,Or.inr rfl,n-1,by push_cast; linarith⟩
    · exact ⟨1,Or.inl rfl,n,by dsimp; linarith⟩

/-- The width and phase crossing conclusions with either endpoint orientation and
the original analytic hypotheses. Unbounded slope is used only above one. -/
theorem analytic_crossing {u : ℝ → ℝ} {a b K : ℝ} (hab : a < b) (hK : 0 < K)
    (hc : ContinuousOn u (Icc a b)) (hu : AnalyticOnNhd ℝ u (Ioo a b))
    (ends : (u a = 0 ∧ u b = K) ∨ (u a = K ∧ u b = 0))
    (hs : ∀ x ∈ Ioo a b, 1 ≤ |deriv u x|) (hbig : ∃ x ∈ Ioo a b, 1 < |deriv u x|) :
    b-a < K ∧ ∀ ψ : ℝ, ∃! x, x ∈ Icc a b ∧ ∃ σ : ℝ, (σ = 1 ∨ σ = -1) ∧
      ∃ n : ℤ, σ*u x-x = ψ+2*K*n := by
  rcases ends with ⟨h0,h1⟩|⟨h1,h0⟩
  · let C := ascendingData u hab hK hc hu h0 h1 hs hbig
    exact ⟨C.hi_sub_lo_lt,C.crossing⟩
  · let v := fun x => K-u x
    have hd (x : ℝ) (hx : x ∈ Ioo a b) : |deriv v x| = |deriv u x| := by
      rw [show deriv v x = 0-deriv u x from ((hasDerivAt_const x K).sub (hu x hx).differentiableAt.hasDerivAt).deriv,
        zero_sub,abs_neg]
    let C := ascendingData v hab hK (continuousOn_const.sub hc)
      (fun x hx => analyticAt_const.sub (hu x hx)) (by simp [v,h1]) (by simp [v,h0])
      (fun x hx => (hd x hx).symm ▸ hs x hx)
      (by obtain ⟨x,hx,h⟩ := hbig; exact ⟨x,hx,(hd x hx).symm ▸ h⟩)
    refine ⟨C.hi_sub_lo_lt,fun ψ => ?_⟩
    change ∃! x, x ∈ Icc a b ∧ hit u K ψ x
    simp_rw [← reflected_hit u K ψ]
    exact C.crossing (ψ+K)

end CrossingData

/-- Specialization of the analytic arc count to the SE(2) scalar crossing equation. -/
theorem JacobiCore.analytic_scalar_crossing (J : JacobiCore) {a b : ℝ} {u : ℝ → ℝ}
    (hab : a < b) (hc : ContinuousOn u (Icc a b)) (hu : AnalyticOnNhd ℝ u (Ioo a b))
    (ends : (u a = 0 ∧ u b = J.K) ∨ (u a = J.K ∧ u b = 0))
    (hs : ∀ x ∈ Ioo a b, 1 ≤ |deriv u x|) (hbig : ∃ x ∈ Ioo a b, 1 < |deriv u x|) (ψ : ℝ) :
    ∃! x, x ∈ Icc a b ∧ J.s2 (ψ+x) - J.s2 (u x) = 0 := by
  have h := (CrossingData.analytic_crossing hab J.K_pos hc hu ends hs hbig).2 ψ
  have eqv (x : ℝ) : J.s2 (ψ+x)-J.s2 (u x) = 0 ↔ ∃ σ : ℝ, (σ = 1 ∨ σ = -1) ∧
      ∃ n : ℤ, σ*u x-x = ψ+2*J.K*n := by
    rw [sub_eq_zero]
    change J.s (ψ+x)^2 = J.s (u x)^2 ↔ _
    rw [J.sn_sq_eq_iff]
    constructor
    · rintro ⟨n,hn|hn⟩
      · exact ⟨1,Or.inl rfl,-n,by push_cast; linarith⟩
      · exact ⟨-1,Or.inr rfl,-n,by push_cast; linarith⟩
    · rintro ⟨σ,hσ,n,hn⟩
      rcases hσ with rfl|rfl
      · exact ⟨-n,Or.inl (by push_cast; linarith)⟩
      · exact ⟨-n,Or.inr (by push_cast; linarith)⟩
  simpa only [eqv] using h

/-- A nonzero linear leading coefficient from inside the bracket, at either
ordinary corner and with either endpoint orientation. -/
theorem JacobiCore.ordinary_corner_order (J : JacobiCore) {u : ℝ → ℝ} {a b p ψ : ℝ}
    (hab : a < b) (hp : p = a ∨ p = b) (n : ℤ)
    (h : (u p = 0 ∧ ψ+p = 2*J.K*n ∧ ∃ c ≠ 0,
             HasDerivWithinAt (fun x => J.s2 (u x)) c (Icc a b) p) ∨
         (u p = J.K ∧ ψ+p = J.K+2*J.K*n ∧ ∃ c ≠ 0,
             HasDerivWithinAt (fun x => 1-J.s2 (u x)) c (Icc a b) p)) :
    NeBot (𝓝[Ioo a b] p) ∧ J.s2 (ψ+p)-J.s2 (u p) = 0 ∧ ∃ L ≠ 0, Tendsto
      (fun x => (J.s2 (ψ+x)-J.s2 (u x))/(x-p)) (𝓝[Ioo a b] p) (𝓝 L) := by
  let F := fun x => J.s2 (ψ+x)-J.s2 (u x)
  have hD : F p = 0 ∧ ∃ L ≠ 0, HasDerivWithinAt F L (Icc a b) p := by
    rcases h with ⟨hu,he,c,hc,hr⟩|⟨hu,he,c,hc,hr⟩
    · obtain ⟨hz,hn,hd⟩ := J.ordinary_corner_zero hu n he hc hr
      exact ⟨hz,-c,hn,hd⟩
    · obtain ⟨hz,hn,hd⟩ := J.ordinary_corner_K hu n he hc hr
      exact ⟨hz,c,hn,hd⟩
  obtain ⟨hz,L,hn,hd⟩ := hD
  have hout : p ∉ Ioo a b := by rcases hp with rfl|rfl <;> simp
  have lim := (hasDerivWithinAt_iff_tendsto_slope' hout).mp (hd.mono Ioo_subset_Icc_self)
  have hnb : NeBot (𝓝[Ioo a b] p) := mem_closure_iff_nhdsWithin_neBot.mp (by
    rw [closure_Ioo hab.ne]; rcases hp with rfl|rfl <;> simp [hab.le])
  refine ⟨hnb,hz,L,hn,lim.congr (fun x => ?_)⟩
  change slope F p x = F x / (x-p)
  simp [slope_def_module,hz,smul_eq_mul,div_eq_inv_mul]

/-- Scalar order for an arbitrary analytic lift in Lemma 3.3. Strict differentiability
of sn² transfers a leading term between two moving arguments with the same limit. -/
theorem JacobiCore.analytic_interior_order (J : JacobiCore) {u : ℝ → ℝ} {a b p σ ψ : ℝ}
    (hp : p ∈ Ioo a b) (hu : AnalyticOnNhd ℝ u (Ioo a b))
    (hrange : MapsTo u (Icc a b) (Icc 0 J.K)) (hσ : σ = 1 ∨ σ = -1)
    (hs : ∀ x ∈ Ioo a b, 1 ≤ |deriv u x|) (hbig : ∃ x ∈ Ioo a b, 1 < |deriv u x|)
    (n : ℤ) (he : ψ+p = σ*u p + 2*J.K*n) :
    ∃ m : ℕ, (if σ*deriv u p = 1 then Odd m ∧ 3 ≤ m else m = 1) ∧
      ∃ c ≠ 0, Tendsto (fun x => (J.s2 (ψ+x)-J.s2 (u x))/(x-p)^m) (𝓝[≠] p) (𝓝 c) := by
  let g := fun x => σ*(u x-u p)-(x-p)
  have hz : g p = 0 := by simp [g]
  have ha : AnalyticAt ℝ g p :=
    (analyticAt_const.mul ((hu p hp).sub analyticAt_const)).sub (analyticAt_id.sub analyticAt_const)
  have hd : HasDerivAt g (σ*deriv u p-1) p :=
    ((((hu p hp).differentiableAt.hasDerivAt.sub_const (u p)).const_mul σ).sub
      ((hasDerivAt_id' p).sub_const p))
  obtain ⟨m,hm,ho⟩ : ∃ m : ℕ, (if σ*deriv u p = 1 then Odd m ∧ 3 ≤ m else m=1) ∧
      analyticOrderAt g p = m := by
    by_cases ht : σ*deriv u p = 1
    · obtain ⟨m,h1,h2,h3⟩ := CrossingData.analytic_signed_order hp hu hσ hs hbig ht
      exact ⟨m,by simpa [ht] using And.intro h1 h2,h3⟩
    · refine ⟨1,by simp [ht],?_⟩
      simpa using ha.analyticOrderAt_eq_one_of_zero_deriv_ne_zero hz (hd.deriv ▸ sub_ne_zero.mpr ht)
  obtain ⟨v,hv,hv0,hfac⟩ := ha.analyticOrderAt_eq_natCast.mp ho
  let w := fun x => σ*u x + 2*J.K*n
  have hper (x : ℝ) : J.s2 (w x) = J.s2 (u x) := by
    apply (J.sn_sq_eq_iff _ _).2
    refine ⟨n,?_⟩
    rcases hσ with h|h
    · left; simp [w,h]
    · right; simp [w,h]
  have hdiff : Tendsto (fun x => (ψ+x-w x)/(x-p)^m) (𝓝[≠] p) (𝓝 (-v p)) := by
    apply Tendsto.congr' _ (hv.continuousAt.tendsto.neg.mono_left nhdsWithin_le_nhds)
    filter_upwards [hfac.filter_mono nhdsWithin_le_nhds,self_mem_nhdsWithin] with x hx hxp
    have hnx : x-p ≠ 0 := sub_ne_zero.mpr (show x ≠ p from hxp)
    have hh : ψ+x-w x = -g x := by dsimp [g,w]; linarith only [he]
    rw [hh,hx]
    simp only [smul_eq_mul]; field_simp [hnx]
  have hn : deriv u p ≠ 0 := by intro h; have := hs p hp; norm_num [h] at this
  have hui : u p ∈ Ioo 0 J.K := by
    have h := hrange (Ioo_subset_Icc_self hp)
    refine ⟨lt_of_le_of_ne h.1 ?_,lt_of_le_of_ne h.2 ?_⟩
    · intro h0
      apply hn
      apply IsLocalMin.deriv_eq_zero
      filter_upwards [Ioo_mem_nhds hp.1 hp.2] with x hx
      exact h0 ▸ (hrange (Ioo_subset_Icc_self hx)).1
    · intro h1
      apply hn
      apply IsLocalMax.deriv_eq_zero
      filter_upwards [Ioo_mem_nhds hp.1 hp.2] with x hx
      exact h1.symm ▸ (hrange (Ioo_subset_Icc_self hx)).2
  let t := ψ+p
  have hsq : J.s2 t = J.s2 (u p) := (congrArg J.s2 he).trans (hper p)
  have hi := Ioo_subset_Icc_self hui
  have ht0 : 0 < J.s2 t := by
    rw [hsq,← J.s2_zero]; exact J.s2_strictMonoOn ⟨le_rfl,J.K_pos.le⟩ hi hui.1
  have ht1 : J.s2 t < 1 := by
    rw [hsq,← J.s2_K]; exact J.s2_strictMonoOn hi ⟨J.K_pos.le,le_rfl⟩ hui.2
  let d := fun x => 2*J.s x*(J.c x*J.d x)
  have hd0 : d t ≠ 0 := by
    change 0 < J.s t^2 at ht0
    change J.s t^2 < 1 at ht1
    have hsn : J.s t ≠ 0 := by intro h; norm_num [h] at ht0
    have hcn : J.c t ≠ 0 := by intro h; have hsc := J.sc t; rw [h] at hsc; nlinarith
    exact mul_ne_zero (mul_ne_zero (by norm_num) hsn) (mul_ne_zero hcn (J.d_pos t).ne')
  have hstrict : HasStrictDerivAt J.s2 (d t) t :=
    hasStrictDerivAt_of_hasDerivAt_of_continuousAt (Eventually.of_forall J.hasDerivAt_s2)
      ((continuousAt_const.mul (J.hs t).continuousAt).mul ((J.hc t).continuousAt.mul (J.hd t).continuousAt))
  have hw : ContinuousAt w p := (continuousAt_const.mul (hu p hp).continuousAt).add continuousAt_const
  have hpair : Tendsto (fun x => (ψ+x,w x)) (𝓝[≠] p) (𝓝 (t,t)) := by
    nth_rw 2 [show t = w p from he]
    exact ((continuousAt_const.add continuousAt_id).prodMk hw).tendsto.mono_left nhdsWithin_le_nhds
  have herr := ((hasDerivAtFilter_iff_isLittleO.mp hstrict).comp_tendsto hpair).tendsto_div_nhds_zero
  have hsec : Tendsto (fun x => d t + (J.s2 (ψ+x)-J.s2 (w x)-(ψ+x-w x)*d t)/(ψ+x-w x))
      (𝓝[≠] p) (𝓝 (d t)) := by
    simpa only [smul_eq_mul,Function.comp_apply,add_zero] using (tendsto_const_nhds (x := d t)).add herr
  refine ⟨m,hm,_,mul_ne_zero hd0 (neg_ne_zero.mpr hv0),?_⟩
  apply Tendsto.congr' _ (hsec.mul hdiff)
  filter_upwards [hdiff.eventually_ne (neg_ne_zero.mpr hv0)] with x hx
  have hnx : ψ+x-w x ≠ 0 := fun h => hx (by rw [h,zero_div])
  change (_ + _) * _ = _
  rw [← hper x]
  field_simp [hnx]
  ring
