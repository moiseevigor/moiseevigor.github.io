import SE2Conjugate.RiccatiDeficit
import SE2Conjugate.CriticalContact

noncomputable section
open Filter Set
open scoped Topology
namespace SBracket

variable (B : SBracket)
local notation "J" => B.toJacobiData

private def rad (x : ℝ) := (J).z x * (1 - (J).z x) * (J).Dz x
private def speed (x : ℝ) := B.ε * (B.zp x / (2 * Real.sqrt (B.rad x)))
private def scale (x : ℝ) := 4 * (B.d x * B.s x)^2 * B.rad x * (B.speed x + 1)

/-- The signed phase relative to its value at the crossing. -/
def phaseGap (σ p x : ℝ) := σ * (B.u x - B.u p) - (x-p)

private theorem rad_pos {p : ℝ} (hp : p ∈ Ioo B.p0 B.p1) : 0 < B.rad p :=
  mul_pos (mul_pos (B.z_pos hp) (sub_pos.mpr (B.z_lt_one hp))) (B.Dz_pos' hp)

private theorem scale_pos {p : ℝ} (hp : p ∈ Ioo B.p0 B.p1) : 0 < B.scale p := by
  have h : 1 ≤ B.speed p := B.one_le_ε_deriv_u hp
  have := B.rad_pos hp
  have ds := mul_ne_zero (B.d_pos p).ne' (B.s_ne hp)
  unfold scale
  positivity

private theorem speed_gap {p : ℝ} (hp : p ∈ Ioo B.p0 B.p1) :
    B.speed p - 1 = (J).H p ^ 2 / B.scale p := by
  have hprod := (J).T1_mul_T2 p
  change (J).T1 p * (J).T2 p = (B.d p * B.s p)^2 * B.rad p at hprod
  have hr := B.rad_pos hp
  have hds := mul_ne_zero (B.d_pos p).ne' (B.s_ne hp)
  have hsquare : (B.speed p)^2 * (4 * (B.d p * B.s p)^2 * B.rad p) =
      ((J).T1 p + (J).T2 p)^2 := by
    unfold speed zp
    rw [mul_pow, B.ε_sq, one_mul, div_pow, div_pow, mul_pow (2 : ℝ), Real.sq_sqrt hr.le]
    field_simp [hds, hr.ne', (B.d_pos p).ne', B.s_ne hp]
    ring
  rw [eq_div_iff (B.scale_pos hp).ne']
  unfold scale JacobiData.H
  linear_combination hsquare + 4 * hprod

private theorem scale_cont {p : ℝ} (hp : p ∈ Ioo B.p0 B.p1) : ContinuousAt B.scale p := by
  have hq : (J).q p ≠ 0 := (B.q_pos p (Ioo_subset_Icc_self hp)).ne'
  have he := (B.eps_pos p (Ioo_subset_Icc_self hp)).ne'
  have hs := B.s_ne hp
  have hd := (B.d_pos p).ne'
  have ha := ((J).hasDerivAt_a p hq hs hd).continuousAt
  have hb := ((J).hasDerivAt_b p he hs hd).continuousAt
  have hz := ((J).hasDerivAt_z p hq he hs hd).continuousAt
  have hD := (B.hasDerivAt_Dz p hq he hs hd).continuousAt
  have hc := (B.hd p).continuousAt
  have hsn := (B.hs p).continuousAt
  have hR : ContinuousAt B.rad p := (hz.mul (continuousAt_const.sub hz)).mul hD
  have hT : ContinuousAt (J).T1 p := ((hc.pow 2).mul hb).mul (continuousAt_const.sub hz)
  have hU : ContinuousAt (J).T2 p := ((hsn.pow 2).mul ha).mul hD
  have hzp : ContinuousAt B.zp p := (hT.add hU).div (hc.mul hsn) (mul_ne_zero hd hs)
  have hv : ContinuousAt B.speed p := continuousAt_const.mul (hzp.div
    (continuousAt_const.mul hR.sqrt) (mul_ne_zero (by norm_num) (Real.sqrt_pos.mpr (B.rad_pos hp)).ne'))
  exact ((continuousAt_const.mul ((hc.mul hsn).pow 2)).mul hR).mul (hv.add continuousAt_const)

private theorem gap_deriv (σ p : ℝ) {x : ℝ} (hx : x ∈ Ioo B.p0 B.p1) :
    HasDerivAt (B.phaseGap σ p) (σ * deriv B.u x - 1) x := by
  exact ((((B.hasDerivAt_u hx).differentiableAt.hasDerivAt.sub_const (B.u p)).const_mul σ).sub
    ((hasDerivAt_id' x).sub_const p))

/-- Tangency occurs exactly on the co-oriented branch at Riccati equality. -/
theorem signed_tangency {σ p : ℝ} (hσ : σ = 1 ∨ σ = -1) (hp : p ∈ Ioo B.p0 B.p1) :
    deriv (B.phaseGap σ p) p = 0 ↔ σ = B.ε ∧ (J).H p = 0 := by
  have h := B.gap_deriv σ p hp
  have hv : B.speed p = B.ε * deriv B.u p := by rw [(B.hasDerivAt_u hp).deriv]; rfl
  have h1 : 1 ≤ B.speed p := B.one_le_ε_deriv_u hp
  rw [h.deriv]
  constructor
  · intro he
    have hsign : σ = B.ε := by
      rcases hσ with hσ|hσ <;> rcases B.hε with hε|hε <;> rw [hσ,hε] <;>
        first | rfl | (rw [hv,hε] at h1; rw [hσ] at he; linarith)
    exact ⟨hsign, B.H_zero_of_unit_slope hp (by change B.speed p = 1; rw [hv, ← hsign]; linarith)⟩
  · rintro ⟨rfl,hH⟩
    have hg := B.speed_gap hp
    simpa [hv,hH] using hg

/-- The crossing is simple on every branch whose signed slope differs from one. -/
theorem simple_phase {σ p : ℝ} (hp : p ∈ Ioo B.p0 B.p1) (hn : σ * deriv B.u p ≠ 1) :
    ∃ c : ℝ, c ≠ 0 ∧ Tendsto (fun x => B.phaseGap σ p x / (x-p)) (𝓝[≠] p) (𝓝 c) := by
  refine ⟨_, sub_ne_zero.mpr hn, ?_⟩
  apply Tendsto.congr' _ (B.gap_deriv σ p hp).tendsto_slope
  exact Eventually.of_forall fun x => by simp [slope_def_module, phaseGap, smul_eq_mul, div_eq_inv_mul]

/-- A co-oriented equality point has strictly positive cubic leading coefficient. -/
theorem cubic_phase {p : ℝ} (hp : p ∈ Ioo B.p0 B.p1) (hH : (J).H p = 0) :
    ∃ c : ℝ, 0 < c ∧ Tendsto (fun x => B.phaseGap B.ε p x / (x-p)^3) (𝓝[≠] p) (𝓝 c) := by
  have hq : (J).q p ≠ 0 := (B.q_pos p (Ioo_subset_Icc_self hp)).ne'
  have he := (B.eps_pos p (Ioo_subset_Icc_self hp)).ne'
  have hd := (B.d_pos p).ne'
  have hH' := (J).hasDerivAt_H p hq he (B.s_ne hp) hd
  have hn := (J).Hp_ne_of_H_zero p hq (B.s_ne hp) hd (B.z_pos hp) hH
  have hl : Tendsto (fun x => (J).H x / (x-p)) (𝓝[≠] p) (𝓝 ((J).Hp p)) := by
    apply Tendsto.congr' _ hH'.tendsto_slope
    exact Eventually.of_forall fun x => by simp [slope_def_module,hH,smul_eq_mul,div_eq_inv_mul]
  have hscale := B.scale_pos hp
  refine ⟨((J).Hp p)^2 / B.scale p / 3, by positivity, ?_⟩
  have hI : ∀ᶠ x in 𝓝[≠] p, x ∈ Ioo B.p0 B.p1 :=
    mem_nhdsWithin_of_mem_nhds (Ioo_mem_nhds hp.1 hp.2)
  have hlin (x : ℝ) := (hasDerivAt_id' x).sub_const p
  apply HasDerivAt.lhopital_zero_nhdsNE (f' := fun x => B.speed x - 1)
    (g' := fun x => 3 * (x-p)^2)
  · filter_upwards [hI] with x hx
    simpa only [speed, rad, (B.hasDerivAt_u hx).deriv] using B.gap_deriv B.ε p hx
  · exact Eventually.of_forall fun x => by simpa only [Pi.pow_def,Nat.cast_ofNat, Nat.reduceSub, mul_one] using (hlin x).pow 3
  · filter_upwards [self_mem_nhdsWithin] with x hx
    exact mul_ne_zero (by norm_num) (pow_ne_zero 2 (sub_ne_zero.mpr (show x ≠ p from hx)))
  · simpa [phaseGap] using (B.gap_deriv B.ε p hp).continuousAt.tendsto.mono_left nhdsWithin_le_nhds
  · simpa using ((hlin p).continuousAt.tendsto.mono_left nhdsWithin_le_nhds).pow 3
  · apply Tendsto.congr' _ (((hl.pow 2).div ((B.scale_cont hp).tendsto.mono_left nhdsWithin_le_nhds)
        hscale.ne').div_const 3)
    filter_upwards [hI] with x hx
    change (((J).H x / (x-p))^2 / B.scale x) / 3 = _
    rw [B.speed_gap hx]
    simp only [div_pow, div_div, mul_assoc, mul_comm, mul_left_comm]


/-- A simple or cubic leading term survives composition with sn² at an interior crossing,
including any representative of the phase modulo 2K. -/
private theorem scalar_transfer {p ψ σ c : ℝ} {m : ℕ} (hp : p ∈ Ioo B.p0 B.p1)
    (hσ : σ = 1 ∨ σ = -1) (n : ℤ) (he : ψ+p = σ*B.u p + 2*B.K*n)
    (hc : c ≠ 0) (hg : Tendsto (fun x => B.phaseGap σ p x / (x-p)^m) (𝓝[≠] p) (𝓝 c)) :
    ∃ a : ℝ, a ≠ 0 ∧ Tendsto (fun x => (B.s (ψ+x)^2 - B.s (B.u x)^2) / (x-p)^m)
      (𝓝[≠] p) (𝓝 a) := by
  let f := fun t => B.s t ^ 2
  let df := fun t => 2 * B.s t * (B.c t * B.d t)
  let t := ψ+p
  let v := fun x => σ*B.u x + 2*B.K*n
  have hper (x : ℝ) : f (v x) = f (B.u x) := by
    apply (B.sn_sq_eq_iff _ _).2
    refine ⟨n, ?_⟩
    rcases hσ with h|h
    · left; simp [v,h]
    · right; simp [v,h]
  have ht : t = v p := he
  have hr : B.s t ^ 2 = B.r p := by
    calc
      _ = f (v p) := congrArg f ht
      _ = _ := (hper p).trans (B.Finv_spec _ ⟨(B.r_pos hp).le,(B.r_lt_one hp).le⟩)
  have hs : B.s t ≠ 0 := by intro h; have hpos := B.r_pos hp; rw [← hr,h] at hpos; norm_num at hpos
  have hct : B.c t ≠ 0 := by
    intro h
    have hsc := B.sc t
    rw [h,hr] at hsc
    linarith [B.r_lt_one hp]
  have hn : df t ≠ 0 := mul_ne_zero (mul_ne_zero (by norm_num) hs) (mul_ne_zero hct (B.d_pos t).ne')
  have hf (x : ℝ) : HasDerivAt f (df x) x := by
    simpa [df,f,Pi.pow_def] using (B.hs x).pow 2
  have hstrict : HasStrictDerivAt f (df t) t :=
    hasStrictDerivAt_of_hasDerivAt_of_continuousAt (Eventually.of_forall hf)
      ((continuousAt_const.mul (B.hs t).continuousAt).mul ((B.hc t).continuousAt.mul (B.hd t).continuousAt))
  have hv : ContinuousAt v p :=
    (continuousAt_const.mul (B.hasDerivAt_u hp).continuousAt).add continuousAt_const
  have hpair : Tendsto (fun x => (ψ+x,v x)) (𝓝[≠] p) (𝓝 (t,t)) := by
    nth_rw 2 [ht]
    exact ((continuousAt_const.add continuousAt_id).prodMk hv).tendsto.mono_left nhdsWithin_le_nhds
  have hsmall := ((hasDerivAtFilter_iff_isLittleO.mp hstrict).comp_tendsto hpair).tendsto_div_nhds_zero
  have hgap (x : ℝ) : ψ+x-v x = -B.phaseGap σ p x := by
    dsimp [phaseGap,v]
    linarith only [he]
  have hdiff : Tendsto (fun x => (ψ+x-v x)/(x-p)^m) (𝓝[≠] p) (𝓝 (-c)) := by
    simpa only [hgap, neg_div] using hg.neg
  have hne := hdiff.eventually_ne (neg_ne_zero.mpr hc)
  refine ⟨df t * (-c), mul_ne_zero hn (neg_ne_zero.mpr hc), ?_⟩
  apply Tendsto.congr' _ ((show Tendsto (fun x => df t +
    (f (ψ+x)-f (v x)-(ψ+x-v x)*df t)/(ψ+x-v x)) (𝓝[≠] p) (𝓝 (df t)) by
      simpa only [smul_eq_mul, Function.comp_apply,add_zero] using
        ((tendsto_const_nhds (x := df t)).add hsmall)).mul hdiff)
  filter_upwards [hne] with x hx
  have hnx : ψ+x-v x ≠ 0 := fun h => hx (by rw [h,zero_div])
  change (_ + _) * _ = (f (ψ+x) - f (B.u x)) / _
  rw [← hper x]
  field_simp [hnx]
  ring

/-- Exact scalar crossing orders for both signed branches in the open SE(2) brackets. -/
theorem scalar_crossing_order {p ψ σ : ℝ} (hp : p ∈ Ioo B.p0 B.p1)
    (hσ : σ = 1 ∨ σ = -1) (n : ℤ) (he : ψ+p = σ*B.u p + 2*B.K*n) :
    ∃ a : ℝ, a ≠ 0 ∧ Tendsto (fun x => (B.s (ψ+x)^2 - B.s (B.u x)^2) /
      (x-p)^(if σ * deriv B.u p = 1 then 3 else 1 : ℕ)) (𝓝[≠] p) (𝓝 a) := by
  split_ifs with h
  · have heq := (B.signed_tangency hσ hp).mp (by rw [(B.gap_deriv σ p hp).deriv,h,sub_self])
    obtain ⟨c,hc,hl⟩ := B.cubic_phase hp heq.2
    exact B.scalar_transfer hp hσ n he hc.ne' (heq.1 ▸ hl)
  · obtain ⟨c,hc,hl⟩ := B.simple_phase hp h
    exact B.scalar_transfer hp hσ n he hc (by simpa using hl)

/-- The reduced Jacobian has the same order as the scalar crossing. -/
theorem determinant_crossing_order {p ψ σ : ℝ} (hp : p ∈ Ioo B.p0 B.p1)
    (hσ : σ = 1 ∨ σ = -1) (n : ℤ) (he : ψ+p = σ*B.u p + 2*B.K*n) :
    ∃ a : ℝ, a ≠ 0 ∧ Tendsto (fun x => B.J2 (ψ+x) x /
      (x-p)^(if σ * deriv B.u p = 1 then 3 else 1 : ℕ)) (𝓝[≠] p) (𝓝 a) := by
  obtain ⟨a,ha,hlim⟩ := B.scalar_crossing_order hp hσ n he
  have hc (x : ℝ) (hx : x ∈ Ioo B.p0 B.p1) : B.J2 (ψ+x) x =
      (J).ell x * (J).Dz x * (B.s (ψ+x)^2-B.s (B.u x)^2) := by
    have hi := Ioo_subset_Icc_self hx
    have hu : B.s (B.u x)^2 = B.r x := B.Finv_spec _ (B.r_mem_Icc hi)
    have hz := (J).z_eq_neg_beta_div_ell x (B.q_pos x hi).ne' (B.eps_pos x hi).ne'
    have hz' := (eq_div_iff (B.ell_pos_Icc hi).ne').mp hz
    have hD := (B.Dz_pos' hx).ne'
    have hsc := B.sc (ψ+x)
    have hab := B.alpha_sub_beta hi
    rw [hu, r, J2]
    field_simp [hD]
    linear_combination (B.s (ψ+x)^2) * hab + (J).β x * hsc + hz'
  have hi := Ioo_subset_Icc_self hp
  have hcont : ContinuousAt (fun x => (J).ell x * (J).Dz x) p :=
    (((B.heps p).continuousAt).mul ((J).hasDerivAt_q p).continuousAt).mul
      (B.hasDerivAt_Dz p (B.q_pos p hi).ne' (B.eps_pos p hi).ne' (B.s_ne hp)
        (B.d_pos p).ne').continuousAt
  refine ⟨_,mul_ne_zero (mul_ne_zero (B.ell_pos_Icc hi).ne' (B.Dz_pos' hp).ne') ha,?_⟩
  apply Tendsto.congr' _ ((hcont.tendsto.mono_left nhdsWithin_le_nhds).mul hlim)
  filter_upwards [mem_nhdsWithin_of_mem_nhds (Ioo_mem_nhds hp.1 hp.2)] with x hx
  rw [hc x hx]
  simp [mul_div_assoc]

end SBracket

namespace CrossingData

/-- A nonnegative real analytic germ of finite order has even order.
The sign of its analytic unit on the right determines its sign on the left. -/
private theorem even_order {g : ℝ → ℝ} {p : ℝ} (hg : AnalyticAt ℝ g p)
    (hn : analyticOrderAt g p ≠ ⊤) (hpos : ∀ᶠ x in 𝓝 p, 0 ≤ g x) :
    Even (analyticOrderNatAt g p) := by
  obtain ⟨v,hv,hv0,he⟩ := hg.analyticOrderAt_ne_top.mp hn
  have hvp : 0 < v p := by
    by_contra! h
    have hneg := hv.continuousAt.eventually_lt (continuousAt_const (y := (0:ℝ))) (lt_of_le_of_ne h hv0)
    obtain ⟨x,hx,hval,hfac,hg0⟩ := ((frequently_gt_nhds p).and_eventually
      (hneg.and (he.and hpos))).exists
    simp only [hfac,smul_eq_mul] at hg0
    exact (not_lt_of_ge hg0) (mul_neg_of_pos_of_neg (pow_pos (sub_pos.mpr hx) _) hval)
  by_contra h
  have ho := Nat.not_even_iff_odd.mp h
  have hplus : ∀ᶠ x in 𝓝 p, 0 < v x := hv.continuousAt (Ioi_mem_nhds hvp)
  obtain ⟨x,hx,hval,hfac,hg0⟩ := ((frequently_lt_nhds p).and_eventually
    (hplus.and (he.and hpos))).exists
  simp only [hfac,smul_eq_mul] at hg0
  exact (not_lt_of_ge hg0) (mul_neg_of_neg_of_pos (ho.pow_neg (sub_neg.mpr hx)) hval)

/-- The general analytic tangency in Lemma 3.3. Unbounded absolute slope is used
only to supply a point at which the absolute slope exceeds one. -/
theorem analytic_signed_order {u : ℝ → ℝ} {a b p σ : ℝ} (hp : p ∈ Ioo a b)
    (hu : AnalyticOnNhd ℝ u (Ioo a b)) (hσ : σ = 1 ∨ σ = -1)
    (hb : ∀ x ∈ Ioo a b, 1 ≤ |deriv u x|) (hbig : ∃ x ∈ Ioo a b, 1 < |deriv u x|)
    (ht : σ * deriv u p = 1) :
    ∃ n : ℕ, Odd n ∧ 3 ≤ n ∧
      analyticOrderAt (fun x => σ * (u x-u p) - (x-p)) p = n := by
  let f := fun x => σ * (u x-u p) - (x-p)
  let g := fun x => σ * deriv u x - 1
  have ha : AnalyticAt ℝ f p :=
    (analyticAt_const.mul ((hu p hp).sub analyticAt_const)).sub (analyticAt_id.sub analyticAt_const)
  have hg : AnalyticOnNhd ℝ g (Ioo a b) :=
    fun x hx => (analyticAt_const.mul (hu x hx).deriv).sub analyticAt_const
  have hf (x : ℝ) (hx : x ∈ Ioo a b) : HasDerivAt f (g x) x := by
    exact ((((hu x hx).differentiableAt.hasDerivAt.sub_const (u p)).const_mul σ).sub
      ((hasDerivAt_id' x).sub_const p))
  have hI := Ioo_mem_nhds hp.1 hp.2
  have hn : analyticOrderAt g p ≠ ⊤ := by
    intro h
    have hall := hg.eqOn_zero_of_preconnected_of_eventuallyEq_zero isPreconnected_Ioo hp
      (analyticOrderAt_eq_top.mp h)
    obtain ⟨x,hx,hgt⟩ := hbig
    have h0 : σ * deriv u x - 1 = 0 := hall hx
    rcases hσ with he|he <;> rw [he] at h0
    · rw [show deriv u x = 1 by linarith,abs_one] at hgt; linarith
    · rw [show deriv u x = -1 by linarith,abs_neg,abs_one] at hgt; linarith
  have h0 : g p = 0 := sub_eq_zero.mpr ht
  have hnonneg : ∀ᶠ x in 𝓝 p, 0 ≤ g x := by
    have hsg : 0 < σ * deriv u p := by rw [ht]; norm_num
    filter_upwards [hI, (show ContinuousAt (fun x => σ * deriv u x) p from continuousAt_const.mul (hu p hp).deriv.continuousAt) (Ioi_mem_nhds hsg)]
      with x hx hxpos
    have habs := hb x hx
    have he : |σ * deriv u x| = |deriv u x| := by rcases hσ with h|h <;> simp [h]
    rw [← he,abs_of_pos hxpos] at habs
    exact sub_nonneg.mpr habs
  let m := analyticOrderNatAt g p
  have hm : Even m := even_order (hg p hp) hn hnonneg
  have hcast : (m : ℕ∞) = analyticOrderAt g p := Nat.cast_analyticOrderNatAt hn
  have hm0 : m ≠ 0 := by
    intro h
    rw [h,Nat.cast_zero] at hcast
    exact (analyticOrderAt_eq_zero.mp hcast.symm).elim (fun h => h (hg p hp)) (fun h => h h0)
  have heq : deriv f =ᶠ[𝓝 p] g := by filter_upwards [hI] with x hx using (hf x hx).deriv
  refine ⟨m+1, hm.add_one, ?_, ?_⟩
  · obtain ⟨j,hj⟩ := hm; omega
  · simp only [Nat.cast_add,Nat.cast_one]
    apply (analyticOrderAt_deriv_eq_iff ha (by simp [f])).mpr
    exact (analyticOrderAt_congr heq).trans hcast.symm

end CrossingData

namespace JacobiCore.RiccatiDeficit
/-- On the original Jacobi phase lift, Riccati equality selects exactly one sign. -/
theorem signed_unit_iff (J : JacobiCore) {p σ : ℝ} (hp : 0 < p) (hs : J.s p ≠ 0)
    (hz : 0 < J.toJacobiFull.z p) (hz1 : J.toJacobiFull.z p < 1)
    (hσ : σ = 1 ∨ σ = -1) :
    σ * deriv (lift J) p = 1 ↔ 0 < σ * deriv (lift J) p ∧
      |J.toJacobiFull.T1 p| = |J.toJacobiFull.T2 p| := by
  have hu := (unit_slope_iff J hp hs hz hz1).2
  have hnorm : |σ * deriv (lift J) p| = |deriv (lift J) p| := by
    rcases hσ with h|h <;> simp [h]
  constructor
  · intro h
    refine ⟨by linarith, hu.mp ?_⟩
    rw [← hnorm,h,abs_one]
  · rintro ⟨h,e⟩
    rw [← abs_of_pos h,hnorm,hu.mpr e]
end JacobiCore.RiccatiDeficit
