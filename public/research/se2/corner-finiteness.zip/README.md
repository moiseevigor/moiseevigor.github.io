# Ordinary corner orders and finiteness of tangency phases on SE(2)

CornerFiniteness proves the nonzero one-sided leading term at either ordinary corner, finiteness of unit-slope parameters and signed phase classes modulo 2K under the endpoint hypotheses, and the analytic crossing principle in both orientations. Ordinary corners require a simple endpoint ratio or complement. The global count of tangencies by modulus is a separate proposition.

Use the toolchain and dependency revisions supplied in this archive. From its root run

    lake exe cache get
    lake build
    lake env lean Audit.lean

Compare the final output with axioms.txt. SHA256SUMS identifies every input. The 81 declarations include the witnesses for the whole-paper claim ledger.
