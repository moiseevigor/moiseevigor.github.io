# Exact root count in every SE(2) Maxwell cell

ExactCellCount identifies the complete set of roots on every indexed half-open cell of the concrete Jacobi functions. The set is the singleton center exactly at the critical modulus and phase class K modulo 2K. Every other case has two distinct roots. Cardinalities count distinct times.

Use the toolchain and dependency revisions supplied in this archive. From its root run

    lake exe cache get
    lake build
    lake env lean Audit.lean

Compare the final output with axioms.txt. SHA256SUMS identifies every input. The 90 declarations include the witnesses for the whole-paper claim ledger.
