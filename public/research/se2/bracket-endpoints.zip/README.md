# Rotating SE(2) cell endpoints

Theorem JacobiCore.EndpointExpansion.compact_three_endpoints proves the Maxwell, beta and alpha endpoint expansions for every n=m+1, uniformly in the modulus on compact subsets of (0,1). The companion theorem alpha_endpoint_spec identifies the indexed alpha root, including at K=2E.

Use the toolchain and dependency revisions supplied in this archive. From its root run

    lake exe cache get
    lake build
    lake env lean Audit.lean

Compare the final output with axioms.txt. SHA256SUMS identifies every input. The 46 declarations include the witnesses for the whole-paper claim ledger.
