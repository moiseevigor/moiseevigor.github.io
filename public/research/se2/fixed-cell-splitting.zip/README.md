# Fixed-cell cube-root splitting on SE(2)

Install the Lean toolchain specified in lean-toolchain. In this directory run:

    lake exe cache get
    lake build
    lake env lean Audit.lean

This archive contains the splitting module and its transitive project-source imports. Mathlib and its dependencies are pinned in lake-manifest.json. Compare the last command with axioms.txt. The main formal statements are fixed_cell_splitting and moving_root_limit in the JacobiConcrete namespace. The website's historical manuscript downloads have their own snapshot manifest.
