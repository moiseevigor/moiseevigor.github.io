import SE2Conjugate.Splitting
#print axioms JacobiCore.Splitting.primitive_taylor_uniform
#print axioms JacobiCore.Splitting.cube_root_splitting
#print axioms JacobiConcrete.criticalGap_derivative
#print axioms JacobiConcrete.signedCubeRoot_cube
#print axioms JacobiConcrete.fixed_cell_splitting
#print axioms JacobiConcrete.signed_scale_limit
#print axioms JacobiConcrete.moving_root_limit
