import SE2Conjugate.ExactCellCount
import SE2Conjugate.EndpointExpansion

noncomputable section
open Set Filter
open scoped Topology
namespace JacobiCore.Exceptional
variable (J : JacobiCore)
def integral (h : ℝ) := ∫ x in (0:ℝ)..h, J.s x^2*J.d x^2/J.c x^2
abbrev window := Ioo (-J.K) J.K
private theorem origin : 0∈window J := ⟨neg_lt_zero.mpr J.K_pos,J.K_pos⟩
private theorem cn {x : ℝ} (hx : x∈window J) : 0<J.c x := by
  by_cases hp : 0≤x
  · exact J.toJacobiFull.c_pos_first ⟨hp,hx.2⟩
  · rw [←(Addition.even_cd J x).1]
    exact J.toJacobiFull.c_pos_first ⟨by linarith,by change -x<J.K; linarith [hx.1]⟩
private theorem sn {x : ℝ} (hx : x∈window J) (hn : x≠0) : J.s x≠0 := by
  rcases lt_or_gt_of_ne hn with hm|hp
  · have h := J.s_pos_of_mem_Ioc (u := -x) ⟨by linarith,by linarith [hx.1]⟩
    rw [J.s_neg] at h; linarith
  · exact (J.s_pos_of_mem_Ioc ⟨hp,hx.2.le⟩).ne'

theorem integral_eq {x : ℝ} (hx : x∈window J) : integral J x=J.exceptionalPrimitive x := by
  have sub : uIcc 0 x ⊆ window J := (convex_Ioo _ _).ordConnected.uIcc_subset (origin J) hx
  have cont : ContinuousOn (fun v => J.s v^2*J.d v^2/J.c v^2) (uIcc 0 x) := by
    intro v hv
    exact ((((J.hs v).continuousAt.pow 2).mul ((J.hd v).continuousAt.pow 2)).div
      ((J.hc v).continuousAt.pow 2) (pow_ne_zero _ (cn J (sub hv)).ne')).continuousWithinAt
  simpa [integral,J.primitive_zero] using intervalIntegral.integral_eq_sub_of_hasDerivAt
    (fun t ht => J.primitive_deriv t (cn J (sub ht)).ne') cont.intervalIntegrable

private theorem primitive_formula {x : ℝ} (hx : x∈window J) :
    J.exceptionalPrimitive x=x-2*J.eps x+J.s x*J.d x/J.c x := by
  change (x-J.eps x)-(J.c x*J.eps x-J.d x*J.s x)/J.c x=_
  field_simp [(cn J hx).ne']; ring

theorem integral_odd {x : ℝ} (hx : x∈window J) : integral J (-x) = -integral J x := by
  have hn : -x∈window J := ⟨by linarith [hx.2],by linarith [hx.1]⟩
  rw [integral_eq J hn,integral_eq J hx,primitive_formula J hn,primitive_formula J hx,
    Addition.epsilon_neg,J.s_neg,(Addition.even_cd J x).1,(Addition.even_cd J x).2]; ring

theorem integral_derivative {x : ℝ} (hx : x∈window J) :
    HasDerivAt (integral J) (J.s x^2*J.d x^2/J.c x^2) x :=
  (J.primitive_deriv x (cn J hx).ne').congr_of_eventuallyEq
    (Filter.Eventually.mono (Ioo_mem_nhds hx.1 hx.2) fun _ ht => integral_eq J ht)

theorem integral_strict : StrictMonoOn (integral J) (window J) := by
  have pos : StrictMonoOn (integral J) (Ico 0 J.K) := by
    apply strictMonoOn_of_deriv_pos (convex_Ico _ _)
    · intro x hx
      exact (integral_derivative J ⟨(origin J).1.trans_le hx.1,hx.2⟩).continuousAt.continuousWithinAt
    · intro x hx
      rw [interior_Ico] at hx
      have hw : x∈window J := ⟨(origin J).1.trans hx.1,hx.2⟩
      rw [(integral_derivative J hw).deriv]
      exact div_pos (mul_pos (sq_pos_of_ne_zero (sn J hw hx.1.ne')) (sq_pos_of_pos (J.d_pos _))) (sq_pos_of_pos (cn J hw))
  intro x hx y hy h
  have zero : (0:ℝ) ∈ Ico 0 J.K := ⟨le_rfl,J.K_pos⟩
  by_cases hp : 0≤x
  · exact pos ⟨hp,hx.2⟩ ⟨hp.trans h.le,hy.2⟩ h
  by_cases hn : y≤0
  · have u := pos (a := -y) (b := -x) ⟨by linarith,by linarith [hy.1]⟩ ⟨by linarith,by linarith [hx.1]⟩ (by linarith)
    rwa [integral_odd J hy,integral_odd J hx,neg_lt_neg_iff] at u
  · have a := pos zero (b := -x) ⟨by linarith,by linarith [hx.1]⟩ (by linarith)
    have b := pos zero (b := y) ⟨by linarith,hy.2⟩ (by linarith)
    rw [integral_odd J hx] at a
    simp [integral] at a b ⊢; linarith

private theorem phase_shift (j : ℤ) (τ p : ℝ) :
    J.toJacobiFull.J2 (τ+2*J.K*j) p=J.toJacobiFull.J2 τ p := by
  have s := J.s2_shift_int j τ
  change J.s _^2=J.s _^2 at s
  unfold JacobiFull.J2
  change _*J.s (τ+2*J.K*j)^2+_*J.c (τ+2*J.K*j)^2=_*J.s τ^2+_*J.c τ^2
  rw [s,show J.c (τ+2*J.K*j)^2=J.c τ^2 by linarith [J.sc (τ+2*J.K*j),J.sc τ]]

def center (m : ℕ) := (2*(m:ℝ)+2)*J.K
def target (m : ℕ) := (2*(m:ℝ)+2)*(2*J.E-J.K)
def prefactor (x : ℝ) := (1-J.k^2)*J.s x*J.c x/J.d x

theorem factor (m : ℕ) {ψ x : ℝ} (hψ : ∃ j : ℤ, ψ=J.K+2*J.K*j) (hx : x∈window J) :
    J.toJacobiFull.J2 (ψ+(center J m+x)) (center J m+x)=prefactor J x*(integral J x-target J m) := by
  obtain ⟨j,rfl⟩ := hψ
  rw [show J.K+2*J.K*j+(center J m+x)=(x+J.K+2*(m+1:ℕ)*J.K)+2*J.K*j by unfold center; push_cast; ring,
      phase_shift,show center J m+x=x+2*(m+1:ℕ)*J.K by unfold center; push_cast; ring,
      J.J2_exceptional _ _ (cn J hx).ne',integral_eq J hx]
  unfold prefactor target; push_cast; ring

private theorem roots_iff (m : ℕ) {ψ x : ℝ} (hψ : ∃ j : ℤ, ψ=J.K+2*J.K*j) (hx : x∈window J) :
    J.toJacobiFull.J2 (ψ+(center J m+x)) (center J m+x)=0 ↔ x=0 ∨ integral J x=target J m := by
  have hk : 0<1-J.k^2 := by nlinarith [J.k_lt_one,J.k_pos,mul_pos (sub_pos.mpr J.k_lt_one) (by linarith [J.k_pos] : 0<1+J.k)]
  rw [factor J m hψ hx,mul_eq_zero,sub_eq_zero]
  apply or_congr_left
  unfold prefactor
  simp only [div_eq_zero_iff,mul_eq_zero,hk.ne',(cn J hx).ne',(J.d_pos x).ne',false_or,or_false]
  exact ⟨fun h => by_contra fun hn => sn J hx hn h,fun h => h ▸ J.s0⟩


def cellRoots (m : ℕ) (ψ : ℝ) :=
  {p | p∈Ico (J.toJacobiFull.pL m) (J.toJacobiFull.pL (m+1)) ∧ J.toJacobiFull.J2 (ψ+p) p=0}

/-- The two bracket roots give existence in the correct cell. Monotonicity
then makes the offset unique on the whole open quarter-period window. -/
theorem cell_equation (m : ℕ) {ψ : ℝ} (hψ : ∃ j : ℤ, ψ=J.K+2*J.K*j) :
    ∃ h ∈ window J, integral J h=target J m ∧
      cellRoots J m ψ={center J m,center J m+h} := by
  let F := J.toJacobiFull
  let P := center J m
  obtain ⟨p,hp,q,hq,roots,co,cent⟩ := F.cell_root_pair m ψ
  change cellRoots J m ψ={p,q} at roots
  have cz := (F.center_root_iff m ψ).mpr hψ
  have cm : P ∈ cellRoots J m ψ := ⟨⟨(F.pL_mem m).2.le,by
    change (2*(m:ℝ)+2)*F.K<F.pL (m+1)
    exact (F.bR_mem m).1.trans ((F.bR_mem m).2.trans (F.pL_succ_mem m).1)⟩,cz⟩
  have loc {t : ℝ} (lo : F.pL m≤t) (hi : t≤F.bR m) : t-P∈window J := by
    change -J.K<t-(2*(m:ℝ)+2)*J.K ∧ t-(2*(m:ℝ)+2)*J.K<J.K
    have a : (2*(m:ℝ)+1)*J.K<t := (F.pL_mem m).1.trans_le lo
    have b : t<(2*(m:ℝ)+3)*J.K := hi.trans_lt (F.bR_mem m).2
    constructor <;> linarith
  have both : p-P∈window J ∧ q-P∈window J := ⟨loc hp.1 (hp.2.trans ((F.eL_le m).trans (F.bR_mem m).1.le)),
    loc ((F.pL_mem m).2.le.trans ((F.eR_ge m).trans hq.1)) hq.2⟩
  by_cases eq : p=q
  · have hc := (co.mp eq).1
    have cp := cent eq
    refine ⟨0,origin J,by simp [integral,target,show 2*J.E-J.K=0 from sub_eq_zero.mpr hc.symm],?_⟩
    change p=P at cp
    rw [roots,←eq,cp,add_zero]
  · rw [roots] at cm
    have cc : P=p ∨ P=q := by simpa using cm
    obtain ⟨t,wt,ht,ct,rr⟩ : ∃ t : ℝ, t-P∈window J ∧ t≠P ∧ t∈cellRoots J m ψ ∧ cellRoots J m ψ={P,t} := by
      rcases cc with a|a
      · exact ⟨q,both.2,a.symm ▸ Ne.symm eq,by rw [roots];simp,by rw [a,roots]⟩
      · exact ⟨p,both.1,a.symm ▸ eq,by rw [roots];simp,by rw [a,roots,pair_comm]⟩
    have et : P+(t-P)=t := by ring
    have z := (roots_iff J m hψ wt).mp (show F.J2 (ψ+(P+(t-P))) (P+(t-P))=0 by rw [et]; exact ct.2)
    exact ⟨t-P,wt,z.resolve_left (sub_ne_zero.mpr ht),by change cellRoots J m ψ={P,P+(t-P)}; rw [et]; exact rr⟩

theorem unique_offset (m : ℕ) : ∃! h : ℝ, h∈window J ∧ integral J h=target J m := by
  obtain ⟨h,hh,e,_⟩ := cell_equation J m (ψ := J.K) ⟨0,by simp⟩
  exact ⟨h,⟨hh,e⟩,fun _ a => (integral_strict J).injOn a.1 hh (a.2.trans e.symm)⟩

def offset (m : ℕ) := (unique_offset J m).exists.choose
theorem offset_spec (m : ℕ) : offset J m ∈ window J ∧ integral J (offset J m)=target J m :=
  (unique_offset J m).exists.choose_spec
theorem exceptional_roots (m : ℕ) {ψ : ℝ} (hψ : ∃ j : ℤ, ψ=J.K+2*J.K*j) :
    cellRoots J m ψ={center J m,center J m+offset J m} := by
  obtain ⟨h,w,e,r⟩ := cell_equation J m hψ
  rw [← (unique_offset J m).unique ⟨w,e⟩ (offset_spec J m)]; exact r

theorem root_order (m : ℕ) :
    (center J m<center J m+offset J m ↔ J.K<2*J.E) ∧
    (center J m+offset J m<center J m ↔ 2*J.E<J.K) ∧
    (center J m+offset J m=center J m ↔ J.K=2*J.E) := by
  obtain ⟨w,e⟩ := offset_spec J m
  have z : integral J 0=0 := by simp [integral]
  have lp := (integral_strict J).lt_iff_lt (origin J) w
  have rp := (integral_strict J).lt_iff_lt w (origin J)
  have eq := (integral_strict J).eq_iff_eq w (origin J)
  rw [e,z] at lp rp eq
  have hn : 0<2*(m:ℝ)+2 := by positivity
  unfold target at lp rp eq
  simp [mul_pos_iff_of_pos_left hn,show ∀ b : ℝ, (2*(m:ℝ)+2)*b<0 ↔ b<0 by intro b; simpa using (mul_lt_mul_iff_right₀ hn (c := (0:ℝ)) (b := b)),hn.ne'] at lp rp eq
  constructor
  · simpa using lp.symm
  constructor
  · simpa using rp.symm
  · simpa [sub_eq_zero,eq_comm (a := J.K)] using eq.symm


private theorem pref_derivative (x : ℝ) :
    HasDerivAt (prefactor J) (deriv (prefactor J) x) x :=
  (((((J.hs x).const_mul (1-J.k^2)).mul (J.hc x)).div (J.hd x) (J.d_pos _).ne').differentiableAt.hasDerivAt)

theorem simple_noncritical (m : ℕ) {ψ x : ℝ} (hψ : ∃ j : ℤ, ψ=J.K+2*J.K*j)
    (nc : J.K≠2*J.E) (hx : x∈window J) (hz : J.toJacobiFull.J2 (ψ+(center J m+x)) (center J m+x)=0) :
    deriv (fun t => J.toJacobiFull.J2 (ψ+t) t) (center J m+x)≠0 := by
  let P := center J m
  let f := fun t => J.toJacobiFull.J2 (ψ+t) t
  have df := (pref_derivative J x).mul ((integral_derivative J hx).sub_const (target J m))
  have gl : HasDerivAt (fun v => f (P+v)) _ x := df.congr_of_eventuallyEq
    (Filter.Eventually.mono (Ioo_mem_nhds hx.1 hx.2) fun v hv => factor J m hψ hv)
  have shifted := gl.comp_of_eq (P+x) ((hasDerivAt_id' (P+x)).sub_const P) (by simp)
  have g : HasDerivAt f _ (P+x) := shifted.congr_of_eventuallyEq
    (Eventually.of_forall fun t => by simp [f])
  change deriv f (P+x)≠0
  rw [g.deriv]
  have hk : 1-J.k^2≠0 := by nlinarith [J.k_pos,J.k_lt_one,mul_pos (sub_pos.mpr J.k_lt_one) (by linarith [J.k_pos] : 0<1+J.k)]
  by_cases ex : x=0
  · subst x
    have der := ((((J.hs 0).const_mul (1-J.k^2)).mul (J.hc 0)).div (J.hd 0) (J.d_pos _).ne').deriv
    change deriv (prefactor J) 0=_ at der
    have ht : target J m≠0 := mul_ne_zero (by positivity) (sub_ne_zero.mpr (Ne.symm nc))
    simp [der,integral,prefactor,J.s0,J.c0,J.d0,hk,ht]
  · have eq := ((roots_iff J m hψ hx).mp hz).resolve_left ex
    have s := sn J hx ex
    simp [eq,prefactor,s,hk,(cn J hx).ne',(J.d_pos x).ne']

private theorem earlier (m : ℕ) {ψ : ℝ} (hψ : ∃ j : ℤ, ψ=J.K+2*J.K*j) (crit : J.K=2*J.E) :
    (J.toJacobiFull.roots ψ m).Finite ∧ (J.toJacobiFull.roots ψ m).ncard=m := by
  let F := J.toJacobiFull
  induction m with
  | zero => rw [F.roots_zero]; simp
  | succ m ih =>
    have e : offset J m=0 := by have := ((root_order J m).2.2).mpr crit; linarith
    have rr := exceptional_roots J m hψ
    rw [e,add_zero,pair_eq_singleton] at rr
    have p : center J m ∈ cellRoots J m ψ := by rw [rr]; simp
    have hn : center J m ∉ F.roots ψ m := fun h => (not_lt_of_ge p.1.1) h.1.2
    rw [F.roots_succ]
    change (F.roots ψ m ∪ cellRoots J m ψ).Finite ∧ (F.roots ψ m ∪ cellRoots J m ψ).ncard=_
    rw [rr,union_singleton,ncard_insert_of_notMem hn ih.1,ih.2]
    exact ⟨ih.1.insert _,rfl⟩

private theorem ranks_of_pair (m : ℕ) {ψ p q : ℝ} (rr : cellRoots J m ψ={p,q}) (le : p≤q)
    {N : ℕ} (old : (J.toJacobiFull.roots ψ m).Finite ∧ (J.toJacobiFull.roots ψ m).ncard=N) :
    LargeIndex.hasRank J ψ p (N+1) ∧ (p<q → LargeIndex.hasRank J ψ q (N+2)) := by
  let F := J.toJacobiFull
  have hp : p∈cellRoots J m ψ := by rw [rr];simp
  have hq : q∈cellRoots J m ψ := by rw [rr];simp
  let before := fun u : ℝ => {t | t∈Ioo 0 u ∧ F.J2 (ψ+t) t=0}
  have classify {t} (ht : F.pL m ≤ t) (hu : t < F.pL (m+1)) (hz : F.J2 (ψ+t) t=0) : t=p ∨ t=q := by
    have v : t∈cellRoots J m ψ := ⟨⟨ht,hu⟩,hz⟩
    simpa [rr] using v
  have first : before p=F.roots ψ m := by
    ext t; constructor
    · rintro ⟨⟨ht,hp'⟩,hz⟩
      refine ⟨⟨ht,?_⟩,hz⟩
      by_contra! hh
      rcases classify hh (hp'.trans hp.1.2) hz with e|e <;> linarith
    · rintro ⟨⟨ht,hp'⟩,hz⟩; exact ⟨⟨ht,hp'.trans_le hp.1.1⟩,hz⟩
  refine ⟨⟨(F.pL_pos m).trans_le hp.1.1,hp.2,?_⟩,?_⟩
  · change (before p).Finite ∧ (before p).ncard+1=_
    rw [first,old.2];exact ⟨old.1,rfl⟩
  intro lt
  have second : before q=insert p (F.roots ψ m) := by
    ext t; constructor
    · rintro ⟨⟨ht,htq⟩,hz⟩
      by_cases hh : t<F.pL m
      · exact Or.inr ⟨⟨ht,hh⟩,hz⟩
      · exact Or.inl ((classify (le_of_not_gt hh) (htq.trans hq.1.2) hz).resolve_right htq.ne)
    · rintro (rfl|⟨⟨ht,htp⟩,hz⟩)
      · exact ⟨⟨(F.pL_pos m).trans_le hp.1.1,lt⟩,hp.2⟩
      · exact ⟨⟨ht,htp.trans_le hq.1.1⟩,hz⟩
  refine ⟨(F.pL_pos m).trans_le hq.1.1,hq.2,?_⟩
  change (before q).Finite ∧ (before q).ncard+1=_
  have hn : p∉F.roots ψ m := fun h => (not_lt_of_ge hp.1.1) h.1.2
  rw [second,ncard_insert_of_notMem hn old.1,old.2];exact ⟨old.1.insert _,rfl⟩

theorem exceptional_ranks (m : ℕ) {ψ : ℝ} (hψ : ∃ j : ℤ, ψ=J.K+2*J.K*j) :
    let P := center J m
    let Q := P+offset J m
    (J.K<2*J.E → LargeIndex.hasRank J ψ P (2*m+1) ∧ LargeIndex.hasRank J ψ Q (2*m+2)) ∧
    (2*J.E<J.K → LargeIndex.hasRank J ψ Q (2*m+1) ∧ LargeIndex.hasRank J ψ P (2*m+2)) ∧
    (J.K=2*J.E → Q=P ∧ LargeIndex.hasRank J ψ P (m+1)) := by
  have rr := exceptional_roots J m hψ
  have ord := root_order J m
  constructor
  · intro lt
    have l := ord.1.mpr lt
    have r := ranks_of_pair J m rr l.le (J.toJacobiFull.roots_ncard lt.ne ψ m)
    exact ⟨r.1,r.2 l⟩
  constructor
  · intro lt
    have l := ord.2.1.mpr lt
    rw [pair_comm] at rr
    have r := ranks_of_pair J m rr l.le (J.toJacobiFull.roots_ncard lt.ne' ψ m)
    exact ⟨r.1,r.2 l⟩
  · intro eq
    have e := ord.2.2.mpr eq
    exact ⟨e,(ranks_of_pair J m rr e.ge (earlier J m hψ eq)).1⟩


open JacobiConcrete
/-- Both signs share the same positive-end equation after reflection. -/
theorem compact_offset_correction {S : Set ℝ} (hs : IsCompact S) (sub : S ⊆ Ioo (0:ℝ) 1)
    (nc : ∀ k ∈ S, 2*secondIntegral k (Real.pi/2)≠JacobiConcrete.K k) :
    ∃ C : ℝ, 0<C ∧ ∀ k (hk : k∈S) (m : ℕ),
      let J := core _ (sub hk).1 (sub hk).2
      let N := (m:ℝ)+1
      let a := J.K-1/(2*N*|2*J.E-J.K|)
      |offset J m-(if J.K<2*J.E then a else -a)| ≤ C/N^2 := by
  obtain ⟨C,hC,est⟩ := EndpointExpansion.compact_exceptional_pole hs sub nc
  refine ⟨C,hC,?_⟩; intro k hk m
  let J := core k (sub hk).1 (sub hk).2
  let N := (m:ℝ)+1
  let h := offset J m
  have ⟨w,eq⟩ := offset_spec J m
  have wh : |h|∈window J := ⟨lt_of_lt_of_le (origin J).1 (abs_nonneg _),abs_lt.mpr w⟩
  have negap : 2*J.E≠J.K := by change 2*(core k (sub hk).1 (sub hk).2).E≠_; rw [show (core k (sub hk).1 (sub hk).2).E=_ from full_E _ _ _]; exact nc k hk
  have pos : 0<h ↔ J.K<2*J.E := by simpa [h] using (root_order J m).1
  have npos : 1≤N := by dsimp [N]; linarith [Nat.cast_nonneg (α := ℝ) m]
  have mag : integral J |h|=N*(2*|2*J.E-J.K|) := by
    change integral J h=(2*(m:ℝ)+2)*(2*J.E-J.K) at eq
    rcases lt_or_gt_of_ne negap with lt|lt
    · have hh : h≤0 := le_of_not_gt fun h => lt.asymm (pos.mp h)
      rw [abs_of_nonpos hh,integral_odd J w,eq,abs_of_neg (sub_neg.mpr lt)]; dsimp [N];ring
    · rw [abs_of_pos (pos.mpr lt),eq,abs_of_pos (sub_pos.mpr lt)]; dsimp [N];ring
  rw [integral_eq J wh,primitive_formula J wh] at mag
  have v := est k hk (N := N) (x := |h|) npos ⟨abs_nonneg _,wh.2.le⟩ (by
    change N*(2*|2*J.E-J.K|)*J.c |h|=_
    field_simp [(cn J wh).ne'] at mag
    linear_combination -mag)
  change |h-(if J.K<2*J.E then _ else _)|≤C/N^2
  change abs (abs h-(J.K-1/(N*(2*|2*J.E-J.K|))))≤_ at v
  rw [show N*(2*|2*J.E-J.K|)=2*N*|2*J.E-J.K| by ring] at v
  split_ifs with lt
  · rwa [abs_of_pos (pos.mpr lt)] at v
  · rw [abs_of_nonpos (le_of_not_gt (fun hh => lt (pos.mp hh)))] at v
    rw [←abs_neg]; convert v using 2; ring


theorem integral_poles :
    Tendsto (integral J) (𝓝[<] J.K) atTop ∧ Tendsto (integral J) (𝓝[>] (-J.K)) atBot := by
  let f := fun A x : ℝ => (x-2*J.eps x-A)*J.c x+J.s x*J.d x
  have cont (A x : ℝ) : ContinuousAt (f A) x :=
    ((((continuousAt_id.sub ((J.heps x).continuousAt.const_mul 2)).sub continuousAt_const).mul
      (J.hc x).continuousAt).add ((J.hs x).continuousAt.mul (J.hd x).continuousAt))
  have id (A x : ℝ) (hx : x∈window J) : (integral J x-A)*J.c x=f A x := by
    rw [integral_eq J hx,primitive_formula J hx]; unfold f; field_simp [(cn J hx).ne'];ring
  constructor
  · refine tendsto_atTop.mpr fun A => ?_
    have pos : 0<f A J.K := by simp [f,J.cK,J.sK,J.d_pos]
    have ev := ((cont A J.K).eventually_const_lt pos).filter_mono (nhdsWithin_le_nhds (s := Iio J.K))
    have low := (eventually_gt_nhds (show -J.K<J.K by linarith [J.K_pos])).filter_mono (nhdsWithin_le_nhds (s := Iio J.K))
    filter_upwards [ev,low,self_mem_nhdsWithin] with x h l u
    have hx : x∈window J := ⟨l,u⟩
    rw [←id A x hx] at h
    exact (sub_pos.mp (pos_of_mul_pos_left h (cn J hx).le)).le
  · refine tendsto_atBot.mpr fun A => ?_
    have neg : f A (-J.K)<0 := by simp [f,(Addition.even_cd J J.K).1,(Addition.even_cd J J.K).2,J.cK,J.s_neg,J.sK,J.d_pos]
    have ev := ((cont A (-J.K)).eventually_lt_const neg).filter_mono (nhdsWithin_le_nhds (s := Ioi (-J.K)))
    have high := (eventually_lt_nhds (show -J.K<J.K by linarith [J.K_pos])).filter_mono (nhdsWithin_le_nhds (s := Ioi (-J.K)))
    filter_upwards [ev,high,self_mem_nhdsWithin] with x h u l
    have hx : x∈window J := ⟨l,u⟩
    rw [←id A x hx] at h
    exact (sub_neg.mp (neg_of_mul_neg_left h (cn J hx).le)).le

theorem modulus_order {k k₀ : ℝ} (hk : k∈Ioo (0:ℝ) 1) (hc : k₀∈Ioo (0:ℝ) 1)
    (eq : JacobiConcrete.K k₀=2*secondIntegral k₀ (Real.pi/2)) (m : ℕ) :
    let J := core k hk.1 hk.2
    (0<offset J m ↔ k<k₀) ∧ (offset J m<0 ↔ k₀<k) ∧ (offset J m=0 ↔ k=k₀) := by
  let J := core k hk.1 hk.2
  have a := gap_strictAnti.lt_iff_gt hc hk
  have b := gap_strictAnti.lt_iff_gt hk hc
  have c := gap_strictAnti.injOn
  have zero : normalizedGap k₀=0 := by simp [normalizedGap,eq]
  have ek : normalizedGap k=(2*J.E-J.K)/k := by rw [normalizedGap,show J.E=_ from full_E _ _ _];rfl
  rw [zero,ek] at a b
  have o := root_order J m
  simp only [lt_add_iff_pos_right,add_eq_left] at o
  refine ⟨?_,?_,?_⟩
  · exact o.1.trans (by simpa [div_pos_iff_of_pos_right hk.1] using a)
  · have v : (2*J.E-J.K)/k<0 ↔ 2*J.E<J.K := by rw [div_neg_iff]; simp [hk.1,hk.1.not_gt]
    rw [v] at b
    simpa using o.2.1.trans b
  · constructor
    · intro h
      apply c hk hc
      rw [ek,zero,←o.2.2.mp h,sub_self,zero_div]
    · rintro rfl
      apply o.2.2.mpr
      exact eq.trans (congrArg (fun z : ℝ => 2*z) (full_E _ hk.1 hk.2).symm)


/-- The ordinary ranked formula has a one-sided choice of boundary representative.
For each n one predicted root is the center exactly. The other predicted root
misses the true root by at most the first pole correction and its remainder. -/
theorem boundary_ranked_law {S : Set ℝ} (hs : IsCompact S) (sub : S ⊆ Ioo (0:ℝ) 1)
    (nc : ∀ k ∈ S, 2*secondIntegral k (Real.pi/2)≠JacobiConcrete.K k) :
    ∃ C : ℝ, 0<C ∧ ∀ k (hk : k∈S) (m : ℕ),
      let J := core k (sub hk).1 (sub hk).2
      let N := (m:ℝ)+1
      let ψ := if J.K<2*J.E then -J.K else J.K
      let B := 1/(2*N*|2*J.E-J.K|)+C/N^2
      ∃ p q, LargeIndex.hasRank J ψ p (2*m+1) ∧ LargeIndex.hasRank J ψ q (2*m+2) ∧
        |p-((2*N-1/2)*J.K-ψ/2)|≤B ∧ |q-((2*N+1/2)*J.K-ψ/2)|≤B := by
  obtain ⟨C,hC,est⟩ := compact_offset_correction hs sub nc
  refine ⟨C,hC,?_⟩; intro k hk m
  let J := core k (sub hk).1 (sub hk).2
  let N := (m:ℝ)+1
  let P := center J m
  let h := offset J m
  let δ := 1/(2*N*|2*J.E-J.K|)
  have e := est k hk m
  change |h-(if J.K<2*J.E then J.K-δ else -(J.K-δ))|≤C/N^2 at e
  have d : 0≤δ := by dsimp [δ,N];positivity
  have b : 0≤δ+C/N^2 := add_nonneg d (div_nonneg hC.le (sq_nonneg _))
  have p_eq : P=2*N*J.K := by unfold P center N;ring
  have ne : 2*J.E≠J.K := by change 2*(core k (sub hk).1 (sub hk).2).E≠_;rw [show (core k (sub hk).1 (sub hk).2).E=_ from full_E _ _ _];exact nc k hk
  dsimp only
  let ψ := if J.K<2*J.E then -J.K else J.K
  change ∃ p q, LargeIndex.hasRank J ψ p (2*m+1) ∧ LargeIndex.hasRank J ψ q (2*m+2) ∧
    |p-((2*N-1/2)*J.K-ψ/2)|≤δ+C/N^2 ∧ |q-((2*N+1/2)*J.K-ψ/2)|≤δ+C/N^2
  unfold ψ
  by_cases lt : J.K<2*J.E
  · simp only [if_pos lt] at e ⊢
    have r := (exceptional_ranks J m (ψ := -J.K) ⟨-1,by push_cast;ring⟩).1 lt
    refine ⟨P,P+h,r.1,r.2,?_,?_⟩
    · rw [p_eq,show 2*N*J.K-((2*N-1/2)*J.K- -J.K/2)=0 by ring,abs_zero]; exact b
    · rw [p_eq,show 2*N*J.K+h-((2*N+1/2)*J.K- -J.K/2)=(h-(J.K-δ))+ -δ by ring]
      exact (abs_add_le ..).trans (by rw [abs_neg,abs_of_nonneg d,add_comm δ];exact add_le_add e (le_refl δ))
  · simp only [if_neg lt] at e ⊢
    have r := (exceptional_ranks J m (ψ := J.K) ⟨0,by simp⟩).2.1 (lt_of_le_of_ne (le_of_not_gt lt) ne)
    refine ⟨P+h,P,r.1,r.2,?_,?_⟩
    · rw [p_eq,show 2*N*J.K+h-((2*N-1/2)*J.K-J.K/2)=(h- -(J.K-δ))+δ by ring]
      exact (abs_add_le ..).trans (by rw [abs_of_nonneg d,add_comm δ];exact add_le_add e (le_refl δ))
    · rw [p_eq,show 2*N*J.K-((2*N+1/2)*J.K-J.K/2)=0 by ring,abs_zero]; exact b

end JacobiCore.Exceptional
