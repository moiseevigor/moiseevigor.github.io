# The exceptional phase on SE(2)

ExceptionalPhase proves the integral equation, strict ordering, distinct positive ranks, and the signed asymptotic correction. EndpointExpansion supplies the uniform bound for the equation at the pole.

Use the toolchain and dependency revisions supplied in this archive. From its root run

    lake exe cache get
    lake build
    lake env lean Audit.lean

Compare the final output with axioms.txt. SHA256SUMS identifies every input. The 123 declarations include the witnesses for the whole-paper claim ledger.
