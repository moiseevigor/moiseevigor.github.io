import SE2Conjugate.BeforeFirst
import SE2Conjugate.CriticalModulus

noncomputable section
open Set

namespace JacobiFull
variable (J : JacobiFull) (m : ℕ) (ψ : ℝ)

/-- The center is an integral number of phase periods from the origin. -/
theorem center_root_iff :
    J.J2 (ψ+(2*m+2)*J.K) ((2*m+2)*J.K) = 0 ↔
      ∃ j : ℤ, ψ = J.K+2*J.K*j := by
  have h := J.J2_even_eq_zero_iff (n := m+1) (by omega) (ψ+(2*m+2)*J.K)
  rw [J.cast2 m] at h
  rw [h]
  constructor
  · rintro ⟨i,hi⟩
    refine ⟨i-(m+1 : ℕ),?_⟩
    push_cast
    linear_combination hi
  · rintro ⟨i,rfl⟩
    refine ⟨i+(m+1 : ℕ),?_⟩
    push_cast
    ring

/-- The half-open cell consists of two bracket roots, with equality precisely at
the critical modulus and phase. In that case their common value is the center. -/
theorem cell_root_pair :
    ∃ p ∈ Icc (J.pL m) (J.eL m), ∃ q ∈ Icc (J.eR m) (J.bR m),
      {x | x ∈ Ico (J.pL m) (J.pL (m+1)) ∧ J.J2 (ψ+x) x = 0} = {p,q} ∧
      (p=q ↔ J.K=2*J.E ∧ ∃ j : ℤ, ψ=J.K+2*J.K*j) ∧
      (p=q → p=(2*m+2)*J.K) := by
  obtain ⟨p,hp,q,hq,roots,shared⟩ := J.coincide_imp m ψ
  have root (x : ℝ) (hx : x ∈ ({p,q} : Set ℝ)) : J.J2 (ψ+x) x=0 := by
    rw [← roots] at hx
    exact hx.2
  have hp0 := root p (by simp)
  have hq0 := root q (by simp)
  refine ⟨p,hp,q,hq,roots,⟨?_,?_⟩,fun he => (shared he).1⟩
  · intro he
    obtain ⟨hc,hk⟩ := shared he
    rw [hc] at hp0
    exact ⟨hk,(J.center_root_iff m ψ).mp hp0⟩
  · rintro ⟨hk,hψ⟩
    have ht := (J.eL_eq_eR_iff m).mpr hk
    have hL := le_antisymm (J.eL_le m) (ht ▸ J.eR_ge m)
    have hR := ht.symm.trans hL
    have hc := (J.center_root_iff m ψ).mpr hψ
    have lp := (J.left_exact_time m ψ).unique ⟨hp,hp0⟩
      ⟨⟨(J.pL_mem m).2.le,hL.ge⟩,hc⟩
    have rq := (J.right_exact_time m ψ).unique ⟨hq,hq0⟩
      ⟨⟨hR.le,(J.bR_mem m).1.le⟩,hc⟩
    exact lp.trans rq.symm

end JacobiFull

namespace JacobiConcrete
open scoped Classical

/-- Theorem 4.1 for the concrete Jacobi functions, including the singleton
root set at the exceptional phase. The article's index is n=m+1. -/
theorem exact_cell_count (k : ℝ) (hk0 : 0<k) (hk1 : k<1) (m : ℕ) (ψ : ℝ) :
    let J := full k hk0 hk1
    let roots := {x | x ∈ Ico (J.pL m) (J.pL (m+1)) ∧ J.J2 (ψ+x) x=0}
    let exceptional := K k=2*secondIntegral k (Real.pi/2) ∧ ∃ j : ℤ, ψ=K k+2*K k*j
    (exceptional → roots = {(2*m+2)*K k}) ∧
      roots.ncard = (if exceptional then 1 else 2) := by
  classical
  dsimp only
  let J := full k hk0 hk1
  obtain ⟨p,_,q,_,roots,iff_eq,center⟩ := J.cell_root_pair m ψ
  rw [full_K,full_E] at iff_eq
  rw [roots]
  by_cases he : K k=2*secondIntegral k (Real.pi/2) ∧ ∃ j : ℤ, ψ=K k+2*K k*j
  · have eq := iff_eq.mpr he
    have hc := center eq
    rw [if_pos he,← eq,hc]
    simp [J,full_K]
  · simp [he,Set.ncard_pair (fun eq => he (iff_eq.mp eq))]

end JacobiConcrete
