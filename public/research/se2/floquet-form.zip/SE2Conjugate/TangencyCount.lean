import SE2Conjugate.CrossingOrder
import SE2Conjugate.SignChart

noncomputable section
open Set Filter
open scoped Topology

namespace JacobiData
variable (J : JacobiData)

/-- Regular extension of H ℓ² / (sn dn⁵) through the cell center. -/
def tangentTest (x : ℝ) : ℝ :=
  (J.d x^2*J.b x*J.α1 x/J.ell x-J.s x*J.a x*J.Dz x)*J.ell x^2/J.d x^5

private theorem a_form {x : ℝ} (hq : J.q x ≠ 0) :
    J.a x = -J.c x-J.d x*J.s x/J.q x := by
  unfold a f1
  rw [show J.eps x-x = -J.q x by unfold q; ring]
  field_simp

private theorem b_form {x : ℝ} (he : J.eps x ≠ 0) :
    J.b x = -J.c x+J.d x*J.s x/J.eps x := by
  unfold b β1
  field_simp
  ring

theorem tangent_V_factor {x : ℝ} (hq : J.q x ≠ 0) (he : J.eps x ≠ 0) :
    J.V x = J.d x*J.s x/(J.eps x*J.q x) *
      (J.k^2*J.c x*J.β1 x+(1-J.k^2)*J.q x) := by
  have h : J.d x^2-J.k^2*J.c x^2=1-J.k^2 := by
    linear_combination J.sd x - J.k^2 * J.sc x
  unfold V Dz z
  rw [J.a_form hq]
  calc
    _ = (J.c x+J.b x)*(1-J.k^2)-J.b x*J.c x*J.k^2*(J.d x*J.s x/J.q x) := by
      linear_combination J.b x*h
    _ = _ := by
      nth_rw 1 [J.b_form he]
      unfold b
      field_simp
      ring

theorem tangentTest_eq {x : ℝ} (hq : J.q x ≠ 0) (he : J.eps x ≠ 0) (hs : J.s x ≠ 0) :
    J.tangentTest x = J.H x*J.ell x^2/(J.s x*J.d x^5) := by
  have hl : J.ell x ≠ 0 := mul_ne_zero he hq
  have hz : 1-J.z x = J.s x*J.α1 x/J.ell x := by
    rw [J.z_eq_neg_beta_div_ell x hq he,J.collapse_beta]
    unfold X
    field_simp
    ring
  unfold tangentTest H T1 T2
  rw [hz]
  rw [← div_div]
  congr 1
  field_simp

private theorem tangentTest_cont {x : ℝ} (hq : J.q x ≠ 0) (he : J.eps x ≠ 0) (hd : J.d x ≠ 0) :
    ContinuousAt J.tangentTest x := by
  have hc := (J.hd x).continuousAt
  have ha := ((J.hasDerivAt_f1 x).continuousAt.div (J.hasDerivAt_q x).continuousAt hq)
  have hb := ((J.hasDerivAt_β1 x).continuousAt.neg.div (J.heps x).continuousAt he)
  have hl := (J.heps x).continuousAt.mul (J.hasDerivAt_q x).continuousAt
  have hz : ContinuousAt J.Dz x := continuousAt_const.add (continuousAt_const.mul (ha.mul hb))
  exact (((((hc.pow 2).mul hb).mul (J.hasDerivAt_α1 x).continuousAt).div hl (mul_ne_zero he hq)).sub
    (((J.hs x).continuousAt.mul ha).mul hz) |>.mul (hl.pow 2)).div (hc.pow 5) (pow_ne_zero 5 hd)

private theorem tangent_log_coeff {x : ℝ} (hq : J.q x ≠ 0) (he : J.eps x ≠ 0)
    (hs : J.s x ≠ 0) (hd : J.d x ≠ 0) :
    (2*J.a x*J.k^2*J.s x^2-2*J.b x*J.d x^2-2*J.c x*J.k^2*J.s x^2-J.c x)/(J.d x*J.s x)
      = J.c x*J.d x/J.s x + 5*(-(J.k^2*J.s x*J.c x))/J.d x -
        2*(J.d x^2/J.eps x + J.k^2*J.s x^2/J.q x) := by
  rw [J.a_form hq,J.b_form he]
  field_simp
  linear_combination J.c x*J.eps x*J.q x*J.sd x

theorem hasDerivAt_tangentTest {x : ℝ} (hq : J.q x ≠ 0) (he : J.eps x ≠ 0)
    (hs : J.s x ≠ 0) (hd : J.d x ≠ 0) :
    HasDerivAt J.tangentTest (-4*J.a x*J.V x*J.ell x^2/J.d x^6) x := by
  have hl := (J.heps x).mul (J.hasDerivAt_q x)
  have base := (((J.hasDerivAt_H x hq he hs hd).mul (hl.pow 2)).div
    ((J.hs x).mul ((J.hd x).pow 5)) (mul_ne_zero hs (pow_ne_zero 5 hd)))
  have near : J.tangentTest =ᶠ[𝓝 x] (fun t => J.H t*J.ell t^2/(J.s t*J.d t^5)) := by
    filter_upwards [(J.hasDerivAt_q x).continuousAt.eventually_ne hq,
      (J.heps x).continuousAt.eventually_ne he,(J.hs x).continuousAt.eventually_ne hs] with t h1 h2 h3
    exact J.tangentTest_eq h1 h2 h3
  apply (base.congr_of_eventuallyEq near).congr_deriv
  have hp : J.Hp x = (J.c x*J.d x/J.s x + 5*(-(J.k^2*J.s x*J.c x))/J.d x -
        2*(J.d x^2/J.eps x + J.k^2*J.s x^2/J.q x))*J.H x-4*J.a x*J.s x*J.V x/J.d x := by
    rw [← J.tangent_log_coeff hq he hs hd]
    unfold Hp
    field_simp
  rw [hp]
  simp only [Pi.mul_apply,Pi.pow_apply, Nat.cast_ofNat]
  unfold ell
  field_simp
  ring

end JacobiData

namespace JacobiFull
open JacobiData
variable (J : JacobiFull) (m : ℕ)
local notation "A" => J.toJacobiData
local notation "P" => (2*(m:ℝ)+2)*J.K

private theorem aligned {x y : ℝ} {i : ℕ} (h : 0<(-1:ℝ)^i*x) (g : 0<(-1:ℝ)^i*y) : 0<x*y := by
  have e : ((-1:ℝ)^i*x)*((-1:ℝ)^i*y)=x*y := by
    rw [mul_mul_mul_comm,← sq,neg_one_pow_sq,one_mul]
  exact e ▸ mul_pos h g

private theorem signed_a {x : ℝ} (hp : x ∈ Ioc (J.pL m) (J.bR m)) : 0<(-1:ℝ)^m*(A).a x := by
  unfold JacobiData.a
  rw [mul_div_assoc']
  exact div_pos (J.signed_f1_pos_cell m ⟨hp.1,hp.2.trans_lt ((J.bR_mem m).2.trans (J.pL_succ_mem m).1)⟩)
    (J.toJacobiInit.q_pos ((J.pL_pos m).trans hp.1))

private theorem brace_pos {x : ℝ} (hx : x ∈ Ioo (J.pL m) (J.bR m)) :
    0<J.k^2*J.c x*(A).β1 x+(1-J.k^2)*(A).q x := by
  have hc := J.c_sign m x ⟨(J.pL_mem m).1.trans hx.1,hx.2.trans (J.bR_mem m).2⟩
  have hb : 0<(-1:ℝ)^(m+1)*(A).β1 x := by
    rcases le_or_gt P x with h|h
    · exact J.signed_β1_pos_before_bR m ⟨h,hx.2⟩
    · rw [neg_one_pow_succ_mul]
      exact neg_pos.mpr (J.signed_β1_neg_odd m ⟨((J.pL_mem m).1.trans hx.1).le,h.le⟩)
  have hk : 0<1-J.k^2 := by nlinarith [J.k_pos,J.k_lt_one]
  rw [mul_assoc (J.k^2)]
  exact add_pos (mul_pos (sq_pos_of_pos J.k_pos) (aligned hc hb))
    (mul_pos hk (J.toJacobiInit.q_pos ((J.pL_pos m).trans hx.1)))

/-- The regularized test has its strict minimum at the half-period. -/
theorem tangentTest_monotone :
    StrictAntiOn (A).tangentTest (Icc (J.pL m) P) ∧ StrictMonoOn (A).tangentTest (Icc P (J.bR m)) := by
  have cont {x : ℝ} (hx : 0<x) := (A).tangentTest_cont (J.toJacobiInit.q_pos hx).ne'
    (J.toJacobiInit.eps_pos hx).ne' (J.d_pos x).ne'
  have sign_deriv {x : ℝ} (hx : x ∈ Ioo (J.pL m) (J.bR m)) (hs : J.s x ≠ 0) :
      ∃ c>0, deriv (A).tangentTest x = -((A).a x*J.s x)*c := by
    have pos := (J.pL_pos m).trans hx.1
    have hq := J.toJacobiInit.q_pos pos
    have he := J.toJacobiInit.eps_pos pos
    have hd := J.d_pos x
    have hv := J.brace_pos m hx
    have hl : 0<(A).ell x := mul_pos he hq
    rw [((A).hasDerivAt_tangentTest hq.ne' he.ne' hs hd.ne').deriv,(A).tangent_V_factor hq.ne' he.ne']
    refine ⟨4*J.d x/(J.eps x*(A).q x)*(J.k^2*J.c x*(A).β1 x+(1-J.k^2)*(A).q x)*(A).ell x^2/J.d x^6,?_,?_⟩
    · exact div_pos (mul_pos (mul_pos (div_pos (mul_pos (by norm_num) hd) (mul_pos he hq)) hv)
        (sq_pos_of_pos hl)) (pow_pos hd _)
    · ring
  constructor
  · apply strictAntiOn_of_deriv_neg (convex_Icc _ _)
    · exact fun x hx => (cont ((J.pL_pos m).trans_le hx.1)).continuousWithinAt
    rw [interior_Icc]
    intro x hx
    have hi : x ∈ Ioo (J.pL m) (J.bR m) := ⟨hx.1,hx.2.trans (J.bR_mem m).1⟩
    have hs := J.signed_s_pos m ⟨(J.pL_mem m).1.trans hx.1,hx.2⟩
    obtain ⟨c,hc,eq⟩ := sign_deriv hi (fun e => hs.ne' (mul_eq_zero_of_right _ e))
    rw [eq]
    exact mul_neg_of_neg_of_pos (neg_neg_of_pos (aligned (J.signed_a m ⟨hi.1,hi.2.le⟩) hs)) hc
  · apply strictMonoOn_of_deriv_pos (convex_Icc _ _)
    · exact fun x hx => (cont ((J.two_m_two_pos m).trans_le hx.1)).continuousWithinAt
    rw [interior_Icc]
    intro x hx
    have hi : x ∈ Ioo (J.pL m) (J.bR m) := ⟨(J.pL_mem m).2.trans hx.1,hx.2⟩
    have hs := J.signed_s_pos_R m ⟨hx.1,by have := hx.2.trans (J.bR_mem m).2; have := J.K_pos; linarith⟩
    obtain ⟨c,hc,eq⟩ := sign_deriv hi (fun e => hs.ne' (mul_eq_zero_of_right _ e))
    rw [neg_one_pow_succ_mul] at hs
    have hsn : 0<(-1:ℝ)^m*(-J.s x) := by simpa using hs
    rw [eq,← mul_neg]
    exact mul_pos (aligned (J.signed_a m ⟨hi.1,hi.2.le⟩) hsn) hc

private theorem test_center :
    (A).tangentTest P = (2*m+2)*(2*J.E-J.K)*(A).ell P/J.d P^2 := by
  have hs := J.s_even (m+1)
  have he := J.eps_even (m+1)
  rw [J.cast2 m] at hs he
  have hsc := J.sc P
  rw [hs] at hsc
  have hc : J.c P^2=1 := by nlinarith
  have hE := J.toJacobiInit.eps_pos (J.two_m_two_pos m)
  have hq := J.toJacobiInit.q_pos (J.two_m_two_pos m)
  have hl : (A).ell P ≠ 0 := (mul_pos hE hq).ne'
  have hd := (J.d_pos P).ne'
  set x := P
  have shift : x-2*J.eps x=(2*m+2)*(J.K-2*J.E) := by rw [he]; dsimp [x]; push_cast; ring
  unfold JacobiData.tangentTest
  rw [(A).b_form hE.ne']
  unfold JacobiData.α1
  simp only [hs,mul_zero,zero_mul,add_zero,sub_zero,zero_div,shift]
  generalize J.c x = c at hc ⊢
  generalize (A).ell x = l at hl ⊢
  generalize J.d x = d at hd ⊢
  field_simp
  ring_nf at hc ⊢
  rw [hc]
  ring

end JacobiFull

namespace SBracket

/-- Parameters of interior unit-slope contacts, before reduction of the phase modulo 2K. -/
def tangentPoints (B : SBracket) : Set ℝ := {p ∈ Ioo B.p0 B.p1 | |deriv B.u p|=1}

theorem mem_tangentPoints (B : SBracket) {p : ℝ} :
    p ∈ B.tangentPoints ↔ p ∈ Ioo B.p0 B.p1 ∧ B.toJacobiData.tangentTest p=0 := by
  change (_ ∧ _) ↔ _
  apply and_congr_right
  intro hi
  have hi' := Ioo_subset_Icc_self hi
  have hD := B.d_pos p
  have hq : B.toJacobiData.q p ≠ 0 := (B.q_pos p hi').ne'
  have he := (B.eps_pos p hi').ne'
  have hl := (B.ell_pos_Icc hi').ne'
  rw [B.toJacobiData.tangentTest_eq hq he (B.s_ne hi)]
  simp only [div_eq_zero_iff,mul_eq_zero,pow_eq_zero_iff (by decide : 2≠0),
    pow_eq_zero_iff (by decide : 5≠0), hl,B.s_ne hi,hD.ne',or_false]
  have hd := ((((B.hasDerivAt_u hi).differentiableAt.hasDerivAt.sub_const (B.u p)).const_mul B.ε).sub
    ((hasDerivAt_id' p).sub_const p)).deriv
  change deriv (B.phaseGap B.ε p) p = B.ε*deriv B.u p-1 at hd
  have iff := B.signed_tangency B.hε hi
  rw [hd,sub_eq_zero] at iff
  have h := B.one_le_ε_deriv_u hi
  rw [← (B.hasDerivAt_u hi).deriv] at h
  have habs : |deriv B.u p|=B.ε*deriv B.u p := by
    rcases B.hε with e|e <;> rw [e] at h ⊢
    · rw [one_mul] at h ⊢; exact abs_of_nonneg (by linarith)
    · rw [neg_one_mul] at h ⊢; exact abs_of_nonpos (by linarith)
  simpa [habs] using iff

end SBracket

namespace JacobiFull
variable (J : JacobiFull) (m : ℕ)
local notation "A" => J.toJacobiData
local notation "P" => (2*(m:ℝ)+2)*J.K

private theorem outer_tests :
    0<(A).tangentTest (J.pL m) ∧ 0<(A).tangentTest (J.bR m) := by
  constructor
  · let x := J.pL m
    have hq := J.toJacobiInit.q_pos (J.pL_pos m)
    have he := J.toJacobiInit.eps_pos (J.pL_pos m)
    have hl : 0<(A).ell x := mul_pos he hq
    have hd := J.d_pos x
    have ha : (A).a x=0 := by simp [JacobiData.a,x,J.f1_pL]
    have hb : 0<(-1:ℝ)^m*(A).b x := by
      unfold JacobiData.b
      rw [mul_div_assoc',mul_neg]
      exact div_pos (neg_pos.mpr (J.signed_β1_neg_odd m (Ioo_subset_Icc_self (J.pL_mem m)))) he
    have hprod := aligned hb (J.signed_α1_pL_pos m)
    change 0< (A).tangentTest x
    unfold JacobiData.tangentTest
    rw [ha,mul_zero,zero_mul,sub_zero,mul_assoc (J.d x^2)]
    positivity
  · let x := J.bR m
    have he := J.toJacobiInit.eps_pos ((J.two_m_two_pos m).trans (J.bR_mem m).1)
    have hq := J.toJacobiInit.q_pos ((J.two_m_two_pos m).trans (J.bR_mem m).1)
    have hl : 0<(A).ell x := mul_pos he hq
    have hd := J.d_pos x
    have hb : (A).b x=0 := by simp [JacobiData.b,x,J.β1_bR]
    have hz : (A).Dz x=1-J.k^2 := by simp [JacobiData.Dz,JacobiData.z,hb]
    have hk : 0<1-J.k^2 := by nlinarith [J.k_pos,J.k_lt_one]
    have hs := J.signed_s_pos_R m ⟨(J.bR_mem m).1,by have := (J.bR_mem m).2; have := J.K_pos; linarith⟩
    rw [neg_one_pow_succ_mul] at hs
    have hsn : 0<(-1:ℝ)^m*(-J.s x) := by simpa [x] using hs
    have hsa := aligned hsn (J.signed_a m ⟨(J.pL_mem m).2.trans (J.bR_mem m).1,le_rfl⟩)
    change 0<(A).tangentTest x
    unfold JacobiData.tangentTest
    rw [hb,mul_zero,zero_mul,zero_div,zero_sub,hz,← neg_mul,← neg_mul]
    positivity

private theorem inner_left_negative (hk : 2*J.E<J.K) : (A).tangentTest (J.eL m)<0 := by
  let x := J.eL m
  have hx : J.pL m<x := J.pL_lt_eL m
  have hend := (J.eL_lt_iff m).mpr hk
  have hs := J.signed_s_pos m ⟨(J.pL_mem m).1.trans hx,hend⟩
  have hp := (J.pL_pos m).trans hx
  have hl : 0<(A).ell x := mul_pos (J.toJacobiInit.eps_pos hp) (J.toJacobiInit.q_pos hp)
  have hd := J.d_pos x
  have ha := J.signed_a m ⟨hx,(hend.trans (J.bR_mem m).1).le⟩
  have hz : (A).z x=1 := (J.leftBracket m).z_of_X_zero
    (J.leftBracket m).Icc_mem_p1 (J.X_eL m)
  have hD : (A).Dz x=1 := by unfold JacobiData.Dz; rw [hz]; ring
  have hzα := (mul_eq_zero.mp (J.X_eL m)).resolve_left (fun e => hs.ne' (mul_eq_zero_of_right _ e))
  have hsa := aligned hs ha
  change (A).tangentTest x<0
  unfold JacobiData.tangentTest
  change (A).α1 x=0 at hzα
  rw [hzα,mul_zero,zero_div,zero_sub,hD,mul_one]
  exact div_neg_of_neg_of_pos (mul_neg_of_neg_of_pos (neg_lt_zero.mpr hsa) (sq_pos_of_pos hl)) (pow_pos hd _)

private theorem one_zero {f : ℝ → ℝ} {a b : ℝ} (hab : a<b) (hc : ContinuousOn f (Icc a b))
    (hinj : InjOn f (Icc a b)) (h : (f a<0 ∧ 0<f b) ∨ (0<f a ∧ f b<0)) :
    {x ∈ Ioo a b | f x=0}.ncard=1 := by
  have hex : ∃ x ∈ Icc a b, f x=0 := by
    rcases h with h|h
    · exact intermediate_value_Icc hab.le hc ⟨h.1.le,h.2.le⟩
    · exact intermediate_value_Icc' hab.le hc ⟨h.2.le,h.1.le⟩
  obtain ⟨x,hx,hz⟩ := hex
  have hi : x ∈ Ioo a b := by
    rcases h with h|h <;> constructor <;> first
      | exact hx.1.lt_of_ne (fun eq => by subst x; linarith)
      | exact hx.2.lt_of_ne (fun eq => by subst x; linarith)
  have singleton : {y ∈ Ioo a b | f y=0}= {x} := by
    ext y
    exact ⟨fun ⟨hy,hy0⟩ => hinj (Ioo_subset_Icc_self hy) hx (hy0.trans hz.symm),
      fun (eq : y=x) => eq ▸ ⟨hi,hz⟩⟩
  rw [singleton,ncard_singleton]

theorem interior_tangency_count :
    let L := J.leftBracket m
    let R := J.rightBracket m
    (J.K ≤ 2*J.E → L.tangentPoints=∅ ∧ R.tangentPoints=∅) ∧
    (2*J.E < J.K → L.tangentPoints.ncard=1 ∧ R.tangentPoints.ncard=1) := by
  let L := J.leftBracket m
  let R := J.rightBracket m
  let f := (A).tangentTest
  have el : L.tangentPoints={x ∈ Ioo (J.pL m) (J.eL m) | f x=0} := Set.ext fun _ => L.mem_tangentPoints
  have er : R.tangentPoints={x ∈ Ioo (J.eR m) (J.bR m) | f x=0} := Set.ext fun _ => R.mem_tangentPoints
  change (_ → L.tangentPoints=∅ ∧ R.tangentPoints=∅) ∧ (_ → L.tangentPoints.ncard=1 ∧ R.tangentPoints.ncard=1)
  rw [el,er]
  obtain ⟨down,up⟩ := J.tangentTest_monotone m
  have hl : 0<(A).ell P := mul_pos (J.toJacobiInit.eps_pos (J.two_m_two_pos m))
    (J.toJacobiInit.q_pos (J.two_m_two_pos m))
  have hd := J.d_pos P
  have cont {x} (hx : 0<x) := (A).tangentTest_cont (J.toJacobiInit.q_pos hx).ne'
    (J.toJacobiInit.eps_pos hx).ne' (J.d_pos x).ne'
  have pl := (J.pL_mem m).2
  have br := (J.bR_mem m).1
  constructor
  · intro hk
    have hc : 0≤f P := by
      rw [show f P=_ from J.test_center m]
      have := sub_nonneg.mpr hk
      positivity
    constructor
    · apply eq_empty_iff_forall_notMem.mpr
      rintro x ⟨⟨hx,hy⟩,hz⟩
      have lt := hy.trans_le (J.eL_le m)
      exact (hc.trans_lt (down ⟨hx.le,lt.le⟩ ⟨pl.le,le_rfl⟩ lt)).ne' hz
    · apply eq_empty_iff_forall_notMem.mpr
      rintro x ⟨⟨hx,hy⟩,hz⟩
      have lt := (J.eR_ge m).trans_lt hx
      exact (hc.trans_lt (up ⟨le_rfl,br.le⟩ ⟨lt.le,hy.le⟩ lt)).ne' hz
  · intro hk
    have hc : f P<0 := by
      rw [show f P=_ from J.test_center m]
      exact div_neg_of_neg_of_pos (mul_neg_of_neg_of_pos (mul_neg_of_pos_of_neg (by positivity) (sub_neg.mpr hk)) hl) (sq_pos_of_pos hd)
    have hR : J.eR m=P := le_antisymm (not_lt.mp (fun h => hk.asymm ((J.eR_gt_iff m).mp h))) (J.eR_ge m)
    rw [hR]
    constructor
    · apply one_zero (J.pL_lt_eL m) (fun x hx => (cont ((J.pL_pos m).trans_le hx.1)).continuousWithinAt)
        (down.injOn.mono (Icc_subset_Icc le_rfl (J.eL_le m)))
      exact Or.inr ⟨(J.outer_tests m).1,J.inner_left_negative m hk⟩
    · apply one_zero br (fun x hx => (cont ((J.two_m_two_pos m).trans_le hx.1)).continuousWithinAt) up.injOn
      exact Or.inl ⟨hc,(J.outer_tests m).2⟩
end JacobiFull

namespace JacobiConcrete
/-- Proposition 4.3 on the concrete SE(2) cells, relative to the unique critical modulus. -/
theorem cell_tangencies {k κ : ℝ} (hk : k ∈ Ioo (0:ℝ) 1) (hκ : κ ∈ Ioo (0:ℝ) 1)
    (critical : K κ=2*secondIntegral κ (Real.pi/2)) (m : ℕ) :
    let F := full k hk.1 hk.2
    (k≤κ → (F.leftBracket m).tangentPoints=∅ ∧ (F.rightBracket m).tangentPoints=∅) ∧
    (κ<k → (F.leftBracket m).tangentPoints.ncard=1 ∧ (F.rightBracket m).tangentPoints.ncard=1) := by
  let F := full k hk.1 hk.2
  have zero : normalizedGap κ=0 := by simp [normalizedGap,← critical]
  have count := F.interior_tangency_count m
  constructor
  · intro h
    apply count.1
    have gap := gap_strictAnti.antitoneOn hk hκ h
    rw [zero] at gap
    dsimp only [F]
    rw [full_K,full_E]
    exact sub_nonneg.mp (by simpa only [zero_mul] using (le_div_iff₀ hk.1).mp gap)
  · intro h
    apply count.2
    have gap := gap_strictAnti hκ hk h
    rw [zero] at gap
    dsimp only [F]
    rw [full_K,full_E]
    exact sub_neg.mp (by simpa only [zero_mul] using (div_lt_iff₀ hk.1).mp gap)
end JacobiConcrete

/-- At a counted point only the co-oriented branch is tangent. Its phase,
including every period translate, gives a cubic zero of the reduced Jacobian. -/
theorem SBracket.counted_contact (B : SBracket) {p : ℝ} (hp : p ∈ B.tangentPoints) :
    (∀ σ : ℝ, (σ=1 ∨ σ= -1) → (σ*deriv B.u p=1 ↔ σ=B.ε)) ∧
    ∀ n : ℤ, let ψ := B.ε*B.u p-p+2*B.K*n
      ∃ c : ℝ, c ≠ 0 ∧ Tendsto (fun x => B.J2 (ψ+x) x/(x-p)^3) (𝓝[≠] p) (𝓝 c) := by
  obtain ⟨hi,hu⟩ := hp
  have h := B.one_le_ε_deriv_u hi
  rw [← (B.hasDerivAt_u hi).deriv] at h
  have eq : B.ε*deriv B.u p=1 := by
    have ha : |B.ε|=1 := by rcases B.hε with e|e <;> simp [e]
    calc
      _ = |B.ε*deriv B.u p| := (abs_of_nonneg (by linarith)).symm
      _ = 1 := by rw [abs_mul,ha,hu,one_mul]
  constructor
  · intro σ _
    exact ⟨fun hz => mul_right_cancel₀ (fun e => by simp [e] at eq) (hz.trans eq.symm),
      fun e => e ▸ eq⟩
  · intro n
    have hphase : B.ε*B.u p-p+2*B.K*n+p=B.ε*B.u p+2*B.K*n := by ring
    simpa only [if_pos eq] using B.determinant_crossing_order hi B.hε n hphase
