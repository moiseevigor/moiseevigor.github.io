import SE2Conjugate.CornerFiniteness
import SE2Conjugate.SignChart

noncomputable section
open Set
namespace JacobiCore.CellEndpointOrder

/-- A zero with a nonzero linear coefficient. -/
def Simple (f : ℝ → ℝ) (p : ℝ) : Prop :=
  f p = 0 ∧ ∃ d ≠ 0, HasDerivAt f d p

private theorem product {f g : ℝ → ℝ} {p a b : ℝ} (hf : HasDerivAt f a p)
    (hg : HasDerivAt g b p)
    (h : (f p = 0 ∧ a ≠ 0 ∧ g p ≠ 0) ∨ (g p = 0 ∧ b ≠ 0 ∧ f p ≠ 0)) :
    Simple (fun x => f x * g x) p := by
  rcases h with ⟨hz,ha,hg'⟩ | ⟨hz,hb,hf'⟩
  · exact ⟨by simp [hz], _, by simpa [hz] using mul_ne_zero ha hg', hf.mul hg⟩
  · exact ⟨by simp [hz], _, by simpa [hz] using mul_ne_zero hf' hb, hf.mul hg⟩

variable (J : JacobiCore) (m : ℕ)

theorem outer (p : ℝ) (hp : p = J.toJacobiFull.pL m ∨ p = J.toJacobiFull.bR m) :
    Simple J.toJacobiData.β p := by
  let F := J.toJacobiFull
  let A := F.toJacobiData
  apply product (A.hasDerivAt_f1 p) (A.hasDerivAt_β1 p)
  rcases hp with rfl | rfl
  · let p := F.pL m
    have hz := F.f1_pL m
    have hs := F.signed_s_pos m (F.pL_mem m)
    have hc : F.c p ≠ 0 := by
      intro h
      change F.c p * _ - F.d p * F.s p = 0 at hz
      rw [h,zero_mul,zero_sub,neg_eq_zero] at hz
      rcases mul_eq_zero.mp hz with hd|hs'
      · exact (J.d_pos p).ne' hd
      · change 0 < _ * F.s p at hs
        simp [hs'] at hs
    have hd := A.hasDerivAt_f1 p
    have hq := (hd.div (F.hc p) hc).unique (A.hasDerivAt_f1_div_c p hc)
    refine Or.inl ⟨hz,?_,?_⟩
    · intro h
      change A.s p * A.d p * A.q p - A.c p * A.d p^2 = 0 at h
      change A.f1 p = 0 at hz
      change (_ * F.c p - A.f1 p * _) / _ = _ at hq
      simp only [h,hz,zero_mul,sub_self,zero_div] at hq
      exact (div_ne_zero (neg_ne_zero.mpr (pow_ne_zero 2 (J.d_pos p).ne')) (pow_ne_zero 2 hc)) hq.symm
    · have h := F.signed_β1_neg_odd m (Ioo_subset_Icc_self (F.pL_mem m))
      exact fun e => (ne_of_lt h) (mul_eq_zero_of_right _ e)
  · let p := F.bR m
    have hs := F.signed_s_pos_R m ⟨(F.bR_mem m).1,by
      have := (F.bR_mem m).2; have := F.K_pos; linarith⟩
    have hf := F.signed_f1_pos_cell m ⟨(F.pL_mem m).2.trans (F.bR_mem m).1,
      (F.bR_mem m).2.trans (F.pL_succ_mem m).1⟩
    refine Or.inr ⟨F.β1_bR m,?_,fun e => hf.ne' (mul_eq_zero_of_right _ e)⟩
    rw [A.β1_deriv_eq_Γ p (J.d_pos p).ne']
    exact neg_ne_zero.mpr (mul_ne_zero (mul_ne_zero (fun e => hs.ne' (mul_eq_zero_of_right _ e))
      (J.d_pos p).ne') (F.toJacobiInit.Γ_pos ((F.two_m_two_pos m).trans (F.bR_mem m).1)).ne')

theorem inner (hk : J.K ≠ 2*J.E) (p : ℝ)
    (hp : p = J.toJacobiFull.eL m ∨ p = J.toJacobiFull.eR m) :
    Simple J.toJacobiData.α p := by
  let F := J.toJacobiFull
  let A := F.toJacobiData
  have hI : p ∈ Ioo (F.pL m) (F.bR m) := by
    rcases hp with rfl|rfl
    · exact ⟨F.pL_lt_eL m,(F.eL_le m).trans_lt (F.bR_mem m).1⟩
    · exact ⟨(F.pL_mem m).2.trans_le (F.eR_ge m),F.eR_lt_bR m⟩
  have hz : F.s p*A.α1 p=0 := by rcases hp with rfl|rfl; exact F.X_eL m; exact F.X_eR m
  have hk' : 1-F.k^2 ≠ 0 := by nlinarith [F.k_lt_one,F.k_pos,mul_pos (sub_pos.mpr F.k_lt_one) (show 0<1+F.k by linarith [F.k_pos])]
  apply product ((F.hs p).const_mul (1-F.k^2)) (A.hasDerivAt_α1 p)
  by_cases he : p=(2*m+2)*F.K
  · subst p
    have hs := F.s_even (m+1)
    rw [F.cast2 m] at hs
    have hc := F.sc ((2*m+2)*F.K)
    have hα := F.signed_α1_2nK m
    refine Or.inl ⟨by simp [hs],mul_ne_zero hk' (mul_ne_zero (fun e => by simp [hs,e] at hc) (J.d_pos _).ne'),?_⟩
    intro e
    rw [e,mul_zero] at hα
    exact (mul_ne_zero (mul_ne_zero (by positivity) (J.d_pos _).ne') (sub_ne_zero.mpr (Ne.symm hk))) hα.symm
  · have hs : F.s p ≠ 0 := by
      rcases lt_or_gt_of_ne he with hl|hr
      · have h := F.signed_s_pos m ⟨(F.pL_mem m).1.trans hI.1,hl⟩
        exact fun e => h.ne' (mul_eq_zero_of_right _ e)
      · have h := F.signed_s_pos_R m ⟨hr,by
          have := hI.2.trans (F.bR_mem m).2; have := F.K_pos; linarith⟩
        exact fun e => h.ne' (mul_eq_zero_of_right _ e)
    have ha := (mul_eq_zero.mp hz).resolve_left hs
    have ep := (EndpointExpansion.alpha_endpoint_spec J m).2.2 p (Ioo_subset_Icc_self hI) ha
    have hd := (SignChart.alpha_simple J m).2.2
    rw [← ep] at hd
    exact Or.inr ⟨ha, (A.hasDerivAt_α1 p).deriv ▸ hd,mul_ne_zero hk' hs⟩

end JacobiCore.CellEndpointOrder

namespace JacobiCore.CellEndpointOrder
private theorem corner (J : JacobiCore) (B : SBracket) (hs : B.s = J.s)
    {p ψ : ℝ} (hp : p ∈ Icc B.p0 B.p1) (n : ℤ)
    (h : (Simple B.toJacobiData.β p ∧ ψ+p=2*J.K*n) ∨
      (Simple B.toJacobiData.α p ∧ ψ+p=J.K+2*J.K*n)) :
    Simple (fun x => B.J2 (ψ+x) x) p := by
  let A := B.toJacobiData
  let D := fun x => A.α x-A.β x
  let I := Icc B.p0 B.p1
  let u := fun x => J.Finv (B.r x)
  have hD (x) (hx : x ∈ I) : D x ≠ 0 := by
    change B.toJacobiData.α x-B.toJacobiData.β x ≠ 0
    rw [B.alpha_sub_beta hx]
    exact (mul_ne_zero (B.ell_pos_Icc hx).ne' (B.Dz_pos_Icc hx).ne')
  have hr (x) (hx : x ∈ I) : J.s2 (u x) = -A.β x / D x := by
    change J.s (J.Finv (B.r x))^2=_
    rw [J.Finv_spec (B.r_mem_Icc hx)]
    unfold SBracket.r
    rw [A.z_eq_neg_beta_div_ell x (B.q_pos x hx).ne' (B.eps_pos x hx).ne']
    change _ = _ / (A.α x-A.β x)
    rw [B.alpha_sub_beta hx,div_div]
  have ha := ((B.hs p).const_mul (1-B.k^2)).mul (A.hasDerivAt_α1 p)
  have hb := (A.hasDerivAt_f1 p).mul (A.hasDerivAt_β1 p)
  have hd : DifferentiableAt ℝ D p := ha.differentiableAt.sub hb.differentiableAt
  let g := fun x => J.s2 (ψ+x)-J.s2 (u x)
  have cg : g p=0 ∧ ∃ c ≠ 0, HasDerivWithinAt g c I p := by
    rcases h with ⟨⟨hz,c,hc,dc⟩,phase⟩|⟨⟨hz,c,hc,dc⟩,phase⟩
    · have hv : B.r p=0 := by
        have eq := hr p hp
        change J.s (J.Finv (B.r p))^2=_ at eq
        simpa [J.Finv_spec (B.r_mem_Icc hp),hz,A] using eq
      have dr := dc.neg.div hd.hasDerivAt (hD p hp)
      have dt : HasDerivWithinAt (fun x => J.s2 (u x)) (-c / D p) I p := by
        apply (dr.hasDerivWithinAt.congr (fun x hx => hr x hx) (hr p hp)).congr_deriv
        simp [hz]; field_simp [hD p hp]
      obtain ⟨h0,hn,ht⟩ := J.ordinary_corner_zero (u := u) (by simp [u,hv,J.Finv_zero]) n phase
        (div_ne_zero (neg_ne_zero.mpr hc) (hD p hp)) dt
      exact ⟨h0,_,hn,ht⟩
    · have complement (x) (hx : x ∈ I) : 1-J.s2 (u x)=A.α x/D x := by
        rw [hr x hx]; field_simp [hD x hx]; dsimp [D]; ring
      have hv : B.r p=1 := by
        have eq := complement p hp
        change 1-J.s (J.Finv (B.r p))^2=_ at eq
        rw [J.Finv_spec (B.r_mem_Icc hp)] at eq
        change 1-B.r p=B.toJacobiData.α p/_ at eq
        rw [hz,zero_div] at eq; linarith
      have dr := dc.div hd.hasDerivAt (hD p hp)
      have dt : HasDerivWithinAt (fun x => 1-J.s2 (u x)) (c / D p) I p := by
        apply (dr.hasDerivWithinAt.congr (fun x hx => complement x hx) (complement p hp)).congr_deriv
        simp [hz]; field_simp [hD p hp]
      obtain ⟨h0,hn,ht⟩ := J.ordinary_corner_K (u := u) (by simp [u,hv,J.Finv_one]) n phase
        (div_ne_zero hc (hD p hp)) dt
      exact ⟨h0,_,hn,ht⟩
  obtain ⟨h0,c,hc,dc⟩ := cg
  have factor (x) (hx : x ∈ I) : B.J2 (ψ+x) x=D x*g x := by
    dsimp only [g]; rw [hr x hx]
    change A.α x*B.s (ψ+x)^2+A.β x*B.c (ψ+x)^2=_*(J.s (ψ+x)^2-_)
    rw [← hs]
    have sc := B.sc (ψ+x)
    rw [show B.c (ψ+x)^2=1-B.s (ψ+x)^2 by linarith]
    field_simp [hD x hx]; dsimp [D]; ring
  have dw := (hd.hasDerivAt.hasDerivWithinAt.mul dc).congr (fun x hx => factor x hx) (factor p hp)
  have line := (hasDerivAt_id' p).const_add ψ
  have diff : DifferentiableAt ℝ (fun x => B.J2 (ψ+x) x) p :=
    (ha.differentiableAt.mul (((B.hs _).comp p line).differentiableAt.pow 2)).add
      (hb.differentiableAt.mul (((B.hc _).comp p line).differentiableAt.pow 2))
  have unique := uniqueDiffOn_Icc B.p0_lt_p1 p hp
  have eq := (dw.derivWithin unique).symm.trans (diff.hasDerivAt.hasDerivWithinAt.derivWithin unique)
  refine ⟨by simpa only [h0,mul_zero] using factor p hp,_,?_,diff.hasDerivAt⟩
  rw [← eq,h0,mul_zero,zero_add]
  exact mul_ne_zero (hD p hp) hc

/-- The outer corners stay simple even at the critical modulus. -/
theorem outer_corner (J : JacobiCore) (m : ℕ) {p ψ : ℝ} (n : ℤ)
    (hp : p=J.toJacobiFull.pL m ∨ p=J.toJacobiFull.bR m) (phase : ψ+p=2*J.K*n) :
    Simple (fun x => J.toJacobiFull.J2 (ψ+x) x) p := by
  let F := J.toJacobiFull
  have h := outer J m p hp
  rcases hp with rfl|rfl
  · exact corner J (F.leftBracket m) rfl ⟨le_rfl,(F.pL_lt_eL m).le⟩ n (Or.inl ⟨h,phase⟩)
  · exact corner J (F.rightBracket m) rfl ⟨(F.eR_lt_bR m).le,le_rfl⟩ n (Or.inl ⟨h,phase⟩)

/-- Both inner corners are simple whenever the two endpoints are distinct. -/
theorem inner_corner (J : JacobiCore) (m : ℕ) (hk : J.K ≠ 2*J.E) {p ψ : ℝ} (n : ℤ)
    (hp : p=J.toJacobiFull.eL m ∨ p=J.toJacobiFull.eR m) (phase : ψ+p=J.K+2*J.K*n) :
    Simple (fun x => J.toJacobiFull.J2 (ψ+x) x) p := by
  let F := J.toJacobiFull
  have h := inner J m hk p hp
  rcases hp with rfl|rfl
  · exact corner J (F.leftBracket m) rfl ⟨(F.pL_lt_eL m).le,le_rfl⟩ n (Or.inr ⟨h,phase⟩)
  · exact corner J (F.rightBracket m) rfl ⟨le_rfl,(F.eR_lt_bR m).le⟩ n (Or.inr ⟨h,phase⟩)
end JacobiCore.CellEndpointOrder
