import SE2Conjugate.EndpointPeriods
import SE2Conjugate.LargeIndex

noncomputable section
open Filter Set
open scoped Topology
namespace JacobiConcrete.FloquetProfile
open AmplitudeChart
/-- Parameters are the modulus and the normalized offset s/K. The auxiliary
variable v=1/n makes the limiting cell a regular parameter value. -/
abbrev Param := ℝ × ℝ
private abbrev E (k : ℝ) := secondIntegral k (Real.pi/2)
def offset (x : Param) := x.2*K x.1
private def src (x : Param) : V3 := ![0,x.1*offset x,x.1]
private def phi (x : Param) := inverseSource (src x) 0
private def S (x : Param) := Real.sin (phi x)
private def C (x : Param) := Real.cos (phi x)
private def D (x : Param) := speed x.1 (phi x)
private def e (x : Param) := secondIntegral x.1 (phi x)
private def q (x : Param) := offset x-e x
private def A (x : Param) := E x.1*(K x.1-E x.1)
private def T (x : Param) := S x*C x*D x
private def U (x : Param) := 2*(K x.1-2*E x.1)*T x
private def V (x : Param) := T x*(offset x-2*e x)+(S x)^2*(D x)^2
private def W (x : Param) (v : ℝ) := (2*E x.1+v*e x)*(2*(K x.1-E x.1)+v*q x)
private def W1 (x : Param) (v : ℝ) := 2*E x.1*q x+2*(K x.1-E x.1)*e x+v*e x*q x
private def Yrate (x : Param) (v : ℝ) := (U x+v*V x)/W x v
private def Y (x : Param) (v : ℝ) := (S x)^2+v*Yrate x v
private def R (x : Param) (v : ℝ) := (1-Y x v)/(1-x.1^2*Y x v)
private def Yerr (x : Param) (v : ℝ) := (4*A x*V x-U x*W1 x v)/(4*A x*W x v)
private def Rerr (x : Param) (v : ℝ) :=
  -(1-x.1^2)*Yrate x v/((1-x.1^2*Y x v)*(1-x.1^2*(S x)^2))

private theorem phi_eq {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) :
    phi x=amplitude _ h.1 h.2 (offset x) := by simp [phi,src,inverseSource,h.1,h.2,h.1.ne']
private theorem bounds {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) :
    0<A x ∧ W x 0≠0 ∧ 0<1-x.1^2*(S x)^2 := by
  have he : 0<E x.1 := by simpa only [full_E] using (full _ h.1 h.2).E_pos
  have hd : 0<K x.1-E x.1 := sub_pos.mpr (by simpa only [full_K,full_E] using (full _ h.1 h.2).E_lt_K)
  exact ⟨mul_pos he hd,by simp [W,he.ne',hd.ne'],radicand_pos _ h.1 h.2 _⟩

private theorem phi_cont {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) : ContinuousAt phi x := by
  have hk := (hasDerivAt_K _ h.1 h.2).continuousAt.comp (continuous_fst.continuousAt (x := x))
  have g : ContinuousAt src x := by
    apply continuousAt_pi.mpr
    intro i; fin_cases i <;> simp [src,offset] <;> fun_prop
  exact (continuous_apply 0).continuousAt.comp ((inverse_source_strict (src x) h.1 h.2).continuousAt.comp g)

private theorem coefficients_cont {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) :
    ContinuousAt (Function.uncurry W) (x,0) ∧ ContinuousAt (Function.uncurry Yerr) (x,0) ∧
    ContinuousAt (Function.uncurry Rerr) (x,0) ∧ ContinuousAt (Function.uncurry R) (x,0) ∧
    ContinuousAt (Function.uncurry Y) (x,0) := by
  let b : Param × ℝ := (x,0)
  have k := (hasDerivAt_K _ h.1 h.2).continuousAt.comp (continuous_fst.continuousAt (x := x))
  have en := (hasDerivAt_completeSecond _ h.1 h.2).continuousAt.comp (continuous_fst.continuousAt (x := x))
  have ph := phi_cont h
  have ep : ContinuousAt e x := secondIntegral_joint_continuous.continuousAt.comp
    (continuous_fst.continuousAt.prodMk ph)
  have dn : ContinuousAt D x := speed_joint_continuous.continuousAt.comp (continuous_fst.continuousAt.prodMk ph)
  have off : ContinuousAt offset x := continuous_snd.continuousAt.mul k
  have qa : ContinuousAt q x := off.sub ep
  have ar : ContinuousAt A x := en.mul (k.sub en)
  have sn : ContinuousAt S x := Real.continuous_sin.continuousAt.comp ph
  have cs : ContinuousAt C x := Real.continuous_cos.continuousAt.comp ph
  have tr : ContinuousAt T x := (sn.mul cs).mul dn
  have ua : ContinuousAt U x := (continuousAt_const.mul (k.sub (continuousAt_const.mul en))).mul tr
  have va : ContinuousAt V x := (tr.mul (off.sub (continuousAt_const.mul ep))).add ((sn.pow 2).mul (dn.pow 2))
  have ⟨ha,hw,hd⟩ := bounds h
  have hD : 1-x.1^2*Y x 0≠0 := by simpa [Y] using hd.ne'
  change ContinuousAt (fun p : Param × ℝ => W p.1 p.2) b ∧ _
  have k₂ : ContinuousAt (fun p : Param × ℝ => K p.1.1) b := by exact ContinuousAt.comp (g := K ∘ Prod.fst) (f := Prod.fst) k (continuous_fst.continuousAt (x := b))
  have e₂ : ContinuousAt (fun p : Param × ℝ => E p.1.1) b := by exact ContinuousAt.comp (g := E ∘ Prod.fst) (f := Prod.fst) en (continuous_fst.continuousAt (x := b))
  have w : ContinuousAt (fun p : Param × ℝ => W p.1 p.2) b := by unfold W; fun_prop
  have w1 : ContinuousAt (fun p : Param × ℝ => W1 p.1 p.2) b := by unfold W1; fun_prop
  have yr : ContinuousAt (fun p : Param × ℝ => Yrate p.1 p.2) b := by unfold Yrate; fun_prop (disch := assumption)
  have y : ContinuousAt (fun p : Param × ℝ => Y p.1 p.2) b := by unfold Y; fun_prop
  refine ⟨w,?_,?_,?_,y⟩
  · change ContinuousAt (fun p : Param × ℝ => Yerr p.1 p.2) b
    unfold Yerr
    apply ContinuousAt.div
    · fun_prop
    · fun_prop
    · exact mul_ne_zero (mul_ne_zero (by norm_num : (4:ℝ)≠0) ha.ne') hw
  · change ContinuousAt (fun p : Param × ℝ => Rerr p.1 p.2) b
    unfold Rerr
    apply ContinuousAt.div
    · fun_prop
    · fun_prop
    · exact mul_ne_zero hD hd.ne'
  · change ContinuousAt (fun p : Param × ℝ => R p.1 p.2) b
    unfold R
    apply ContinuousAt.div
    · fun_prop
    · fun_prop
    · exact hD

private theorem compact_bound {Z : Set Param} (hz : IsCompact Z) (f : Param → ℝ → ℝ)
    (h : ∀ x ∈ Z, ∃ C : ℝ, ∀ᶠ p : Param × ℝ in 𝓝 (x,0), |f p.1 p.2| ≤ C) :
    ∃ C : ℝ, 0<C ∧ ∀ᶠ v in 𝓝 (0:ℝ), ∀ x ∈ Z, |f x v| ≤ C := by
  apply hz.induction_on (p := fun Z => ∃ C : ℝ, 0<C ∧ ∀ᶠ v in 𝓝 (0:ℝ), ∀ x ∈ Z, |f x v| ≤ C)
  · exact ⟨1,zero_lt_one,by simp⟩
  · intro s t hst ⟨c,hc,hs⟩
    exact ⟨c,hc,hs.mono fun _ hv x hx => hv x (hst hx)⟩
  · intro s t ⟨c,hc,hs⟩ ⟨d,_,ht⟩
    refine ⟨max c d,hc.trans_le (le_max_left ..),?_⟩
    filter_upwards [hs,ht] with v sv tv
    intro x hx; rcases hx with hx|hx
    · exact (sv x hx).trans (le_max_left ..)
    · exact (tv x hx).trans (le_max_right ..)
  · intro x hx
    obtain ⟨c,hc⟩ := h x hx
    rw [nhds_prod_eq] at hc
    obtain ⟨s,hs,t,ht,hst⟩ := Filter.mem_prod_iff.mp hc
    refine ⟨s,mem_nhdsWithin_of_mem_nhds hs,max c 1,zero_lt_one.trans_le (le_max_right ..),?_⟩
    filter_upwards [ht] with v hv
    exact fun y hy => (hst (Set.mk_mem_prod hy hv)).trans (le_max_left ..)

private theorem tube {Z : Set Param} (hz : IsCompact Z) {P : Param → ℝ → Prop}
    (h : ∀ x ∈ Z, ∀ᶠ p : Param × ℝ in 𝓝 (x,0), P p.1 p.2) :
    ∀ᶠ v in 𝓝 (0:ℝ), ∀ x ∈ Z, P x v := by
  have unif := hz.mem_nhdsSet_prod_of_forall (l := 𝓝 (0:ℝ)) (s := {p : Param × ℝ | P p.1 p.2}) (by intro x hx; rw [← nhds_prod_eq]; exact h x hx)
  obtain ⟨s,hs,t,ht,hst⟩ := Filter.mem_prod_iff.mp unif
  exact Filter.mem_of_superset ht fun _ hv x hx => hst (Set.mk_mem_prod (subset_of_mem_nhdsSet hs hx) hv)

private theorem bounded_near {f : Param → ℝ → ℝ} {x : Param}
    (hf : ContinuousAt (Function.uncurry f) (x,0)) :
    ∃ C : ℝ, ∀ᶠ p : Param × ℝ in 𝓝 (x,0), |f p.1 p.2| ≤ C :=
  ⟨|f x 0|+1,(hf.abs.eventually_lt_const (by linarith : |f x 0| < |f x 0|+1)).mono fun _ h => h.le⟩

/-- y and r evaluated in the actual translated cell. -/
def cellY (J : JacobiCore) (n : ℕ) (s : ℝ) :=
  J.toJacobiData.X (s+2*n*J.K)/J.toJacobiData.ell (s+2*n*J.K)
def cellR (J : JacobiCore) (n : ℕ) (s : ℝ) :=
  J.toJacobiData.z (s+2*n*J.K)/J.toJacobiData.Dz (s+2*n*J.K)

private theorem identify {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) (n : ℕ) (hn : (n:ℝ)≠0)
    (hw : W x (n:ℝ)⁻¹≠0) :
    let J := core _ h.1 h.2
    cellY J n (offset x)=Y x (n:ℝ)⁻¹ ∧ cellR J n (offset x)=R x (n:ℝ)⁻¹ := by
  let J := core _ h.1 h.2
  let s := offset x
  let v := (n:ℝ)⁻¹
  have hs : S x=J.s s := by rw [S,phi_eq h]; rfl
  have hc : C x=J.c s := by rw [C,phi_eq h]; rfl
  have hd : D x=J.d s := by rw [D,phi_eq h]; rfl
  have he : e x=J.eps s := by rw [e,phi_eq h]; rfl
  have ej : E x.1=J.E := (full_E _ h.1 h.2).symm
  have w : W x v*(n:ℝ)^2=J.periodWeight n s := by
    unfold W q JacobiCore.periodWeight
    rw [he,ej]; change (2*J.E+v*J.eps s)*(2*(J.K-J.E)+v*(s-J.eps s))*_=_
    dsimp [v]; field_simp; ring
  have c : U x*(n:ℝ)+V x=J.profileCorrection n s := by
    unfold U V T JacobiCore.profileCorrection; rw [hs,hc,hd,he,ej]
    change 2*(J.K-2*J.E)*_*_+_=_
    ring
  have wpos : J.periodWeight n s≠0 := w ▸ mul_ne_zero hw (pow_ne_zero 2 hn)
  have yh := J.profile_exact n s wpos
  have y : cellY J n s=Y x v := by
    change cellY J n s-J.s s^2=_ at yh
    rw [← w,← c] at yh
    unfold Y Yrate
    rw [hs]; dsimp only [v] at *
    field_simp [hw,hn] at yh ⊢
    linear_combination yh
  refine ⟨y,?_⟩
  let p := s+2*n*J.K
  have hl : J.toJacobiData.ell p≠0 := (J.weight_at_period n s) ▸ wpos
  have hq := right_ne_zero_of_mul hl
  have he' := left_ne_zero_of_mul hl
  have z : J.toJacobiData.z p=1-cellY J n s := by
    rw [J.toJacobiData.z_eq_neg_beta_div_ell p hq he',J.toJacobiData.collapse_beta]
    change _=1-J.toJacobiData.X p/J.toJacobiData.ell p
    field_simp; ring
  unfold cellR R
  change J.toJacobiData.z p/(1-J.k^2+J.k^2*J.toJacobiData.z p)=_
  rw [z,y]; congr 1; change 1-x.1^2+x.1^2*(1-Y x v)=_; ring

private theorem rzero {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) :
    let J := core _ h.1 h.2
    R x 0=J.s (J.K-|offset x|)^2 := by
  let J := core _ h.1 h.2
  let s := offset x
  have e₁ : S x=J.s s := by rw [S,phi_eq h]; rfl
  have ev := J.quarter_values (-|s|)
  have ec : J.c (-|s|)=J.c s := by
    rw [(JacobiCore.Addition.even_cd J _).1]; rcases le_or_gt 0 s with h|h
    · rw [abs_of_nonneg h]
    · rw [abs_of_neg h,(JacobiCore.Addition.even_cd J _).1]
  have ed : J.d (-|s|)=J.d s := by
    rw [(JacobiCore.Addition.even_cd J _).2]; rcases le_or_gt 0 s with h|h
    · rw [abs_of_nonneg h]
    · rw [abs_of_neg h,(JacobiCore.Addition.even_cd J _).2]
  change R x 0=J.s (J.K-|s|)^2
  rw [show J.K-|s|= -|s|+J.K by ring,ev.1,ec,ed]
  simp only [R,Y,zero_mul,add_zero,e₁]
  change (1-J.s s^2)/(1-J.k^2*J.s s^2)=(J.c s/J.d s)^2
  rw [← J.sd,div_pow,show 1-J.s s^2=J.c s^2 by linarith [J.sc s]]

private theorem identities {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) (v : ℝ)
    (hw : W x v ≠ 0) (hy : 1-x.1^2*Y x v ≠ 0) :
    Y x v-S x^2-v*(U x/(4*A x))=v^2*Yerr x v ∧ R x v-R x 0=v*Rerr x v := by
  obtain ⟨ha,_,hd⟩ := bounds h
  have w : W x v=4*A x+v*W1 x v := by unfold W A W1; ring
  constructor
  · unfold Y Yrate Yerr
    rw [w] at hw ⊢
    field_simp [ha.ne',hw]; ring
  · unfold R Rerr
    simp only [show Y x 0=S x^2 by simp [Y]]
    generalize gy : Y x v = y at hy ⊢
    generalize ga : S x ^ 2 = a at hd ⊢
    have heqy : y=a+v*Yrate x v := by grind [Y]
    rw [div_sub_div _ _ hy hd.ne',← mul_div_assoc]
    congr 1
    rw [heqy]; ring

def linearCorrection (J : JacobiCore) (s : ℝ) :=
  (J.K-2*J.E)*J.s s*J.c s*J.d s/(2*J.E*(J.K-J.E))

private theorem correction_eq {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) :
    U x/(4*A x)=linearCorrection (core _ h.1 h.2) (offset x) := by
  let J := core _ h.1 h.2
  have hs : S x=J.s (offset x) := by rw [S,phi_eq h]; rfl
  have hc : C x=J.c (offset x) := by rw [C,phi_eq h]; rfl
  have hd : D x=J.d (offset x) := by rw [D,phi_eq h]; rfl
  unfold U A T linearCorrection
  rw [hs,hc,hd,show E x.1=J.E from (full_E _ h.1 h.2).symm]
  change 2*(J.K-2*J.E)*_/(4*(J.E*(J.K-J.E)))=(J.K-2*J.E)*_*_*_/(2*J.E*(J.K-J.E))
  field_simp; ring

private theorem good_near {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) :
    ∀ᶠ p : Param × ℝ in 𝓝 (x,0), W p.1 p.2≠0 ∧ 1-p.1.1^2*Y p.1 p.2≠0 := by
  obtain ⟨w,_,_,_,y⟩ := coefficients_cont h
  have d : ContinuousAt (fun p : Param × ℝ => 1-p.1.1^2*Y p.1 p.2) (x,0) := by
    change ContinuousAt (fun p : Param × ℝ => Y p.1 p.2) _ at y
    fun_prop
  exact (w.eventually_ne (bounds h).2.1).and (d.eventually_ne (by simpa [Y] using (bounds h).2.2.ne'))

private theorem invn : Tendsto (fun n : ℕ => (n:ℝ)⁻¹) atTop (𝓝 0) := by
  simpa [one_div] using (tendsto_one_div_atTop_nhds_zero_nat (𝕜 := ℝ))

theorem compact_profiles {Z : Set Param} (hz : IsCompact Z) (sub : ∀ x ∈ Z, x.1 ∈ Ioo (0:ℝ) 1) :
    ∃ B : ℝ, 0<B ∧ ∀ᶠ n : ℕ in atTop, ∀ x (hx : x∈Z),
      let J := core _ (sub x hx).1 (sub x hx).2
      let s := offset x
      |cellY J n s-J.s s^2-(n:ℝ)⁻¹*linearCorrection J s| ≤ ((n:ℝ)⁻¹)^2*B ∧
      |cellR J n s-J.s (J.K-|s|)^2| ≤ (n:ℝ)⁻¹*B := by
  obtain ⟨a,ha,ea⟩ := compact_bound hz Yerr fun x hx => bounded_near (coefficients_cont (sub x hx)).2.1
  obtain ⟨b,_,eb⟩ := compact_bound hz Rerr fun x hx => bounded_near (coefficients_cont (sub x hx)).2.2.1
  refine ⟨max a b,ha.trans_le (le_max_left ..),?_⟩
  have eg := tube hz (P := fun x v => W x v≠0 ∧ 1-x.1^2*Y x v≠0) fun x hx => good_near (sub x hx)
  filter_upwards [invn.eventually ea,invn.eventually eb,invn.eventually eg,eventually_ge_atTop 1] with n e₁ e₂ e₃ hn
  intro x hx
  have h := sub x hx
  have hn' : 0<(n:ℝ) := by exact_mod_cast (show 0<n by omega)
  have ⟨hw,hy⟩ := e₃ x hx
  have ⟨ey,er⟩ := identify h n hn'.ne' hw
  have ⟨ay,ar⟩ := identities h _ hw hy
  dsimp only
  rw [ey,er,←rzero h,←correction_eq h,show (core _ h.1 h.2).s (offset x)=S x by rw [S,phi_eq h]; rfl, ay,ar,abs_mul,abs_mul,abs_of_nonneg (sq_nonneg _),abs_of_pos (inv_pos.mpr hn')]
  exact ⟨mul_le_mul_of_nonneg_left ((e₁ x hx).trans (le_max_left ..)) (sq_nonneg _),
    mul_le_mul_of_nonneg_left ((e₂ x hx).trans (le_max_right ..)) (inv_pos.mpr hn').le⟩
private def decode (p : ℝ × ℝ) := firstIntegral p.1 (Real.arcsin (Real.sqrt p.2))
private theorem decode_cont {p : ℝ × ℝ} (h : p.1 ∈ Ioo (0:ℝ) 1) : ContinuousAt decode p :=
  (firstIntegral_joint_continuousAt _ _ h.1 h.2).comp (f := fun q : Param => (q.1,Real.arcsin (Real.sqrt q.2)))
    (continuous_fst.continuousAt.prodMk (Real.continuous_arcsin.continuousAt.comp
      (Real.continuous_sqrt.continuousAt.comp continuous_snd.continuousAt)))

private theorem decode_eq {k r : ℝ} (h : k ∈ Ioo (0:ℝ) 1) (hr : r ∈ Icc (0:ℝ) 1) :
    (core k h.1 h.2).Finv r=decode (k,r) := by
  apply JacobiCore.Finv_unique
  · have hm := (firstIntegral_strictMono k h.1 h.2).monotone
    exact ⟨by simpa [decode,firstIntegral_zero] using hm (Real.arcsin_nonneg.mpr (Real.sqrt_nonneg r)),
      hm (Real.arcsin_le_pi_div_two _)⟩
  · change Real.sin (amplitude k h.1 h.2 (firstIntegral k (Real.arcsin (Real.sqrt r))))^2=r
    rw [amplitude_integral,Real.sin_arcsin,Real.sq_sqrt hr.1]
    · linarith [Real.sqrt_nonneg r]
    · exact (Real.sqrt_le_one.mpr hr.2)

private theorem offset_mem {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) (hs : |x.2|≤1) :
    let J := core _ h.1 h.2
    J.K-|offset x| ∈ Icc 0 J.K := by
  have hk := (core _ h.1 h.2).K_pos
  change 0≤K x.1-|x.2*K x.1| ∧ K x.1-|x.2*K x.1|≤K x.1
  change 0<K x.1 at hk
  rw [abs_mul,abs_of_pos hk]
  constructor <;> nlinarith [abs_nonneg x.2]

private theorem decode_limit {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) (hs : |x.2|≤1) :
    decode (x.1,R x 0)=K x.1-|offset x| := by
  let J := core _ h.1 h.2
  have hm := offset_mem h hs
  have er := rzero h
  have hr : R x 0 ∈ Icc (0:ℝ) 1 := by
    rw [er]; exact ⟨sq_nonneg _,by nlinarith [J.sc (J.K-|offset x|),sq_nonneg (J.c (J.K-|offset x|))]⟩
  rw [←decode_eq h hr]
  exact J.Finv_unique hm er.symm

private theorem branch_near {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) (hs : |x.2|≤1)
    {ε : ℝ} (he : 0<ε) :
    ∀ᶠ p : Param × ℝ in 𝓝 (x,0), |decode (p.1.1,R p.1 p.2)-(K p.1.1-|offset p.1|)|<ε := by
  let g (p : Param × ℝ) := (p.1.1,R p.1 p.2)
  have rc := (coefficients_cont h).2.2.2.1
  have kc := (hasDerivAt_K _ h.1 h.2).continuousAt
  have gc : ContinuousAt g (x,0) := (continuous_fst.comp continuous_fst).continuousAt.prodMk rc
  have dc : ContinuousAt (decode ∘ g) (x,0) := ContinuousAt.comp (g := decode) (f := g) (decode_cont (p := g (x,0)) h) gc
  have kc₂ : ContinuousAt (fun p : Param × ℝ => K p.1.1) (x,0) := ContinuousAt.comp (g := K) (f := fun p : Param × ℝ => p.1.1) kc (continuous_fst.comp continuous_fst).continuousAt
  have off : ContinuousAt (fun p : Param × ℝ => offset p.1) (x,0) := (continuous_snd.comp continuous_fst).continuousAt.mul kc₂
  let gap (p : Param × ℝ) := decode (g p)-(K p.1.1-|offset p.1|)
  have c : ContinuousAt gap (x,0) := dc.sub (kc₂.sub off.abs)
  have ez : |gap (x,0)|<ε := by change |decode (x.1,R x 0)-(K x.1-|offset x|)|<ε; rw [decode_limit h hs,sub_self,abs_zero]; exact he
  exact c.abs.eventually_lt_const ez

theorem compact_zero_curves {Z : Set Param} (hz : IsCompact Z)
    (sub : ∀ x ∈ Z, x.1 ∈ Ioo (0:ℝ) 1) (hs : ∀ x ∈ Z, |x.2|≤1) {ε : ℝ} (he : 0<ε) :
    ∀ᶠ n : ℕ in atTop, ∀ x (hx : x∈Z),
      let J := core _ (sub x hx).1 (sub x hx).2
      let r := cellR J n (offset x)
      r ∈ Icc (0:ℝ) 1 → |J.Finv r-(J.K-|offset x|)|<ε ∧
        |(2*J.K-J.Finv r)-(J.K+|offset x|)|<ε := by
  have e := tube hz (P := fun x v => |decode (x.1,R x v)-(K x.1-|offset x|)|<ε)
    fun x hx => branch_near (sub x hx) (hs x hx) he
  have eg := tube hz (P := fun x v => W x v≠0) fun x hx => (good_near (sub x hx)).mono fun _ hg => hg.1
  filter_upwards [invn.eventually e,invn.eventually eg,eventually_ge_atTop 1] with n ev ew hn
  intro x hx
  dsimp only
  intro hr
  have h := sub x hx
  have er := (identify h n (by exact_mod_cast (show n≠0 by omega)) (ew x hx)).2
  rw [decode_eq h hr,er]
  have v := ev x hx
  exact ⟨v,by convert v using 1; rw [←abs_neg]; congr 1; change -(2*K x.1-_-(K x.1+_))=_; ring⟩


private theorem regular {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) (hs : |x.2| ∈ Ioo (0:ℝ) 1) :
    R x 0 ∈ Ioo (0:ℝ) 1 := by
  let J := core _ h.1 h.2
  have hk : 0<K x.1 := J.K_pos
  have hm := offset_mem h hs.2.le
  have hu : 0<J.K-|offset x| ∧ J.K-|offset x|<J.K := by
    change 0<K x.1-|x.2*K x.1| ∧ K x.1-|x.2*K x.1|<K x.1
    rw [abs_mul,abs_of_pos hk]; constructor <;> nlinarith [hs.1,hs.2,mul_pos hs.1 hk,mul_lt_mul_of_pos_right hs.2 hk]
  rw [rzero h]
  change 0<J.s2 _ ∧ J.s2 _<1
  exact ⟨by simpa only [J.s2_zero] using J.s2_strictMonoOn ⟨le_rfl,J.K_pos.le⟩ hm hu.1,
    by simpa only [J.s2_K] using J.s2_strictMonoOn hm ⟨J.K_pos.le,le_rfl⟩ hu.2⟩

private theorem decode_lip {p : Param} (h : p.1 ∈ Ioo (0:ℝ) 1) (hr : p.2 ∈ Ioo (0:ℝ) 1) :
    ∃ L, ∃ u ∈ 𝓝 p, LipschitzOnWith L decode u := by
  have hs := (Real.hasStrictDerivAt_arcsin (x := Real.sqrt p.2)
    (by linarith [Real.sqrt_nonneg p.2]) (by nlinarith [Real.sq_sqrt hr.1.le,hr.2])).comp _ (Real.hasStrictDerivAt_sqrt hr.1.ne')
  have hd := (hasStrictFDerivAt_firstIntegral p.1 _ h.1 h.2).comp p
    ((hasStrictFDerivAt_fst (𝕜 := ℝ) (p := p)).prodMk (hs.comp_hasStrictFDerivAt p (hasStrictFDerivAt_snd (𝕜 := ℝ) (p := p))))
  exact hd.exists_lipschitzOnWith

private def branchRate (x : Param) (v : ℝ) :=
  (decode (x.1,R x v)-decode (x.1,R x 0))/v

private theorem rate_near {x : Param} (h : x.1 ∈ Ioo (0:ℝ) 1) (hs : |x.2| ∈ Ioo (0:ℝ) 1) :
    ∃ C : ℝ, ∀ᶠ p : Param × ℝ in 𝓝 (x,0), |branchRate p.1 p.2|≤C := by
  obtain ⟨L,u,hu,lip⟩ := decode_lip (p := (x.1,R x 0)) h (regular h hs)
  have rc := (coefficients_cont h).2.2.2.1
  have c₁ : ContinuousAt (fun p : Param × ℝ => (p.1.1,R p.1 p.2)) (x,0) :=
    (continuous_fst.comp continuous_fst).continuousAt.prodMk rc
  have c₀ : ContinuousAt (fun p : Param × ℝ => (p.1.1,R p.1 0)) (x,0) :=
    c₁.comp (g := fun q : Param × ℝ => (q.1.1,R q.1 q.2)) (f := fun p : Param × ℝ => (p.1,(0:ℝ))) (continuous_fst.continuousAt.prodMk continuousAt_const)
  obtain ⟨B,bd⟩ := bounded_near (coefficients_cont h).2.2.1
  refine ⟨L*max B 0,?_⟩
  have hk : ∀ᶠ p : Param × ℝ in 𝓝 (x,0), p.1.1 ∈ Ioo (0:ℝ) 1 :=
    (continuous_fst.comp continuous_fst).continuousAt (Ioo_mem_nhds h.1 h.2)
  filter_upwards [c₁ hu,c₀ hu,bd,good_near h,hk] with p a b hb hg hp
  have d := lip.dist_le_mul (p.1.1,R p.1 p.2) a (p.1.1,R p.1 0) b
  simp only [Prod.dist_eq,dist_self,Real.dist_eq] at d
  unfold branchRate
  by_cases hv : p.2=0
  · simp [hv,mul_nonneg L.coe_nonneg (le_max_right B 0)]
  rw [abs_div,div_le_iff₀ (abs_pos.mpr hv)]
  rw [max_eq_right (abs_nonneg _),(identities hp p.2 hg.1 hg.2).2,abs_mul] at d
  calc
    _ ≤ _ := d
    _ ≤ _ := by nlinarith [mul_le_mul_of_nonneg_left (hb.trans (le_max_left B 0)) (mul_nonneg L.coe_nonneg (abs_nonneg p.2))]

/-- Away from the three corners both actual branches exist for large n
and converge at inverse-index speed, uniformly on compact parameter sets. -/
theorem compact_regular_curves {Z : Set Param} (hz : IsCompact Z)
    (sub : ∀ x ∈ Z, x.1 ∈ Ioo (0:ℝ) 1) (hs : ∀ x ∈ Z, |x.2| ∈ Ioo (0:ℝ) 1) :
    ∃ B : ℝ, 0<B ∧ ∀ᶠ n : ℕ in atTop, ∀ x (hx : x∈Z),
      let J := core _ (sub x hx).1 (sub x hx).2
      let r := cellR J n (offset x)
      r ∈ Ioo (0:ℝ) 1 ∧ |J.Finv r-(J.K-|offset x|)|≤B*(n:ℝ)⁻¹ ∧
        |(2*J.K-J.Finv r)-(J.K+|offset x|)|≤B*(n:ℝ)⁻¹ := by
  obtain ⟨B,bp,eb⟩ := compact_bound hz branchRate fun x hx => rate_near (sub x hx) (hs x hx)
  have eg := tube hz (P := fun x v => W x v≠0 ∧ R x v ∈ Ioo (0:ℝ) 1) (by
    intro x hx
    have h := sub x hx
    have hr := regular h (hs x hx)
    exact ((good_near h).mono fun _ hg => hg.1).and ((coefficients_cont h).2.2.2.1 (Ioo_mem_nhds hr.1 hr.2)))
  refine ⟨B,bp,?_⟩
  filter_upwards [invn.eventually eb,invn.eventually eg,eventually_ge_atTop 1] with n bound good hn
  intro x hx
  have h := sub x hx
  have hn' : 0<(n:ℝ) := by exact_mod_cast (show 0<n by omega)
  have ⟨w,r⟩ := good x hx
  have er := (identify h n hn'.ne' w).2
  dsimp only
  rw [er]
  refine ⟨r,?_⟩
  rw [decode_eq h ⟨r.1.le,r.2.le⟩]
  have d := bound x hx
  rw [branchRate,abs_div,abs_of_pos (inv_pos.mpr hn'),div_le_iff₀ (inv_pos.mpr hn'),decode_limit h (hs x hx).2.le] at d
  exact ⟨d,by change |2*K x.1-_-(K x.1+_)|≤_; rw [show 2*K x.1-decode (x.1,R x (n:ℝ)⁻¹)-(K x.1+|offset x|) = -(decode (x.1,R x (n:ℝ)⁻¹)-(K x.1-|offset x|)) by ring,abs_neg]; exact d⟩
end JacobiConcrete.FloquetProfile
