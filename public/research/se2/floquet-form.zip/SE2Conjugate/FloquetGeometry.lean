import SE2Conjugate.EndpointPeriods
import SE2Conjugate.LargeIndex

noncomputable section
open Set Filter
open scoped Topology
namespace JacobiConcrete.Floquet
open AmplitudeChart
abbrev E (k : ℝ) := secondIntegral k (Real.pi/2)
def length (k : ℝ) := 4*(K k-E k)
def period (k : ℝ) := 4*(k*K k)

theorem length_derivative {k : ℝ} (hk : k ∈ Ioo (0:ℝ) 1) :
    HasDerivAt length (4*k*E k/(1-k^2)) k ∧ 0<deriv length k := by
  have h := ((hasDerivAt_K k hk.1 hk.2).sub (hasDerivAt_completeSecond k hk.1 hk.2)).const_mul 4
  have hd : 0<1-k^2 := by nlinarith [hk.1,hk.2]
  have he : 0<E k := by simpa only [full_E] using (full k hk.1 hk.2).E_pos
  have eq : HasDerivAt length (4*k*E k/(1-k^2)) k := h.congr_deriv (by unfold E; field_simp [hk.1.ne',hd.ne']; ring)
  exact ⟨eq,eq.deriv.symm ▸ div_pos (mul_pos (mul_pos (by norm_num) hk.1) he) hd⟩

/-- Coordinates are phase, modulus, and physical time in this order. -/
def sourcePoint (z : V3) : V3 := ![z 2,z 1*z 0,z 1]
def path (σ : ℝ) (z : V3) := rectifiedEndpoint σ (sourcePoint z)
def initialAngle (z : V3) := angle 0 (inverseSource (sourcePoint z))
def drift (σ : ℝ) (z : V3) : V3 :=
  ![σ*length (z 1)*Real.sin (initialAngle z),-σ*length (z 1)*Real.cos (initialAngle z),0]
def shifted (n : ℕ) (z : V3) : V3 := z + (n*period (z 1)) • Pi.single 2 1

private theorem source_diff (z : V3) : DifferentiableAt ℝ sourcePoint z := by
  apply differentiableAt_pi.mpr
  intro i; fin_cases i <;> simp [sourcePoint] <;> fun_prop

private theorem angle_eq {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) :
    initialAngle z = (full (z 1) h.1 h.2).rotationAngle (z 0) := by
  change initialAngle z = Real.arcsin (z 1*Real.sin (amplitude _ h.1 h.2 (z 0)))
  simp [initialAngle,inverseSource,sourcePoint,h.1,h.2,angle,h.1.ne']

private theorem angle_diff {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) : DifferentiableAt ℝ initialAngle z := by
  have hi := inverse_source_strict (sourcePoint z) h.1 h.2
  have hm := inverse_source_modulus (sourcePoint z) h.1 h.2
  exact ((angle_deriv 0 _ (hm ▸ h.1) (hm ▸ h.2)).differentiableAt.comp z
    (hi.differentiableAt.comp z (source_diff z)))

private theorem path_eq (σ : ℝ) {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) :
    let J := full (z 1) h.1 h.2
    path σ z = ![J.endpointX σ (z 0) (z 2),J.endpointY σ (z 0) (z 2),J.endpointTheta (z 0) (z 2)] := by
  simpa [path,sourcePoint,h.1.ne'] using rectified_eq_concrete σ (sourcePoint z) h.1 h.2

private theorem path_diff (σ : ℝ) {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) : DifferentiableAt ℝ (path σ) z :=
  (rectified_deriv σ (sourcePoint z) h.1 h.2).differentiableAt.comp z (source_diff z)

@[simp] private theorem shift0 (n : ℕ) (z : V3) : shifted n z 0=z 0 := by simp [shifted]
@[simp] private theorem shift1 (n : ℕ) (z : V3) : shifted n z 1=z 1 := by simp [shifted]
@[simp] private theorem shift2 (n : ℕ) (z : V3) : shifted n z 2=z 2+n*period (z 1) := by simp [shifted]

theorem period_translation (σ : ℝ) {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) (n : ℕ) :
    path σ (shifted n z)=path σ z + (n:ℝ) • drift σ z := by
  let J := core (z 1) h.1 h.2
  let F := J.toJacobiFull
  let v := F.terminalPhase (z 0) (z 2)
  let N : ℕ := 2*n
  have hp : F.terminalPhase (z 0) (z 2+n*period (z 1)) = v+2*N*J.K := by
    change z 0+(z 2+↑n*(4*(z 1*J.K)))/(z 1) = z 0+z 2/(z 1)+2*↑(2*n)*J.K
    push_cast; field_simp [h.1.ne']; ring
  have hn : (-1:ℝ)^N=1 := by simp [N,pow_mul]
  have hW : F.endpointW (z 0) (z 2+n*period (z 1))=F.endpointW (z 0) (z 2)+n*length (z 1) := by
    unfold JacobiFull.endpointW
    rw [hp,show F.eps (v+2*N*J.K)=J.eps v+2*N*J.E from J.epsilon_periods N v]
    change (z 2+↑n*(4*(z 1*J.K)))/(z 1)+_-(J.eps v+2*↑N*J.E)=z 2/(z 1)+_-J.eps v+↑n*(4*(J.K-E (z 1)))
    unfold E
    rw [← full_E (z 1) h.1 h.2]
    change _ = _ + ↑n*(4*(J.K-J.E))
    dsimp only [N]; push_cast; field_simp [h.1.ne']; ring
  have sc := J.s_shift_n N v
  have cc := J.c_shift_n N v
  rw [hn,one_mul] at sc cc
  change F.s (v+2*N*J.K)=F.s v at sc
  change F.c (v+2*N*J.K)=F.c v at cc
  rw [path_eq σ (z := shifted n z) (by simpa),path_eq σ h]
  simp only [shift0,shift1,shift2,drift,angle_eq h]
  change ![F.endpointX σ _ _,F.endpointY σ _ _,F.endpointTheta _ _] = _
  ext i
  fin_cases i
  · change F.endpointX σ _ _=F.endpointX σ _ _+↑n*(σ*length (z 1)*Real.sin (F.rotationAngle _))
    unfold JacobiFull.endpointX
    rw [hW,hp,cc,F.sin_rotationAngle]; change _ = σ*F.k*(F.d _*(F.c _-F.c v)+_)+_; ring
  · change F.endpointY σ _ _=F.endpointY σ _ _+↑n*(-σ*length (z 1)*Real.cos (F.rotationAngle _))
    unfold JacobiFull.endpointY
    rw [hW,hp,cc,F.cos_rotationAngle]; change _ = σ*(F.k^2*F.s _*(F.c _-F.c v)-_)+_; ring
  · change F.endpointTheta _ _=F.endpointTheta _ _+↑n*0
    unfold JacobiFull.endpointTheta JacobiFull.rotationAngle
    rw [hp,sc]; simp [v]

theorem drift_length (σ : ℝ) (hs : σ^2=1) {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) :
    Real.sqrt ((drift σ z 0)^2+(drift σ z 1)^2)=length (z 1) := by
  have hl : 0<length (z 1) := by
    unfold length E
    rw [← full_E (z 1) h.1 h.2]
    exact mul_pos (by norm_num) (sub_pos.mpr (full (z 1) h.1 h.2).E_lt_K)
  have eq : (drift σ z 0)^2+(drift σ z 1)^2=(length (z 1))^2 := by
    simp [drift,mul_pow,hs,← mul_add,(Real.sin_sq_add_cos_sq _)]
  rw [eq,Real.sqrt_sq hl.le]

end JacobiConcrete.Floquet

namespace JacobiConcrete.Floquet
open AmplitudeChart
private abbrev basis (i : Fin 3) : V3 := Pi.single i 1

private theorem line_deriv (z : V3) (i : Fin 3) :
    HasDerivAt (fun r : ℝ => z+r • basis i) (basis i) 0 := by
  simpa using (((hasDerivAt_id' (0:ℝ)).smul_const (basis i)).const_add z)

theorem direction_deriv {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) :
    fderiv ℝ initialAngle z (basis 0)=(z 1)*(full _ h.1 h.2).c (z 0) := by
  have hd := (angle_diff h).hasFDerivAt.comp_hasDerivAt_of_eq 0 (line_deriv z 0) (by simp)
  have heq (r : ℝ) : initialAngle (z+r • basis 0)=(full _ h.1 h.2).rotationAngle (z 0+r) := by
    rw [angle_eq (by simpa [basis] using h)]
    simp [basis]
  exact (hd.congr_of_eventuallyEq (Eventually.of_forall fun r => (heq r).symm)).unique
    (by simpa only [Function.comp_def,mul_one] using! ((full _ h.1 h.2).hasDerivAt_rotationAngle (z 0)).comp_of_eq 0 ((hasDerivAt_id' (0:ℝ)).const_add (z 0)) (by simp))

private theorem angle_time {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) :
    fderiv ℝ initialAngle z (basis 2)=0 := by
  have hd := (angle_diff h).hasFDerivAt.comp_hasDerivAt_of_eq 0 (line_deriv z 2) (by simp)
  apply (hd.congr_of_eventuallyEq (f₁ := fun _ => (full _ h.1 h.2).rotationAngle (z 0)) _).unique (hasDerivAt_const ..)
  exact Eventually.of_forall fun r => by change _ = initialAngle (z+r • basis 2); rw [angle_eq (by simpa [basis] using h)]; simp [basis]

private theorem heading_time (σ : ℝ) {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) :
    jacobian (path σ) z 2 2 = -(full _ h.1 h.2).c ((full _ h.1 h.2).terminalPhase (z 0) (z 2)) := by
  let J := full _ h.1 h.2
  have hd := ((coord 2).hasFDerivAt.comp z (path_diff σ h).hasFDerivAt)
  have hh := hd.comp_hasDerivAt_of_eq 0 (line_deriv z 2) (by simp)
  have heq : (fun r => J.endpointTheta (z 0) (z 2+r)) =ᶠ[𝓝 0] (fun r => (path σ (z+r • basis 2)) 2) := by
    apply Eventually.of_forall
    intro r
    change _ = (path σ (z+r • basis 2)) 2
    rw [path_eq σ (by simpa [basis] using h)]
    simp [basis,J]
  exact (hh.congr_of_eventuallyEq heq).unique
    (by simpa only [Function.comp_def,mul_one] using! (J.hasDerivAt_endpointTheta (z 0) (z 2)).comp_of_eq 0 ((hasDerivAt_id' (0:ℝ)).const_add (z 2)) (by simp))

private def driftLinear (σ : ℝ) (z : V3) : V3 →L[ℝ] V3 :=
  let a := initialAngle z
  let da := fderiv ℝ initialAngle z
  let dl := deriv length (z 1) • coord 1
  ContinuousLinearMap.pi ![(σ*Real.sin a) • dl + (σ*length (z 1)*Real.cos a) • da,
    (-σ*Real.cos a) • dl + (σ*length (z 1)*Real.sin a) • da,0]

private theorem drift_deriv (σ : ℝ) {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) :
    HasFDerivAt (drift σ) (driftLinear σ z) z := by
  have ha := (angle_diff h).hasFDerivAt
  have hl := (length_derivative h).1.differentiableAt.hasDerivAt.comp_hasFDerivAt z
    (hasFDerivAt_apply (𝕜 := ℝ) 1 z)
  apply hasFDerivAt_pi.mpr
  intro i; fin_cases i
  · apply (((hl.const_mul σ).mul ha.sin)).congr_fderiv
    ext v; simp [coord]; ring
  · apply (((hl.const_mul (-σ)).mul ha.cos)).congr_fderiv
    ext v; simp [coord]; ring
  · exact hasFDerivAt_const ..

private abbrev col (M : Matrix (Fin 3) (Fin 3) ℝ) (i : Fin 3) : V3 := fun j => M j i
private def triple (a b c : V3) := (Matrix.of ![a,b,c]).det

def mixed (σ : ℝ) (z : V3) :=
  let M := jacobian (path σ) z
  let B := jacobian (drift σ) z
  triple (col B 0) (col M 1) (col M 2) + triple (col M 0) (col B 1) (col M 2)

theorem drift_area (σ : ℝ) (hs : σ^2=1) {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) :
    let B := jacobian (drift σ) z
    B 0 0*B 1 1-B 1 0*B 0 1 =
      -(z 1)*length (z 1)*deriv length (z 1)*(full _ h.1 h.2).c (z 0) := by
  dsimp only
  simp only [jacobian,(drift_deriv σ h).fderiv,driftLinear,ContinuousLinearMap.pi_apply,
    Matrix.cons_val_zero,Matrix.cons_val_one,add_apply,smul_apply,
    coord,ContinuousLinearMap.proj_apply,smul_eq_mul]
  simp only [Pi.single_eq_same,Pi.single_eq_of_ne (by decide : (1:Fin 3)≠0)]
  rw [direction_deriv (z := z) h]
  linear_combination (norm := ring) -(z 1)*length (z 1)*deriv length (z 1)*(full _ h.1 h.2).c (z 0)*
    (σ^2*(Real.sin_sq_add_cos_sq (initialAngle z))+hs)

private theorem shift_det (n : ℕ) {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) :
    DifferentiableAt ℝ (shifted n) z ∧ (jacobian (shifted n) z).det=1 := by
  have hp := (((hasDerivAt_id' (z 1)).mul (hasDerivAt_K _ h.1 h.2)).const_mul 4).const_mul (n:ℝ)
  have hd := (hasFDerivAt_id (𝕜 := ℝ) z).add ((hp.comp_hasFDerivAt z (hasFDerivAt_apply (𝕜 := ℝ) 1 z)).smul_const (basis 2))
  change HasFDerivAt (𝕜 := ℝ) (shifted n) _ z at hd
  refine ⟨hd.differentiableAt,?_⟩
  simp [jacobian,hd.fderiv,Matrix.det_fin_three,basis]

/-- The determinant in phase, modulus, time order. Rotating the two spatial
rows to body coordinates preserves all three determinants in this identity. -/
theorem geometric_polynomial (σ : ℝ) (hs : σ^2=1) {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) (n : ℕ) :
    let F := full _ h.1 h.2
    (jacobian (path σ) (shifted n z)).det =
      (n:ℝ)^2 * (-F.c (F.terminalPhase (z 0) (z 2))) *
      (-(z 1)*length (z 1)*deriv length (z 1)*F.c (z 0)) +
      n*mixed σ z + (jacobian (path σ) z).det := by
  obtain ⟨ds,det1⟩ := shift_det n h
  have dc := (path_diff σ (z := shifted n z) (by simpa using h)).hasFDerivAt.comp z ds.hasFDerivAt
  have dp := (path_diff σ h).hasFDerivAt.add ((drift_deriv σ h).const_smul (n:ℝ))
  have heq : (path σ ∘ shifted n) =ᶠ[𝓝 z] (fun w => path σ w+(n:ℝ) • drift σ w) := by
    filter_upwards [((coord 1).continuous.continuousAt (x := z)).eventually_mem (Ioo_mem_nhds h.1 h.2)] with w hw
    exact period_translation σ hw n
  have eq := (dc.congr_of_eventuallyEq heq.symm).unique dp
  have mat := congrArg linearMatrix eq
  rw [linearMatrix_comp,← jacobian_eq_linearMatrix,← jacobian_eq_linearMatrix] at mat
  let M := jacobian (path σ) z
  let B := jacobian (drift σ) z
  have add : jacobian (path σ) (shifted n z) * jacobian (shifted n) z=M+(n:ℝ) • B := by
    rw [mat]; ext i j; simp [linearMatrix,M,B,jacobian,(drift_deriv σ h).fderiv]
  have det := congrArg Matrix.det add
  rw [Matrix.det_mul,det1,mul_one] at det
  have b2 (j : Fin 3) : B 2 j=0 := by simp [B,jacobian,(drift_deriv σ h).fderiv,driftLinear]
  have bt (i : Fin 3) : B i 2=0 := by
    have at0 : fderiv ℝ initialAngle z (Pi.single 2 1)=0 := angle_time h
    fin_cases i <;> simp [B,jacobian,(drift_deriv σ h).fderiv,driftLinear,coord,at0]
  dsimp only
  rw [det,← heading_time σ h,← drift_area σ hs h]
  change (M+(n:ℝ) • B).det = _*M 2 2*(B 0 0*B 1 1-B 1 0*B 0 1)+n*
    (triple (col B 0) (col M 1) (col M 2)+triple (col M 0) (col B 1) (col M 2))+M.det
  simp [triple,Matrix.det_fin_three,col,b2,bt]; ring

theorem leading_zero_iff {z : V3} (h : z 1 ∈ Ioo (0:ℝ) 1) :
    let F := full _ h.1 h.2
    (-F.c (F.terminalPhase (z 0) (z 2)))*(-(z 1)*length (z 1)*deriv length (z 1)*F.c (z 0))=0 ↔
    F.c (F.terminalPhase (z 0) (z 2))=0 ∨ ∃ j : ℤ, z 0=F.K+2*F.K*j := by
  let F := full _ h.1 h.2
  have hl : 0<length (z 1) := by
    unfold length E; rw [← full_E _ h.1 h.2]; exact mul_pos (by norm_num) (sub_pos.mpr F.E_lt_K)
  simp only [mul_eq_zero,neg_eq_zero,h.1.ne',hl.ne',(length_derivative h).2.ne',false_or]
  have iff : F.c (z 0)=0 ↔ ∃ j : ℤ, z 0=F.K+2*F.K*j := by
    have ht := F.J2_even_eq_zero_iff (n := 1) (by decide) (z 0)
    have hb := F.toJacobiPeriodic.β1_even 1
    have hf := F.toJacobiPeriodic.f1_even 1
    have he := F.E_pos
    have hd := F.E_lt_K.ne
    unfold JacobiFull.J2 JacobiData.α JacobiData.β at ht
    rw [F.s_even,hb,hf] at ht
    simpa [he.ne',sub_ne_zero.mpr hd] using ht
  exact or_congr_right iff

/-- Left trivialization rotates the spatial velocities by the negative
terminal heading. This applies equally to the two mixed determinants. -/
def bodyFrame (θ : ℝ) : Matrix (Fin 3) (Fin 3) ℝ :=
  !![Real.cos θ, Real.sin θ, 0; -Real.sin θ, Real.cos θ, 0; 0, 0, 1]

theorem body_determinant (θ : ℝ) (M : Matrix (Fin 3) (Fin 3) ℝ) :
    (bodyFrame θ * M).det=M.det := by
  have hb : (bodyFrame θ).det=1 := by
    simp [bodyFrame,Matrix.det_fin_three]
    nlinarith [Real.sin_sq_add_cos_sq θ]
  rw [Matrix.det_mul,hb,one_mul]

end JacobiConcrete.Floquet
