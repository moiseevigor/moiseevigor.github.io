# The Floquet determinant and limiting curves on SE(2)

FloquetGeometry proves the determinant coefficients and their geometric interpretation. FloquetProfile proves both compact-uniform profile estimates, convergence of the real branches, and the inverse-index rate on regular offsets.

Use the toolchain and dependency revisions supplied in this archive. From its root run

    lake exe cache get
    lake build
    lake env lean Audit.lean

Compare the final output with axioms.txt. SHA256SUMS identifies every input. The 108 declarations include the witnesses for the whole-paper claim ledger.
