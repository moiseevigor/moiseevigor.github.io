# Ordinary cell endpoints on SE(2)

CellEndpointOrder proves the simple-zero conditions for the two outer endpoints at every modulus and both distinct inner endpoints. It applies Lemma 3.3 and proves a nonzero ordinary derivative of the reduced Jacobian at each matching phase. The shared critical inner endpoint is covered separately by the quartic limit.

Use the toolchain and dependency revisions supplied in this archive. From its root run

    lake exe cache get
    lake build
    lake env lean Audit.lean

Compare the final output with axioms.txt. SHA256SUMS identifies every input. The 85 declarations include the witnesses for the whole-paper claim ledger.
