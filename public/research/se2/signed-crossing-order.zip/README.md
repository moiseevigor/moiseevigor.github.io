# Signed crossing orders on SE(2)

CrossingData.analytic_signed_order proves that a general analytic tangent phase has odd order at least three. SBracket.signed_tangency selects the branch. SBracket.scalar_crossing_order and SBracket.determinant_crossing_order give exact first or third order on the open rotating brackets. The formal order is a two-sided limit of the quotient by the corresponding power, with a nonzero limit.

Use the toolchain and dependency revisions supplied in this archive. From its root run

    lake exe cache get
    lake build
    lake env lean Audit.lean

Compare the final output with axioms.txt. SHA256SUMS identifies every input. The 73 declarations include the witnesses for the whole-paper claim ledger.
