# Rotating SE(2) coefficient sign chart

JacobiCore.SignChart.alpha_simple proves the exact nonzero derivative of the indexed alpha endpoint. alpha_signs and beta_signs give the signs on each side, alpha_center_value gives the exact center value, and modulus_placement treats both sides of the critical modulus and equality. Audit.lean covers all witnesses in the updated whole-paper ledger.

Use the toolchain and dependency revisions supplied in this archive. From its root run

    lake exe cache get
    lake build
    lake env lean Audit.lean

Compare the final output with axioms.txt. SHA256SUMS identifies every input. The 57 declarations include the witnesses for the whole-paper claim ledger.
